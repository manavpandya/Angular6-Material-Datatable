import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { translate, Trans } from 'react-i18next';


class App extends Component {
  render() {
    const { t, i18n } = this.props;
  

    const changeLanguage = (lng) => {
      i18n.changeLanguage(lng);
      console.log(i18n);
    };

    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
          <button onClick={() => changeLanguage('es')}>Spanish</button>
          <button onClick={() => changeLanguage('en')}>English</button>
        </header>
        <p className="App-intro">
        <Trans>This is simple paragraph to test translation feature</Trans>
        </p>
      </div>
    );
  }
}

export default translate('translations')(App);
