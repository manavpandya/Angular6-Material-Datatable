import { combineReducers, createStore, applyMiddleware } from 'redux';
import { localeReducer } from "../dist/index";
import { cssLazyLoader } from "../dist/lazyLoader";

export const store = createStore(combineReducers({
		locale: localeReducer("en", require("../locales/index").default)
	}),
	applyMiddleware(
		cssLazyLoader(["LOCALE_CHANGED"], {
			"en": {address: "en.css", direction: "ltr"},
			"es": {address: "es.css", direction: "rtl"}
		}),
	)
);