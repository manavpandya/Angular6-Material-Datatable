import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import { translatable } from "react-multilingual";


const rootReducer = combineReducers({
    trans : translatable
});

export default rootReducer;
