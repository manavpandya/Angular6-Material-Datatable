export default {
	hello : "hello"
};