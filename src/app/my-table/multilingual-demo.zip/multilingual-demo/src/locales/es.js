export default {
	hello : "hello123"
};