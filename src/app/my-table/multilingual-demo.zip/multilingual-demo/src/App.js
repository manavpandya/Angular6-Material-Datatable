import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { translatable } from "react-multilingual";

class App extends Component {
  render() {

    let { hello, changeLocale } = this.props;
    console.log(this.props);
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <div>
            <button onClick={() => changeLocale("en")}>en</button>
            <button onClick={() => changeLocale("fa")}>fa</button>
            <p>
                {/* {hello} */}
            </p>
        </div>
      </div>
    );
  }
}

const mapTranslationsToProps = ({hello}) => ({hello});
export default translatable(mapTranslationsToProps)(App);
// export default App;
