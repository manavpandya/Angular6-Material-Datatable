const CANDIDATE_API_URL = process.env.API_URL || "https://candidates-erg-staging.talentxapp.com/api/";
const BASE_URL = process.env.NODE_ENV === 'development' ? CANDIDATE_API_URL : `${window.location.protocol}//${window.location.host}/api/`;
export const { NODE_ENV } = process.env;
export default BASE_URL;
