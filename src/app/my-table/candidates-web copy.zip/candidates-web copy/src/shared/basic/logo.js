import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';

class Logo extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }
  render() {
    const { dark , size} = this.props;
    return (
      <Fragment>
        { !dark && <img style={{ height: `${size}rem` }} src="/logo.png" alt="logo" /> }
        { dark && <img style={{ height: `${size}rem` }} src="/logo-dark.svg" alt="logo" /> }
      </Fragment>
    );
  }
}

Logo.propTypes = {
  dark: PropTypes.bool,
  size : PropTypes.number,
};

Logo.defaultProps = {
  dark: true,
  size : 3,
};

export default Logo;
