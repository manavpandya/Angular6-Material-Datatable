import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Select } from 'redux-form-material-ui';
import { InputLabel } from 'material-ui/Input';
import { FormControl } from 'material-ui/Form';

const getColor = (touched, error, isFocused) => {
  if (touched && error) {
    return '#f44336';
  }
  return isFocused ? '#17375C' : '#a4a4a4';
};

class RegularSelect extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectFocused: false,
    };
    this.setSelectFocused = this.setSelectFocused.bind(this);
  }

  setSelectFocused(isFocused) {
    this.setState({
      selectFocused: isFocused,
    });
  }

  render() {
    const { meta, label, children } = this.props;
    const { error, touched } = meta;
    return (
      <FormControl className={this.props.className}>
        <InputLabel
          htmlFor={this.props.id}
          style={{
            color: getColor(touched, error, this.state.selectFocused),
          }}
        >
          {label}
        </InputLabel>
        <Select
          {...this.props}
          id={this.props.id}
          className="reg-select"
          inputProps={{
            className: 'helloMe',
            onFocus: () => this.setSelectFocused(true),
            onBlur: () => this.setSelectFocused(false),
          }}
        >
          {children}
        </Select>
        {
          touched && error &&
          <p className="error">{error}</p>
        }
      </FormControl>
    );
  }
}

RegularSelect.propTypes = {
  meta: PropTypes.object.isRequired, // eslint-disable-line
  label: PropTypes.string,
  children: PropTypes.arrayOf(PropTypes.element).isRequired,
  id: PropTypes.string.isRequired,
  className: PropTypes.string,
};

RegularSelect.defaultProps = {
  label: '',
  className: '',
};

export default RegularSelect;
