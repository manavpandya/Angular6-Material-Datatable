import React from 'react';
import Select from 'react-select';
import PropTypes from 'prop-types';
import 'react-select/dist/react-select.css';

import BASE_URL from '../../constants';

const SelectType = (type, props, asyncProps) => {
  const { getOptions, options } = props;
  switch (type) {
    case 'Async':
      return (
        <Select.Async
          {...props}
          {...asyncProps}
          loadOptions={getOptions.bind(null, `${BASE_URL}terms/search?search_type=leaf_only&skill=`)} // eslint-disable-line
        />
      );
    case 'AsyncCreatable':
      return (
        <Select.AsyncCreatable
          {...props}
          {...asyncProps}
          loadOptions={getOptions.bind(null, `${BASE_URL}terms/search?search_type=leaf_only&skill=`)} // eslint-disable-line
        />
      );
    case 'Creatable':
      return (
        <Select.Creatable
          {...props}
          {...asyncProps}
        />
      );
    default:
      return (
        <Select
          {...props}
          {...asyncProps}
          options={options}
        />
      );
  }
};

SelectType.propTypes = {
  options: PropTypes.arrayOf(PropTypes.object),
  getOptions: PropTypes.func,
};

SelectType.defaultProps = {
  options: [],
  getOptions: () => { },
};

const MultiSelect = (props) => {
  const {
    type,
    input,
    meta,
  } = props;
  const { error, touched } = meta;
  const asyncProps = {
    multi: true,
    valueKey: props.valueKey,
    labelKey: props.labelKey,
    value: input.value && input.value.length > 0 // eslint-disable-line
      ? typeof input.value[0] === 'string'
        ? input.value.map(val => ({ value: val }))
        : input.value
      : [],
    onBlurResetsInput: false,
    onBlur: () => input.onBlur(input.value),
    onChange: (values) => {
      if (input.onChange && values) {
        input.onChange(values);
      } else {
        input.onChange(null);
      }
      return values;
    },
  };
  return (
    <div>
      <div className={`select-wrapper ${touched && error ? 'select-wrapper-error' : ''}`}>
        {SelectType(type, props, asyncProps)}
      </div>
      {
        touched && error &&
        <p className="error">{error}</p>
      }
    </div>
  );
};

MultiSelect.propTypes = {
  input: PropTypes.object.isRequired, // eslint-disable-line
  meta: PropTypes.object.isRequired, // eslint-disable-line
  type: PropTypes.oneOf(['Async', 'AsyncCreatable', 'Creatable', '']),
  valueKey: PropTypes.string,
  labelKey: PropTypes.labelKey,
};

MultiSelect.defaultProps = {
  type: '',
  valueKey: 'value',
  labelKey: 'value',
};

export default MultiSelect;
