import React from 'react';
import VisibilitySensor from 'react-visibility-sensor';
import PropTypes from 'prop-types';

const InfiniteScroll = ({ onReachedBottom }) =>
  <VisibilitySensor partialVisibility onChange={isVisible => isVisible && onReachedBottom()} />;

InfiniteScroll.propTypes = {
  onReachedBottom: PropTypes.func.isRequired,
};

export default InfiniteScroll;
