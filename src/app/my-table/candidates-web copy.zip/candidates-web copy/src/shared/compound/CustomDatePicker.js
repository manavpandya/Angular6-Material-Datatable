import React from 'react';
import PropTypes from 'prop-types';
import { DatePicker } from 'material-ui-pickers';
import { MuiThemeProvider, createMuiTheme } from 'material-ui';
import moment from 'moment';

const materialTheme = createMuiTheme({
  overrides: {
    MuiDialog: {
      root: {
        pointerEvents: 'all'
      },
    },
  },
});

const CustomDatePicker = (props) => {
  const { input, label, meta } = props;
  const { error } = meta;
  return (
    <MuiThemeProvider theme={materialTheme}>
      <div className="search-datepicker picker">
        <DatePicker
          onChange={(event) => {
            if (input.onChange && event != null) {
              input.onChange(moment(event.toDate()).format('YYYY-MM-DD'));
            } else {
              input.onChange(null);
            }
          }}
          {...props}
          error={error ? true : false} // eslint-disable-line
          keyboard
          clearable
          label={label}
          format="YYYY-MM-DD"
          invalidLabel=" "
          value={input.value ? input.value : ''}
          disableFuture="true"
        />
        {
          error &&
          <p className="error">{error}</p>
        }
      </div>
    </MuiThemeProvider>
  );
};


CustomDatePicker.propTypes = {
  meta: PropTypes.object, // eslint-disable-line
  input: PropTypes.objectOf(PropTypes.string),
  label: PropTypes.string.isRequired,
};


CustomDatePicker.defaultProps = {
  meta: {},
  input: {},
};

export default CustomDatePicker;
