import React , { Component } from 'react';
import { PropTypes } from 'prop-types';
import LanguageIcon from 'material-ui-icons/Language';
import { MenuList, MenuItem } from 'material-ui/Menu';
import Menu from './menu';
import { IntlActions } from 'react-redux-multilingual';

class LanguageOptions extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  
  render() {
    return (
      <div className="candidate-actions">
      <Menu
        iconPrefix={<LanguageIcon className="more-vert" style={{ color: this.props.color }} />}
        popup={
          <MenuList role="menu">
            {
               this.props.languages.map(language => (
                  <MenuItem
                  key={language.label}
                  className="menu-item"
                  onClick={() => {
                    this.props.dispatch(IntlActions.setLocale(language.locale));
                    localStorage.setItem('language', language.locale);
                  }}
                  >
                  {language.label}
                  </MenuItem>
              ))
            }
          </MenuList>
        }
      />
    </div>
    );
  }
}

LanguageOptions.propTypes = {
  languages: PropTypes.arrayOf(PropTypes.object),
  color: PropTypes.string,
};

LanguageOptions.defaultProps = {
  languages: [],
  color: '#333333',
};

export default LanguageOptions;
