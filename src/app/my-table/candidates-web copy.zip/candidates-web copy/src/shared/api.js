import axios from 'axios';
import BASE_URL from "./../constants";

function makeHeaders() {
  let headerObj = {};

  if (JSON.parse(localStorage.getItem('user_info')) != null) {
    const token = `Bearer ${JSON.parse(localStorage.getItem('user_info'))}`;
    headerObj = {
      Authorization: token,
    };
  }
  return headerObj;
}

export default () => axios.create({
  withCredentials: true,
  baseURL: `${BASE_URL}/`,
  headers: makeHeaders(),
});
