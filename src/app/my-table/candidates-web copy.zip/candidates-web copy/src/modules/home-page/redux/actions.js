import api from '../../../shared/api';
import * as ActionTypes from './actionTypes';

export function getSearchedJobs(type,key,location,startDate,pageNo=1,perPage=10) {
  return {
    type: ActionTypes.GET_SEARCHED_JOBS,
    payload: api().get(`account/job_position/search?${type ? 'employmenttype=' + type + '&' : ''}${key ? 'key=' + key + '&' : ''}${location ? 'location=' + location + '&' : ''}${startDate ? 'start=' + startDate + '&' : ''}${pageNo ? 'page=' + pageNo + '&' : 'page=1&'}${perPage ? 'per_page=' + perPage : 'per_page=10'}`).then(res => ({
      ...res.data,
      perPage,
    })),
  };
}

export function flushSearchedJobs() {
  return {
    type: ActionTypes.FLUSH_SEARCHED_JOBS,
    payload: null,
  }
}

export function createNewJob(data) {
  return {
    type: ActionTypes.CREATE_NEWJOB,
    payload: api().post('job_position/create', data),
  };
}

export function updateJob(id, data) {
  return {
    type: ActionTypes.UPDATE_JOB,
    payload: api().put(`job_position/${id}`, data),
  };
}

export function bookmarkJob(jobData) {
  return {
    type: ActionTypes.BOOKMARK_JOB_POSITION,
    meta: {
      id: jobData.entity_id,
    },
    payload: api().post('bookmarks', jobData).then(res => ({
      ...res.data,
      id: jobData.entity_id,
    })),
  };
}

export function unBookmarkJob(jobData) {
  return {
    type: ActionTypes.UNBOOKMARK_JOB_POSITION,
    meta: {
      id: jobData.entity_id,
    },
    payload: api().delete( 'bookmarks', { data : jobData } ).then(res => ({
      ...res.data,
      id: jobData.entity_id,
    })),
  };
}

export function applyJob(jobPositionId,jobData) {
  return {
    type: ActionTypes.APPLY_JOB_POSITION,
    meta: {
      id: jobPositionId,
    },
    payload: api().post(`account/${jobPositionId}/applications`, jobData).then(res => ({
      ...res.data,
      id: jobPositionId,
    })),
  };
}

export function getJobsMatchingTitleOfProfile(profile_id, pageNo = 1, pageSize = 10) {
  return {
    type: ActionTypes.GET_JOBS_MATCHING_TITLE_OF_PROFILE,
    payload: api().get(`/profile/${profile_id}/job_position/matches/title?page=${pageNo}&per_page=${pageSize}`).then(res => ({
      ...res.data,
      pageSize: pageSize,
    })),
  }
}

export function flushJobsMatchingSkillsOfProfile() {
  return {
    type: ActionTypes.FLUSH_JOBS_MATCHING_SKILLS_OF_PROFILE,
    payload: null,
  }
}

export function getJobsMatchingSkillsOfProfile(profile_id, pageNo = 1, pageSize = 10) {
  return {
    type: ActionTypes.GET_JOBS_MATCHING_SKILLS_OF_PROFILE,
    payload: api().get(`/profile/${profile_id}/job_position/matches/important_skills?page=${pageNo}&per_page=${pageSize}`).then(res => ({
      ...res.data,
      pageSize: pageSize,
    })),
  }
}

export function getOptions(url, input){
  const token = `Bearer ${JSON.parse(localStorage.getItem('user_info'))}`;
  if (!input) {
    return Promise.resolve({ options: [] });
  }
  return fetch(url + input, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': token,
    },

  }).then(response => response.json())
    .then(json => ({ options: json.terms }));
};