import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';

class NavLinks extends Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }
  render() {
    const {
      linkTo, imgSrc,
    } = this.props;
    return (
      <NavLink exact to={linkTo} onClick={this.props.onClick}>
        <img className="icon" src={imgSrc} alt="applications" />
      </NavLink>
    );
  }
}

NavLinks.propTypes = {
  linkTo: PropTypes.string,
  imgSrc: PropTypes.string,
};

NavLinks.defaultProps = {
  linkTo: '',
  imgSrc: '',
};

export default NavLinks;
