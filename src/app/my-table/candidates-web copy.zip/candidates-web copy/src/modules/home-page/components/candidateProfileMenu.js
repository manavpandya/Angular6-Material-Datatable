import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';
import Avatar from '../../home-page/components/avatar';
import Menu from '../../../shared/compound/menu';
import {
    logoutFunction,
    } from '../../auth/redux/actions';
import candidateProfileImage from '../../../assets/images/candidate-profile.png';

class CandidateProfileMenu extends Component {
  render() {
    const username = (this.props ? this.props.userName : '');
    const email = (this.props ? this.props.email : '');
    return (
      <div title={`${username} \n${email}`}>
        { username?
            <Menu
            ref="menu"
            label={ <Fragment> <Avatar avatar={candidateProfileImage} size="1"  alt={`${username} \n${email}`} /> &nbsp;<h4 className="normal-fonts">{`${username} `}</h4></Fragment> }
            popup={
              <ul className="profile-menu">
                <li>
                    <NavLink  to="/candidate/profile">
                      My Profile
                    </NavLink>
                </li>
                <li>
                  <NavLink to="/logout">
                    Logout
                  </NavLink>
                </li>
              </ul>
            }
          >
          </Menu> : ''
        }
      </div>
    )
  }
};

CandidateProfileMenu.propTypes = {
    logoutFunction: PropTypes.func,
    email: PropTypes.string,
    userName: PropTypes.string,
  };

  CandidateProfileMenu.defaultProps = {
    logoutFunction: () => {},
    email: '',
    userName: '',
  };

  const mapDispatchToProps = dispatch => ({
    logoutFunction: () => dispatch(logoutFunction()),
    dispatch,
  });

export default connect(null, mapDispatchToProps)(CandidateProfileMenu);

