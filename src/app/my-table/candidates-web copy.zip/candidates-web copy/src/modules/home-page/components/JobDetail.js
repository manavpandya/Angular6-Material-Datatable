import React, { Component } from 'react'
import PropTypes from 'prop-types';
// import Tooltip from 'material-ui/Tooltip';
import Tooltip from '@material-ui/core/Tooltip';
import Dialog, {
    DialogContent,
    DialogActions
  } from 'material-ui/Dialog'
import Button from 'material-ui/Button';

class JobDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }

  render() {
    const { open , handleClose, userProfileId , id, jobTitle, location, jobDescription, jobStartDate, allowToApply, isApplied, applysJob, isBookmarked, bookmarksJob, unBookmarksJob } = this.props;
    return (
        <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="md"
        className="job-detail-dialog"
        style={{ pointerEvents: 'all'}}>
            <DialogContent className="candidate-profile">
                    <div className="id">
                        <div className="details">
                            <h1>{jobTitle}</h1>
                            <h3>{location}</h3>
                        </div>
                        <div style={{alignItems: 'flex-end'}} className="actions">
                            {
                                allowToApply
                                ? isApplied
                                    ? <span className="icon applied job-apply-btn top-applied disabled">Applied</span>
                                    : <span onClick={(event) => applysJob(event, id,userProfileId)} className="icon applied top-applied job-apply-btn">Apply</span>
                                : false
                            }
                            {
                                isBookmarked
                                ? 
                                    <Tooltip id="tooltip-fab" title="Unbookmark">
                                        <img  onClick={(event) => unBookmarksJob(event, id)} className="icon bookmark" src="/icons/bookmarked.svg" alt="unbookmarked" />
                                    </Tooltip>
                                : 
                                    <Tooltip id="tooltip-fab" title="Bookmark">              
                                        <img style={{minWidth: '22px'}} onClick={(event) => bookmarksJob(event, id)} className="icon bookmark" src="/icons/bookmark.svg" alt="bookmarked" />
                                    </Tooltip>
                            }
                        </div>
                    </div>
                    <div className="job-desc">
                        {jobDescription}
                    </div>
            </DialogContent>
            <DialogActions style={{ justifyContent: 'space-between' }}>
                <h6 className="posted">Posted: {jobStartDate}</h6>
                <Button onClick={handleClose}>Close</Button>
          </DialogActions>
        </Dialog>
    )
  }
}

JobDetail.propTypes = {
  id: PropTypes.string,
  jobTitle: PropTypes.string,
  location: PropTypes.string,
  jobDescription: PropTypes.string,
  jobStartDate: PropTypes.string,
  allowToApply: PropTypes.bool,
  isApplied: PropTypes.bool,
  applysJob: PropTypes.func,
  isBookmarked: PropTypes.bool,
  bookmarksJob: PropTypes.func,
  unBookmarksJob: PropTypes.func,
};

JobDetail.defaultProps = {
  id: '',
  jobTitle: '',
  location: '',
  jobDescription: '',
  jobStartDate: '',
  allowToApply: false,
  isApplied: false,
  applysJob: () => {},
  isBookmarked: false,
  bookmarksJob: () => {},
  unBookmarksJob: () => {},
};

export default JobDetail
