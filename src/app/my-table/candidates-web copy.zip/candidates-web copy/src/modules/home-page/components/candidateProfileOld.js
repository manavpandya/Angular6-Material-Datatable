import React, { Component , Fragment } from 'react';
import { Form, Field, reduxForm } from 'redux-form';
import PropTypes from 'prop-types';
import { Button } from 'material-ui';
import AddIcon from 'material-ui-icons/Add';
import TogglePanel from '../../candidate/fields/TogglePanel';
import Languages from '../../candidate/fields/Languages';
import LanguagesReadOnly from '../../candidate/fields/LanguagesReadOnly';
import Navigation from './navigation';
import profile from '../../candidate/data/profile';

class CandidatesProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  componentDidMount () {
    this.setState({ profile: profile })
  }

  render() {
    let { profile } = this.state;

    return (
        <Fragment>
        <div className="page candidate">
        <header>
            <div className="container">
                <Navigation 
                logout={this.props.logout}
                changeLanguages={this.changeLanguages}/>
            </div>
        </header>
        {
        profile &&
        <main className="profile">
            <div className="container">
            <h1>&nbsp;</h1>
            <h3>Personal Information</h3>
            <h3>Skills</h3>
            <TogglePanel
                title="Skills"
                />
            <h3>License &amp; Certifications</h3>
            <TogglePanel
                title="Licenses"
                read={ <div><Button><AddIcon />Add</Button></div> }
            />
            <TogglePanel
                title="Certificates"
                read={ <div><Button><AddIcon />Add</Button></div> }
            />
            <h3>Languages Known</h3>
            <TogglePanel
                title="Languages"
                read={ <LanguagesReadOnly value={ profile.language } /> }
                edit={ <Languages value={ profile.language } /> }
            />
            </div>
        </main>
        }
        </div>
      </Fragment>
    );
  }
}

CandidatesProfile.propTypes = {
  handleSubmit: PropTypes.func,
  initialValues: PropTypes.object, // eslint-disable-line
  selectedSkills: PropTypes.object,// eslint-disable-line
  history: PropTypes.object, // eslint-disable-line
  addNewSkill: PropTypes.func,
  getRequiredSkills: PropTypes.func,
  addGreatestSkill: PropTypes.func,
  deleteGreatestSkill: PropTypes.func,
  logout: PropTypes.func,
};

CandidatesProfile.defaultProps = {
  handleSubmit: () => {},
  addNewSkill: () => { },
  initialValues: {},
  selectedSkills: {},
  history: {},
  getRequiredSkills:() => { },
  addGreatestSkill: () => { },
  deleteGreatestSkill:() => { },
  logout: () => {},  
};

const CandidateProfile = reduxForm({
  form: 'NewJobForm', // a unique identifier for this form
  enableReinitialize: true
})(CandidatesProfile);

export default CandidateProfile;
