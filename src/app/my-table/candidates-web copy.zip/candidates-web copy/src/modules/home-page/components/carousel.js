import React, { Component } from 'react';
import PropTypes from 'prop-types';
import BlockUI from 'react-block-ui';
import { withTranslate } from 'react-redux-multilingual';
import JobDetail from '../components/JobDetail';
import Slider from '../components/slider';
import JobSummary from '../components/jobSummary';
import { showNotification } from '../../../utils/Notifications';

class Carousel extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.error !== nextProps.error) {
      showNotification(nextProps.error.message, 'error', 8000);
    }
  }

  selectJob = (job) => {
    this.setState({ selected: job , open: true })
  }

  handleClose = () => {
    this.setState({open: false});
  };

  render() {
    const selectedJob = this.state && this.state.selected; 
    return (
      <BlockUI tag="div" className="matching-jobs-loader" blocking={this.props.loading}>
        <main className="top-matches">
          <div className="container">
            <br />
            <h1>
              <span>{this.props.title}</span> {this.props.totalCount ? `(${this.props.totalCount})` : ""}
            </h1>
            <section className="jobs">
              {
                !((this.props.jobs && this.props.jobs.length > 0) || this.props.loading)
                  ? (
                    <div className="no-profiles">
                      <p>
                        {this.props.translate(this.props.emptyResultMessage)}
                      </p>
                    </div>
                  )
                  : ( 
                    <Slider slides={
                      [
                        ...this.props.jobs.map(job => (
                          <a className="carousel-jobdetail" key={job.id} onClick={() => this.selectJob(job)}>
                            <JobSummary
                              id={job.id}
                              jobTitle={job.job_description.job_title}
                              jobLocation={job.location.country || `${"No Location Found"}`}
                              jobRegion={job.location.region}
                              jobDescription={
                                job.job_description.description
                                ? job.job_description.description
                                : job.job_description.employer
                                  ? job.job_description.employer
                                  : 'No description available'
                              }
                              isApplied={job.is_applied}
                              isBookmarked={job.is_bookmarked}
                              startDate={job.job_description.job_start_date}
                              job={job}
                              bookmarksJob={this.props.bookmarksJob}
                              unBookmarksJob={this.props.unBookmarksJob}
                              applysJob={this.props.applysJob}
                              jobBookmarkedLoading={this.props.jobBookmarkedLoading}
                              jobBookmarkedError={this.props.jobBookmarkedError}
                              jobAppliedLoading={this.props.jobAppliedLoading}
                              jobAppliedError={this.props.jobAppliedError}
                              activeJobId={this.props.activeJobId}
                            />
                          </a>
                        )),
                        this.props.showLoadMore
                        && <div key="" className="job-ad-summary see-all" onClick={() => this.props.getNextPage()}>
                            <h3>See more</h3>
                          </div>
                      ]
                    } />
                  )
                }
            </section>
            <div>
            {
                this.state && this.state.selected &&
                  <JobDetail
                    allowToApply={true}
                    open={this.state ? this.state.open : false}
                    id={selectedJob && selectedJob.id}
                    jobTitle={selectedJob && selectedJob.job_description && selectedJob.job_description.job_title}
                    location={selectedJob && selectedJob.location && (selectedJob.location.country || `${"No Location Found"}`)}
                    jobDescription={
                      selectedJob && selectedJob.job_description && selectedJob.job_description.description
                      ? selectedJob.job_description.description
                      : selectedJob.job_description.employer
                        ? selectedJob.job_description.employer
                        : 'No description available'
                    }
                    isApplied={selectedJob && selectedJob.is_applied}
                    isBookmarked={selectedJob && selectedJob.is_bookmarked}
                    jobStartDate={selectedJob && selectedJob.job_description && selectedJob.job_description.job_start_date}
                    handleClose={this.handleClose}
                    job={selectedJob && selectedJob}
                    bookmarksJob={this.props.bookmarksJob}
                    unBookmarksJob={this.props.unBookmarksJob}
                    applysJob={this.props.applysJob}
                    jobBookmarkedLoading={this.props.jobBookmarkedLoading}
                    jobBookmarkedError={this.props.jobBookmarkedError}
                    jobAppliedLoading={this.props.jobAppliedLoading}
                    jobAppliedError={this.props.jobAppliedError}
                    activeJobId={this.props.activeJobId}
                  />
              }
            </div>
          </div>
        </main>
      </BlockUI>
    );
  }
}

Carousel.propTypes = {
  title: PropTypes.string,
  jobs: PropTypes.arrayOf(PropTypes.object),
  error: PropTypes.objectOf(PropTypes.any),
  jobBookmarkedLoading:PropTypes.bool,
  jobBookmarkedError:PropTypes.bool,
  jobAppliedLoading:PropTypes.bool,
  jobAppliedError:PropTypes.bool,
  translate: PropTypes.func.isRequired,
  loading: PropTypes.bool,
};

Carousel.defaultProps = {
  title: '',
  jobs: [],
  error: {},
  jobBookmarkedLoading: false,
  jobBookmarkedError: false,
  jobAppliedLoading: false,
  jobAppliedError: false,
  loading: false,
};

export default withTranslate(Carousel);
