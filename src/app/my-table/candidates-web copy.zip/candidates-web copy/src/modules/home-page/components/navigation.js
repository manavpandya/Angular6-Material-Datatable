import _ from 'lodash';
import React, { Component } from 'react';
import Logo from '../../../shared/basic/logo';
import { NavLink } from 'react-router-dom';
import NavLinks from '../components/navLink';
import LanguageOption from '../../../shared/compound/languageOption';
import languages from '../../../i18n/languages';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import CandidateSearch from '../../candidate/components/CandidateSearch';
import CandidateProfileMenu from './candidateProfileMenu';
// import Tooltip from 'material-ui/Tooltip';
import Tooltip from '@material-ui/core/Tooltip';
import { getProfileData } from '../../candidate/redux/actions';
import { flushAppliedJobApplications, flushBookmarkedJobPositions } from '../../jobs/redux/actions';
import { withStyles } from 'material-ui';

const styles = {
  root: {
    borderRadius: 3,
  },
  label: {
    textTransform: 'capitalize',
  },
};

class Navigation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tooltip: false,
      selectedLanguage:'',
    };
    this.getLanguageLabel = this.getLanguageLabel.bind(this);
  }

  componentDidMount() {
    if (Object.keys(this.props.loggedUserProfile).length === 0) {
      this.props.getProfileData();
    }
    this.getLanguageLabel();
  }

  getLanguageLabel()
  {
    const selectedLang = _.find(languages,['locale',localStorage.getItem('language')]) || 'en';
    this.setState({ selectedLanguage: selectedLang.label });
  }

  render() {
    const { profile } = (this.props ? this.props.loggedUserProfile : null );
    const hasContactInformation = profile && profile.contact_information;
    const email = hasContactInformation ? hasContactInformation.email[0] : null;
    const userName = hasContactInformation ? hasContactInformation.person_name.FormattedName : null;
    return (
      <nav className="navigation">
        <div className="primary">
          <NavLink exact to="/dashboard">
            <Logo dark />
          </NavLink>
          <Tooltip id="tooltip-fab" title="Applications">
            <div aria-label="Applications">
              <NavLinks linkTo="/candidate/applications" imgSrc="/icons/application.svg" onClick={() => this.props.flushAppliedJobApplications()} />
            </div>
          </Tooltip>
          <Tooltip id="tooltip-fab" title="Bookmarks">
            <div aria-label="Bookmarks">
              <NavLinks linkTo="/candidate/bookmarks" imgSrc="/icons/bookmark.svg" onClick={() => this.props.flushBookmarkedJobPositions()} />
            </div>
          </Tooltip>
          {/* <Tooltip  id="tooltip-fab" title="Search Job"> */}
            <div aria-label="Search Job">
              <CandidateSearch/>
            </div>
          {/* </Tooltip> */}
          {/* <Tooltip id="tooltip-fab" title="Notifications">
            <div aria-label="Notifications">
              <NavLinks  linkTo="candidate/notifications" imgSrc="/icons/notification.svg" />
            </div>
          </Tooltip> */}
        </div>
        <div className="secondary">
          {/* <Tooltip id="tooltip-fab" title="Chats">
              <div aria-label="Chats">
                <NavLinks linkTo="candidate/chat" imgSrc="/icons/chat.svg" />
              </div>
          </Tooltip> */}
          {/* &nbsp;&nbsp; */}
          <Tooltip PopperProps={{ style: { pointerEvents: 'none' } }} id="tooltip-fab" title={this.state.selectedLanguage || 'English'}>
              <div aria-label="Choose Language">
                <LanguageOption
                  dispatch={this.props.dispatch}
                  languages={languages}
                />
              </div>
          </Tooltip>
          &nbsp;&nbsp;
          <CandidateProfileMenu
          email={email}
          userName={userName}/>
        </div>
      </nav>
    );
  }
}

Navigation.propTypes = {
  loggedUserProfile: PropTypes.objectOf(PropTypes.any),
  getProfileData: PropTypes.func,
  getAppliedJobApplications: PropTypes.func,
  getBookmarkedJobPositions: PropTypes.func,
  classes: PropTypes.object.isRequired,
};

Navigation.defaultProps = {
  getProfileData: () => {},
  getAppliedJobApplications: () => {},
  getBookmarkedJobPositions: () => {},
};

const mapDispatchToProps = dispatch => ({
  getProfileData: () => dispatch(getProfileData()),
  flushAppliedJobApplications: () => dispatch(flushAppliedJobApplications()),
  flushBookmarkedJobPositions: () => dispatch(flushBookmarkedJobPositions()),
  dispatch,
});

const mapStateToProps = state => ({
  loggedUserProfile: state.candidate.loggedUserProfile,
});

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(Navigation));
