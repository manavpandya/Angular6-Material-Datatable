import * as actionTypes from './actionTypes';

const initialState = {
  register: {},
  loggedUserProfile: {},
  profile: {},    
  registerLoading: false,
  registerSuccess: false,
  registerError: null,
  searchedData: [],
  searchedDataLoading: false,
  searchedDataError: false,
  searchedJobPositionsCurrentPageNo: 0,
  searchedJobPositionsCurrentPageSize: 10,
  jobsMatchingTitleOfProfile: [],
  jobBookmarkedLoading: false,
  jobBookmarkedError: false,
  jobAppliedLoading: false,
  jobAppliedError: false,
  jobsMatchingTitleOfProfileCurrentPageNo: 1,
  jobsMatchingTitleOfProfileCurrentPageSize: 10,
  totalJobsMatchingTitleOfProfile: 0,
  jobsMatchingTitleOfProfileLoading: false,
  jobsMatchingTitleOfProfileError: null,
  jobsMatchingSkillsOfProfile: [],
  jobsMatchingSkillsOfProfileCurrentPageNo: 1,
  jobsMatchingSkillsOfProfileCurrentPageSize: 10,
  totalJobsMatchingSkillsOfProfile: 0,
  jobsMatchingSkillsOfProfileLoading: false,
  jobsMatchingSkillsOfProfileError: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
     // Searched Job
   case actionTypes.FLUSH_SEARCHED_JOBS:
     return {
        ...state,
        searchedData: [],
        searchedJobPositionsCurrentPageNo: 0,
        searchedJobPositionsCurrentPageSize: 10,
        total: 0,
        searchedJobsLoading: false,
        searchedDataLoading: false,
        searchedDataError: null,
        searchedJobsError: null,
      }
   case actionTypes.GET_SEARCHED_JOBS_SUCCESS:
     return {
       ...state,
       searchedData: [
         ...state.searchedData,
         ...action.payload.job_positions,
       ],
       searchedJobPositionsCurrentPageNo: action.payload.page,
       searchedJobPositionsCurrentPageSize: action.payload.perPage,
       total: action.payload.total,
       searchedDataLoading: false,
       searchedDataError: false,
       searchedJobsLoading: false,
       searchedJobsSuccess: true,
       searchedJobsError: null,
     };
   case actionTypes.GET_SEARCHED_JOBS_LOADING:
   return {
       ...state,
       searchedDataLoading: true,
       searchedDataError: false,
       searchedJobsLoading: true,
       searchedJobsSuccess: false,
       searchedJobsError: null,
     };
   case actionTypes.GET_SEARCHED_JOBS_ERROR:
     return {
       ...state,
       searchedDataLoading: false,
       searchedDataError: action.payload,
       searchedJobsLoading: false,
       searchedJobsSuccess: false,
       searchedJobsError: action.payload,
     };
  //  case actionTypes.GET_CHANGED_SEARCHED_JOB:
  //      return {
  //      ...state,
  //      selectedSearchedJob : action.payload,
  //  };
    case actionTypes.REGISTER_CANDIDATE_SUCCESS:
      return {
        ...state,
        register: action.payload,
        registerLoading: false,
        registerSuccess: true,
        registerError: null,
      };
    case actionTypes.REGISTER_CANDIDATE_LOADING:
      return {
        ...state,
        register: null,
        registerLoading: true,
        registerSuccess: false,
        registerError: null,
      };
    case actionTypes.REGISTER_CANDIDATE_ERROR:
      return {
        ...state,
        register: null,
        registerLoading: false,
        registerSuccess: false,
        registerError: action.payload,
      };
    case actionTypes.GET_JOBS_MATCHING_TITLE_OF_PROFILE_SUCCESS:
      return {
        ...state,
        loggedUserProfile: action.payload.page > 1 ? [...state.jobsMatchingSkillsOfProfile, ...action.payload.profiles] : action.payload.profiles,
        jobsMatchingTitleOfProfile: action.payload.page > 1 ? [...state.jobsMatchingSkillsOfProfile, ...action.payload.profiles] : action.payload.profiles,
        jobsMatchingTitleOfProfileCurrentPageNo: action.payload.page,
        jobsMatchingTitleOfProfileCurrentPageSize: action.payload.pageSize,
        totalJobsMatchingTitleOfProfile: action.payload.total,
        jobsMatchingTitleOfProfileLoading: false,
        jobsMatchingTitleOfProfileError: null,
      };
    case actionTypes.GET_JOBS_MATCHING_TITLE_OF_PROFILE_LOADING:
      return {
        ...state,
        jobsMatchingTitleOfProfileLoading: true,
        jobsMatchingTitleOfProfileError: null,
      };
    case actionTypes.GET_JOBS_MATCHING_TITLE_OF_PROFILE_ERROR:
      return {
        ...state,
        jobsMatchingTitleOfProfileLoading: false,
        jobsMatchingTitleOfProfileError: action.payload,
      }
    case actionTypes.FLUSH_JOBS_MATCHING_SKILLS_OF_PROFILE:
      return {
        ...state,
        jobsMatchingSkillsOfProfile: [],
        jobsMatchingSkillsOfProfileCurrentPageNo: 1,
        jobsMatchingSkillsOfProfileCurrentPageSize: 10,
        totalJobsMatchingSkillsOfProfile: 0,
        jobsMatchingSkillsOfProfileLoading: false,
        jobsMatchingSkillsOfProfileError: null,
      }
    case actionTypes.GET_JOBS_MATCHING_SKILLS_OF_PROFILE_SUCCESS:
      return {
        ...state,
        jobsMatchingSkillsOfProfile: action.payload.page > 1 ? [...state.jobsMatchingSkillsOfProfile, ...action.payload.profiles] : action.payload.profiles,
        jobsMatchingSkillsOfProfileCurrentPageNo: action.payload.page,
        jobsMatchingSkillsOfProfileCurrentPageSize: action.payload.pageSize,
        totalJobsMatchingSkillsOfProfile: action.payload.total,
        jobsMatchingSkillsOfProfileLoading: false,
        jobsMatchingSkillsOfProfileError: null,
      };
    case actionTypes.GET_JOBS_MATCHING_SKILLS_OF_PROFILE_LOADING:
      return {
        ...state,
        jobsMatchingSkillsOfProfileLoading: true,
        jobsMatchingSkillsOfProfileError: null,
      }
    case actionTypes.GET_JOBS_MATCHING_SKILLS_OF_PROFILE_ERROR:
      return {
        ...state,
        jobsMatchingSkillsOfProfileLoading: false,
        jobsMatchingSkillsOfProfileError: action.payload,
      }
    case actionTypes.BOOKMARK_JOB_POSITION_SUCCESS:
      const jobsMatchingTitleOfProfile = state.jobsMatchingTitleOfProfile || [];
      const jobsMatchingSkillsOfProfile = state.jobsMatchingSkillsOfProfile || [];
      const searchedData = state.searchedData || [];
      return { ...state, jobsMatchingTitleOfProfile: [...jobsMatchingTitleOfProfile.map(
            job => {
              if (job.id === action.payload.id) {
                const matchingJob = job;
                matchingJob.is_bookmarked = true;
                return matchingJob;
              }
              return job;
            }
          )], jobsMatchingSkillsOfProfile: [...jobsMatchingSkillsOfProfile.map(
            job => {
              if (job.id === action.payload.id) {
                const matchingJob = job;
                matchingJob.is_bookmarked = true;
                return matchingJob;
              }
              return job;
            }
          )],
          searchedData: [...searchedData.map(
            job => {
              if (job.id === action.payload.id) {
                const matchingJob = job;
                matchingJob.is_bookmarked = true;
                return matchingJob;
              }
              return job;
            }
          )]
          , activeJobId: "", jobBookmarkedLoading: false, jobBookmarkedError: false };
    case actionTypes.BOOKMARK_JOB_POSITION_LOADING:
      return {
        ...state,
        activeJobId: action.meta.id,
        jobBookmarkedLoading: true,
        jobBookmarkedError: false,
      };
    case actionTypes.BOOKMARK_JOB_POSITION_ERROR:
      return {
        ...state,
        activeJobId: '',
        jobBookmarkedLoading: false,
        jobBookmarkedError: true,
      };
    case actionTypes.UNBOOKMARK_JOB_POSITION_SUCCESS:
      return {
        ...state,
        jobsMatchingTitleOfProfile: [
          ...state.jobsMatchingTitleOfProfile.map(job => {
            if (job.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.is_bookmarked = false;
              return matchingJob;
            }
            return job;
          })
        ],
        jobsMatchingSkillsOfProfile: [
          ...state.jobsMatchingSkillsOfProfile.map(job => {
            if (job.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.is_bookmarked = false;
              return matchingJob;
            }
            return job;
          })
        ],
        searchedData: [
          ...state.searchedData.map(
          job => {
            if (job.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.is_bookmarked = false;
              return matchingJob;
            }
            return job;
          }
        )],
        activeJobId: '',
        jobBookmarkedLoading: false,
        jobBookmarkedError: false,
      };
    case actionTypes.UNBOOKMARK_JOB_POSITION_LOADING:
      return {
        ...state,
        activeJobId: action.meta.id,
        jobBookmarkedLoading: true,
        jobBookmarkedError: false,
      };
    case actionTypes.UNBOOKMARK_JOB_POSITION_ERROR:
      return {
        ...state,
        activeJobId: '',
        jobBookmarkedLoading: false,
        jobBookmarkedError: true,
      };
    case actionTypes.APPLY_JOB_POSITION_SUCCESS:
      return {
        ...state,
        jobsMatchingTitleOfProfile: [
          ...state.jobsMatchingTitleOfProfile.map(job => {
            if (job.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.is_applied = true;
              return matchingJob;
            }
            return job;
          })
        ],
        jobsMatchingSkillsOfProfile: [
          ...state.jobsMatchingSkillsOfProfile.map(job => {
            if (job.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.is_applied = true;
              return matchingJob;
            }
            return job;
          })
        ],
        searchedData: [
          ...state.searchedData.map(job => {
            if (job.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.is_applied = true;
              return matchingJob;
            }
            return job;
          })
        ],
        activeJobId: '',
        jobAppliedLoading: false,
        jobAppliedError: false,
      };
    case actionTypes.APPLY_JOB_POSITION_LOADING:
      return {
        ...state,
        activeJobId: action.meta.id,
        jobAppliedLoading: true,
        jobAppliedError: false,
      };
    case actionTypes.APPLY_JOB_POSITION_ERROR:
      return {
        ...state,
        activeJobId: '',
        jobAppliedLoading: false,
        jobAppliedError: true,
      };
    case actionTypes.LOGOUT_SUCCESS: {
      return {
        ...state,
        loggedUserProfile: {},
        profile: {},        
      };
    }
    default:
      return state;
  }
}
