
import React, { Component } from 'react';
import _ from 'lodash';
import c from 'classnames';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import Navigation from './components/navigation';
import Carousel from './components/carousel';
import JobSkills from './components/jobSkills';
import { withTranslate } from 'react-redux-multilingual';
import { showNotification } from '../../utils/Notifications';
import { logoutFunction } from '../auth/redux/actions';
import {
  getRequiredSkills,
  addGreatestSkill,
  deleteGreatestSkill,
  addAdditionalSkill,
  deleteAdditionalSkill
} from '../candidate/redux/actions';
import {
  getJobsMatchingTitleOfProfile,
  getJobsMatchingSkillsOfProfile,
  flushJobsMatchingSkillsOfProfile
} from './redux/actions';
import {
 bookmarkJob,
 unBookmarkJob,
 applyJob,
} from '../home-page/redux/actions';

class DashboardContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hasScrolled: false,
      seletcedValue: {},
      isHidden: true,
    };
    this.getNextPageOfJobsMatchingTitleOfProfile = this.getNextPageOfJobsMatchingTitleOfProfile.bind(this)
    this.getNextPageOfJobsMatchingSkillsOfProfile = this.getNextPageOfJobsMatchingSkillsOfProfile.bind(this)
    this.handleScroll = this.handleScroll.bind(this);
    this.logout = this.logout.bind(this);
    this.bookmarksJob = this.bookmarksJob.bind(this);
    this.unBookmarksJob = this.unBookmarksJob.bind(this);
    this.applysJob = this.applysJob.bind(this);
  }

  componentDidMount() {
    window.addEventListener('scroll', this.handleScroll);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.loggedUserProfile !== nextProps.loggedUserProfile) {
      if(nextProps && nextProps.loggedUserProfile && nextProps.loggedUserProfile.profile)
      {
        this.props.getJobsMatchingTitleOfProfile(nextProps.loggedUserProfile.profile.id, 1, 10);
        this.props.getJobsMatchingSkillsOfProfile(nextProps.loggedUserProfile.profile.id, 1, 10);
      }
    }
  }

  componentWillUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  }

  getNextPageOfJobsMatchingTitleOfProfile() {
    this.props.getJobsMatchingTitleOfProfile(
      this.props.loggedUserProfile.profile.id,
      this.props.jobsMatchingTitleOfProfileCurrentPageNo + 1,
      this.props.jobsMatchingTitleOfProfileCurrentPageSize
    );
  }

  getNextPageOfJobsMatchingSkillsOfProfile() {
    this.props.getJobsMatchingSkillsOfProfile(
      this.props.loggedUserProfile.profile.id,
      this.props.jobsMatchingSkillsOfProfileCurrentPageNo + 1,
      this.props.jobsMatchingSkillsOfProfileCurrentPageSize
    );
  }

  handleScroll() {
    const { scrollTop } = (document.scrollingElement);
    if (scrollTop > 100) {
      this.setState({ hasScrolled: true });
    } else {
      this.setState({ hasScrolled: false });
    }
  }

  logout() {
    this.props.logout();
  }

  bookmarksJob(event,value)
  {
    event.preventDefault();    
    event.stopPropagation();
    if(value)
    {
      this.props.bookmarkJob({ "entity_type" : "job_position" , "entity_id": value }).then(() => {
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      });
    }
  }

  unBookmarksJob(event,value)
  {
    event.preventDefault();  
    event.stopPropagation();      
    if(value)
    {
      this.props.unBookmarkJob({ "entity_type" : "job_position" , "entity_id": value }).then(() => {
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      });
    }
  }

  applysJob(event,value)
  {
    event.preventDefault();
    event.stopPropagation();    
    const profileId = !_.isEmpty(this.props.loggedUserProfile.profile) ? this.props.loggedUserProfile.profile.id : null;
    if(value && profileId)
    {
      this.props.applyJob(value, { "profile_id" : profileId , "external_id": value }).then(() => {
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      });
    }
  }

  render() {
    const addedSkills = !_.isEmpty(this.props.loggedUserProfile && this.props.loggedUserProfile.profile && this.props.loggedUserProfile.profile.qualifications )  ? this.props.loggedUserProfile.profile.qualifications.important_skills : null;
    const additionalSkills = !_.isEmpty(this.props.loggedUserProfile && this.props.loggedUserProfile.profile && this.props.loggedUserProfile.profile.qualifications )  ? this.props.loggedUserProfile.profile.qualifications.additional_skills : null;
    const profileId = !_.isEmpty(this.props.loggedUserProfile && this.props.loggedUserProfile.profile) ? this.props.loggedUserProfile.profile.id : null;
    const skillCount = this.props.loggedUserProfile && this.props.loggedUserProfile.profile && this.props.loggedUserProfile.profile.qualifications && this.props.loggedUserProfile.profile.qualifications.additional_skills.length;
    return (
      <div className={c('page', 'candidate', { scrolled: this.state.hasScrolled })}>
        <header>
          <div className="container">
            <Navigation
              logout={this.props.logout}
              changeLanguages={this.changeLanguages}
              loggedUserProfile={this.loggedUserProfile}
            />
          </div>
        </header>
        <div className="jobs-matching-title">
          <Carousel
            title={this.props.translate('jobsMatchingYourProfile')}
            jobs={this.props.jobsMatchingTitleOfProfile}
            totalCount={this.props.totalJobsMatchingTitleOfProfile}
            loading={this.props.jobsMatchingTitleOfProfileLoading}
            error={this.props.jobsMatchingTitleOfProfileError}
            bookmarksJob={this.bookmarksJob}
            unBookmarksJob={this.unBookmarksJob}
            applysJob={this.applysJob}
            jobBookmarkedLoading={this.props.jobBookmarkedLoading}
            jobBookmarkedError={this.props.jobBookmarkedError}
            jobAppliedLoading={this.props.jobAppliedLoading}
            jobAppliedError={this.props.jobAppliedError}
            activeJobId={this.props.activeJobId}
            showLoadMore={(this.props.totalJobsMatchingTitleOfProfile / (this.props.jobsMatchingTitleOfProfileCurrentPageNo * this.props.jobsMatchingTitleOfProfileCurrentPageSize)) > 1}
            getNextPage={this.getNextPageOfJobsMatchingTitleOfProfile}
            emptyResultMessage={'profileNotMatching'}
          />
        </div>
        <JobSkills
          addGreatestSkill = {this.props.addGreatestSkill}
          deleteGreatestSkill = {this.props.deleteGreatestSkill}
          addAdditionalSkill = {this.props.addAdditionalSkill}
          deleteAdditionalSkill = {this.props.deleteAdditionalSkill}
          flushJobsMatchingSkillsOfProfile={this.props.flushJobsMatchingSkillsOfProfile}
          profileId={profileId}
          addedSkills={addedSkills}
          additionalSkills={additionalSkills}
          skillCount={skillCount}
          initialValues={{ required_skills : addedSkills ,additional_skills : additionalSkills}}
          skillsLoading={this.props.skillsLoading}
          selectedSkills={this.state.seletcedValue}
          isHidden={this.state.isHidden}
          getJobsMatchingSkillsOfProfile={this.props.getJobsMatchingSkillsOfProfile}
          loggedUserProfile={this.props.loggedUserProfile}
        />
        <div className="jobs-matching-profile">
          <Carousel
            title={this.props.translate('jobsMatchingYourSkills')}
            jobs={this.props.jobsMatchingSkillsOfProfile}
            totalCount={this.props.totalJobsMatchingSkillsOfProfile}
            loading={this.props.jobsMatchingSkillsOfProfileLoading}
            error={this.props.jobsMatchingSkillsOfProfileError}
            bookmarksJob={this.bookmarksJob}
            unBookmarksJob={this.unBookmarksJob}
            applysJob={this.applysJob}
            jobBookmarkedLoading={this.props.jobBookmarkedLoading}
            jobBookmarkedError={this.props.jobBookmarkedError}
            jobAppliedLoading={this.props.jobAppliedLoading}
            jobAppliedError={this.props.jobAppliedError}
            activeJobId={this.props.activeJobId}
            showLoadMore={(this.props.totalJobsMatchingSkillsOfProfile / (this.props.jobsMatchingSkillsOfProfileCurrentPageNo * this.props.jobsMatchingSkillsOfProfileCurrentPageSize)) > 1}
            getNextPage={this.getNextPageOfJobsMatchingSkillsOfProfile}
            emptyResultMessage={'noMatchedResultForGreatestSkills'}            
          />
        </div>
      </div>
    );
  }
}

DashboardContainer.propTypes = {
  initialValues: PropTypes.object, // eslint-disable-line
  translate: PropTypes.func.isRequired,
  logout: PropTypes.func,
  history: PropTypes.object, // eslint-disable-line
  getRequiredSkills: PropTypes.func,
  addGreatestSkill: PropTypes.func,
  deleteGreatestSkill: PropTypes.func,
  addAdditionalSkill: PropTypes.func,
  deleteAdditionalSkill: PropTypes.func,
  skillsLoading: PropTypes.bool.isRequired,
  loggedUserProfile: PropTypes.objectOf(PropTypes.any),
  jobsMatchingTitleOfProfile: PropTypes.arrayOf(PropTypes.object),
  jobsMatchingTitleOfProfileCurrentPageNo: PropTypes.number,
  jobsMatchingTitleOfProfileCurrentPageSize: PropTypes.number,
  totalJobsMatchingTitleOfProfile: PropTypes.number,
  jobsMatchingSkillsOfProfile: PropTypes.arrayOf(PropTypes.object),
  jobsMatchingSkillsOfProfileCurrentPageNo: PropTypes.number,
  jobsMatchingSkillsOfProfileCurrentPageSize: PropTypes.number,
  totalJobsMatchingSkillsOfProfile: PropTypes.number,
  jobsMatchingTitleOfProfileLoading: PropTypes.bool,
  jobsMatchingTitleOfProfileError: PropTypes.objectOf(PropTypes.any),
  jobsMatchingSkillsOfProfileLoading: PropTypes.bool,
  jobsMatchingSkillsOfProfileError: PropTypes.objectOf(PropTypes.any),
  jobBookmarkedLoading: PropTypes.bool,
  jobBookmarkedError: PropTypes.bool,
  jobAppliedLoading: PropTypes.bool,
  jobAppliedError: PropTypes.bool,
  activeJobId: PropTypes.string,
  flushJobsMatchingSkillsOfProfile: PropTypes.func,
};

DashboardContainer.defaultProps = {
  initialValues: {},
  getRequiredSkills:() => { },
  addGreatestSkill: () => { },
  deleteGreatestSkill:() => { },
  addAdditionalSkill: () => { },
  deleteAdditionalSkill:() => { },
  logout: () => {},
  getAccountMe: () => {},
  history: {},
  loggedUserProfile: {},
  jobsMatchingTitleOfProfile: [],
  jobsMatchingTitleOfProfileCurrentPageNo: 1,
  jobsMatchingTitleOfProfileCurrentPageSize: 10,
  totalJobsMatchingTitleOfProfile: 0,
  jobsMatchingSkillsOfProfile: [],
  jobsMatchingSkillsOfProfileCurrentPageNo: 1,
  jobsMatchingSkillsOfProfileCurrentPageSize: 10,
  totalJobsMatchingSkillsOfProfile: 0,
  jobsMatchingTitleOfProfileLoading: false,
  jobsMatchingTitleOfProfileError: {},
  jobsMatchingSkillsOfProfileLoading: false,
  jobsMatchingSkillsOfProfileError: {},
  jobBookmarkedLoading: false,
  jobBookmarkedError: false,
  jobAppliedLoading: false,
  jobAppliedError: false,
  activeJobId: '',
  flushJobsMatchingSkillsOfProfile: () => {},
};

const mapStateToProps = state => ({
  loggedUserProfile: state.candidate.loggedUserProfile,
  skillsLoading: state.candidate.skillsLoading,
  candidateProfile: state.candidate.candidateProfile,
  jobsMatchingTitleOfProfile: state.dashboard.jobsMatchingTitleOfProfile,
  jobsMatchingTitleOfProfileCurrentPageNo: state.dashboard.jobsMatchingTitleOfProfileCurrentPageNo,
  jobsMatchingTitleOfProfileCurrentPageSize: state.dashboard.jobsMatchingTitleOfProfileCurrentPageSize,
  totalJobsMatchingTitleOfProfile: state.dashboard.totalJobsMatchingTitleOfProfile,
  jobsMatchingSkillsOfProfile: state.dashboard.jobsMatchingSkillsOfProfile,
  jobsMatchingSkillsOfProfileCurrentPageNo: state.dashboard.jobsMatchingSkillsOfProfileCurrentPageNo,
  jobsMatchingSkillsOfProfileCurrentPageSize: state.dashboard.jobsMatchingSkillsOfProfileCurrentPageSize,
  totalJobsMatchingSkillsOfProfile: state.dashboard.totalJobsMatchingSkillsOfProfile,
  jobsMatchingTitleOfProfileLoading:
    state.dashboard.jobsMatchingTitleOfProfileLoading,
  jobsMatchingTitleOfProfileError:
    state.dashboard.jobsMatchingTitleOfProfileError,
  jobsMatchingSkillsOfProfileLoading:
    state.dashboard.jobsMatchingSkillsOfProfileLoading,
  jobsMatchingSkillsOfProfileError:
    state.dashboard.jobsMatchingSkillsOfProfileError,
  jobBookmarkedLoading: state.dashboard.jobBookmarkedLoading,
  jobBookmarkedError: state.dashboard.jobBookmarkedError,
  jobAppliedLoading: state.dashboard.jobAppliedLoading,
  jobAppliedError: state.dashboard.jobAppliedError,
  activeJobId: state.dashboard.activeJobId,
  additional_skills: state.candidate.additional_skills,
  skillCount: state.candidate.skillCount,
});

const mapDispatchToProps = dispatch => ({
  logout: () => dispatch(logoutFunction()),
  getRequiredSkills:(query) => dispatch(getRequiredSkills(query)),
  addGreatestSkill:(profileId,values) => dispatch(addGreatestSkill(profileId,values)),
  deleteGreatestSkill:(profileId,value) => dispatch(deleteGreatestSkill(profileId,value)),
  addAdditionalSkill:(profileId,values) => dispatch(addAdditionalSkill(profileId,values)),
  deleteAdditionalSkill:(profileId,value) => dispatch(deleteAdditionalSkill(profileId,value)),
  getJobsMatchingTitleOfProfile: (profileId, pageNo, pageSize) =>
    dispatch(getJobsMatchingTitleOfProfile(profileId, pageNo, pageSize)),
  getJobsMatchingSkillsOfProfile: (profileId, pageNo, pageSize) =>
    dispatch(getJobsMatchingSkillsOfProfile(profileId, pageNo, pageSize)),
  bookmarkJob:(jobData) => dispatch(bookmarkJob(jobData)),
  unBookmarkJob:(jobData) => dispatch(unBookmarkJob(jobData)),
  applyJob:(profileId,jobData) => dispatch(applyJob(profileId,jobData)),
  flushJobsMatchingSkillsOfProfile: () => dispatch(flushJobsMatchingSkillsOfProfile()),
  dispatch,
});

export default connect(mapStateToProps,mapDispatchToProps)(withRouter(withTranslate(DashboardContainer))); // eslint-disable-line