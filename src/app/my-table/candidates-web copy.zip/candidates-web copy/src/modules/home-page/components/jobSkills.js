import React, { Component } from 'react';
import _ from 'lodash';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import { Field, reduxForm } from 'redux-form';
import GridList, { GridListTile } from 'material-ui/GridList';
import Avatar from '../components/avatar';
import MultiSelect from '../../../shared/basic/MultiSelect';
import { hasChildren } from '../../../utils/validators';
import { withStyles } from 'material-ui/styles';
// import { showNotification } from '../../../utils/Notifications';
import BlockUi from 'react-block-ui';
import { getOptions } from '../redux/actions';
import candidateProfileImage from '../../../assets/images/candidate-profile.png';

const styles = theme => ({
  customFont : {
    fontSize: '16px !important'
  }
});

const errors = {};

const validate = (values) => {
  errors.required_skills = hasChildren(values.required_skills);
  return errors;
};

// const items = (selectedSkills,deleteSkill,profileId) => _.map(selectedSkills, (value) => {
//   if (value.display_value) {
//     return (<span key={value.display_value} className="skill">
//     <span style={{marginRight: '1rem'}}>{value.display_value}</span>&nbsp;
//       <ClearIcon onClick={() => deleteSkill(value.id,profileId)} className={this.props ? this.props.classes.customFont : null}/>
//     </span>);
//   }
//   return '';
// });

class JobSkills extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isHidden: false,
    };
    this.addNewSkill = this.addNewSkill.bind(this);
  }

  addNewSkill() {
    this.setState({
      isHidden: !this.state.isHidden,
    });
  }

  componentWillMount()
  {
    this.props.getRequiredSkills();
  }

  addGreatestSkill(profileId,skillId)
  {
    const skillIds = _.map(skillId,'id').filter(n => n);
    const newlyAddedSkills = _.difference(skillIds,_.map(this.props.addedSkills,'id').filter(n => n));
    const deletedSkill = _.difference(_.map(this.props.addedSkills,'id').filter(n => n),skillIds);

    const additionalSkills = _.filter(skillId, n => typeof n.id === typeof undefined).filter(n => _.isPlainObject(n));
    const newlyAddedAdditionalSkill = _.difference(_.map(additionalSkills,'display_value'),_.map(this.props.additionalSkills,'display_value'));
    let promise;
    if(skillIds)
    {
        if (this.props.addedSkills && this.props.addedSkills.length>0 && !_.isEmpty(deletedSkill)){
          promise = this.props.deleteGreatestSkill(profileId,Object.assign({},{ "important_skill_ids": deletedSkill }));
        }else {
          if(!_.isEmpty(newlyAddedSkills)){
          promise =  this.props.addGreatestSkill(profileId,Object.assign({},{"important_skill_ids": newlyAddedSkills }));
          }
          else if (deletedSkill && deletedSkill.length){
            promise = this.props.deleteGreatestSkill(profileId, Object.assign({}, { "important_skill_ids": deletedSkill }));
          }
        }
    }
    if(!_.isEmpty(newlyAddedAdditionalSkill)){
      this.props.addAdditionalSkill(profileId,Object.assign({"additional_skills": newlyAddedAdditionalSkill }));
    }
  }

  deleteAdditionalSkill(profileId,value)
  {
    const deletedAdditionalSkills = _.difference(this.props.additionalSkills,_.map(value,'value'));
    if (deletedAdditionalSkills && deletedAdditionalSkills.length > 0){
      this.props.deleteAdditionalSkill(profileId, Object.assign({ "additional_skills": deletedAdditionalSkills }));
    }
  }

  render() {
    const { classes } = this.props;
    return (
      <main className="persuade skills">
        <div className="container">
          <h1>{this.props.translate('getBetterMatches')}</h1>
          <section>
            <div className="highest">
              <h3>{this.props.translate('highestMatchPossible')}</h3>
              <h1 className="percent">0%</h1>
            </div>
            <div className="profile">
              <h3><a href="/candidate/profile">{this.props.translate('updateProfile')}</a></h3>
              <Avatar avatar={candidateProfileImage} size="3" />
            </div>
            <div className="skills">
              <h3>{this.props.translate('greatestSkillsAre')}</h3>
              <BlockUi blocking={this.props.skillsLoading}>
              <div className="skills-list">
                {/* { skillsCount > 0 &&
                            items(this.props.addedSkills,this.deleteSkill,this.props.profileId)
                          }
                <button className="skill add" href="#" onClick={() => this.addNewSkill()}>
                  <span>+</span>
                </button> */}
                <form>
                  <div id="required_skills">
                      <GridList
                        padding={1}
                        cols={1}
                        cellHeight={200}
                      >
                        <GridListTile >
                          <Field
                            getOptions={getOptions}
                            valueKey="display_value"
                            labelKey="display_value"
                            type="AsyncCreatable"
                            name="required_skills"
                            onChange={values => {
                              this.addGreatestSkill(this.props.profileId,values)
                            }}
                            component={MultiSelect}
                            clearable={false}
                            backspaceRemoves={false}
                            closeOnSelect={true}
                          />
                        </GridListTile>
                      </GridList>
                  </div>
                </form>
                {this.props && this.props.skillCount > 0 &&
                  <div className="additional_skills" id="additional_skills">
                  <GridList
                    padding={1}
                    cols={1}
                    cellHeight={200}
                  >
                      <GridListTile >
                        <Field
                          name="additional_skills"
                          component={MultiSelect}
                          clearable={false}
                          backspaceRemoves={false}
                          closeOnSelect={true}
                          searchable={false}                                                      
                          onChange={values => {
                            this.deleteAdditionalSkill(this.props.profileId,values)
                          }}
                        />
                      </GridListTile>
                    </GridList>
                  </div>
                }
              </div>
              </BlockUi>
            </div>
          </section>
        </div>
      </main>
    );
  }
}

JobSkills.propTypes = {
  handleSubmit: PropTypes.func,
  initialValues: PropTypes.object, // eslint-disable-line
  selectedSkills: PropTypes.object,// eslint-disable-line
  history: PropTypes.object, // eslint-disable-line
  addNewSkill: PropTypes.func,
  getRequiredSkills: PropTypes.func,
  addGreatestSkill: PropTypes.func,
  deleteGreatestSkill: PropTypes.func,
  addAdditionalSkill: PropTypes.func,
  deleteAdditionalSkill: PropTypes.func,
  classes: PropTypes.object.isRequired,
  getJobsMatchingSkillsOfProfile: PropTypes.func,
  loggedUserProfile: PropTypes.objectOf(PropTypes.any),
};

JobSkills.defaultProps = {
  handleSubmit: () => {},
  addNewSkill: () => { },
  initialValues: {},
  selectedSkills: {},
  history: {},
  getRequiredSkills:() => { },
  addGreatestSkill: () => { },
  deleteGreatestSkill:() => { },
  addAdditionalSkill: () => { },
  deleteAdditionalSkill: () => { },
  getJobsMatchingSkillsOfProfile: () => {},
  loggedUserProfile: {},
};

const JobSkill = reduxForm({
  form: 'NewJobForm',
  validate,
  enableReinitialize: true
})(JobSkills);

export default withRouter(withTranslate(withStyles(styles)(JobSkill)));
