import React from 'react';
import PropTypes from 'prop-types';
import BlockUI from 'react-block-ui';
import Tooltip from '@material-ui/core/Tooltip';

const JobSummary = props => {
return (
  <BlockUI tag="div" blocking={props.activeJobId === props.id && (props.jobBookmarkedLoading || props.jobAppliedLoading)} >
    <div className="job-ad-summary job-description">
      <div className="job-header">
        {
          props.isApplied
          ? <span className="icon applied job-apply-btn disabled">Applied&nbsp;</span>
          : <span onClick={(event) => props.applysJob(event,props.id)} className="icon applied job-apply-btn">Apply&nbsp;</span>
        }
        {
          props.isBookmarked
          ? 
            <Tooltip id="tooltip-fab" title="Unbookmark">
              <img onClick={(event) => props.unBookmarksJob(event,props.id)} className="icon" src="/icons/bookmarked.svg" alt="unbookmarked" />
            </Tooltip>
          : 
            <Tooltip id="tooltip-fab" title="Bookmark">
              <img onClick={(event) => props.bookmarksJob(event,props.id)} className="icon" src="/icons/bookmark.svg" alt="bookmarked" />
            </Tooltip>
        }
      </div>
      <h3>{props.jobTitle}</h3>
      <h5>{`${props.jobRegion} - ${props.jobLocation}`}</h5>
      <div className="scrollable">
      {
        props.jobDescription
      }
      </div>
      <div className="footer"><h6 className="posted">{`Posted on ${props.startDate}`}</h6></div>
    </div>
  </BlockUI>
)
}


JobSummary.propTypes = {
  posted: PropTypes.string,
  job: PropTypes.objectOf(PropTypes.any),
  bookmarksJob: PropTypes.func,
  applysJob: PropTypes.func,
  jobBookmarkedLoading: PropTypes.bool,
  jobAppliedLoading: PropTypes.bool,
};

JobSummary.defaultProps = {
  posted: '',
  job: {},
  bookmarksJob: () => {},
  applysJob: () => {},
  jobBookmarkedLoading: false,
  jobAppliedLoading: false,
};

export default JobSummary;
