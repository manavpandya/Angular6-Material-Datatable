import React, { Component } from 'react';
import PropTypes from 'prop-types';

class Avatar extends Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }
  render() {
    const {
      avatar, alt, border, size,
    } = this.props;
    return (
      <img
        src={avatar}
        alt={alt}
        className="avatar"
        style={{
 width: `${(size || 1) * 2}rem`, height: `${(size || 1) * 2}rem`, border: `1px solid ${border}`, borderRadius: '50%',
}}
      />
    );
  }
}

Avatar.propTypes = {
  avatar: PropTypes.string,
  alt: PropTypes.string,
  border: PropTypes.string,
  size: PropTypes.string,
};

Avatar.defaultProps = {
  avatar: '',
  alt: '',
  border: '',
  size: '',
};

export default Avatar;
