import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';

import TogglePanel from './TogglePanel'
import MultiSelect from '../../../shared/basic/MultiSelect';
import { getOptions } from '../../../utils';
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class Event extends Component {
  constructor(props) {
    super(props);
    this.onUpdateEvents = this.onUpdateEvents.bind(this);
  }

  onUpdateEvents(values) {
    this.props.updateProfileData({ speaking_engagements: { ...this.props.value, speaking_events_history: values.speakingEventsHistory.map(event => event.value) } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="skills">
            {
              this.props.value.speaking_events_history && this.props.value.speaking_events_history.length > 0
              ? this.props.value.speaking_events_history.map(event => 
                 <span key={event.value} className="bordered-box">{event.value}</span>
                )
              : 'No data provided'
            }
          </p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateEvents)}>
            <Field 
              getOptions={getOptions}
              type="Creatable"
              name="speakingEventsHistory"
              component={MultiSelect}
            />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('speakingEventsHistoryForm')
        }}
        formName="speakingEventsHistoryForm"
    />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    speakingEventsHistory: props.value.speaking_events_history,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),  
});

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'speakingEventsHistoryForm', enableReinitialize: true, destroyOnUnmount: false })(Event));