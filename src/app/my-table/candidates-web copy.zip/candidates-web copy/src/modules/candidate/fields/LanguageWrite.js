import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Button, Checkbox as ChkBox } from 'material-ui'
import CloseIcon from 'material-ui-icons/Close'
import AddIcon from 'material-ui-icons/Add'
import { reduxForm, Form, Field, reset } from 'redux-form';
import { TextField, Checkbox } from 'redux-form-material-ui';

import { addLanguageCapability, removeLanguageCapability, removeLanguage, addNewLanguage } from '../redux/actions';
import { required } from '../../../utils/validators';

class LanguageWrite extends Component {
  constructor(props) {
    super(props);
    this.changeLanguageCapability = this.changeLanguageCapability.bind(this);
    this.addNewLanguage = this.addNewLanguage.bind(this);
  }

  changeLanguageCapability(language, capability) {
    if (this.props.language[capability].includes(language)) {
      this.props.removeLanguageCapability(language, capability);
    } else {
      this.props.addLanguageCapability(language, capability);
    }
  }

  addNewLanguage(values) {
    const { newLangugage, read, write, speak } = values;
    const status = [];
    if (read) status.push('read');
    if (write) status.push('write');
    if (speak) status.push('speak');
    this.props.addNewLanguage(newLangugage, status);
    this.props.reset();
  }

  render() {
    const { read, speak, write } = this.props.language;
    const languages = [...new Set([...read, ...write, ...speak])].sort((a, b) => {
      if (a < b) return -1;
      if (a > b) return 1;
      return 0;
    });
    return (
      <div className="f languages">
        <ul>
          {
            languages.map(language => (
              <li key={language} className="language">
                <strong className="lang">{ language }</strong>
                <label>
                  <ChkBox checked={speak.includes(language)} onChange={() => this.changeLanguageCapability(language, 'speak')} />
                  <span>Speak</span>
                </label>
                <label>
                  <ChkBox checked={read.includes(language)} onChange={() => this.changeLanguageCapability(language, 'read')} />
                  <span>Read</span>
                </label>
                <label>
                  <ChkBox checked={write.includes(language)} onChange={() => this.changeLanguageCapability(language, 'write')} />
                  <span>Write</span>
                </label>
                <span className="actions">
                  <Button onClick={() => this.props.removeLanguage(language)}>
                    <CloseIcon style={{ width: '1rem' }} />
                  </Button>
                </span>
              </li>
            ))
          }
          <li>
            <Form className="language add" onSubmit={this.props.handleSubmit(this.addNewLanguage)}>
              <strong className="lang">
                <Field name="newLangugage" type="text" component={TextField} />
              </strong>
              <label>
                <Field name="speak" component={Checkbox} label="" />
                <span>Speak</span>
              </label>
              <label>
                <Field name="read" component={Checkbox} label="" />
                <span>Read</span>
                </label>
              <label>
                <Field name="write" component={Checkbox} label="" />
                <span>Write</span>
              </label>                
              <span className="actions">
                <Button raised type="submit">
                  <AddIcon style={{ width: '1rem' }} />
                </Button>
              </span>
            </Form>
          </li>
        </ul>
      </div>
    );
  }
}

const validate = (values) => {
  const errors = {};
  errors.newLangugage = required(values.newLangugage);
  if (!(values.read || values.write || values.speak)) {
    errors.read = 'one of read, write, speak is required';
    errors.write = 'one of read, write, speak is required';
    errors.speak = 'one of read, write, speak is required';
  }
  return errors;
}

const mapStateToProps = (state, props) => ({
  language: state.candidate.language,
});

const mapDispatchToProps = dispatch => ({
  addLanguageCapability: (language, capability) =>
    dispatch(addLanguageCapability(language, capability)),
  removeLanguageCapability: (language, capability) =>
    dispatch(removeLanguageCapability(language, capability)),
  removeLanguage: language => dispatch(removeLanguage(language)),
  addNewLanguage: (language, status) => dispatch(addNewLanguage(language, status)),
  reset: () => dispatch(reset()),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'languageForm', validate })(LanguageWrite));
