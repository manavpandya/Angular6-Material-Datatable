const profile = () => {
    return {
      "language": {
        "speak": [
          "Sourashtra",
          "English",
          "Tamil",
          "Hindi"
        ],
        "read": [
          "Sourashtra",
          "English",
          "Tamil",
          "Hindi"
        ],
        "write": [
          "Sourashtra",
          "English",
          "Tamil",
          "Hindi",
        ]
      },
    }
  }
  
  export default profile()