import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import { showNotification } from '../../../utils/Notifications';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';

class PreferredEmail extends Component {
  constructor(props) {
    super(props);
    this.onUpdatePreferredEmail = this.onUpdatePreferredEmail.bind(this);
  }

  onUpdatePreferredEmail(values) {
    this.props.updateProfileData({ preferred_email: values.preferred_email })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="current">{this.props.value || 'No data provided'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdatePreferredEmail)}>
            <Field name="preferred_email" type="text" component={TextField} />
          </Form>
        }
        onSubmit={() => this.props.submit('preferredEmailForm')}
        formName="preferredEmailForm"                
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    preferred_email: props.value,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'preferredEmailForm', enableReinitialize: true, destroyOnUnmount: false })(PreferredEmail));