import React from 'react';
import { reduxForm, Form, FieldArray, Field } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import IconButton from 'material-ui/IconButton';
import Button from 'material-ui/Button';
import RemoveIcon from 'material-ui-icons/Delete';
import CheckIcon from 'material-ui-icons/Check';
import CustomDatePicker from '../../../shared/compound/CustomDatePicker';

const renderSchool = ({onUpdateSchool , onDeleteSchool, fields, meta: { error, submitFailed } }) => (
  <ul>
    {
      fields.map((education, index) => (
        <li key={index} className="school-card">
          <IconButton
            className="add-school"
            onClick={() => onUpdateSchool(fields.get(index))}>
            <CheckIcon />
          </IconButton>
          <IconButton
            className="remove-school"
            onClick={() => onDeleteSchool(fields.get(index).id)}>
            <RemoveIcon />
          </IconButton>
          <div className="fields">
            <Field
              name={`${education}.school`}
              className="field"
              label="School"
              component={TextField}/>
          </div>
          <div className="fields">
            <Field
              name={`${education}.school_type`}
              className="field field-left"
              label="School Type"
              component={TextField}/>
            <Field
              name={`${education}.location`}
              className="field field-right"
              label="Location"
              component={TextField}/>
          </div>
          <div className="fields">
            <Field
              name={`${education}.degree`}
              className="field"
              label="Degree"
              component={TextField}/>
          </div>
          <div className="fields">
            <Field
              name={`${education}.grade`}
              className="field field-left"
              label="Grade"
              component={TextField}/>
            <Field
              name={`${education}.major`}
              className="field field-right"
              label="Major"
              component={TextField}/>
          </div>
          <div className="fields">
            <Field
              name={`${education}.start_date`}
              className="field field-left"
              label="Start Date"
              component={CustomDatePicker}/>
            <Field
              name={`${education}.end_date`}
              className="field field-right"
              label="End Date"
              component={CustomDatePicker}/>
          </div>
        </li>
      ))
    }
    <li>
      <Button variant="raised" onClick={() => fields.push({})}>Add New School</Button>
      {submitFailed && error && <span>{error}</span>}
    </li>
  </ul>
)

const EducationWrite = props => (
  <Form>
    <FieldArray name="schools" onUpdateSchool={props.onUpdateSchool} onDeleteSchool={props.onDeleteSchool} component={renderSchool} />
  </Form>
);

export default reduxForm({ form: 'schoolForm', enableReinitialize: true })(EducationWrite);