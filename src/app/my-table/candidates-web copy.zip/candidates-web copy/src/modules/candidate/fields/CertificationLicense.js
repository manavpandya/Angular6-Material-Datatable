import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';

import TogglePanel from './TogglePanel'
import MultiSelect from '../../../shared/basic/MultiSelect';
import { getOptions } from '../../../utils';
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class CertificationLicense extends Component {
  constructor(props) {
    super(props);
    this.onUpdateCertificationLicense = this.onUpdateCertificationLicense.bind(this);
  }

  onUpdateCertificationLicense(values) {
    this.props.updateProfileData({ certification_license: { ...this.props.value, license_and_certifications: values.licenseAndCertifications.map(licenseAndCertification => licenseAndCertification.value) } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));      
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="skills">
            {
              this.props.value && this.props.value.license_and_certifications
              && this.props.value.license_and_certifications.filter(licenseAndCertification => licenseAndCertification.value !== "").length > 0
              ? this.props.value.license_and_certifications.filter(licenseAndCertification => licenseAndCertification.value !== "").map(licenseAndCertification => 
                  <span key={licenseAndCertification.value} className="bordered-box">{licenseAndCertification.value}</span>
                )
              : 'No data provided'
            }
          </p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateCertificationLicense)}>
            <Field 
              getOptions={getOptions}
              type="Creatable"
              name="licenseAndCertifications"
              component={MultiSelect}
            />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('certificationLicenseForm')
        }}
        formName="certificationLicenseForm"
    />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    licenseAndCertifications: props.value.license_and_certifications,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),  
});

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'certificationLicenseForm', enableReinitialize: true, destroyOnUnmount: false })(CertificationLicense));