import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class CurrentLocation extends Component {
  constructor(props) {
    super(props);
    this.onUpdateCurrentLocation = this.onUpdateCurrentLocation.bind(this);
  }

  onUpdateCurrentLocation(values) {
    this.props.updateProfileData({ location_details: { ...this.props.value, current_location: values.current_location } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));      
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="current">{this.props.value.current_location || 'No data provided'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateCurrentLocation)}>
            <Field name="current_location" type="text" component={TextField} />
          </Form>
        }
        onSubmit={() => this.props.submit('currentLocationForm')}
        formName="currentLocationForm"
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    current_location: props.value.current_location,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'currentLocationForm', enableReinitialize: true, destroyOnUnmount: true })(CurrentLocation));