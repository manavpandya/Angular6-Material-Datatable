import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class PreferredMobile extends Component {
  constructor(props) {
    super(props);
    this.onUpdatePreferredMobile = this.onUpdatePreferredMobile.bind(this);
  }

  onUpdatePreferredMobile(values) {
    this.props.updateProfileData({ preferred_mobile: values.preferred_mobile })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="current">{this.props.value[1].Telephone.FormattedNumber || 'No data provided'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdatePreferredMobile)}>
            <Field name="preferred_mobile" type="text" component={TextField} />
          </Form>
        }
        onSubmit={() => this.props.submit('preferredMobileForm')}
        formName="preferredMobileForm"        
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    preferred_mobile: props.value,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'preferredMobileForm', enableReinitialize: true, destroyOnUnmount: false })(PreferredMobile));