import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class Patent extends Component {
  constructor(props) {
    super(props);
    this.onUpdatePatents = this.onUpdatePatents.bind(this);
  }

  onUpdatePatents(values) {
    this.props.updateProfileData({ patent: {
      description: values.description,
      inventors: values.inventors,
      patent_details: values.patentDetails,
      patent_title: values.patentTitle,
    } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <div className="skills">
            {
              this.props.value && this.props.value.description && this.props.value.inventors
              && this.props.value.patent_details && this.props.value.patent_title
                ? (
                  <div>
                    {
                      this.props.value.description && <p>{`Description: ${this.props.value.description}`}</p>
                    }
                    {
                      this.props.value.inventors && <p>{`Inventors: ${this.props.value.inventors}`}</p>
                    }
                    {
                      this.props.value.patent_details && <p>{`Patent Details: ${this.props.value.patent_details}`}</p>
                    }
                    {
                      this.props.value.patent_title && <p>{`Patent Title: ${this.props.value.patent_title}`}</p>
                    }
                  </div>
                )
                : 'No data available'
            }
          </div>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdatePatents)}>
            <Field name="description" label="Description" className="patent-field" component={TextField} />
            <Field name="inventors" label="Inventors" className="patent-field" component={TextField} />
            <Field name="patentDetails" label="Patent Details" className="patent-field" component={TextField} />
            <Field name="patentTitle" label="Patent Title" className="patent-field" component={TextField} />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('patentsForm')
        }}
        formName="patentsForm"
    />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    description: props.value.description,
    inventors: props.value.inventors,
    patentDetails: props.value.patent_details,
    patentTitle: props.value.patent_title,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),  
});

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'patentsForm', enableReinitialize: true, destroyOnUnmount: false })(Patent));