import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class Name extends Component {
  constructor(props) {
    super(props);
    this.onUpdateName = this.onUpdateName.bind(this);
  }

  onUpdateName(values) {
    this.props.updateProfileData({ 
      contact_information: { 
        ...this.props.value, 
        person_name: { 
          ...this.props.value.person_name, 
          FormattedName: values.personName 
        } 
      }
    }).catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="contact">{this.props.value.person_name.FormattedName || 'No data'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateName)}>
            <Field name="personName" component={TextField} />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('nameForm')
        }}
        formName="nameForm"
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    personName: props.value.person_name.FormattedName,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'nameForm', enableReinitialize: true, destroyOnUnmount: false })(Name));