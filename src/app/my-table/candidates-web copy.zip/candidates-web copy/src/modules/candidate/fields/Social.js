import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, reset } from 'redux-form';
import { Button } from 'material-ui';
import CloseIcon from 'material-ui-icons/Close';
import AddIcon from 'material-ui-icons/Add';
import TogglePanel from './TogglePanel'
import { updateProfileData ,
  addNewSocialLink,
  removeSocialLink
} from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';
import { required } from '../../../utils/validators';
import { TextField } from 'redux-form-material-ui';

class Social extends Component {
  constructor(props) {
    super(props);
    this.onUpdateSocialWrite = this.onUpdateSocialWrite.bind(this);
    this.addNewSocialLink = this.addNewSocialLink.bind(this);
  }

  onUpdateSocialWrite() {
    this.props.updateProfileData({ contact_information: { ...this.props.value, social_network_links: this.props.social_network_links }})
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  addNewSocialLink(values) {
    this.props.addNewSocialLink(values.socialLink);
    this.props.reset();
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="preferred-contact">
            {
              this.props.value.social_network_links && this.props.value.social_network_links.length > 0 
                ? (
                  this.props.value.social_network_links.map(link => 
                    <span key={link} className="bordered-box">
                      {link}
                    </span>
                  )
                )
                : 'No data'
            }
          </p>
        }
        edit={
          <div className="f mobiles">
            <ul>
              {
                this.props.social_network_links.map(link => 
                  <li className="mobile-wrapper">
                    <strong className="mobile">{ link }</strong>
                    <span className="actions">
                      <Button onClick={() => this.props.removeSocialLink(link)}>
                        <CloseIcon style={{ width: '1rem' }} />
                      </Button>
                    </span>
                  </li>
                )
              }
              <li>
                <Form onSubmit={this.props.handleSubmit(this.addNewSocialLink)}>
                  <Field
                    name="socialLink"
                    type="text"
                    className="mobile"
                    component={TextField}
                  />
                  <span className="actions">
                    <Button raised type="submit">
                      <AddIcon style={{ width: '1rem' }} />
                    </Button>
                  </span>
                </Form>
              </li>
            </ul>
          </div>
        }
        onSubmit={() => {
          this.onUpdateSocialWrite();
        }}
        formName="socialWriteForm"
      />
    )
  }
};

const validate = (values, props) => {
  const errors = {};
  errors.socialLink = required(values.socialLink);
  if (props.social_network_links.includes(values.socialLink)) {
    errors.socialLink = 'duplicate';
  }
  return errors;
}

const mapStateToProps = (state, props) => ({
  social_network_links: state.candidate.social_network_links, 
});

const mapDispatchToProps = dispatch => ({
  updateProfileData: data => dispatch(updateProfileData(data)),
  removeSocialLink: link => dispatch(removeSocialLink(link)),
  addNewSocialLink: link => dispatch(addNewSocialLink(link)),
  reset: () => dispatch(reset()),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'socialWriteForm', enableReinitialize: true, destroyOnUnmount: false , validate})(Social));