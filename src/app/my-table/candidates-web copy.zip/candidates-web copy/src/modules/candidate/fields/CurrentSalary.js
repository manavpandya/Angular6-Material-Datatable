import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class CurrentSalary extends Component {
  constructor(props) {
    super(props);
    this.onUpdateCurrentSalary = this.onUpdateCurrentSalary.bind(this);
  }

  onUpdateCurrentSalary(values) {
    this.props.updateProfileData({ personal_information: { ...this.props.value, current_salary: values.current_salary }})
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));      
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="current">{this.props.value.current_salary || 'No data'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateCurrentSalary)}>
            <Field name="current_salary" component={TextField} />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('currentSalaryForm')
        }}
        formName="currentSalaryForm"
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    current_salary: props.value.current_salary,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'currentSalaryForm', enableReinitialize: true, destroyOnUnmount: false })(CurrentSalary));