import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class ExpectedSalary extends Component {
  constructor(props) {
    super(props);
    this.onUpdateExpectedSalary = this.onUpdateExpectedSalary.bind(this);
  }

  onUpdateExpectedSalary(values) {
    this.props.updateProfileData({ personal_information: { ...this.props.value, required_salary: values.expected_salary }})
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));      
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="current">{this.props.value.required_salary || 'No data'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateExpectedSalary)}>
            <Field name="expected_salary" component={TextField} />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('expectedSalaryForm')
        }}
        formName="expectedSalaryForm"
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    expected_salary: props.value.required_salary,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'expectedSalaryForm', enableReinitialize: true, destroyOnUnmount: false })(ExpectedSalary));