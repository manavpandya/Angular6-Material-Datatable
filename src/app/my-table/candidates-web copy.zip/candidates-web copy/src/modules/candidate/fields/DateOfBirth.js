import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import CustomDatePicker from '../../../shared/compound/CustomDatePicker';
import { showNotification } from '../../../utils/Notifications';

class DateOfBirth extends Component {
  constructor(props) {
    super(props);
    this.onUpdateDateOfBirth = this.onUpdateDateOfBirth.bind(this);
  }

  onUpdateDateOfBirth(values) {
    this.props.updateProfileData({ personal_information: { ...this.props.value, date_of_birth: values.dateOfBirth } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="contact">{this.props.value.date_of_birth || 'No data'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateDateOfBirth)}>
            <Field name="dateOfBirth" component={CustomDatePicker} />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('dateOfBirthForm')
        }}
        formName="dateOfBirthForm"
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    dateOfBirth: props.value.date_of_birth,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'dateOfBirthForm', enableReinitialize: true, destroyOnUnmount: false })(DateOfBirth));