import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class Availability extends Component {
  constructor(props) {
    super(props);
    this.onUpdateAvailability = this.onUpdateAvailability.bind(this);
  }

  onUpdateAvailability(values) {
    this.props.updateProfileData({ location_details: { ...this.props.value, availability: values.availability } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));  
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="current">{this.props.value.availability || 'No data provided'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateAvailability)}>
            <Field name="availability" type="text" component={TextField} />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('availabilityForm');
        }}
        formName="availabilityForm"
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    availability: props.value.availability,
  }
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'availabilityForm', enableReinitialize: true, destroyOnUnmount: true })(Availability));