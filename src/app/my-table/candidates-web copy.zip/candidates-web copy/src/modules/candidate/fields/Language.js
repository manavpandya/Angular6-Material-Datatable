import React, { Component } from 'react';
import { connect } from 'react-redux';
import TogglePanel from './TogglePanel'
import LanguageReadOnly from './LanguageReadOnly'
import LanguageWrite from './LanguageWrite'

import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class Language extends Component {
  constructor(props) {
    super(props);
    this.onUpdateLanguage = this.onUpdateLanguage.bind(this);
  }

  onUpdateLanguage() {
    this.props.updateProfileData({ language: this.props.language })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={ <LanguageReadOnly value={ this.props.value } /> }
        edit={ <LanguageWrite value={ this.props.value } /> }
        onSubmit={this.onUpdateLanguage}
        formName="languageForm"
      />
    )
  }
};

const mapStateToProps = state => ({
  language: state.candidate.language,
});

const mapDispatchToProps = dispatch => ({
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(Language);
