import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, reset } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import { Button } from 'material-ui';
import CloseIcon from 'material-ui-icons/Close';
import AddIcon from 'material-ui-icons/Add';
import { withTranslate } from 'react-redux-multilingual';

import TogglePanel from './TogglePanel'
import { updateProfileData, removeEmail, addNewEmail } from '../redux/actions';
import { required, matchRegEx, email } from '../../../utils/validators';
import { showNotification } from '../../../utils/Notifications';

let invalidEmail = ''

class Email extends Component {
  constructor(props) {
    super(props);
    this.onUpdateEmail = this.onUpdateEmail.bind(this);
    this.addNewEmail = this.addNewEmail.bind(this);
  }

  componentDidMount() {
    invalidEmail = this.props.translate('invalidEmail');
  }

  onUpdateEmail() {
    this.props.updateProfileData({ contact_information: { ...this.props.value, email: this.props.email } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));      
  }

  addNewEmail(values) {
    this.props.addNewEmail(values.email);
    this.props.reset();
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="preferred-contact">
            {
              this.props.email && this.props.email.length > 0 
              && this.props.email.filter(email => email !== "").length > 0
                ? (
                  this.props.email.filter(email => email !== "").map(email => 
                    <span key={email} className="bordered-box">
                      {email}
                    </span>
                  )
                )
                : 'No data'
            }
          </p>
        }
        edit={
          <div className="f mobiles">
            <ul>
              {
                this.props.email.map(email => 
                  <li className="mobile-wrapper">
                    <strong className="email">{ email }</strong>
                    <span className="actions">
                      <Button onClick={() => this.props.removeEmail(email)}>
                        <CloseIcon style={{ width: '1rem' }} />
                      </Button>
                    </span>
                  </li>
                )
              }
              <li>
                <Form onSubmit={this.props.handleSubmit(this.addNewEmail)}>
                  <Field
                    name="email"
                    type="text"
                    className="email"
                    component={TextField}
                  />
                  <span className="actions">
                    <Button raised type="submit">
                      <AddIcon style={{ width: '1rem' }} />
                    </Button>
                  </span>
                </Form>
              </li>
            </ul>
          </div>
        }
        onSubmit={() => {
          this.onUpdateEmail();
        }}
        formName="emailForm"
      />
    )
  }
}

const validate = (values, props) => {
  const errors = {};
  errors.email = required(values.email);
  if (!errors.email) errors.email = !matchRegEx(values.email, email) && invalidEmail;
  if (props.email.includes(values.email)) {
    errors.email = 'duplicate';
  }
  return errors;
}

Email.propTypes = {
  translate: PropTypes.func,
};

Email.defaultProps = {
  translate: () => {},
};

const mapStateToProps = (state, props) => ({
  email: state.candidate.email, 
});

const mapDispatchToProps = dispatch => ({
  updateProfileData: data => dispatch(updateProfileData(data)),
  removeEmail: email => dispatch(removeEmail(email)),
  addNewEmail: email => dispatch(addNewEmail(email)),
  reset: () => dispatch(reset()),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'emailForm', enableReinitialize: true, destroyOnUnmount: false, validate })(withTranslate(Email)));