import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, reset } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import { Button } from 'material-ui';
import CloseIcon from 'material-ui-icons/Close';
import AddIcon from 'material-ui-icons/Add';
import { withTranslate } from 'react-redux-multilingual';

import TogglePanel from './TogglePanel'
import { updateProfileData, removeMobile, addNewMobile } from '../redux/actions';
import { required, matchRegEx, phone } from '../../../utils/validators';
import { showNotification } from '../../../utils/Notifications';

let invalidMobile = '';

class Mobile extends Component {
  constructor(props) {
    super(props);
    this.onUpdateMobile = this.onUpdateMobile.bind(this);
    this.addNewMobile = this.addNewMobile.bind(this);
  }

  componentDidMount() {
    invalidMobile = this.props.translate('invalidMobile');
  }

  onUpdateMobile() {
    this.props.updateProfileData({ contact_information: { ...this.props.value, mobile: this.props.mobile } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  addNewMobile(values) {
    this.props.addNewMobile(values.mobile);
    this.props.reset();
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="preferred-contact">
            {
              this.props.mobile && this.props.mobile.length > 0 
              && this.props.mobile.filter(mobile => mobile !== "").length > 0
                ? (
                  this.props.mobile.filter(mobile => mobile !== "").map(mobile => 
                    <span key={mobile} className="bordered-box">
                      {mobile}
                    </span>
                  )
                )
                : 'No data'
            }
          </p>
        }
        edit={
          <div className="f mobiles">
            <ul>
              {
                this.props.mobile.map(mobile => 
                  <li className="mobile-wrapper">
                    <strong className="mobile">{ mobile }</strong>
                    <span className="actions">
                      <Button onClick={() => this.props.removeMobile(mobile)}>
                        <CloseIcon style={{ width: '1rem' }} />
                      </Button>
                    </span>
                  </li>
                )
              }
              <li>
                <Form onSubmit={this.props.handleSubmit(this.addNewMobile)}>
                  <Field
                    name="mobile"
                    type="text"
                    className="mobile"
                    component={TextField}
                  />
                  <span className="actions">
                    <Button raised type="submit">
                      <AddIcon style={{ width: '1rem' }} />
                    </Button>
                  </span>
                </Form>
              </li>
            </ul>
          </div>
        }
        onSubmit={() => {
          this.onUpdateMobile();
        }}
        formName="mobileForm"
      />
    )
  }
}

const validate = (values, props) => {
  const errors = {};
  errors.mobile = required(values.mobile);
  if (!errors.mobile) errors.mobile = !matchRegEx(values.mobile, phone) && invalidMobile;
  if (props.mobile.includes(values.mobile)) {
    errors.mobile = 'duplicate';
  }
  return errors;
}

const mapStateToProps = (state, props) => ({
  mobile: state.candidate.mobile, 
});

const mapDispatchToProps = dispatch => ({
  updateProfileData: data => dispatch(updateProfileData(data)),
  removeMobile: mobile => dispatch(removeMobile(mobile)),
  addNewMobile: mobile => dispatch(addNewMobile(mobile)),
  reset: () => dispatch(reset()),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'mobileForm', enableReinitialize: true, destroyOnUnmount: false, validate })(withTranslate(Mobile)));