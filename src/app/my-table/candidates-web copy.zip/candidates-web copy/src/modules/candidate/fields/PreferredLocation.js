import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class PreferredLocation extends Component {
  constructor(props) {
    super(props);
    this.onUpdatePreferredLocation = this.onUpdatePreferredLocation.bind(this);
  }

  onUpdatePreferredLocation(values) {
    this.props.updateProfileData({ location_details: { ...this.props.value, preferred_location: values.preferred_location } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="current">{this.props.value.preferred_location || 'No data provided'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdatePreferredLocation)}>
            <Field name="preferred_location" type="text" component={TextField} />
          </Form>
        }
        onSubmit={() => this.props.submit('preferredLocationForm')}
        formName="preferredLocationForm"                                
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    preferred_location: props.value.preferred_location,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'preferredLocationForm', enableReinitialize: true, destroyOnUnmount: false })(PreferredLocation));