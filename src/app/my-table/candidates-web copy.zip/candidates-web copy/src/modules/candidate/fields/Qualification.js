import React, { Component } from 'react';
import _ from 'lodash';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import TogglePanel from './TogglePanel'
import MultiSelect from '../../../shared/basic/MultiSelect';
import { getOptions } from '../../../utils';
import { 
  updateCandidateSkills,
  deleteCandidateSkills
 } from '../redux/actions';
import { sortAll } from '../../../utils/index';

class Qualification extends Component {
  constructor(props) {
    super(props);
    this.onUpdateQualifications = this.onUpdateQualifications.bind(this);
    this.deleteDuplicateSkills = this.deleteDuplicateSkills.bind(this);    
  }

  componentWillReceiveProps(nextProps) {
    this.deleteDuplicateSkills();    
  }

  deleteDuplicateSkills(addedSkills)
  {
    if(addedSkills)
    {
      const profileId = this.props && this.props.loggedUserProfile && this.props.loggedUserProfile.profile && this.props.loggedUserProfile.profile.id;        
      const uniqSkills = _.uniqBy(addedSkills, 'display_value');
      const idsToRemove = [];
      addedSkills.map(skill => {
        if (!_.find(uniqSkills, { id: skill.id }))
        return idsToRemove.push(skill.id);
      });
      if(idsToRemove && idsToRemove !== null)
      {
        this.props.deleteCandidateSkills(profileId,Object.assign({ "skill_ids": idsToRemove}));
      }
    }
  }


  onUpdateQualifications(values) {
    const profileId = this.props && this.props.loggedUserProfile && this.props.loggedUserProfile.profile && this.props.loggedUserProfile.profile.id;    
    this.deleteDuplicateSkills(values.skills);    
    const skillIds = _.map(values.skills,'id').filter(n => n);
    const oldSkills = _.map(this.props.value.skills,'id').filter(n => n);
    const diffDeletedSkills = _.difference(oldSkills,skillIds);
    const diffAddedSkills = _.difference(skillIds,oldSkills);
    let promise;
    if(!_.isEmpty(diffDeletedSkills)){
      promise = this.props.deleteCandidateSkills(profileId,Object.assign({ "skill_ids": diffDeletedSkills}));
    }
    if(!_.isEmpty(diffAddedSkills)){
      promise =  this.props.updateCandidateSkills(profileId,Object.assign({},{"skill_ids": diffAddedSkills }));
    }
  }

  render() {
    sortAll(this.props.value.skills,'display_value');
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="skills">
            {
              this.props.value && this.props.value.skills && this.props.value.skills.length > 0            
                ? this.props.value.skills.map(skill => 
                  <span key={skill.display_value} className="bordered-box">{skill.display_value}</span>
                )
                : 'No data provided'
            }
          </p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateQualifications)}>
            <Field 
              getOptions={getOptions}
              valueKey="display_value"
              labelKey="display_value"
              type="Async"
              name="skills"
              backspaceRemoves={false}
              clearable={false}                            
              component={MultiSelect}
            />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('qualificationsForm')
        }}
        formName="qualificationsForm"
    />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    skills: props.value.skills,
  },
  loggedUserProfile: state.candidate.loggedUserProfile,
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateCandidateSkills: (profileId,skillId) => dispatch(updateCandidateSkills(profileId,skillId)),  
  deleteCandidateSkills: (profileId,skillId) => dispatch(deleteCandidateSkills(profileId,skillId)),  
});

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'qualificationsForm', enableReinitialize: true, destroyOnUnmount: false })(Qualification));