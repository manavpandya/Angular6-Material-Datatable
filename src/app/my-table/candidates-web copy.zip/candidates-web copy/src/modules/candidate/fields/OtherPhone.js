import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, reset } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import { Button } from 'material-ui';
import CloseIcon from 'material-ui-icons/Close';
import AddIcon from 'material-ui-icons/Add';
import { withTranslate } from 'react-redux-multilingual';

import TogglePanel from './TogglePanel'
import { updateProfileData, removeOtherPhoneNo, addNewOtherPhoneNo } from '../redux/actions';
import { required, matchRegEx, phone } from '../../../utils/validators';
import { showNotification } from '../../../utils/Notifications';

let invalidMobile = '';

class OtherPhoneNo extends Component {
  constructor(props) {
    super(props);
    this.onUpdateOtherPhoneNo = this.onUpdateOtherPhoneNo.bind(this);
    this.addNewOtherPhoneNo = this.addNewOtherPhoneNo.bind(this);
  }

  componentDidMount() {
    invalidMobile = this.props.translate('invalidMobile');
  }

  onUpdateOtherPhoneNo() {
    this.props.updateProfileData({ contact_information: { ...this.props.value, other_phone_no: this.props.otherPhoneNo } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  addNewOtherPhoneNo(values) {
    this.props.addNewOtherPhoneNo(values.otherPhoneNo);
    this.props.reset();
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="preferred-contact">
            {
              this.props.otherPhoneNo && this.props.otherPhoneNo.length > 0 
              && this.props.otherPhoneNo.filter(otherPhoneNo => otherPhoneNo !== "").length > 0
                ? (
                  this.props.otherPhoneNo.filter(otherPhoneNo => otherPhoneNo !== "").map(otherPhoneNo => 
                    <span key={otherPhoneNo} className="bordered-box">
                      {otherPhoneNo}
                    </span>
                  )
                )
                : 'No data'
            }
          </p>
        }
        edit={
          <div className="f mobiles">
            <ul>
              {
                this.props.otherPhoneNo.map(otherPhoneNo => 
                  <li className="mobile-wrapper">
                    <strong className="mobile">{ otherPhoneNo }</strong>
                    <span className="actions">
                      <Button onClick={() => this.props.removeOtherPhoneNo(otherPhoneNo)}>
                        <CloseIcon style={{ width: '1rem' }} />
                      </Button>
                    </span>
                  </li>
                )
              }
              <li>
                <Form onSubmit={this.props.handleSubmit(this.addNewOtherPhoneNo)}>
                  <Field
                    name="otherPhoneNo"
                    type="text"
                    className="mobile"
                    component={TextField}
                  />
                  <span className="actions">
                    <Button raised type="submit">
                      <AddIcon style={{ width: '1rem' }} />
                    </Button>
                  </span>
                </Form>
              </li>
            </ul>
          </div>
        }
        onSubmit={() => {
          this.onUpdateOtherPhoneNo();
        }}
        formName="otherPhoneNoForm"
      />
    )
  }
}

const validate = (values, props) => {
  const errors = {};
  errors.otherPhoneNo = required(values.otherPhoneNo);
  if (!errors.otherPhoneNo) errors.otherPhoneNo = !matchRegEx(values.otherPhoneNo, phone) && invalidMobile;
  if (props.otherPhoneNo.includes(values.otherPhoneNo)) {
    errors.otherPhoneNo = 'duplicate';
  }
  return errors;
}

const mapStateToProps = (state, props) => ({
  otherPhoneNo: state.candidate.otherPhoneNo, 
});

const mapDispatchToProps = dispatch => ({
  updateProfileData: data => dispatch(updateProfileData(data)),
  removeOtherPhoneNo: otherPhoneNo => dispatch(removeOtherPhoneNo(otherPhoneNo)),
  addNewOtherPhoneNo: otherPhoneNo => dispatch(addNewOtherPhoneNo(otherPhoneNo)),
  reset: () => dispatch(reset()),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'otherPhoneNoForm', enableReinitialize: true, destroyOnUnmount: false, validate })(withTranslate(OtherPhoneNo)));