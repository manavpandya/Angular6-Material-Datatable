import React, { Component } from 'react';
import _ from 'lodash'

export default class LanguageReadOnly extends Component {
  constructor(props) {
    super(props);
    this.state = {
      languages: this.dataToViewData(this.props.value)
    }
  }

  canSpeak = (speak, lang) => {
    return _.includes(speak, lang)
  }

  canRead = (read, lang) => {
    return _.includes(read, lang)
  }

  canWrite = (write, lang) => {
    return _.includes(write, lang)
  }

  dataToViewData = (data) => {
    let languages = []
    _.union(data.speak, data.read, data.write).forEach((l) =>
      languages.push({
        language: l,
        canSpeak: this.canSpeak(data.speak, l),
        canRead: this.canRead(data.read, l),
        canWrite: this.canWrite(data.write, l)
      })
    )
    return languages
  }

  viewDataToData = (data) => {

  }

  render() {
    let { languages } = this.state
    return (
      <div className="f languages readonly">
        <ul>
          {
            languages.map(
              (l, i) =>
              <li key={i} className="language">
                <strong className="lang">{ l.language }</strong>
                { l.canSpeak && <span title="Speak" className="speak">S</span> }
                { l.canRead && <span title="Read" className="read">R</span> }
                { l.canWrite && <span title="Write" className="write">W</span> }
              </li>
            )
          }
        </ul>
      </div>
    )
  }
};
