import React, { Component, Fragment } from 'react'
import _ from 'lodash'
import BlockUI from 'react-block-ui';
import { connect } from 'react-redux';

import TogglePanel from './TogglePanel'
import fieldmap from './FieldMap'

const getConfig = (groups, group) => {
  let g = _.filter(groups, { name: group })
  return (g.length > 0) ? g[0] : {}
}

const renderComponent = (component, props, label, key) => {
  const Component = component
  return <Component value={ props } key={ key } label={ label } />
}

class FieldGroupTab extends Component {
  render() {
    let { data, config, match } = this.props;
    const group = getConfig(config ? config.groups : [], match.params.group);
    return (
      // <BlockUI tag="div" blocking={this.props.profileLoading}>
        <div>
        { 
          group && group.fieldsets
          ? group.fieldsets.map((fieldset, i) => {
              return <Fragment key={i}>
                {
                  fieldset.legend ?
                  <h3>{ fieldset.legend }</h3> : null
                }
                {
                  fieldset.fields &&
                  fieldset.fields.map((field, i) => {
                    return (
                      fieldmap[field.key]
                        ? renderComponent(fieldmap[field.key], data[field.data], field.label, i)
                        : <TogglePanel key={ i } title={ field.label } />
                    ) 
                  })
                }
              </Fragment>
            })
          : <span className="toggle-panel" />
        }
        </div>
      // </BlockUI>
    )
  }
};

const mapStateToProps = state => ({
  profileLoading: state.candidate.profileLoading,
})

export default connect(mapStateToProps)(FieldGroupTab);