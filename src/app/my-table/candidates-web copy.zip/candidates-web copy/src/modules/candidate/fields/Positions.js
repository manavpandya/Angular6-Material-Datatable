import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';

import TogglePanel from './TogglePanel'
import MultiSelect from '../../../shared/basic/MultiSelect';
import { getOptions } from '../../../utils';
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';
import { getJobsMatchingTitleOfProfile } from '../../home-page/redux/actions';

class Position extends Component {
  constructor(props) {
    super(props);
    this.onUpdatePositions = this.onUpdatePositions.bind(this);
  }

  onUpdatePositions(values) {
    const profileId = this.props.loggedUserProfile && this.props.loggedUserProfile.profile ? this.props.loggedUserProfile.profile.id : null;
    this.props.updateProfileData({ experience_details: { ...this.props.value, all_job_titles: values.allJobTitles.map(jobTitle => jobTitle.value) } }).then(() => {
      this.props.getJobsMatchingTitleOfProfile(profileId,1,10);
    }).catch(() => showNotification('There was a problem saving the changes', 'error', 8000)); 
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="skills">
            {
              this.props.value && this.props.value.all_job_titles && this.props.value.all_job_titles.length > 0
                ? this.props.value.all_job_titles.map(jobTitle => 
                    <span key={jobTitle.value} className="bordered-box">{jobTitle.value}</span>
                  )
                : 'No data provided'
            }
          </p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdatePositions)}>
            <Field 
              getOptions={getOptions}
              type="Creatable"
              name="allJobTitles"
              component={MultiSelect}
            />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('positionsForm')
        }}
        formName="positionsForm"
    />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    allJobTitles: props.value.all_job_titles,
  },
  loggedUserProfile: state.candidate.loggedUserProfile,  
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),  
  getJobsMatchingTitleOfProfile: (profileId,pageNo,perPage) => dispatch(getJobsMatchingTitleOfProfile(profileId,pageNo,perPage)),
});

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'positionsForm', enableReinitialize: true, destroyOnUnmount: false })(Position));