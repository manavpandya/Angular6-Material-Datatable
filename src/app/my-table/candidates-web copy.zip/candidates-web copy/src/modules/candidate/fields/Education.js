import _ from 'lodash';
import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { submit } from 'redux-form';
import TogglePanel from './TogglePanel'
import EducationWrite from './EducationWrite';
import { 
  updateCandidateProfileData,
  addCandidateProfileData,
  removeCandidateProfileData
 } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class School extends Component {
  constructor(props) {
    super(props);
    this.onUpdateSchool = this.onUpdateSchool.bind(this);
    this.onDeleteSchool = this.onDeleteSchool.bind(this);
  }

  onUpdateSchool(values) {
    const profileId = this.props && this.props.loggedUserProfile && this.props.loggedUserProfile.profile && this.props.loggedUserProfile.profile.id;    
    const schoolDetail = values;
    if(schoolDetail)
    {
      if (schoolDetail.id) {
        this.props.updateCandidateProfileData(profileId,schoolDetail.id,schoolDetail);
      } else {
        _.isEmpty(schoolDetail) ? showNotification("Empty value is not allowed",'error',8000) : this.props.addCandidateProfileData(profileId,schoolDetail)
      }
    }
  }

  onDeleteSchool(schoolId)
  {
    const profileId = this.props && this.props.loggedUserProfile && this.props.loggedUserProfile.profile && this.props.loggedUserProfile.profile.id;    
    if(schoolId)
    {
      this.props.removeCandidateProfileData(profileId,schoolId);
    }
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="education">
            {
              this.props.value && this.props.value.length > 0
                ? this.props.value.map(educationDetail => 
                    <span key={educationDetail.school} className="bordered-box">{educationDetail.school}</span>
                  )
                : 'No data provided'
            }
          </p>
        }
        edit={
          <EducationWrite
            initialValues={{
              schools: this.props.value  
            }}
            schools={this.props.value}
            onUpdateSchool={this.onUpdateSchool}
            onDeleteSchool={this.onDeleteSchool}
          />
        }
        formName="schoolForm"
      />
    )
  }
}

School.propTypes = {
  loggedUserProfile: PropTypes.objectOf(PropTypes.any),
};

School.defaultProps = {
  loggedUserProfile: {},
};

const mapStateToProps = state =>({
  loggedUserProfile: state.candidate.loggedUserProfile,  
})

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateCandidateProfileData: (profileId,id,data) => dispatch(updateCandidateProfileData(profileId,id,data)),
  addCandidateProfileData: (profileId,data) => dispatch(addCandidateProfileData(profileId,data)),
  removeCandidateProfileData: (profileId,id) => dispatch(removeCandidateProfileData(profileId,id)),
})

export default connect(mapStateToProps, mapDispatchToProps)(School);