import Language from './Language'
import Social from './Social'
import Email from './Email'
import Name from './Name'
import Mobile from './Mobile'
import OtherPhone from './OtherPhone'
import CurrentSalary from './CurrentSalary'
import Expectedsalary from './Expectedsalary'
import PreferredMobile from './PreferredMobile'
import PreferredEmail from './PreferredEmail'
import Education from './Education'
import Qualification from './Qualification'
// import Licenses from './Licenses'
// import Certificates from './Certificates'
import CertificationLicense from './CertificationLicense';
import Patents from './Patents';
import Publications from './Publications';
import Events from './Events';
import DateOfBirth from './DateOfBirth'
import Nationality from './Nationality'
import Gender from './Gender'
import Positions from './Positions'
import Availability from './Availability';
import WebAddress from './WebAddress';
import CurrentLocation from './CurrentLocation';
import PreferredLocation from './PreferredLocation';

const fieldmap = {
  person_name: Name,
  date_of_birth: DateOfBirth,
  gender: Gender,
  nationality: Nationality,
  mobile: Mobile,
  other_phone: OtherPhone,
  email: Email,
  internet_web_address: WebAddress,
  social: Social,
  school: Education,
  all_job_titles: Positions,
  skills: Qualification,
  language: Language,
  license_and_certifications: CertificationLicense,
  patents: Patents,
  publication_history: Publications,
  speaking_events_history: Events,
  availability: Availability,
  current_salary: CurrentSalary,
  expected_salary: Expectedsalary,
  preferred_mobile: PreferredMobile,
  preferred_email: PreferredEmail,
  current_location: CurrentLocation,
  preferred_location: PreferredLocation,
  // licenses: Licenses,
  // certificates: Certificates,
}

export default fieldmap
