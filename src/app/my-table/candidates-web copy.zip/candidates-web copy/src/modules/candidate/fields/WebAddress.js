import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class WebAddress extends Component {
  constructor(props) {
    super(props);
    this.onUpdateWebAddress = this.onUpdateWebAddress.bind(this);
  }

  onUpdateWebAddress(values) {
    this.props.updateProfileData({ internet_web_address: values.internet_web_address })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="current">{this.props.value || 'No data provided'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateWebAddress)}>
            <Field name="internet_web_address" type="text" component={TextField} />
          </Form>
        }
        onSubmit={() => this.props.submit('webAddressForm')}
        formName="webAddressForm"                        
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    internet_web_address: props.value,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'webAddressForm', enableReinitialize: true, destroyOnUnmount: false })(WebAddress));