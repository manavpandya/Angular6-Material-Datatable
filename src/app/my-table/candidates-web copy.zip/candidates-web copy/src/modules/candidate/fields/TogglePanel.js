import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import EditIcon from 'material-ui-icons/Edit'
import SaveIcon from 'material-ui-icons/Check'
import Button from 'material-ui/Button'
import c from 'classnames'
import BlockUI from 'react-block-ui';

import { changeMountedForm , changeMountedProfileForm } from '../redux/actions';

class TogglePanel extends Component {
  edit = () => {
    this.props.changeMountedForm(this.props.formName);
    this.props.changeMountedProfileForm(this.props.formName);
  }

  save = () => {
    this.props.changeMountedForm('');
  }

  render() {
    return (
      <BlockUI tag="div" blocking={(this.props.mountedProfileForm !== this.props.formName) && this.props.profileLoading}>
        <div className={ c('toggle-panel', { 'edit': (this.props.mountedForm === this.props.formName) } )}>
          <header>
            <h4>{ this.props.title }</h4>
          </header>
          <div>{ this.props.mountedForm !== this.props.formName ? this.props.read : this.props.edit }</div>
          { 
            this.props.mountedForm !== this.props.formName
            ? (
              <footer className="readonly">
                <Button onClick={ this.edit }> <EditIcon /> </Button>
              </footer>
            )
            : (
              <footer>
                <Button
                  raised
                  color="primary"
                  onClick={() => { 
                    Promise.resolve(this.props.onSubmit())
                      .then(() => this.save())
                  }}
                >
                  <SaveIcon />
                </Button>
              </footer>
            )
          }
        </div>
      </BlockUI>
    )
  }
};

TogglePanel.propTypes = {
  title: PropTypes.string,
  read: PropTypes.oneOfType([PropTypes.string, PropTypes.element, PropTypes.arrayOf(PropTypes.element)]),
  edit: PropTypes.oneOfType([PropTypes.string, PropTypes.element, PropTypes.arrayOf(PropTypes.element)]),
  onSubmit: PropTypes.func,
}

TogglePanel.defaultProps = {
  title: '',
  read: <div />,
  edit: <div />,
  onSubmit: () => {},
}

const mapStateToProps = state => ({
  mountedForm: state.candidate.mountedForm,
  mountedProfileForm: state.candidate.mountedProfileForm,
});

const mapDispatchToProps = dispatch => ({
  changeMountedForm: formName => dispatch(changeMountedForm(formName)),
  changeMountedProfileForm: formName => dispatch(changeMountedProfileForm(formName)),
})

export default connect(mapStateToProps, mapDispatchToProps)(TogglePanel);
