import React, { Component, Fragment } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Button from 'material-ui/Button';
import TextField from 'material-ui/TextField';
import { Form, Field, reduxForm } from 'redux-form';
import {
  getSearchedJobs,
  flushSearchedJobs
} from '../../home-page/redux/actions';
import { showNotification } from '../../../utils/Notifications';
import { withRouter } from 'react-router';
import RegularSelect from '../../../shared/basic/RegularSelect';
import CustomDatePicker from '../../../shared/compound/CustomDatePicker';
import { MenuItem } from 'material-ui/Menu';
import Dialog from 'material-ui/Dialog';

const textFieldStyle = {
  width: 'auto',
  margin: '0 0.5rem',
  fontWeight: 'bold',
  minWidth: 'auto',
  textAlign: 'center'
}

class CandidatesSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      selectedValue: 'PleaseSelect'
    }
    this.getSearchedJob = this.getSearchedJob.bind(this);
    this.resetForm = this.resetForm.bind(this);
  }


  openSearchForm = () => {
    this.setState({open: true})
  }

  closeSearchForm = () => {
    this.setState({open: false})
  }

  resetForm()
  {
    localStorage.setItem('job_type','');
    localStorage.setItem('job_key', '');
    localStorage.setItem('job_location', '');
    localStorage.setItem('job_date', '');
    this.setState({open: false})
    this.props.getSearchedJobs();
  }

  getSearchedJob(searchData)
  {
    if(searchData)
    {
      localStorage.setItem('job_type', searchData.employmenttype === 'PleaseSelect' ? '' : searchData.employmenttype);
      localStorage.setItem('job_key', searchData.designation || '');
      localStorage.setItem('job_location', searchData.location || '');
      localStorage.setItem('job_date', searchData.date || '');
      const { employmenttype , designation ,location ,date  } = searchData;
      this.props.getSearchedJobs(employmenttype,designation,location,date).then(() => {
          this.props.history.push('/candidate/search');
          this.setState({open: false});
        }).catch((err) => {
          showNotification(err, 'error', 8000);
        });
      this.props.flushSearchedJobs();
      this.props.history.push('/candidate/search');
      this.setState({open: false});
    }
  }

  renderField({
    input,
    label,
    type,
    style,
    className,
    value,
    placeholder,
    disableFuture,
    meta: { touched, error, warning }
  }) {
    return (
      <TextField {...input} label={label} type={type} style={style} placeholder={placeholder} disableFuture={disableFuture} />
    )
  }

  handleOpen = () => {
    this.setState({open: true});
  };

  handleClose = () => {
    this.setState({open: false});
  };

  render() {
    let { open } = this.state;
    return (
      <Fragment>
        <a className="search-launcher" onClick={this.openSearchForm}>
          <img className="icon" src="/icons/search.svg" alt="notification" />
        </a>
        <Dialog
          open={this.state.open}
          onClose={this.handleClose}
          className="search-dialog customContentStyle">
          <Form onSubmit={this.props.handleSubmit(this.getSearchedJob)}>
          <div className="search">
            { open && <div className="mask"></div> }
            { open && <div className="form">
              <div>
                <span>{this.props.translate('lookingFor')}</span>&nbsp;&nbsp;
                <Field
                  name="employmenttype"
                  component={RegularSelect}
                  value={this.state.selectedValue}
                  className="emp-type-selected">
                    <MenuItem value="PleaseSelect">Please Select</MenuItem>
                    <MenuItem value="Full Time">Full Time</MenuItem>
                    <MenuItem value="Part Time">Part Time</MenuItem>
                </Field>
                <span>{this.props.translate('workIn')}</span>
                  <Field
                    name="designation"
                    type="text"
                    placeholder={"Computer Engineer"}
                    component={this.renderField}
                    style={textFieldStyle}
                  />,&nbsp;&nbsp;
                <span>{this.props.translate('countryIn')}</span>
                  <Field
                      name="location"
                      type="text"
                      placeholder={"US"}
                      component={this.renderField}
                      style={textFieldStyle}
                    />,&nbsp;&nbsp;
                <span>{this.props.translate('startingDate')}</span>
                      {/* <Field
                        name="date"
                        type="date"
                        component={this.renderField}
                        placeholder={"2017-05-24"}
                        style={textFieldStyle}
                        disableFuture={true}
                      /> */}
                      <Field
                        name="date"
                        component={CustomDatePicker}
                        disableFuture={true}
                        style={textFieldStyle}
                        label={''}
                      />
              <br /><br />
              </div>
              <Button 
              colorOverrides={{
                label:"blue", 
                background: "red",
                hoverBackground: "white",
                disabledBackground: "white",
              }}
              type="submit" variant="raised" color="primary">{this.props.translate('search')}</Button>&nbsp;&nbsp;
              {/* <Button color="primary" onClick={this.resetForm}>{this.props.translate('reset')}</Button>&nbsp;&nbsp; */}
              <Button color="primary" onClick={this.closeSearchForm}>{this.props.translate('cancel')}</Button>
            </div>
            }
          </div>
          </Form>
        </Dialog>
      </Fragment>
    )
  }
}

CandidatesSearch.propTypes = {
  translate: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  getSearchedJobs: PropTypes.func,  
  history: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
    PropTypes.object,
  ]),
  searchedJobsLoading: PropTypes.bool,
  flushSearchedJobs: PropTypes.func,  
};

CandidatesSearch.defaultProps = {
  getSearchedJobs: () => {},
  searchedJobsLoading: false,
  history: {},
  flushSearchedJobs: () => {},  
};

const mapStateToProps = state => ({
  searchedJobsLoading : state.jobs.searchedJobsLoading,
  initialValues: {
    employmenttype: 'PleaseSelect'
  }
});


const mapDispatchToProps = dispatch => ({
  getSearchedJobs: (employmenttype,designation,location,date) => dispatch(getSearchedJobs(employmenttype,designation,location,date)),
  flushSearchedJobs: () => dispatch(flushSearchedJobs()),  
  dispatch,
});

const CandidateSearch = reduxForm({
  form: 'JobSearch',
  enableReinitialize: true,
  destroyOnUnmount: false,
})(CandidatesSearch);

export default connect(mapStateToProps,mapDispatchToProps)(withRouter(withTranslate(CandidateSearch)));
