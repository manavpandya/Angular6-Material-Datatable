import React, { Component } from 'react';
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';

import TogglePanel from './TogglePanel'
import MultiSelect from '../../../shared/basic/MultiSelect';
import { getOptions } from '../../../utils';
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class Certificate extends Component {
  constructor(props) {
    super(props);
    this.onUpdateCertificates = this.onUpdateCertificates.bind(this);
  }

  onUpdateCertificates(values) {
    this.props.updateProfileData({ certificates: [ { list: values.list } ] })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));      
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="skills">
            {
              (this.props.value[0].list && this.props.value[0].list.map(skill => 
                <span key={skill.display_value} className="bordered-box">{skill.display_value}</span>
              ))
              || 'No data provided'
            }
          </p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateCertificates)}>
            <Field 
              getOptions={getOptions}
              valueKey="display_value"
              labelKey="display_value"
              type="AsyncCreatable"
              name="list"
              component={MultiSelect}
            />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('certificatesForm')
        }}
        formName="certificatesForm"
    />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    list: props.value[0].list,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),  
});

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'certificatesForm', enableReinitialize: true, destroyOnUnmount: false })(Certificate));