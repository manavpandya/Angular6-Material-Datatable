import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class Nationality extends Component {
  constructor(props) {
    super(props);
    this.onUpdateNationality = this.onUpdateNationality.bind(this);
  }

  onUpdateNationality(values) {
    this.props.updateProfileData({ personal_information: { ...this.props.value, nationality: values.nationality } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="contact">{this.props.value.nationality || 'No data'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateNationality)}>
            <Field name="nationality" component={TextField} />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('nationalityForm')
        }}
        formName="nationalityForm"
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    nationality: props.value.nationality,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'nationalityForm', enableReinitialize: true, destroyOnUnmount: false })(Nationality));