import React, { Component } from 'react'
import { connect } from 'react-redux';
import { reduxForm, Form, Field, submit } from 'redux-form';
import { TextField } from 'redux-form-material-ui';

import TogglePanel from './TogglePanel'
import { updateProfileData } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';

class Gender extends Component {
  constructor(props) {
    super(props);
    this.onUpdateGender = this.onUpdateGender.bind(this);
  }

  onUpdateGender(values) {
    this.props.updateProfileData({ personal_information: { ...this.props.value, gender: values.gender } })
      .catch(() => showNotification('There was a problem saving the changes', 'error', 8000));
  }

  render() {
    return (
      <TogglePanel
        title={ this.props.label }
        read={
          <p className="contact">{this.props.value.gender || 'Gender not specified'}</p>
        }
        edit={
          <Form onSubmit={this.props.handleSubmit(this.onUpdateGender)}>
            <Field name="gender" component={TextField} />
          </Form>
        }
        onSubmit={() => {
          this.props.submit('genderForm')
        }}
        formName="genderForm"
      />
    )
  }
}

const mapStateToProps = (state, props) => ({
  initialValues: {
    gender: props.value.gender,
  },
});

const mapDispatchToProps = dispatch => ({
  submit: formName => dispatch(submit(formName)),
  updateProfileData: data => dispatch(updateProfileData(data)),
})

export default connect(mapStateToProps, mapDispatchToProps)(reduxForm({ form: 'genderForm', enableReinitialize: true, destroyOnUnmount: false })(Gender));