import React, { Component } from 'react';
import { TextField, Button } from 'material-ui'
import AddIcon from 'material-ui-icons/Add'
import CloseIcon from 'material-ui-icons/Close'
import _ from 'lodash'

export default class Languages extends Component {
  constructor(props) {
    super(props);
    this.state = {
      languages: this.dataToViewData(this.props.value)
    }
  }

  canSpeak = (speak, lang) => {
    return _.includes(speak, lang)
  }

  canRead = (read, lang) => {
    return _.includes(read, lang)
  }

  canWrite = (write, lang) => {
    return _.includes(write, lang)
  }

  dataToViewData = (data) => {
    let languages = []
    _.union(data.speak, data.read, data.write).forEach((l) =>
      languages.push({
        language: l,
        canSpeak: this.canSpeak(data.speak, l),
        canRead: this.canRead(data.read, l),
        canWrite: this.canWrite(data.write, l)
      })
    )
    return languages
  }

  viewDataToData = (data) => {

  }

  render() {
    let { languages } = this.state
    return (
      <div className="f languages">
        <ul>
          {
            languages.map(
              (l, i) =>
              <li key={i} className="language">
                <strong className="lang">{ l.language }</strong>
                <label>
                  <input type="checkbox" checked={l.canSpeak} readOnly />
                  <span>Speak</span>
                </label>
                <label>
                  <input type="checkbox" checked={l.canRead} readOnly />
                  <span>Read</span>
                </label>
                <label>
                  <input type="checkbox" checked={l.canWrite} readOnly />
                  <span>Write</span>
                </label>
                <span className="actions">
                  <Button>
                    <CloseIcon style={{ width: '1rem' }}on />
                  </Button>
                </span>
              </li>
            )
          }
          <li className="language add">
            <strong className="lang"><TextField type="text" value="Add Language" /></strong>
            <label>
              <input type="checkbox" readOnly />
              <span>Speak</span>
            </label>
            <label>
              <input type="checkbox" readOnly />
              <span>Read</span>
            </label>
            <label>
              <input type="checkbox" readOnly />
              <span>Write</span>
            </label>
            <span className="actions">
              <Button raised>
                <AddIcon style={{ width: '1rem' }} />
              </Button>
            </span>
          </li>
        </ul>
      </div>
    )
  }
};
