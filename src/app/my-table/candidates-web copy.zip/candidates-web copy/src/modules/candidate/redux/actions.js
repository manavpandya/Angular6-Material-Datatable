import api from '../../../shared/api';
import * as constants from './actionTypes';

export function uploadCandidateProfiles(formData) {
  return {
    type: constants.UPLOAD_CANDIDATE_PROFILES,
    payload: api().post('/account/upload_profile', formData),
  };
}

export function registerCandidate(candidateData) {
  return {
    type: constants.CANDIDATE_REGISTER,
    payload: api().post('accounts/register', candidateData),
      // .then((data) => {
      //   localStorage.setItem('user_info', JSON.stringify(data.data.access_token));
      //   // window.location.reload();
      // }),
  };
}

export function getRequiredSkills(searchedQuery) {
  return {
    type: constants.GET_GREATEST_SKILLS,
    payload: api().get(`terms/search?search_type=leaf_only&skill=${searchedQuery}`)
      .then((data) => {
        return data.data
      }),
  };
}

export function addGreatestSkill(profileId,skillsIds) {
  return {
    type: constants.ADD_GREATEST_SKILL,
    payload: api().put(`profile/${profileId}/important_skills`,skillsIds)
      .then((data) => {
        return data.data
      }),
  };
}

export function deleteGreatestSkill(profileId,skillsIds) {
  return {
    type: constants.DELETE_GREATEST_SKILL,
    payload: api().delete(`profile/${profileId}/important_skills`,{data:skillsIds})
      .then((data) => {
        return {
          skillsIds,
          data: data.data
        }
      }),
  };
}

export function addAdditionalSkill(profileId,skillsIds) {
  return {
    type: constants.ADD_ADDITIONAL_SKILL,
    payload: api().put(`profile/${profileId}/skills/additional_skills`,skillsIds)
      .then((data) => {
        return data.data
      }),
  };
}

export function deleteAdditionalSkill(profileId,skillsIds) {
  return {
    type: constants.DELETE_ADDITIONAL_SKILL,
    payload: api().delete(`profile/${profileId}/skills/additional_skills`,{data:skillsIds})
      .then((data) => {
        return {
          skillsIds,
          data: data.data
        }
      }),
  };
}

export function getAccountMe() {
  return {
    type: constants.GET_ACCOUNT_ME,
    payload: api().get('/accounts/me'),
  };
}

export function getProfileData() {
  return {
    type: constants.GET_PROFILE_DATA,
    payload: api().get('/account/profile'),
  }
}

export function updateProfileData(data) {
  return {
    type: constants.UPDATE_PROFILE_DATA,
    payload: api().put('account/profile', data).then(() => {
      return data
    }),
  }
}

export function updateCandidateSkills(profileId,skillId) {
  return {
    type: constants.UPDATE_CANDIDATE_PROFILE_SKILL,
    payload: api().put(`/profile/${profileId}/skills/skills`,skillId)
  }
}

export function deleteCandidateSkills(profileId,skillId) {
  return {
    type: constants.DELETE_CANDIDATE_PROFILE_SKILL,
    payload: api().delete(`/profile/${profileId}/skills/skills`, { data : skillId }).then(() => ({
      id: skillId
    })),
  }
}

export function updateCandidateProfileData(profileId,id,data) {
  return {
    type: constants.UPDATE_USER_PROFILE_DATA,
    payload: api().put(`profile/${profileId}/education_details/${id}`, data).then(() => ({
      ...data,
      id: id,
    })),
  }
}

export function addCandidateProfileData(profileId,data) {
  return {
    type: constants.ADD_USER_PROFILE_DATA,
    payload: api().put(`profile/${profileId}/education_details`, data).then((res) => {
      return {data: res.data}
    }),
  }
}

export function removeCandidateProfileData(profileId,id) {
  return {
    type: constants.DELETE_USER_PROFILE_DATA,
    payload: api().delete(`profile/${profileId}/education_details/${id}`).then(() => ({
      id,
    })),
  }
}

export function removeSocialLink(link) {
  return {
    type: constants.REMOVE_SOCIAL_LINK,
    payload: link
  }
}

export function addNewSocialLink(link) {
  return {
    type: constants.ADD_NEW_SOCIAL_LINK,
    payload: link,
  }
}

export function changeMountedForm(formName) {
  return {
    type: constants.CHANGE_MOUNTED_FORM,
    payload: formName,
  };
}

export function changeMountedProfileForm(formName) {
  return {
    type: constants.CHANGE_MOUNTED_PROFILE_FORM,
    payload: formName,
  };
}

export function addLanguageCapability(language, capability) {
  return {
    type: constants.ADD_LANGUAGE_CAPABILITY,
    payload: { language, capability }
  }
}

export function removeLanguageCapability(language, capability) {
  return {
    type: constants.REMOVE_LANGUAGE_CAPABILITY,
    payload: { language, capability }
  }
}

export function removeLanguage(language) {
  return {
    type: constants.REMOVE_LANGUAGE,
    payload: language
  }
}

export function addNewLanguage(language, status) {
  return {
    type: constants.ADD_NEW_LANGUAGE,
    payload: { language, status }
  }
}

export function removeMobile(mobile) {
  return {
    type: constants.REMOVE_MOBILE,
    payload: mobile
  }
}

export function addNewMobile(mobile) {
  return {
    type: constants.ADD_NEW_MOBILE,
    payload: mobile,
  }
}

export function removeOtherPhoneNo(mobile) {
  return {
    type: constants.REMOVE_OTHER_PHONE_NO,
    payload: mobile
  }
}

export function addNewOtherPhoneNo(mobile) {
  return {
    type: constants.ADD_NEW_OTHER_PHONE_NO,
    payload: mobile
  }
}

export function removeEmail(email) {
  return {
    type: constants.REMOVE_EMAIL,
    payload: email
  }
}

export function addNewEmail(email) {
  return {
    type: constants.ADD_NEW_EMAIL,
    payload: email
  }
}
