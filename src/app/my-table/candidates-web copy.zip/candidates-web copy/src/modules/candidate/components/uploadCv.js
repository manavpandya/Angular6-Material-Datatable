import React, { Component } from 'react';
import Button from 'material-ui/Button'
import Dropzone from 'react-dropzone';
import PropTypes from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';

class UploadCV extends Component {
  render() {
    let dropzoneRef;
    return (
      <div>
        <h1>{this.props.translate('newToTalentX')}</h1>
        <Button onClick={() => { dropzoneRef.open() }} className="upload-cv-btn" disabled={this.props.startUpload}>
          {this.props.translate('uploadCvToRegister')}
          <Dropzone
            ref={(node) => { dropzoneRef = node; }}
            className="drop-zone"
            multiple={false}
            onDrop={ this.props.onDropFiles}
            accept=".doc,.pdf"
          >
            <p>
              Try dropping some files here or click here to select a file to be uploaded.Files must be doc and pdf only.
            </p>
          </Dropzone>
        </Button>
      </div>
    )
  }
};

UploadCV.propTypes = {
  translate: PropTypes.func.isRequired,
  startUpload: PropTypes.bool,
};

UploadCV.defaultProps = {
  startUpload: false,
};

export default  withTranslate(UploadCV);
