import * as actionTypes from './actionTypes';
import config from '../../../pages/candidate/data/profile/config';

const initialState = {
  mountedForm: '',
  mountedProfileForm: '',
  candidateProfile: {},
  candidateInformation: {},
  loggedUserProfile: {},
  skills: {},
  skillsLoading: false,
  skillsError:false,
  allJobTitles: {},
  allJobTitlesLoading: false,
  allJobTitlesError: false,
  userProfileLoading:false,
  candidateRegisterSuccess:false,
  candidateRegisterError:false,
  candidateRegisterLoading:false,
  candidateProfilesLoading: false,
  candidateProfilesError: null,
  candidateRegisterDataLoading: false,
  accountInfo: {},
  accountInfoLoading: false,
  accountInfoError: null,
  profile: {},
  profileLoading: false,
  profileError: null,
  language: {},
  mobile: [],
  otherPhoneNo: [],
  email: [],
  social_network_links: []
};

export default function (state = initialState, action) {
  switch (action.type) {
    case actionTypes.LOGOUT_SUCCESS: {
      return {
        ...state,
        loggedUserProfile: {},
        candidateProfile: {},
        candidateInformation: {},
      };
    }
    case actionTypes.UPLOAD_CANDIDATE_PROFILES_SUCCESS : {
      return {
        ...state,
        candidateProfile: action.payload.data,
        candidateProfilesLoading: false,
        candidateProfilesError: null,
      };
    }
    case actionTypes.UPLOAD_CANDIDATE_PROFILES_LOADING : {
      return {
        ...state,
        candidateProfilesLoading: true,
        candidateProfilesError: null,
      };
    }
    case actionTypes.UPLOAD_CANDIDATE_PROFILES_ERROR : {
      return {
        ...state,
        candidateProfilesLoading: false,
        candidateProfilesError: action.payload.data,
      };
    }
    case actionTypes.CANDIDATE_REGISTER_SUCCESS : {
      return {
        ...state,
        candidateInformation: action.payload.data,
        candidateRegisterSuccess: true,
      };
    }
    case actionTypes.CANDIDATE_REGISTER_DATA_LOADING
    : {
      return {
        ...state,
        candidateRegisterDataLoading: true,
      };
    }
    case actionTypes.CANDIDATE_REGISTER_LOADING : {
      return {
        ...state,
        candidateRegisterSuccess: false,
        candidateRegisterLoading: true,
      };
    }
    case actionTypes.CANDIDATE_REGISTER_ERROR : {
      return {
        ...state,
        candidateRegisterError: true,
      };
    }
    case actionTypes.ADD_GREATEST_SKILL_SUCCESS: {
      return {
        ...state,
        loggedUserProfile: { profile: { ...state.loggedUserProfile.profile, ...action.payload.profile } },
        skills: action.payload.data,
        skillsLoading: false,
        skillsError: false,
      };
    }
    case actionTypes.ADD_GREATEST_SKILL_LOADING : {
      return {
        ...state,
        skillsLoading: true,
        skillsError: false,
      };
    }
    case actionTypes.ADD_GREATEST_SKILL_ERROR : {
      return {
        ...state,
        skillsLoading: false,
        skillsError: true,
      };
    }
    // Get matching job of Title
    case actionTypes.GET_JOBS_MATCHING_TITLE_OF_PROFILE_SUCCESS:
    return {
      ...state,
      jobsMatchingTitleOfProfile: action.payload.page > 1 ? [...state.jobsMatchingSkillsOfProfile, ...action.payload.profiles] : action.payload.profiles,
      jobsMatchingTitleOfProfileCurrentPageNo: action.payload.page,
      jobsMatchingTitleOfProfileCurrentPageSize: action.payload.pageSize,
      totalJobsMatchingTitleOfProfile: action.payload.total,
      jobsMatchingTitleOfProfileLoading: false,
      jobsMatchingTitleOfProfileError: null,
    };
  case actionTypes.GET_JOBS_MATCHING_TITLE_OF_PROFILE_LOADING:
    return {
      ...state,
      jobsMatchingTitleOfProfileLoading: true,
      jobsMatchingTitleOfProfileError: null,
    };
  case actionTypes.GET_JOBS_MATCHING_TITLE_OF_PROFILE_ERROR:
  return {
    ...state,
    jobsMatchingTitleOfProfileLoading: false,
    jobsMatchingTitleOfProfileError: null,
  };
  case actionTypes.DELETE_GREATEST_SKILL_SUCCESS: {
    if (action.payload.data && action.payload.data.message && action.payload.data.message === "ok") {
      const currentProfile = state.loggedUserProfile.profile;
      const impSkills = currentProfile.qualifications && currentProfile.qualifications.important_skills ? currentProfile.qualifications.important_skills : [];
      const deletedSkills = action.payload.skillsIds && action.payload.skillsIds.important_skill_ids ? action.payload.skillsIds.important_skill_ids : [];
      const filteredSkills = impSkills.filter(skill => deletedSkills.indexOf(skill.id) < 0);
      currentProfile.qualifications.important_skills = filteredSkills;
      return {
        ...state,
        loggedUserProfile: { profile: { ...currentProfile } },
        skills: action.payload.data,
        skillsLoading: false,
        skillsError: false,
      };
    }
    return {
      ...state,
      skills: action.payload.data,
      skillsLoading: false,
      skillsError: false,
    };
  }
  case actionTypes.DELETE_GREATEST_SKILL_LOADING : {
    return {
      ...state,
      skillsLoading: true,
      skillsError: false,
    };
  }
  case actionTypes.DELETE_GREATEST_SKILL_ERROR : {
    return {
      ...state,
      skillsLoading: false,
      skillsError: true,
    };
  }
  // Add additional skill
  case actionTypes.ADD_ADDITIONAL_SKILL_SUCCESS: {
    return {
      ...state,
      loggedUserProfile: { profile: { ...state.loggedUserProfile.profile, ...action.payload.profile } },
      additional_skills: action.payload.data,
      skillsLoading: false,
      skillsError: false,
    };
  }
  case actionTypes.ADD_ADDITIONAL_SKILL_LOADING : {
    return {
      ...state,
      skillsLoading: true,
      skillsError: false,
    };
  }
  case actionTypes.ADD_ADDITIONAL_SKILL_ERROR : {
    return {
      ...state,
      skillsLoading: false,
      skillsError: true,
    };
  }
  // delete additional skills
  case actionTypes.DELETE_ADDITIONAL_SKILL_SUCCESS: {
    if (action.payload.data && action.payload.data.message && action.payload.data.message === "ok") {
      const currentProfile = state.loggedUserProfile.profile;
      const impSkills = currentProfile.qualifications && currentProfile.qualifications.additional_skills ? currentProfile.qualifications.additional_skills : [];
      const deletedSkills = action.payload.skillsIds && action.payload.skillsIds.additional_skills ? action.payload.skillsIds.additional_skills : [];
      const filteredSkills = impSkills.filter(skill => deletedSkills.indexOf(skill) < 0);
      currentProfile.qualifications.additional_skills = filteredSkills;
      return {
        ...state,
        loggedUserProfile: { profile: { ...currentProfile } },
        additional_skills: action.payload.data,
        skillsLoading: false,
        skillsError: false,
      };
    }
    return {
      ...state,
      additional_skills: action.payload.data,
      skillsLoading: false,
      skillsError: false,
    };
  }
    case actionTypes.DELETE_ADDITIONAL_SKILL_LOADING : {
      return {
        ...state,
        skillsLoading: true,
        skillsError: false,
      };
    }
    case actionTypes.DELETE_ADDITIONAL_SKILL_ERROR : {
      return {
        ...state,
        skillsLoading: false,
        skillsError: true,
      };
    }
    case actionTypes.GET_ACCOUNT_ME_SUCCESS:
    return {
      ...state,
      accountInfo: action.payload.data,
      accountInfoLoading: false,
      accountInfoError: null,
    };
  case actionTypes.GET_ACCOUNT_ME_LOADING:
    return {
      ...state,
      accountInfoLoading: true,
      accountInfoError: null,
    };
  case actionTypes.GET_ACCOUNT_ME_ERROR:
    return {
      ...state,
      accountInfo: {},
      accountInfoLoading: false,
      accountInfoError: action.payload,
    };
  case actionTypes.GET_PROFILE_DATA_SUCCESS:
    return {
      ...state,
      loggedUserProfile: action.payload.data,
      profile: {
        data: {
          ...action.payload.data.profile,
          // qualifications: {
          //   ...action.payload.data.profile && action.payload.data.profile.qualifications,
          //   skills: [
          //     ...action.payload.data.profile && action.payload.data.profile.qualifications
          //     && action.payload.data.profile.qualifications.skills
          //     ? action.payload.data.profile.qualifications.skills
          //     : {display_value: ''},
          //   ],
          // },
          experience_details: {
            ...action.payload.data.profile && action.payload.data.profile.experience_details,
            all_job_titles: [
              ...action.payload.data.profile && action.payload.data.profile.experience_details
              && action.payload.data.profile.experience_details.all_job_titles
              ? action.payload.data.profile.experience_details.all_job_titles.map(titles => ({value: titles}))
              : {value: ''},
            ]
          },
          certification_license: {
            ...action.payload.data.profile && action.payload.data.profile.certification_license,
            license_and_certifications: [
              ...action.payload.data.profile && action.payload.data.profile.certification_license
              && action.payload.data.profile.certification_license.license_and_certifications
              ? action.payload.data.profile.certification_license.license_and_certifications.map(licenseAndCertification => ({value: licenseAndCertification}))
              : {value: ''},
            ]
          },
          publication: {
            ...action.payload.data.profile && action.payload.data.profile.publication,
            publication_history: [
              ...action.payload.data.profile && action.payload.data.profile.publication
              && action.payload.data.profile.publication.publication_history
              ? action.payload.data.profile.publication.publication_history.map(publication => ({value: publication}))
              : {value: ''},
            ]
          },
          speaking_engagements: {
            ...action.payload.data.profile && action.payload.data.profile.speaking_engagements,
            speaking_events_history: [
              ...action.payload.data.profile && action.payload.data.profile.speaking_engagements
              && action.payload.data.profile.speaking_engagements.speaking_events_history
              ? action.payload.data.profile.speaking_engagements.speaking_events_history.map(event => ({value: event}))
              : {value: ''},
            ]
          }
        },
        config: config,
      },
      language: {
        ...action.payload.data.profile ? action.payload.data.profile.language : {},
      },
      mobile: [
        ...action.payload.data.profile && action.payload.data.profile.contact_information
        && action.payload.data.profile.contact_information.mobile
          ? action.payload.data.profile.contact_information.mobile
          : [],
      ],
      social_network_links: [
        ...action.payload.data.profile && action.payload.data.profile.contact_information
        && action.payload.data.profile.contact_information.social_network_links
          ? action.payload.data.profile.contact_information.social_network_links
          : [],
      ],
      otherPhoneNo: [
        ...action.payload.data.profile && action.payload.data.profile.contact_information
        && action.payload.data.profile.contact_information.other_phone_no
          ? action.payload.data.profile.contact_information.other_phone_no
          : [],
      ],
      email: [
        ...action.payload.data.profile && action.payload.data.profile.contact_information
        && action.payload.data.profile.contact_information.email
          ? action.payload.data.profile.contact_information.email
          : [],
      ],
      profileLoading: false,
      profileError: null,
    };
  case actionTypes.GET_PROFILE_DATA_LOADING:
    return {
      ...state,
      profileLoading: true,
      profileError: null,
    }
  case actionTypes.GET_PROFILE_DATA_ERROR:
    return {
      ...state,
      profileLoading: false,
      profileError: action.payload,
    }
  case actionTypes.UPDATE_PROFILE_DATA_SUCCESS:
    return {
      ...state,
      profile: {
        ...state.profile,
        data: {
          ...state.profile.data,
          ...action.payload,
          // qualifications: {
          //   ...action.payload.qualifications || state.profile.data.qualifications,
          //   skills: [
          //     ...action.payload && action.payload.qualifications
          //       ? action.payload.qualifications.skills
          //         ? action.payload.qualifications.skills.map(skill => ({display_value: skill}))
          //         : {display_value: ''}
          //       : state.profile.data.qualifications
          //         ? state.profile.data.qualifications.skills
          //         : {display_value: ''},
          //   ],
          // },
          experience_details: {
            ...action.payload.experience_details || state.profile.data.experience_details,
            all_job_titles: [
              ...action.payload && action.payload.experience_details
                ? action.payload.experience_details.all_job_titles
                  ? action.payload.experience_details.all_job_titles.map(title => ({value: title}))
                  : {value: ''}
                : state.profile.data.experience_details
                  ? state.profile.data.experience_details.all_job_titles
                  : {value: ''},
            ]
          },
          certification_license: {
            ...action.payload.certification_license || state.profile.data.certification_license,
            license_and_certifications: [
              ...action.payload && action.payload.certification_license
                ? action.payload.certification_license.license_and_certifications
                  ? action.payload.certification_license.license_and_certifications.map(licenseAndCertification => ({value: licenseAndCertification}))
                  : {value: ''}
                : state.profile.data.certification_license
                  ? state.profile.data.certification_license.license_and_certifications
                  : {value: ''},
            ]
          },
          publication: {
            ...action.payload.publication || state.profile.data.publication,
            publication_history: [
              ...action.payload && action.payload.publication
                ? action.payload.publication.publication_history
                  ? action.payload.publication.publication_history.map(publication => ({value: publication}))
                  : {value: ''}
                : state.profile.data.publication
                  ? state.profile.data.publication.publication_history
                  : {value: ''},
            ]
          },
          speaking_engagements: {
            ...action.payload.speaking_engagements || state.profile.data.speaking_engagements,
            speaking_events_history: [
              ...action.payload && action.payload.speaking_engagements
                ? action.payload.speaking_engagements.speaking_events_history
                  ? action.payload.speaking_engagements.speaking_events_history.map(event => ({value: event}))
                  : {value: ''}
                : state.profile.data.speaking_engagements
                  ? state.profile.data.speaking_engagements.speaking_events_history
                  : {value: ''},
            ]
          },
        },
      },
      language: {
        ...state.profile.data.language,
        ...action.payload.language,
      },
      contact_information: {
        ...state.profile.data.contact_information,
        ...action.payload.contact_information,
      },
      profileLoading: false,
      profileError: null,
    }
    case actionTypes.UPDATE_PROFILE_DATA_LOADING:
      return {
        ...state,
        profileLoading: true,
        profileError: null,
      }
    case actionTypes.UPDATE_PROFILE_DATA_ERROR:
      return {
        ...state,
        profileLoading: false,
        profileError: action.payload,
      }
    // New user profile data update
    case actionTypes.UPDATE_USER_PROFILE_DATA_SUCCESS:
    return {
      ...state,
      profile: {
        ...state.profile,
        data: {
          ...state.profile.data,
          education_details: [
            ...state.profile.data.education_details.map(education => {
              if (education.id === action.payload.id) {
                return action.payload
              }
              return education;
            }),
          ]
        }
      },
      profileLoading: false,
      profileError: null,
    }
    case actionTypes.UPDATE_USER_PROFILE_DATA_LOADING:
      return {
        ...state,
        profileLoading: true,
        profileError: null,
      }
    case actionTypes.UPDATE_USER_PROFILE_DATA_ERROR:
      return {
        ...state,
        profileLoading: false,
        profileError: action.payload,
      }
    // Add user education detail
    case actionTypes.ADD_USER_PROFILE_DATA_SUCCESS:
    return {
      ...state,
      profile: {
        ...state.profile,
        data: {
          ...state.profile.data,
          education_details: [
            ...action.payload.data.education_details
          ]
        }
      },
      profileLoading: false,
      profileError: null,
    }
    case actionTypes.ADD_USER_PROFILE_DATA_LOADING:
      return {
        ...state,
        profileLoading: true,
        profileError: null,
      }
    case actionTypes.ADD_USER_PROFILE_DATA_ERROR:
      return {
        ...state,
        profileLoading: false,
        profileError: action.payload,
      }
    // Update skill of user profile
    case actionTypes.UPDATE_CANDIDATE_PROFILE_SKILL_SUCCESS:
    return {
      ...state,
      profile:{
        ...state.profile,
        data: {
           ...state.profile.data,
            qualifications: {
            ...state.profile.data && state.profile.data.qualifications,
              skills: [
                ...action.payload.data.profile && action.payload.data.profile.qualifications
                && action.payload.data.profile.qualifications.skills
                ? action.payload.data.profile.qualifications.skills
                : state.profile.data.qualifications.skills,
              ],
          },
        }
      },
      profileLoading: false,
      profileError: null,
    }
    case actionTypes.UPDATE_CANDIDATE_PROFILE_SKILL_LOADING:
      return {
        ...state,
        profileLoading: true,
        profileError: null,
      }
    case actionTypes.UPDATE_CANDIDATE_PROFILE_SKILL_ERROR:
      return {
        ...state,
        profileLoading: false,
        profileError: action.payload,
      }
    // Delete skill of user profile
    case actionTypes.DELETE_CANDIDATE_PROFILE_SKILL_SUCCESS:
    return {
      ...state,
      profile: {
        ...state.profile,
        data: {
          ...state.profile.data,
          qualifications: {
            ...state.profile.data.qualifications,
            skills: [
              ...state.profile.data.qualifications.skills.filter(skill => !action.payload.id.skill_ids.includes(skill.id)),
            ]
          }
        }
      },
      profileLoading: false,
      profileError: null,
    }
    case actionTypes.DELETE_CANDIDATE_PROFILE_SKILL_LOADING:
      return {
        ...state,
        profileLoading: true,
        profileError: null,
      }
    case actionTypes.DELETE_CANDIDATE_PROFILE_SKILL_ERROR:
      return {
        ...state,
        profileLoading: false,
        profileError: action.payload,
      }
    case actionTypes.DELETE_USER_PROFILE_DATA_SUCCESS:
      return {
        ...state,
        profile: {
          ...state.profile,
          data: {
            ...state.profile.data,
            education_details: [
              ...state.profile.data.education_details.filter(education => education.id !== action.payload.id),
            ]
          }
        },
        profileLoading: false,
        profileError: null,
    }
    case actionTypes.DELETE_USER_PROFILE_DATA_LOADING:
      return {
        ...state,
        profileLoading: true,
        profileError: null,
      }
    case actionTypes.DELETE_USER_PROFILE_DATA_ERROR:
      return {
        ...state,
        profileLoading: false,
        profileError: action.payload,
      }
    case actionTypes.CHANGE_MOUNTED_FORM:
      return {
        ...state,
        mountedForm: action.payload,
        mountedProfileForm: action.payload,
      };
    case actionTypes.ADD_LANGUAGE_CAPABILITY:
      return {
        ...state,
        language: {
          ...state.language,
          [action.payload.capability]: [
            ...state.language[action.payload.capability],
            action.payload.language,
          ],
        },
      }
    case actionTypes.REMOVE_LANGUAGE_CAPABILITY:
      return {
        ...state,
        language: {
          ...state.language,
          [action.payload.capability]: [
            ...state.language[action.payload.capability].filter(language => language !== action.payload.language),
          ],
        },
      }
    case actionTypes.REMOVE_LANGUAGE:
      return {
        ...state,
        language: {
          ...Object.keys(state.language).reduce((obj, languageKey) => {
            obj[languageKey] = state.language[languageKey].filter(language => language !== action.payload)
            return obj;
          }, {})
        },
      }
    case actionTypes.ADD_NEW_LANGUAGE:
      return {
        ...state,
        language: {
          ...Object.keys(state.language).reduce((obj, languageKey) => {
            if (action.payload.status.includes(languageKey)) {
              obj[languageKey] = [
                ...state.language[languageKey],
                action.payload.language,
              ];
            } else {
              obj[languageKey] = state.language[languageKey]
            }
            return obj;
          }, {})
        },
      }
    case actionTypes.REMOVE_MOBILE:
      return {
        ...state,
        mobile: [
          ...state.mobile.filter(mobile => mobile !== action.payload),
        ],
      }
    case actionTypes.ADD_NEW_MOBILE:
    return {
      ...state,
      mobile: [
        ...state.mobile,
        action.payload,
      ],
    }
    case actionTypes.REMOVE_SOCIAL_LINK:
      return {
        ...state,
        social_network_links: [
          ...state.social_network_links.filter(link => link !== action.payload),
        ],
      }
    case actionTypes.ADD_NEW_SOCIAL_LINK:
    return {
      ...state,
      social_network_links: [
        ...state.social_network_links,
        action.payload,
      ],
    }
    case actionTypes.REMOVE_OTHER_PHONE_NO:
      return {
        ...state,
        otherPhoneNo: [
          ...state.otherPhoneNo.filter(mobile => mobile !== action.payload),
        ],
      }
    case actionTypes.ADD_NEW_OTHER_PHONE_NO:
    return {
      ...state,
      otherPhoneNo: [
        ...state.otherPhoneNo,
        action.payload,
      ],
    }
    case actionTypes.REMOVE_EMAIL:
      return {
        ...state,
        email: [
          ...state.email.filter(email => email !== action.payload),
        ],
      }
    case actionTypes.ADD_NEW_EMAIL:
    return {
      ...state,
      email: [
        ...state.email,
        action.payload,
      ],
    }
  default:
      return state;
  }
}
