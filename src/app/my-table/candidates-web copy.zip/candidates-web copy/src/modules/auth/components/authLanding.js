import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import { LinearProgress } from 'material-ui/Progress';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import About from '../../candidate/components/about';
import SignIn from '../components/login'
import Register from '../components/register'
import UploadCV from '../../candidate/components/uploadCv'
import { showNotification } from '../../../utils/Notifications';
import {
  uploadCandidateProfiles
} from '../../candidate/redux/actions';

class LandingPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      files: [],
      completed: 0,
      startUpload: false,
      uploadComplete: false,
      candidateRegistered: false,
    }
    this.changeViewState = this.changeViewState.bind(this);
  }

  timer = null;

  upload = () => {
    const { completed } = this.state;
    this.setState({ startUpload: true });
    if (completed === 100) {
      clearInterval(this.timer);
      this.setState({ uploadComplete: true });
    } else {
      const diff = Math.random() * 10;
      this.setState({ completed: Math.min(completed + diff, 100) });
    }
  };

  startUpload = () => {
    this.timer = setInterval(this.upload, 100);
  }

  changeViewState()
  {
    this.setState({ candidateRegistered : true , uploadComplete: false ,startUpload: false ,completed: 0  });
  }

  cancelRegistration = () => {
    this.setState({ startUpload: false, uploadComplete: false, completed: 0 });
  }

  onDropFiles= (event) => {
    const filesArray = Array.from(event);
    const file = filesArray[0];
    if(file.size > 5 * 1024 * 1024){
      showNotification("Please select smaller size, maximum file size allowed is 5MB", 'error', 8000);
      return false;
    }
    Promise.all(filesArray.map((file) => {
      const formData = new FormData();
      formData.append('file', file);
      return this.props.uploadCandidateProfiles(formData);
    })).then(() => {
      this.setState({ candidateRegistered : false  });
      if (filesArray.length > 0) {
        showNotification(`Your profile is uploaded, please continue with the registration.`, 'success', 8000);
      }
    }).catch((err) => {
      showNotification(err, 'error', 8000);
    });
    this.timer = setInterval(this.upload, 100);
  }

  render() {
    let { startUpload, uploadComplete ,candidateRegistered } = this.state;
    return (
      <Fragment>
        <div className="page candidate">
          <div className="page candidate-landing">
            <About />
            <section className="authenticate">
              {
                uploadComplete &&
                <div className="upload">
                  <h1>{this.props.translate('uploadSuccess')}</h1>
                </div>
              }
              {  candidateRegistered ?
                  <SignIn/> :
                  uploadComplete ?
                    <Register
                    onCancel={() => this.cancelRegistration()}
                    changeViewState={this.changeViewState}
                    candidateProfilesLoading={this.props.candidateProfilesLoading}/>
                  :
                  <SignIn />
              }
              {
                !uploadComplete &&
                <div className="upload">
                  <UploadCV onDropFiles={this.onDropFiles} startUpload={startUpload} />
                  { startUpload &&  <LinearProgress color="secondary" variant="determinate" value={this.state.completed} /> }
                </div>
              }
            </section>
          </div>
        </div>
      </Fragment>
    )
  }
}

LandingPage.propTypes = {
  translate: PropTypes.func.isRequired,
  uploadCandidateProfiles: PropTypes.func,
  candidateProfilesLoading: PropTypes.bool,
};

LandingPage.defaultProps = {
  uploadCandidateProfiles: () => {},
  candidateProfilesLoading: false,
};

const mapStateToProps = state => ({
  candidateProfilesLoading: state.candidate.candidateProfilesLoading,
});

const mapDispatchToProps = dispatch => ({
  uploadCandidateProfiles: formData => dispatch(uploadCandidateProfiles(formData)),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(LandingPage));

