import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { updateToken } from '../redux/actions';
import { getAccountMe } from '../../candidate/redux/actions';

export default function (ComposedComponent) {
  class Authentication extends Component {
    constructor(props) {
      super(props);
      this.state = {
        pageAccessible: false,
      };
    }

    componentWillMount() {
      const token = localStorage.getItem('user_info');
      if (token) {
        if (Object.keys(this.props.accountInfo).length === 0) {
          this.props.getAccountMe()
            .then(() => {
              this.setState({ pageAccessible: true });
            })
            .catch(() => {
              localStorage.removeItem('user_info');
              localStorage.removeItem('tenant');
              this.props.history.push('/');
            });
        } else {
          this.setState({ pageAccessible: true });
        }
      } else {
        this.props.history.push('/');
      }
    }
    componentWillReceiveProps() {
    }
    render() {
      return this.state.pageAccessible ? <ComposedComponent {...this.props} /> : <div />;
    }
  }

  Authentication.propTypes = {
    updateToken: PropTypes.func,
    history: PropTypes.object, // eslint-disable-line
    getAccountMe: PropTypes.func,
    accountInfo: PropTypes.object, // eslint-disable-line
    token: PropTypes.string,
  };

  Authentication.defaultProps = {
    updateToken: () => {},
    history: {},
    getAccountMe: () => {},
    accountInfo: () => {},
    token: '',
  };

  const mapStateToProps = state => ({
    accountInfo: state.candidate.accountInfo,
    token: state.login.token,
  });

  const mapDispatchToProps = dispatch => ({
    updateToken: token => dispatch(updateToken(token)),
    getAccountMe: () => dispatch(getAccountMe()),
  });

  return connect(mapStateToProps, mapDispatchToProps)(withRouter(Authentication));
}
