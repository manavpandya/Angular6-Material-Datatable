import React from 'react';
import PropTypes from 'prop-types';
import Paper from 'material-ui/Paper';
import CheckCircle from 'material-ui-icons/CheckCircle';
import Cancel from 'material-ui-icons/Cancel';

const Confirmation = props => (
  <div>
    <Paper className="authentication widget">
      <div className="confirmation">
        <h1>{props.header}</h1>
        {
          props.button ?
            <div>
              {
                props.responseLogo ?
                  <div className="confirm-logo">
                    <CheckCircle />
                  </div>
                :
                  <div className="cancel-logo">
                    <Cancel />
                  </div>
              }
              <div className="confirmation-button">
                {props.button}
              </div>
            </div>
          :
            <div />
        }
      </div>
    </Paper>
  </div>
);

Confirmation.propTypes = {
  header: PropTypes.string.isRequired,
  button: PropTypes.element,
  responseLogo: PropTypes.bool,
};

Confirmation.defaultProps = {
  button: <div />,
  responseLogo: true,
};

export default Confirmation;
