import React from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import Paper from 'material-ui/Paper';
import Button from 'material-ui/Button';
import { TextField } from 'redux-form-material-ui';
import { reduxForm, Form, Field } from 'redux-form';

const ResetPasswordPage = props => (
  <Paper className="authentication widget">
    <h1>Reset Password</h1>
    <Form onSubmit={props.handleSubmit(props.submitNewPassword)}>
      <div>
        <Field
          name="newPassword"
          type="password"
          component={TextField}
          label="New Password"
        />
      </div>
      <br />
      <div>
        <Field
          name="confirmPassword"
          type="password"
          component={TextField}
          label="Confirm Password"
        />
      </div>
      <br />
      <div className="reset-buttons">
        <Button
          type="submit"
        >
        Reset Password
        </Button>
        <Button
          type="button"
          onClick={() => props.history.push('/')}
        >
        Cancel
        </Button>
      </div>
    </Form>
  </Paper>
);

ResetPasswordPage.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  submitNewPassword: PropTypes.func.isRequired,
  history: PropTypes.object.isRequired, // eslint-disable-line
};

ResetPasswordPage.defaulProps = {
  submitNewPassword: () => {},
};

export default reduxForm({ form: 'resetPasswordPage' })(withRouter(ResetPasswordPage));
