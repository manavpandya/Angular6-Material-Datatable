import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { Form, Field, reduxForm } from 'redux-form';
import { withTranslate } from 'react-redux-multilingual';
import { TextField } from 'redux-form-material-ui';
import Button from 'material-ui/Button';
import PropTypes from 'prop-types';
import LanguageOption from '../../../shared/compound/languageOption';
import languages from '../../../i18n/languages';
import { showNotification } from '../../../utils/Notifications';
import { USER_LOGIN_SUCCESS } from '../redux/actionTypes';
import { loginFunction, updateToken, moreCandidateDetails, firstLogin } from '../redux/actions';
import Loader from '../../../shared/basic/Loader';
import { getAccountMe } from '../../candidate/redux/actions';

const required = value => (value == null ? 'required' : undefined);
const validate = (values) => {
  const errors = {};
  errors.username = required(values.username);
  errors.password = required(values.password);
  return errors;
};

const loginFailure = (res) => {
  const response = JSON.parse(JSON.stringify(res));
  if (response.response) {
    const message = response.response ? response.response.data.description : this.props.translate('networkError');
    showNotification(message, 'error', 8000);
  }
};

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };
    this.login = this.login.bind(this);
    const token = localStorage.getItem('user_info');
    if (token) props.history.push('/dashboard');
  }

  login(credentials) {
    this.props.loginFunction(credentials, this.props.Intl.locale).then(({ action }) => {
      if (action.type === USER_LOGIN_SUCCESS) {
        const token = localStorage.getItem('user_info');
        if (token) {
          this
            .props
            .updateToken(token);
        }
        this.props.getAccountMe()
          .then((success) => {
            if (this.props.firstLoginFlag) {
              this.handleClickOpen();
            } else {
              this.props.history.push('/dashboard');
            }
          });
      }
    }).catch(err => loginFailure(err));
    return true;
  }

  render() {
    const {
      valid,
      loginLoading,
      accountInfoLoading,
      handleSubmit,
    } = this.props;
    return (
      <div className="form sign-in">
        {(loginLoading || accountInfoLoading ) && <Loader />}
        <div>
          <div className="main-section">
            <div className="primary-section">
              <h1>{this.props.translate('signIn')}</h1>
            </div>
            <div className="secondary-section">
              <LanguageOption
                  dispatch={this.props.dispatch}
                  languages={languages}
                  />
            </div>
          </div>
          <Form onSubmit={handleSubmit(this.login)}>
            <div  className="f">
              <Field
                name="username"
                autoComplete="username"
                type="text"
                label={this.props.translate('email')}
                component={TextField}
              />
            </div>
            <div  className="f">
              <Field
                name="password"
                label={this.props.translate('password')}
                type="password"
                autoComplete="password"
                component={TextField}
              />
            </div>
            <div className="f footer">
              <Button
                color="primary"
                variant="raised"
                type="submit"
                className="signin-button"
                disabled={!valid}
              >
                {this.props.translate('login')}
              </Button>
              <Button
                className="login-buttons"
                type="button"
                onClick={() => this.props.history.push('/reset_password')}
              >
                {this.props.translate('forgotPassword')}
              </Button>
            </div>
          </Form>
        </div>
      </div>
    );
  }
}

Login.propTypes = {
  translate: PropTypes.func.isRequired,
  history: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
    PropTypes.object,
  ]),
  dispatch: PropTypes.func.isRequired,
  match: PropTypes.object, // eslint-disable-line
  username: PropTypes.string,
  password: PropTypes.string,
  valid: PropTypes.bool.isRequired,
  loginFunction: PropTypes.func,
  updateToken: PropTypes.func,
  firstLogin: PropTypes.func,
  loginLoading: PropTypes.bool,
  firstLoginFlag: PropTypes.bool,
  candidateDetailsLoading: PropTypes.bool,
  moreCandidateDetails: PropTypes.func,
  anyTouched: PropTypes.bool,
  handleSubmit: PropTypes.func.isRequired,
  Intl: PropTypes.object, // eslint-disable-line
  getAccountMe: PropTypes.func,
  accountInfoLoading: PropTypes.bool,
};

Login.defaultProps = {
  match: {},
  username: '',
  password: '',
  loginFunction: () => {},
  moreCandidateDetails: () => {},
  firstLogin: () => {},
  updateToken: {},
  loginLoading: false,
  firstLoginFlag: false,
  candidateDetailsLoading: false,
  history: {},
  anyTouched: false,
  Intl: {},
  accountInfoLoading: false,
  getAccountMe: () => {},
};

// const selector = formValueSelector('CandidateLogin');

const LoginForm = reduxForm({
  form: 'CandidateLogin', // a unique identifier for this form
  validate,
})(Login);

const mapDispatchToProps = dispatch => ({
  loginFunction: (credentials, locale) => dispatch(loginFunction(credentials, locale)),
  dispatch,
  updateToken: token => dispatch(updateToken(token)),
  firstLogin: flag => dispatch(firstLogin(flag)),
  moreCandidateDetails: values => dispatch(moreCandidateDetails(values)),
  getAccountMe: () => dispatch(getAccountMe()),
});

export default connect((state => ({
  // username: selector(state, 'username'),
  // password: selector(state, 'password'),
  accessToken: state.login.token || null,
  accountInfo: state.candidate.accountInfo,
  accountInfoLoading: state.candidate.accountInfoLoading,
  loginLoading: state.login.loginLoading || false,
  candidateDetailsLoading: state.login.candidateDetailsLoading,
  firstLoginFlag: state.login.firstLoginFlag,
  loginError: state.login.loginError || null,
  Intl: state.Intl,
})), mapDispatchToProps)(withRouter(withTranslate(LoginForm)));