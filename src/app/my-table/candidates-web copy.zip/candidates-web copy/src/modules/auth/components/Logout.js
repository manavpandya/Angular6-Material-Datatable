import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { logoutFunction } from '../redux/actions';

class Logout extends Component {
  componentDidMount() {
    this.props.logout();
    localStorage.removeItem('user_info');
    localStorage.removeItem('job_key');
    localStorage.removeItem('job_location');
    localStorage.removeItem('job_date');
    localStorage.removeItem('job_type');
    setTimeout(() => {
      this.props.history.push('/');
    });
  }
  render() {
    return (
      <div />
    );
  }
}

Logout.propTypes = {
  history: PropTypes.object.isRequired, // eslint-disable-line
  logout: PropTypes.func,
};

Logout.defaultProps = {
  logout: () => {},
};

const mapDispatchToProps = dispatch => ({
  logout: () => dispatch(logoutFunction()),
});

export default connect(null, mapDispatchToProps)(withRouter((Logout)));
