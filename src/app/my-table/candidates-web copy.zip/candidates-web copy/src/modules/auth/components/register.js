import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { reduxForm, Form, Field } from 'redux-form';
import { withStyles } from 'material-ui';
import { withTranslate } from 'react-redux-multilingual';
import { TextField, Button } from 'material-ui'
import PropTypes from 'prop-types';
import LanguageOption from '../../../shared/compound/languageOption';
import languages from '../../../i18n/languages';
import {
  registerCandidate
} from '../../candidate/redux/actions';
import { showNotification } from '../../../utils/Notifications';
import BlockUi from 'react-block-ui';
import Checkbox from 'material-ui/Checkbox';

const validate = values => {
  const errors = {}
  if(!values.password)
  {
    errors.password = 'Required'
  }
  if(!values.confirm_password)
  {
    errors.confirm_password = 'Required'
  }
  if(values.password !== values.confirm_password)
  {
    errors.confirm_password = 'Password does not matched'
  }
  if (!values.email) {
    errors.email = 'Required'
  } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
    errors.email = 'Invalid email address'
  }
  if (!values.agreeToTermsandCondidtions) {
    errors.agreeToTermsandCondidtions = "Required"
  }
  return errors
}

const styles = {
  label: {
    color: 'red',
  }
}

class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      candidateRegistered:false,
    }
    this.handleRegistration = this.handleRegistration.bind(this);
  }

  handleRegistration(values) {
    const userData = {
      username: values.name,
      password: values.password,
      email: values.email,
      profile_id: values.profile_id,
    };
    this.props.registerCandidate(userData).then(() => {
      this.props.changeViewState();
      this.props.history.push('/');
      showNotification(`Your profile is created, you can login after your account is activated. Please follow instructions sent to your email address.`, 'success', 8000);
    }).catch((err) => {
        if(err.response.data.message.email)
          showNotification(err.response.data.message.email, 'error', 8000);
        else if(err.response.data.message.password)
          showNotification(err.response.data.message.password, 'error', 8000);
        else if(err.response.data.message.username)
          showNotification(err.response.data.message.username, 'error', 8000);
    });
  }

  renderField({
    input,
    label,
    type,
    meta: { touched, error, warning }
  }) {
    return (
      <div>
      <TextField {...input} label={label} type={type} />
      {touched &&
        ((error && <span style={{color :'red'}}>{error}</span>))}
        </div>
    )
  }

  renderCheckbox({
    input,
    label,
    type,
    meta: { touched, error, warning },
    ...rest,
  }) {
    return (
    <div>
      <Checkbox {...rest} {...input} type="checkbox" />
      <span className={touched && error ? 'validate-checkbox' : ''}>{label}</span>
    </div>
    );
  }

  render() {
    return (
      <div className="form register">
        <div className="main-section">
            <div className="primary-section">
              <h1>{this.props.translate('completeRegistration')}</h1>
            </div>
            <div className="secondary-section">
              <LanguageOption
                dispatch={this.props.dispatch}
                languages={languages}
              />
            </div>
        </div>
        <BlockUi blocking={this.props.candidateProfilesLoading}>
        <Form onSubmit={this.props.handleSubmit(this.handleRegistration)}>
          <div className="f">
            <Field
              name="email"
              type="text"
              label="Email"
              fullWidth
              component={this.renderField}
            />
          </div>
          <div className="f">
              <Field
                name="password"
                type="password"
                label="Password"
                fullWidth
                component={this.renderField}
              />
          </div>
          <div className="f">
              <Field
                name="confirm_password"
                type="password"
                label="Confirm Password"
                fullWidth
                component={this.renderField}
              />
          </div>
          <div className="f" hidden>
              <Field
                name="profile_id"
                type="text"
                label=""
                fullWidth
                component={this.renderField}
              />
          </div>
          <div className="f" hidden>
              <Field
                name="name"
                type="text"
                label=""
                fullWidth
                component={this.renderField}
              />
          </div>
          <div className="f">
            <Field
              name="agreeToTermsandCondidtions"
              label="I agree to Terms & Conditions"
              component={this.renderCheckbox}
            />
          </div>
          <div className="f footer">
            <Button onClick={() => this.props.history.push('/dashboard')}>{this.props.translate('cancel')}</Button>&nbsp;
            <Button color="primary" variant="raised" type="submit">{this.props.translate('register')}</Button>
          </div>
        </Form>
        </BlockUi>
      </div>
    )
  }
}

Register.propTypes = {
  translate: PropTypes.func.isRequired,
  candidateProfile: PropTypes.object.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  registerCandidate: PropTypes.func,
  valid: PropTypes.bool.isRequired,
  anyTouched: PropTypes.bool,
  history: PropTypes.object.isRequired, // eslint-disable-line
  changeViewState: PropTypes.func.isRequired,
  candidateProfilesLoading: PropTypes.bool.isRequired,
};

Register.defaultProps = {
  registerCandidate: () => {},
  anyTouched: false,
};

const mapStateToProps = state => {
  if(state.candidate.candidateProfile.profile)
  {
    return{
      candidateProfile: state.candidate.candidateProfile,
      initialValues: {
        email: state.candidate.candidateProfile.profile.email,
        profile_id: state.candidate.candidateProfile.profile.profile_id,
        name: state.candidate.candidateProfile.profile.name
    }
  }
  }
  else
  {
    return{
      candidateProfilesLoading: state.candidate.candidateProfilesLoading,
      candidateProfile: state.candidate.candidateProfile,
      initialValues: {
        email: null,
        profile_id: null
    }
  }
}
}

const mapDispatchToProps = dispatch => ({
  registerCandidate: (credentials) => dispatch(registerCandidate(credentials)),
  dispatch,
});

const RegisterForm = reduxForm({
  form: 'Registration',
  validate,
  enableReinitialize: true
})(Register);

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(withRouter(withTranslate(RegisterForm))));
