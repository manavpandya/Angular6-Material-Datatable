import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { showNotification } from './../../utils/Notifications';
import { verifyToken } from './redux/actions';
import RenderResetPage from './components/renderResetPage';

class RenderResetPageContainer extends Component {
  constructor(props) {
    super(props);
    this.showError = this.showError.bind(this);
  }

  componentDidMount() {
    if (this.props.match.params.token) {
      this.props.verifyToken(this.props.match.params.token)
        .catch(error => showNotification(error, 'error', 5000));
    }
  }

  showError(tokenResponse) {
    if (tokenResponse === 'error') {
      setTimeout(() => this.props.history.push('/'), 5000);
    }
  }

  render() {
    const resetToken = this.props.match.params.token;
    return (
      <div>
        <RenderResetPage
          verifyingToken={this.props.verifyingToken}
          tokenResponse={this.props.tokenResponse}
          resetToken={resetToken}
          paramsToken={this.props.match.params.token}
          showError={this.showError}
        />
      </div>
    );
  }
}

RenderResetPageContainer.propTypes = {
  match: PropTypes.object.isRequired, // eslint-disable-line
  verifyToken: PropTypes.func,
  verifyingToken: PropTypes.bool,
  history: PropTypes.object.isRequired, // eslint-disable-line
  tokenResponse: PropTypes.string,
};

RenderResetPageContainer.defaultProps = {
  verifyToken: () => {},
  verifyingToken: false,
  tokenResponse: '',
};

const mapStateToProps = state => ({
  tokenResponse: state.login.tokenResponse,
  verifyingToken: state.login.verifyingToken,
  verifiedToken: state.login.verifiedToken,
});

const mapDispatchToProps = dispatch => ({
  verifyToken: token => dispatch(verifyToken(token)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(RenderResetPageContainer)));// eslint-disable-line
