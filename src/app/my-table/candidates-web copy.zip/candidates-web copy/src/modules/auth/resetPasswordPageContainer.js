import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import Button from 'material-ui/Button';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { showNotification } from '../../utils/Notifications';
import { required, isEqual } from '../../utils/validators';
import { resetPasswordFunction, gotToIndexPage } from './redux/actions';
import ResetPasswordPage from './components/resetPasswordPage';
import Loader from '../../shared/basic/Loader';
import Confirmation from './components/Confirmation';

const errors = {};

let translate = () => {};

const validate = (values) => {
  errors.newPassword = required(values.newPassword);
  errors.confirmPassword = required(values.confirmPassword);
  if (values.confirmPassword) {
    errors.confirmPassword = !isEqual(values.newPassword, values.confirmPassword)
      ? translate('passwordNotMatched')
      : undefined;
  }
  return errors;
};

class ResetPasswordPageContainer extends Component {
  constructor(props) {
    super(props);

    this.submitNewPassword = this.submitNewPassword.bind(this);
  }

  componentDidMount() {
    translate = this.props.translate; // eslint-disable-line
  }

  submitNewPassword(values) {
    const passwords = {
      new_password: values.newPassword,
      confirm_password: values.confirmPassword,
    };
    this.props.resetPasswordFunction(
      this.props.resetToken,
      passwords,
    ).catch(error => showNotification(error.response.data.message.password, 'error', 5000));
  }

  render() {
    return (
      <div>
        <ResetPasswordPage
          submitNewPassword={this.submitNewPassword}
          validate={validate}
        />
        {
          this.props.settingPassword ?
            <Loader />
            :
            ''
        }
        {
          this.props.passwordSet ?
            <div>
              <Confirmation
                header={this.props.translate('passwordChangesSuccessMsg')}
                button={
                  <Button
                    type="button"
                    onClick={() => {
                      this.props.gotToIndexPage();
                      this.props.history.push('/');
                    }}
                  >
                    {this.props.translate('goToLoginPage')}
                  </Button>
                }
              />
            </div>
            :
            ''
        }
      </div>
    );
  }
}

ResetPasswordPageContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  resetPasswordFunction: PropTypes.func,
  settingPassword: PropTypes.bool,
  passwordSet: PropTypes.bool,
  gotToIndexPage: PropTypes.func,
  resetToken: PropTypes.string,
  match: PropTypes.object.isRequired, // eslint-disable-line
  history: PropTypes.object.isRequired // eslint-disable-line
};

ResetPasswordPageContainer.defaultProps = {
  resetPasswordFunction: () => {},
  gotToIndexPage: () => {},
  resetToken: '',
  settingPassword: false,
  passwordSet: false,
};

const mapStateToProps = state => ({
  settingPassword: state.login.settingPassword,
  passwordSet: state.login.passwordSet,
  errorSettingPassword: state.login.errorSettingPassword,
});

const mapDispatchToProps = dispatch => ({
  resetPasswordFunction: (token, passwords) => dispatch(resetPasswordFunction(token, passwords)),
  gotToIndexPage: () => dispatch(gotToIndexPage()),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(ResetPasswordPageContainer)));// eslint-disable-line
