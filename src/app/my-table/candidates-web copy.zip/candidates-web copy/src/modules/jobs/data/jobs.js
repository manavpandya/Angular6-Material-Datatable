import faker from 'faker'
import moment from 'moment'
import locations from './client/locations';
import projects from './client/projects';
import { resolve } from 'path';

const recency = 30
let shorten = (dateString) => {
  return dateString
    .replace(/in /, '')
    .replace(/a /, '1')
    .replace(/ months/, 'm')
    .replace(/ days/, 'd')
    .replace(/ hours/, 'h')
    .replace(/month/, 'm')
    .replace(/day/, 'd')
    .replace(/ hour/, 'h')
}

const jobTitles = () => {
  return [
    'Applications Engineer',
    'ARM Facilitator',
    'Automation Engineer',
    'Cementing Engineer',
    'Certification Engineer',
    'Chemical Engineer',
    'Chief Engineer',
    'Civil and Structural Engineer',
    'Civil Engineer',
    'Close Out Engineer',
    'Commissioning Engineer',
    'Completions Engineer',
    'Construction Engineer',
    'Contract Engineer',
    'Contracts Engineer',
    'Control and Instrumentation Engineer',
    'Control Systems Engineer',
    'Corrosion Engineer',
    'Cost Control Engineer',
    'Cost Engineer',
    'DCS Engineer',
    'Design Engineer',
    'Development Engineer',
    'Drilling Engineer',
    'Electrical and Instrumentation Engineer',
    'Electrical Design Engineer',
    'Electrical Engineer',
    'Engineering Operations',
    'Environmental Engineer',
    'Estimating Engineer',
    'Fabrication Engineer',
    'Facilities Engineer',
    'Field Engineer',
    'Field Service Engineer',
    'Fire Protection Engineer',
    'Flow Assurance Engineer',
    'Geotechnical and Geoscience Engineer',
    'Graduate Engineer',
    'HSE Engineer',
    'HVAC Engineer',
    'Inspection Engineer',
    'Installation engineer',
    'Instrument Commissioning Engineer',
    'Instrument Engineer',
    'Instrumentation Engineer',
    'Integrity Engineer',
    'Interface Engineer',
    'Loss Prevention Engineer',
    'Machinery Engineer',
    'Maintenance Engineer',
    'Marine Engineer',
    'Materials Engineer',
    'Mechanical Commissioning Engineer',
    'Mechanical Design Engineer',
    'Mechanical Engineer',
    'Mechanical Handling Engineer',
    'Mechanical Maintenance Engineer',
    'Mechanical Project Engineer',
    'Metallurgy Engineer',
    'Modeling Engineer',
    'Mud Engineer',
    'Networking Engineer',
    'Noise and Vibration Engineer',
    'Oil Spill Response Engineer',
    'Operations Engineer',
    'Petroleum Engineer',
    'Pipe Support Engineer',
    'Pipeline Engineer',
    'Pipeline Project Engineer',
    'Piping Design Engineer',
    'Piping Engineer',
    'Piping Materials Engineer',
    'Piping Stress Engineer',
    'Planning Engineer',
    'Process Chemical Engineer',
    'Process Engineer',
    'Process Safety Engineer',
    'Procurement Engineer',
    'Project Controls Engineer',
    'Project Engineer',
    'Project Management Engineer',
    'QA and QC Engineer',
    'QA Engineer',
    'Quality Control Engineer',
    'Quality Engineer',
    'Reliability Engineer',
    'Reservoir Engineer',
    'Riser Engineer',
    'Risk Engineer',
    'Rotating Equipment Engineer',
    'ROV Engineer',
    'Safety Case Engineer',
    'Safety Engineer',
    'Schedule Engineer',
    'Scheduling Engineer',
    'Seismic Engineer',
    'Service Engineer',
    'Site Engineer',
    'Static Equipment Engineer',
    'Stimulation Engineer',
    'Structural Design Engineer',
    'Structural Engineer',
    'Subcontracts Engineer',
    'Subsea Engineer',
    'Subsea Pipeline Engineer',
    'Subsea Project Engineer',
    'Systems Engineer',
    'Technical Safety Engineer',
    'Technical Sales Engineer',
    'Technical Support Engineer',
    'Telecommunications Engineer',
    'Testing Engineer',
    'Tooling Engineer',
    'Weight Control Engineer',
    'Welding Engineer',
    'Well Integrity Engineer',
    'Work Pack Engineer'
  ]
}


const createJob = (bookmarked, hasApplied) => {
  const bookmark = (bookmarked === true) ? true : faker.helpers.randomize([true, false])
  const applied = (hasApplied === true) ? true : faker.helpers.randomize([true, false])
  return {
    title: faker.helpers.randomize(jobTitles()),
    location: faker.helpers.randomize(locations()),
    description: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    posted: shorten(moment(faker.date.recent(recency)).fromNow()),
    isBookmarked: bookmark,
    applied: applied,
    projects : faker.helpers.randomize(projects())
  }
}

const getJobs = (count, bookmarked, applied) => {
  let jobs = []
  for (let i = 0; i < count; i++) {
    jobs.push(createJob(bookmarked, applied))
  }
  return Promise.resolve(jobs)
}

export default getJobs