import React, { Component } from 'react'
import PropTypes from 'prop-types';
import BlockUI from 'react-block-ui';
// import Tooltip from 'material-ui/Tooltip';
import Tooltip from '@material-ui/core/Tooltip';
class JobAdSummary extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }

  render() {
    const { userProfileId , loading, id, jobTitle, location, jobDescription, jobStartDate, allowToApply, isApplied, applysJob, isBookmarked, bookmarksJob, unBookmarksJob } = this.props;
    return (
      <BlockUI tag="div" className="job-ad-summary inline" blocking={loading}>
        {
          allowToApply
          ? isApplied
            ? <span className="icon applied job-apply-btn top-applied disabled">Applied</span>
            : <span onClick={(event) => applysJob(event, id,userProfileId)} className="icon applied top-applied job-apply-btn">Apply</span>
          : false
        }
        {
          isBookmarked
          ? 
            <Tooltip id="tooltip-fab" title="Unbookmark">
                <img  onClick={(event) => unBookmarksJob(event, id)} className="icon bookmark" src="/icons/bookmarked.svg" alt="unbookmarked" />
            </Tooltip>
          : 
            <Tooltip id="tooltip-fab" title="Bookmark">              
                <img onClick={(event) => bookmarksJob(event, id)} className="icon bookmark" src="/icons/bookmark.svg" alt="bookmarked" />
            </Tooltip>
        }
        <h3>{jobTitle}</h3>
        <h5>{location}</h5>
        <div className="scrollable">
          {jobDescription
            ? jobDescription
            : "No description available"}
        </div>
        <div className="footer">
          <h6 className="posted">Posted: {jobStartDate}</h6>
        </div>
      </BlockUI>
    )
  }
}

JobAdSummary.propTypes = {
  id: PropTypes.string,
  jobTitle: PropTypes.string,
  location: PropTypes.string,
  jobDescription: PropTypes.string,
  jobStartDate: PropTypes.string,
  allowToApply: PropTypes.bool,
  isApplied: PropTypes.bool,
  applysJob: PropTypes.func,
  isBookmarked: PropTypes.bool,
  bookmarksJob: PropTypes.func,
  unBookmarksJob: PropTypes.func,
};

JobAdSummary.defaultProps = {
  id: '',
  jobTitle: '',
  location: '',
  jobDescription: '',
  jobStartDate: '',
  allowToApply: false,
  isApplied: false,
  applysJob: () => {},
  isBookmarked: false,
  bookmarksJob: () => {},
  unBookmarksJob: () => {},
};

export default JobAdSummary
