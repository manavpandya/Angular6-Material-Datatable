import React, { Component } from 'react';
class JobDescription extends Component {
  render () {
    return (
      <div className="job-description">
        TechnipFMC is a global leader in subsea, onshore/offshore, and surface projects. With our proprietary technologies and production systems, integrated expertise, and comprehensive solutions, we are transforming our clients’ project economics. To learn more about how we are enhancing the performance of the world’s energy industry, go to www.TechnipFMC.com.
        Organization Unit : Connector [51931269]
        Business Unit : Schilling Robotics - US [ESSR]
        Grade : GRADE 17
        Employee Group : Established Employee
        Employee Sub-Group : Salary Full Time
        Personnel Sub-Area : Davis, CA
        Work Schedule : Normal (M - F)
        Location : Davis , CA
        Posted by: Bailey Barrows
      </div>
    );
  }
}
export default JobDescription
