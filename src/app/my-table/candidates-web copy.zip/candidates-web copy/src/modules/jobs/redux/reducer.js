import * as actionTypes from './actionTypes';

const initialState = {
  jobs: [],
  selectedSearchedJob: {},
  searchedJobPositionsCurrentPageNo: 0,
  searchedJobPositionsCurrentPageSize: 10,
  searchedData: [],
  searchedDataLoading: false,
  searchedDataError: false,
  selectedBookmarkedJobPosition: {},
  selectedAppliedJobApplication: {},
  searchedJobsLoading: false,
  searchedJobsSuccess: false,
  searchedJobsError: null,
  appliedJobApplications: [],
  appliedJobApplicationsCurrentPageNo: 0,
  appliedJobApplicationsCurrentPageSize: 10,
  totalAppliedJobApplications: 0,
  appliedJobApplicationsLoading: false,
  appliedJobApplicationsSuccess: false,
  appliedJobApplicationsError: null,
  bookmarkedJobPositions: [],
  bookmarkedJobPositionsCurrentPageNo: 0,
  bookmarkedJobPositionsCurrentPageSize: 10,
  totalBookmarkedJobPositions: 0,
  bookmarkedJobPositionsLoading: false,
  bookmarkedJobPositionsSuccess: false,
  bookmarkedJobPositionsError: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    // Applied Jobs
    case actionTypes.GET_APPLIED_JOB_APPLICATIONS_SUCCESS:
        return {
        ...state,
        appliedJobApplications: [
          ...state.appliedJobApplications,
          ...action.payload.applications,
        ],
        appliedJobApplicationsCurrentPageNo: action.payload.page,
        appliedJobApplicationsCurrentPageSize: action.payload.pageSize,
        totalAppliedJobApplications: action.payload.total,
        appliedJobApplicationsLoading: false,
        appliedJobApplicationsSuccess: true,
        appliedJobApplicationsError: null,
        };
    case actionTypes.GET_APPLIED_JOB_APPLICATIONS_LOADING:
      return {
        ...state,
        appliedJobApplicationsLoading: true,
        appliedJobApplicationsSuccess: false,
        appliedJobApplicationsError: null,
      };
    case actionTypes.GET_APPLIED_JOB_APPLICATIONS_ERROR:
    return {
        ...state,
        appliedJobApplicationsLoading: false,
        appliedJobApplicationsSuccess: false,
        appliedJobApplicationsError: action.payload,
      };
    case actionTypes.GET_CHANGED_APPLIED_JOB_APPLICATION:
        return {
        ...state,
        selectedAppliedJobApplication : action.payload,
    };
    case actionTypes.APPLY_JOB_POSITION_SUCCESS:
      return {
        ...state,
        appliedJobApplications: [
          ...state.appliedJobApplications.map(job => {
            if (job.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.is_applied = true;
              return matchingJob;
            }
            return job;
          })
        ],
        appliedJobApplicationsLoading: false,
        appliedJobApplicationsError: null,
        searchedJobsLoading: false,
      };
    case actionTypes.APPLY_JOB_POSITION_LOADING:
      return {
        ...state,
        appliedJobApplicationsLoading: true,
        appliedJobApplicationsError: null,
        searchedJobsLoading: true,        
      };
    case actionTypes.APPLY_JOB_POSITION_ERROR:
      return {
        ...state,
        appliedJobApplicationsLoading: false,
        appliedJobApplicationsError: action.payload,
        searchedJobsLoading: false,               
      };
    case actionTypes.FLUSH_APPLIED_JOB_APPLICATIONS:
      return {
        ...state,
        appliedJobApplications: [],
        appliedJobApplicationsCurrentPageNo: 0,
        appliedJobApplicationsCurrentPageSize: 10,
        totalAppliedJobApplications: 0,
        appliedJobApplicationsLoading: false,
        appliedJobApplicationsError: null,
      }

    // Bookmarked Jobs
    case actionTypes.GET_BOOKMARKED_JOB_POSITIONS_SUCCESS:
        return {
          ...state,
          bookmarkedJobPositions: [
            ...state.bookmarkedJobPositions,
            ...action.payload.job_positions,
          ],
          bookmarkedJobPositionsCurrentPageNo: action.payload.page,
          bookmarkedJobPositionsCurrentPageSize: action.payload.pageSize,
          totalBookmarkedJobPositions: action.payload.total,
          bookmarkedJobPositionsLoading: false,
          bookmarkedJobPositionsSuccess: true,
          bookmarkedJobPositionsError: null,
        };
    case actionTypes.GET_BOOKMARKED_JOB_POSITIONS_LOADING:
        return {
        ...state,
        bookmarkedJobPositionsLoading: true,
        bookmarkedJobPositionsSuccess: false,
        bookmarkedJobPositionsError: null,
        };
    case actionTypes.GET_BOOKMARKED_JOB_POSITIONS_ERROR:
    return {
        ...state,
        bookmarkedJobPositionsLoading: false,
        bookmarkedJobPositionsSuccess: false,
        bookmarkedJobPositionsError: true,
        };
    case actionTypes.GET_CHANGED_BOOKMARKED_JOB_POSITIONS:
        return {
        ...state,
        selectedBookmarkedJobPosition : action.payload,
    };
    case actionTypes.BOOKMARK_JOB_POSITION_SUCCESS:
      return {
        ...state,
        bookmarkedJobPositions: [
          ...state.bookmarkedJobPositions,
          action.payload
        ],
        appliedJobApplications: [
          ...state.appliedJobApplications.map(job => {
            if (job.job_position.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.job_position.is_bookmarked = true;
              return matchingJob;
            }
            return job;
          })
        ],
        bookmarkedJobPositionsLoading: false,
        bookmarkedJobPositionsError: null,
      }
    case actionTypes.BOOKMARK_JOB_POSITION_LOADING:
      return {
        ...state,
        bookmarkedJobPositionsLoading: true,
        bookmarkedJobPositionsError: null,
      }
    case actionTypes.BOOKMARK_JOB_POSITION_ERROR:
      return {
        ...state,
        bookmarkedJobPositionsLoading: false,
        bookmarkedJobPositionsError: action.payload,
      }
    case actionTypes.UNBOOKMARK_JOB_POSITION_SUCCESS:
      return {
        ...state,
        bookmarkedJobPositions: [
          ...state.bookmarkedJobPositions.filter(job_position => job_position.id !== action.payload.id),
        ],
        totalBookmarkedJobPositions: state.totalBookmarkedJobPositions - 1,
        appliedJobApplications: [
          ...state.appliedJobApplications.map(job => {
            if (job.job_position.id === action.payload.id) {
              const matchingJob = job;
              matchingJob.job_position.is_bookmarked = false;
              return matchingJob;
            }
            return job;
          })
        ],
        bookmarkedJobPositionsLoading: false,
        bookmarkedJobPositionsError: null,
      }
    case actionTypes.UNBOOKMARK_JOB_POSITION_LOADING:
      return {
        ...state,
        bookmarkedJobPositionsLoading: true,
        bookmarkedJobPositionsError: null,
      }
    case actionTypes.UNBOOKMARK_JOB_POSITION_ERROR:
      return {
        ...state,
        bookmarkedJobPositionsLoading: false,
        bookmarkedJobPositionsError: action.payload,
      }
    case actionTypes.FLUSH_BOOKMARKED_JOB_POSITIONS:
      return {
        ...state,
        bookmarkedJobPositions: [],
        bookmarkedJobPositionsCurrentPageNo: 0,
        bookmarkedJobPositionsCurrentPageSize: 10,
        totalBookmarkedJobPositions: 0,
        bookmarkedJobPositionsLoading: false,
        bookmarkedJobPositionsError: null,
      }
    default:
      return state;
  }
}
