export default function() {
    return [
      {
        city: 'Sydney',
        country: 'Australia'
      },
      {
        city: 'Melbourne',
        country: 'Australia'
      },
      {
        city: 'Brisbane',
        country: 'Australia'
      },
      {
        city: 'Perth',
        country: 'Australia'
      },
      {
        city: 'Adelaide',
        country: 'Australia'
      },
      {
        city: 'Gold Coast–Tweed Heads',
        country: 'Australia'
      },
      {
        city: 'Newcastle–Maitland',
        country: 'Australia'
      },
      {
        city: 'Canberra–Queanbeyan',
        country: 'Australia'
      },
      {
        city: 'Sunshine Coast',
        country: 'Australia'
      },
      {
        city: 'Wollongong',
        country: 'Australia'
      },
      {
        city: 'Hobart',
        country: 'Australia'
      },
      {
        city: 'Geelong',
        country: 'Australia'
      },
      {
        city: 'Townsville',
        country: 'Australia'
      },
      {
        city: 'Cairns',
        country: 'Australia'
      },
      {
        city: 'Darwin',
        country: 'Australia'
      },
      {
        city: 'Toowoomba',
        country: 'Australia'
      },
      {
        city: 'Ballarat',
        country: 'Australia'
      },
      {
        city: 'Bendigo',
        country: 'Australia'
      },
      {
        city: 'Albury–Wodonga',
        country: 'Australia'
      },
      {
        city: 'Launceston',
        country: 'Australia'
      },
      {
        city: 'Mackay',
        country: 'Australia'
      },
      {
        city: 'Rockhampton',
        country: 'Australia'
      },
      {
        city: 'Bunbury',
        country: 'Australia'
      },
      {
        city: 'Bundaberg',
        country: 'Australia'
      },
      {
        city: 'Coffs Harbour',
        country: 'Australia'
      },
      {
        city: 'Wagga Wagga',
        country: 'Australia'
      },
      {
        city: 'Hervey Bay',
        country: 'Australia'
      },
      {
        city: 'Mildura–Wentworth',
        country: 'Australia'
      },
      {
        city: 'Shepparton–Mooroopna',
        country: 'Australia'
      },
      {
        city: 'Port Macquarie',
        country: 'Australia'
      },
      {
        city: 'Gladstone–Tannum Sands',
        country: 'Australia'
      },
      {
        city: 'Tamworth',
        country: 'Australia'
      },
      {
        city: 'Traralgon–Morwell',
        country: 'Australia'
      },
      {
        city: 'Orange',
        country: 'Australia'
      },
      {
        city: 'Bowral–Mittagong',
        country: 'Australia'
      },
      {
        city: 'Geraldton',
        country: 'Australia'
      },
      {
        city: 'Busselton',
        country: 'Australia'
      },
      {
        city: 'Dubbo',
        country: 'Australia'
      },
      {
        city: 'Nowra–Bomaderry',
        country: 'Australia'
      },
      {
        city: 'Bathurst',
        country: 'Australia'
      },
      {
        city: 'Warragul–Drouin',
        country: 'Australia'
      },
      {
        city: 'Warrnambool',
        country: 'Australia'
      },
      {
        city: 'Albany',
        country: 'Australia'
      },
      {
        city: 'Kalgoorlie–Boulder',
        country: 'Australia'
      },
      {
        city: 'Devonport',
        country: 'Australia'
      },
      {
        city: 'Istanbul',
        country: 'Turkey'
      },
      {
        city: 'Moscow',
        country: 'Russia'
      },
      {
        city: 'London',
        country: 'United Kingdom'
      },
      {
        city: 'Saint Petersburg',
        country: 'Russia'
      },
      {
        city: 'Berlin',
        country: 'Germany'
      },
      {
        city: 'Madrid',
        country: 'Spain'
      },
      {
        city: 'Kiev',
        country: 'Ukraine'
      },
      {
        city: 'Rome',
        country: 'Italy'
      },
      {
        city: 'Paris',
        country: 'France'
      },
      {
        city: 'Minsk',
        country: 'Belarus'
      },
      {
        city: 'Bucharest',
        country: 'Romania'
      },
      {
        city: 'Vienna',
        country: 'Austria'
      },
      {
        city: 'Budapest',
        country: 'Hungary'
      },
      {
        city: 'Hamburg',
        country: 'Germany'
      },
      {
        city: 'Warsaw',
        country: 'Poland'
      },
      {
        city: 'Barcelona',
        country: 'Spain'
      },
      {
        city: 'Munich',
        country: 'Germany'
      },
      {
        city: 'Kharkiv',
        country: 'Ukraine'
      },
      {
        city: 'Milan',
        country: 'Italy'
      },
      {
        city: 'Prague',
        country: 'Czech Republic'
      },
      {
        city: 'Sofia',
        country: 'Bulgaria'
      },
      {
        city: 'Nizhny Novgorod',
        country: 'Russia'
      },
      {
        city: 'Kazan',
        country: 'Russia'
      },
      {
        city: 'Brussels',
        country: 'Belgium'
      },
      {
        city: 'Samara',
        country: 'Russia'
      },
      {
        city: 'Belgrade',
        country: 'Serbia'
      },
      {
        city: 'Birmingham',
        country: 'United Kingdom'
      },
      {
        city: 'Ufa',
        country: 'Russia'
      },
      {
        city: 'Rostov-on-Don',
        country: 'Russia'
      },
      {
        city: 'Tbilisi',
        country: 'Georgia'
      },
      {
        city: 'Cologne',
        country: 'Germany'
      },
      {
        city: 'Perm',
        country: 'Russia'
      },
      {
        city: 'Voronezh',
        country: 'Russia'
      },
      {
        city: 'Volgograd',
        country: 'Russia'
      },
      {
        city: 'Odessa',
        country: 'Ukraine'
      },
      {
        city: 'Dnipro',
        country: 'Ukraine'
      },
      {
        city: 'Naples',
        country: 'Italy'
      }
    ]
  }
  