import React, { Component } from 'react';

class JobThumb extends Component {
  render() {
    let { logo, alt, title, size, border } = this.props
    border = border || '#333333'
    size = size || 1
    logo = logo || ''
    return (
      <span className="job-thumb" >
        <img src={logo} alt={alt} title={title} style={{ width: `${size * 2}rem`, height: `${size * 2}rem`, border: `0px solid ${border}` }}  />
      </span>
    )
  }
}

export default JobThumb