export default function() {
    return [
      {
        name: 'Prelude FLNG',
        location: 'Browse Basin, Australia',
        client: 'Shell'
      },
      {
        name: 'Appomattox',
        location: 'Gulf of Mexico',
        client: 'Shell'
      },
      {
        name: 'Nigeria Liquefied Natural Gas (NLNG)',
        location: 'Bonny',
        client: 'Shell'
      },
      {
        name: 'Pennsylvania Petrochemicals Complex',
        location: 'Pennsylvania',
        client: 'Shell'
      },
      {
        name: 'Southern Swamp Associated Gas Solutions Project (SSAGS)',
        location: 'Nigeria',
        client: 'Shell'
      },
      {
        name: 'Trans Niger Pipeline Loopline (TNP)',
        location: '',
        client: 'Shell'
      },
      {
        name: 'Bonga North West',
        location: 'Bonga',
        client: 'Shell'
      },
      {
        name: 'Gumusut-Kakap',
        location: 'Malaysia',
        client: 'Shell'
      },
      {
        name: 'Malikai',
        location: 'Malaysia',
        client: 'Shell'
      },
      {
        name: 'Mars B',
        location: 'Gulf of Mexico',
        client: 'Shell'
      },
      {
        name: 'Majnoon',
        location: 'Iraq',
        client: 'Shell'
      },
      {
        name: 'Malampaya Phases 2 & 3',
        location: 'Philippines',
        client: 'Shell'
      },
      {
        name: 'Ormen Lange',
        location: 'Norway',
        client: 'Shell'
      },
      {
        name: 'Gorgon',
        location: 'Australia',
        client: 'Chevron'
      },
      {
        name: 'Wheatstone',
        location: 'Australia',
        client: 'Chevron'
      },
      {
        name: 'Jack/St. Malo',
        location: 'U.S. Gulf of Mexico',
        client: 'Chevron'
      },
      {
        name: 'Tengiz Expansion',
        location: 'Kazakhstan',
        client: 'Chevron'
      },
      {
        name: 'Big Foot',
        location: 'U.S. Gulf of Mexico',
        client: 'Chevron'
      },
      {
        name: 'Mafumeira Sul',
        location: 'Angola',
        client: 'Chevron'
      },
      {
        name: 'The Permian Basin',
        location: 'America',
        client: 'Chevron'
      },
      {
        name: 'Alder',
        location: 'North Sea',
        client: 'Chevron'
      },
      {
        name: 'Angola LNG',
        location: 'Africa',
        client: 'Chevron'
      },
    ]
  }
  