import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';
import Navigation from '../../modules/home-page/components/navigation';
import JobAdSummary from '../jobs/JobAdSummary';
import JobDetails from '../jobs/JobDetails';
import { showNotification } from '../../utils/Notifications';
import BlockUi from 'react-block-ui';
import InfiniteScroll from '../../shared/basic/InfiniteScroll';
import {
changeSelectedSearchedJob,
} from './redux/actions';
import {
  getSearchedJobs,  
  bookmarkJob,
  unBookmarkJob,
  applyJob,
  flushSearchedJobs
} from '../home-page/redux/actions';
import JobDetail from '../home-page/components/JobDetail';

class CandidateJobs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selected: null,
      open: false,
    }
    this.bookmarksJob = this.bookmarksJob.bind(this);
    this.unBookmarksJob = this.unBookmarksJob.bind(this);
    this.applysJob = this.applysJob.bind(this);
    this.checkLoaderVisibility = this.checkLoaderVisibility.bind(this);
  }

  checkLoaderVisibility() {
    return this.props.searchedJobPositionsCurrentPageNo === 0
      ? true
      : (this.props.total / (this.props.searchedJobPositionsCurrentPageNo * this.props.searchedJobPositionsCurrentPageSize)) > 1;
  }

  getNextPage() {
    const employmenttype = localStorage.getItem('job_type');
    const designation = localStorage.getItem('job_key');
    const location = localStorage.getItem('job_location');
    const date = localStorage.getItem('job_date');
    this.props.getSearchedJobs(employmenttype,designation,location,date,(this.props.searchedJobPositionsCurrentPageNo + 1),10);
  }

  bookmarksJob(event, value)
  {
    event.stopPropagation();
    if(value)
    {
      this.props.bookmarkJob({ "entity_type" : "job_position" , "entity_id": value }).then(() => {
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      });       
    }
  }

  unBookmarksJob(event, value)
  {
    event.stopPropagation();
    if(value)
    {
      this.props.unBookmarkJob({ "entity_type" : "job_position" , "entity_id": value }).then(() => {
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      });       
    }
  }

  applysJob(event,id,userProfileId)
  {
    event.stopPropagation();
    if(userProfileId && id)
    {
      this.props.applyJob(id, { "profile_id" : userProfileId , "external_id": id }).then(() => {
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      }); 
    }
  }

  selectJob = (job) => {
    this.setState({ selected: job , open: true })
  }

  handleClose = () => {
    this.setState({open: false});
  };

  render() {
    const { selectedSearchedJob } = this.props ? this.props.jobs : null;
    const  { profile } = this.props ? this.props.loggedUserProfile : null;
    const userProfileId  = profile ? profile.id : null;
    const { total , searchedData } = this.props;
    const selectedJob = this.state.selected;
    return ( <Fragment>
        <div className="page candidate">
          <header>
            <div className="container">
              <Navigation />
            </div>
          </header>
          <main className="search-results">
            <div className="container">
              <h1>{this.props.translate('searchResults')} ({total})</h1>
              <div className="jobs">
                <BlockUi className="full-width" blocking={this.props.searchedDataLoading}> 
                  <div className="list">
                    {
                    !total ? <div className="no-profiles">
                        <p>{this.props.translate('noSearchResultFound')}</p>
                      </div> : searchedData.map((job, i) => <a key={i} onClick={() => this.selectJob(job) }>
                          <JobAdSummary 
                            isApplied={job.is_applied} 
                            isBookmarked={job.is_bookmarked} 
                            loading={this.props.activeJobId === job.id && this.props.searchedJobsLoading} 
                            id={job.id} jobTitle={job.job_description && job.job_description.job_title} 
                            location={job && job.location && (job.location.country || `${"No Location Found"}`)} 
                            jobDescription={job && job.job_description ? (job.job_description.description ? job.job_description.description : job.job_description.employer ? job.job_description.employer : "No description available") : "No description available"} 
                            jobStartDate={String(job.job_description && job.job_description.job_start_date)} 
                            bookmarksJob={this.bookmarksJob} 
                            unBookmarksJob={this.unBookmarksJob} 
                            allowToApply={true} 
                            applysJob={this.applysJob} 
                            userProfileId={userProfileId} 
                            activeJobId={this.props.activeJobId} />
                        </a>)}
                    {
                      this.checkLoaderVisibility() &&
                      <InfiniteScroll
                        onReachedBottom={() => this.getNextPage()}
                      />
                    }
                  </div>
                </BlockUi>
                {selectedSearchedJob && Object.keys(selectedSearchedJob).length > 0 && <div className="selected">
                      <JobDetails job={selectedSearchedJob} />
                    </div>}
              </div>
              <div>
              {
                this.state && this.state.selected &&
                <JobDetail
                  open={this.state ? this.state.open : false}
                  handleClose={this.handleClose}
                  isBookmarked={selectedJob.is_bookmarked}                  
                  isApplied={selectedJob.is_applied}
                  allowToApply={true}
                  loading={this.props.activeJobId === selectedJob.id && this.props.searchedJobsLoading} 
                  id={selectedJob.id} 
                  jobTitle={selectedJob.job_description && selectedJob.job_description.job_title} 
                  location={selectedJob && selectedJob.location && (selectedJob.location.country || `${"No Location Found"}`)} 
                  jobDescription={selectedJob && selectedJob.job_description ? (selectedJob.job_description.description ? selectedJob.job_description.description : selectedJob.job_description.employer ? selectedJob.job_description.employer : "No description available") : "No description available"} 
                  jobStartDate={String(selectedJob.job_description && selectedJob.job_description.job_start_date)} 
                  bookmarksJob={this.bookmarksJob}
                  unBookmarksJob={this.unBookmarksJob}
                />
              }
              </div>
            </div>
          </main>
        </div>
      </Fragment>
    )
  }
}

CandidateJobs.propTypes = {
  translate: PropTypes.func.isRequired,
  getSearchedJobs: PropTypes.func.isRequired,
  selectedSearchedJob:PropTypes.object,
  searchedJobsLoading: PropTypes.bool,
  searchedJobsError: PropTypes.objectOf(PropTypes.any),
  bookmarkJob: PropTypes.func,
  unBookmarkJob: PropTypes.func,
  loggedUserProfile: PropTypes.objectOf(PropTypes.any),
  activeJobId: PropTypes.string,
  searchedJobPositionsCurrentPageNo: PropTypes.number,
  searchedJobPositionsCurrentPageSize: PropTypes.number,
  total: PropTypes.number,
  searchedData: PropTypes.arrayOf(PropTypes.any),  
  searchedDataLoading: PropTypes.bool,
  flushSearchedJobs: PropTypes.func,
};

CandidateJobs.defaultProps = {
  selectedSearchedJob: {},
  searchedJobsLoading: false,
  searchedJobsError: {}, 
  bookmarkJob: () => {},
  unBookmarkJob: () => {},
  loggedUserProfile: {},
  activeJobId: '',
  searchedJobPositionsCurrentPageNo: 0,
  searchedJobPositionsCurrentPageSize: 10,
  total: 0,
  searchedData: [],
  searchedDataLoading: false,
  flushSearchedJobs: () => {},
};

const mapStateToProps = state => ({
  jobs: state.jobs,
  selectedJob: state.jobs.selectedJob,
  searchedJobsLoading: state.jobs.searchedJobsLoading,
  searchedJobsError: state.jobs.searchedJobsError,
  searchedJobPositionsCurrentPageNo: state.dashboard.searchedJobPositionsCurrentPageNo,
  searchedJobPositionsCurrentPageSize: state.dashboard.searchedJobPositionsCurrentPageSize,
  total: state.dashboard.total,
  loggedUserProfile: state.candidate.loggedUserProfile,
  activeJobId: state.dashboard.activeJobId,
  searchedData: state.dashboard.searchedData, 
  searchedDataLoading: state.dashboard.searchedDataLoading, 
});

const mapDispatchToProps = dispatch => ({
  getSearchedJobs:(type,key,location,date,pageNo,perPage) => dispatch(getSearchedJobs(type,key,location,date,pageNo,perPage)),
  changeSelectedSearchedJob: (job) => dispatch(changeSelectedSearchedJob(job)),
  bookmarkJob:(jobData) => dispatch(bookmarkJob(jobData)),
  unBookmarkJob:(jobData) => dispatch(unBookmarkJob(jobData)),
  applyJob:(profileId,jobData) => dispatch(applyJob(profileId,jobData)),
  flushSearchedJobs: () => dispatch(flushSearchedJobs()),
  
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(CandidateJobs));