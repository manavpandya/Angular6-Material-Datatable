import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import Badge from 'material-ui/Badge'
import NotificationIcon from 'material-ui-icons/Notifications'
import JobThumb from '../jobs/JobThumb'

class JobSummary extends Component {
  render () {
    let { job, jobStatus } = this.props;
    let clientLogo = '/logos/' + job.projects.client.toLowerCase() + '.svg';
    let projectDesc = `${ job.projects.client }, ${ job.projects.name }, ${ job.projects.location}`
    return (
      <Link to="/recruiter/jobs/job" onClick={ this.props.onClick }>
        <div className={'job job-summary ' + (job.read === false ? 'unread' : '')}>
          <div className="id">
            <div className="client-logo">
              <JobThumb logo={clientLogo} size={0.5} alt={projectDesc} title={projectDesc} border="transparent" />
            </div>
            <div className="desc">
              <h6 className="meta-id">
                <span>
                  <span className="code">{ job.code }</span>
                  { job.type === 'contract' && <span className="job-type">Contract</span>}
                </span>
                <span className="date posted">{ job.posted }</span>
                {/* <span className="date due">Due: { job.due }</span> */}
              </h6>
              <div className="position">
                <h3 className="title">
                  { job.title }
                </h3>
                { job.positions > 1 ? <h3 className="open-positions">{ job.positions }</h3> : <span /> }
              </div>
              <div className="metrics">
                {(jobStatus < 2) && <label><span>Matched</span><strong>{ job.matched.length }</strong></label>}
                {(jobStatus === 2) && <label><span>Shortlisted</span><strong>{ job.shortlisted.length }</strong></label>}
                {(jobStatus === 3) && <label><span>Qualified</span><strong>{ job.qualified.length }</strong></label>}
                {(jobStatus === 4) && <label><span>Presented</span><strong>{ job.presented.length }</strong></label>}
                {(jobStatus === 4) && <label><span>Hired</span><strong>{ job.hired.length }</strong></label>}
              </div>
              <div className="dates">
                <p className="date last-updated"><span>Updated:</span><span>{ job.lastUpdated }</span></p>
                <p className="date posted"><span>Posted:</span><span>{ job.posted }</span></p>
                <p className="date due"><span>Due:</span><span>{ job.due }</span></p>
              </div>
              {
                (!job.read) ?
                  <Badge badgeContent={job.notification} className="notification">
                    <NotificationIcon style={{ width: 20, color: '#666' }} />
                  </Badge> : <span />
              }
            </div>
          </div>
        </div>
      </Link>
    );
  }
}

export default JobSummary
