import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';
import InfiniteScroll from '../../shared/basic/InfiniteScroll';
import Navigation from '../../modules/home-page/components/navigation';
import { showNotification } from '../../utils/Notifications';
import JobAdSummary from './JobAdSummary';
import JobAdd from './JobAdd';
import {
  flushBookmarkedJobPositions,
  getBookmarkedJobPositions,
  changeSelectedBookmarkedJobPosition,
} from './redux/actions';
import {
  unBookmarkJob,
  applyJob,
} from '../home-page/redux/actions';
import BlockUi from 'react-block-ui';
import JobDetail from '../home-page/components/JobDetail';

class JobBookmarked extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      selected: null,
    }
    this.checkLoaderVisibility = this.checkLoaderVisibility.bind(this);
    this.getNextPage = this.getNextPage.bind(this);
    this.unBookmarksJob = this.unBookmarksJob.bind(this);
    this.applysJob = this.applysJob.bind(this);
  }

  checkLoaderVisibility() {
    return this.props.bookmarkedJobPositionsCurrentPageNo === 0
      ? true
      : (this.props.totalBookmarkedJobPositions / (this.props.bookmarkedJobPositionsCurrentPageNo * this.props.bookmarkedJobPositionsCurrentPageSize)) > 1;
  }

  getNextPage() {
    this.props.getBookmarkedJobPositions(this.props.bookmarkedJobPositionsCurrentPageNo + 1);
  }

  unBookmarksJob(event, value)
  {
    event.preventDefault();    
    event.stopPropagation();
    if(value)
    {
      this.props.unBookmarkJob({ "entity_type" : "job_position" , "entity_id": value }).then(() => {
        this.props.flushBookmarkedJobPositions();
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      });       
    }
    this.setState({open: false});    
  }

  applysJob(event, value)
  {
    event.preventDefault();
    event.stopPropagation();
    const profileId = this.props.loggedUserProfile && this.props.loggedUserProfile.profile ? this.props.loggedUserProfile.profile.id : null;
    if(value && profileId)
    {
      this.props.applyJob(value, { "profile_id" : profileId , "external_id": value }).then(() => {
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      }); 
    } else {
      showNotification('Profile id not found', 'error', 8000);
    }
    this.setState({open: false});    
  }

  selectJob = (job) => {
    this.setState({ selected: job , open: true })
  }

  handleClose = () => {
    this.setState({open: false});
  };

  render() {
    const { bookmarkedJobPositions, selectedBookmarkedJobPosition } = this.props;
    const selectedJobDetail = this.state && this.state.selected; 
    return (
      <Fragment>
       <div className="page candidate">
        <header>
          <div className="container">
            <Navigation />
          </div>
        </header>
        <main className="search-results">
          <div className="container">
            <h1>{this.props.translate('myBookmarks')} ({this.props.totalBookmarkedJobPositions})</h1>
            <div className="jobs">
              <BlockUi className="full-width" blocking={this.props.bookmarkedJobPositionsLoading}> 
                <div className="list">
                  {
                    bookmarkedJobPositions.map((bookmarkedJobApplication, i) =>
                      <a key={i} onClick={() => this.selectJob(bookmarkedJobApplication) }>
                        <JobAdSummary
                          loading={this.props.activeJobId === bookmarkedJobApplication.id && (this.props.appliedJobApplicationsLoading || this.props.bookmarkedJobPositionsLoading)}
                          id={bookmarkedJobApplication && bookmarkedJobApplication.id}
                          jobTitle={bookmarkedJobApplication && bookmarkedJobApplication.job_description && bookmarkedJobApplication.job_description.job_title}
                          location={bookmarkedJobApplication && bookmarkedJobApplication.location && (bookmarkedJobApplication.location.country || `${"No Location Found"}`)}
                          jobDescription={
                            bookmarkedJobApplication && bookmarkedJobApplication.job_description
                            ? bookmarkedJobApplication.job_description.description
                              ? bookmarkedJobApplication.job_description.description 
                              : bookmarkedJobApplication.job_description.employer
                                ? bookmarkedJobApplication.job_description.employer
                                : 'No description available'
                            : 'No description available'
                          }
                          jobStartDate={String(bookmarkedJobApplication && bookmarkedJobApplication.job_description && bookmarkedJobApplication.job_description.job_start_date)}
                          allowToApply
                          isApplied={bookmarkedJobApplication && bookmarkedJobApplication.is_applied}
                          applysJob={this.applysJob}
                          isBookmarked={true}
                          unBookmarksJob={this.unBookmarksJob}
                        />
                      </a>
                    )
                  }
                  {
                    this.checkLoaderVisibility() &&
                    <InfiniteScroll
                      onReachedBottom={() => this.getNextPage()}
                    />
                  }
                  {/* {
                    this.props.bookmarkedJobPositionsLoading
                    ? (
                      <div className="infinite-spinner">
                        {this.props.translate('pleaseWait')}
                      </div>
                    )
                    : this.checkLoaderVisibility() &&
                      <div className="btn-load-more-container">
                        <Button
                          className="btn-load-more"
                          onClick={() => this.getNextPage()}
                        >
                          {this.props.translate('loadMore')}
                        </Button>
                      </div>
                  } */}
                </div>
              </BlockUi>
              {
                selectedBookmarkedJobPosition && Object.keys(selectedBookmarkedJobPosition).length > 0 &&
                <div className="selected">
                  <JobAdd job={selectedBookmarkedJobPosition} />
                </div>
              }
            </div>
            <div>
            {
                this.state && this.state.selected &&
                <JobDetail
                  open={this.state ? this.state.open : false}
                  handleClose={this.handleClose}
                  id={selectedJobDetail && selectedJobDetail.id}
                  jobTitle={selectedJobDetail && selectedJobDetail.job_description && selectedJobDetail.job_description.job_title}                
                  location={(selectedJobDetail && selectedJobDetail.location && selectedJobDetail.location.country) || `${"No Location Found"}`}
                  jobDescription={
                    selectedJobDetail && selectedJobDetail.job_description 
                    ? selectedJobDetail.job_description.description
                      ? selectedJobDetail.job_description.description 
                      : selectedJobDetail.job_description.employer
                        ? selectedJobDetail.job_description.employer
                        : 'No description available'
                    : 'No description available'
                  }
                  jobStartDate={String(selectedJobDetail && selectedJobDetail.job_description && selectedJobDetail.job_description.job_start_date)}
                  isApplied={true}
                  allowToApply={true}
                  isBookmarked={true}
                  bookmarksJob={this.bookmarksJob}
                  unBookmarksJob={this.unBookmarksJob}
                />
              }
            </div>
          </div>
        </main>
       </div>
      </Fragment>
    )
  }
}

JobBookmarked.propTypes = {
  translate: PropTypes.func.isRequired,
  flushBookmarkedJobPositions: PropTypes.func,
  getBookmarkedJobPositions: PropTypes.func.isRequired,
  selectedBookmarkedJobPosition:PropTypes.object,
  bookmarkedJobPositions: PropTypes.arrayOf(PropTypes.any),
  bookmarkedJobPositionsCurrentPageNo: PropTypes.number,
  bookmarkedJobPositionsCurrentPageSize: PropTypes.number,
  totalBookmarkedJobPositions: PropTypes.number,
  bookmarkedJobPositionsLoading: PropTypes.bool,
  appliedJobApplicationsLoading: PropTypes.bool,
  applyJob: PropTypes.func,
  unBookmarkJob: PropTypes.func,
  loggedUserProfile: PropTypes.objectOf(PropTypes.any),
  activeJobId: PropTypes.string,
};

JobBookmarked.defaultProps = {
  flushBookmarkedJobPositions: () => {},
  bookmarkedJobPositions: [],
  bookmarkedJobPositionsCurrentPageNo: 0,
  bookmarkedJobPositionsCurrentPageSize: 10,
  totalBookmarkedJobPositions: 0,
  bookmarkedJobPositionsLoading: false,
  appliedJobApplicationsLoading: false,
  applyJob: () => {},
  unBookmarkJob: () => {},
  loggedUserProfile: {},
  activeJobId: '',
}

const mapStateToProps = state => ({
  bookmarkedJobPositions: state.jobs.bookmarkedJobPositions,
  bookmarkedJobPositionsCurrentPageNo: state.jobs.bookmarkedJobPositionsCurrentPageNo,
  bookmarkedJobPositionsCurrentPageSize: state.jobs.bookmarkedJobPositionsCurrentPageSize,
  totalBookmarkedJobPositions: state.jobs.totalBookmarkedJobPositions,
  bookmarkedJobPositionsLoading: state.jobs.bookmarkedJobPositionsLoading,
  appliedJobApplicationsLoading: state.jobs.appliedJobApplicationsLoading,
  activeJobId: state.dashboard.activeJobId,
  selectedBookmarkedJobPosition: state.jobs.selectedBookmarkedJobPosition,
  loggedUserProfile: state.candidate.loggedUserProfile,
  // selectedJob: state.jobs.selectedJob,
});

const mapDispatchToProps = dispatch => ({
  flushBookmarkedJobPositions: () => dispatch(flushBookmarkedJobPositions()),
  getBookmarkedJobPositions: (pageNo, pageSize) => dispatch(getBookmarkedJobPositions(pageNo, pageSize)),
  changeSelectedBookmarkedJobPosition: (job) => dispatch(changeSelectedBookmarkedJobPosition(job)),
  unBookmarkJob:(jobData) => dispatch(unBookmarkJob(jobData)),
  applyJob:(profileId,jobData) => dispatch(applyJob(profileId,jobData)),
  dispatch,
});


export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(JobBookmarked));//eslint-disable-line