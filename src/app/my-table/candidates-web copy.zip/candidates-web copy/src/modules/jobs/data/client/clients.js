import _ from 'lodash';
import projects from './projects';

const clients = _.map(projects(), function (p) {
  return p.client
})

export default function() {
  return _.uniq(clients)
}
