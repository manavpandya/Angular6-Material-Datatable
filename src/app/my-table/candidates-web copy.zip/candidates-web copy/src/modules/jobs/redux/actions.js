import api from '../../../shared/api';
import * as ActionTypes from './actionTypes';

export function changeSelectedSearchedJob(data) {
    return {
      type: ActionTypes.GET_CHANGED_SEARCHED_JOB,
      payload: data,
    };
  }

export function getBookmarkedJobPositions(pageNo = 1, pageSize = 10) {
  return {
      type: ActionTypes.GET_BOOKMARKED_JOB_POSITIONS,
      payload: api().get(`/accounts/bookmarks?page=${pageNo}&per_page=${pageSize}`).then(res => ({
        ...res.data,
        pageSize,
      })), // getJobs(4,true),
  };
}

export function flushBookmarkedJobPositions() {
  return {
    type: ActionTypes.FLUSH_BOOKMARKED_JOB_POSITIONS,
    payload: null,
  }
}

export function changeSelectedBookmarkedJobPosition(data) {
    return {
      type: ActionTypes.GET_CHANGED_BOOKMARKED_JOB_POSITIONS,
      payload: data,
    };
  }

export function getAppliedJobApplications(pageNo = 1, pageSize = 10) {
  return {
      type: ActionTypes.GET_APPLIED_JOB_APPLICATIONS,
      payload: api().get(`/account/applications?page=${pageNo}&per_page=${pageSize}`).then(res => ({
        ...res.data,
        pageSize,
      })), // getJobs(10, false, true),
  };
}

export function flushAppliedJobApplications() {
  return {
    type: ActionTypes.FLUSH_APPLIED_JOB_APPLICATIONS,
    payload: null,
  }
}

export function changeSelectedAppliedJobApplication(data) {
  return {
    type: ActionTypes.GET_CHANGED_APPLIED_JOB_APPLICATION,
    payload: data,
  };
}