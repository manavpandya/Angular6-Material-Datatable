import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Button from 'material-ui/Button';
import Tooltip from 'material-ui/Tooltip';

class JobAdd extends Component {
  constructor(props) {
    super(props);
    this.state = {
      job: this.props.job
    }
  }

  toggleBookmark = () => {
    let job = this.state.job
    job.isBookmarked = !job.isBookmarked
    this.setState({ job: job })
  }

  render() {
    let { job } = this.props;
    return (
      <div className="job-ad">
        <h1>{ job.job_position && job.job_position.job_description && job.job_position.job_description.job_title }</h1>
        <p>{ job.job_position && job.job_position.location && `${job.location.city}, ${job.location.country}` }</p>
        {/* <p>{ job.description.substr(0, 300) }</p> */}
        <div className="actions">
        {
          job && (
            job.isBookmarked
              ? (
                <Tooltip id="tooltip-fab" title="Unbookmark">
                  <Button aria-label="Unbookmark" onClick={ this.toggleBookmark } className="bookmarked">
                    <img className="icon bookmark" src="/icons/bookmark.svg" alt="bookmarked" />
                    Bookmark
                  </Button>
                </Tooltip>
              )
              : (
                <Tooltip id="tooltip-fab" title="Bookmark">                
                  <Button aria-label="Boookmark" onClick={ this.toggleBookmark } className="bookmark">
                    <img className="icon bookmark" src="/icons/bookmark.svg" alt="bookmark" />
                    Bookmark
                  </Button>
                </Tooltip>
              )
          )
        }
        { job && (
          job.applied
            ? <Button variant="raised" disabled className="applied">Applied</Button>
            : <Button variant="raised" color="primary" className="apply">Apply</Button>
        )
        }
        </div>

        <div className="job-description">
          {
            job.job_position && job.job_position.job_description
            ? job.job_position.job_description.description
              ? job.job_position.job_description.description 
              : job.job_position.job_description.employer
                ? job.job_position.job_description.employer
                : 'No description available'
            : 'No description available'
          }
        </div>

      </div>
    )
  }
}

JobAdd.propTypes = {
  job: PropTypes.objectOf(PropTypes.any),
};

JobAdd.defaultProps = {
  job: {},
};

export default JobAdd;
