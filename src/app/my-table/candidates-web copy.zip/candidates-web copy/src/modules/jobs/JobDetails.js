import React, { Component } from 'react';
import JobDescription from '../jobs/JobDescription';
import Button from 'material-ui/Button';

class JobDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      job: this.props.job
    }
  }

  toggleBookmark = () => {
    let job = this.state.job
    job.isBookmarked = !job.isBookmarked
    this.setState({ job: job })
  }

  render() {
    let { job } = this.props;
    return (
      <div className="job-ad">
        <h1>{ job.title }</h1>
        <p>{ Object.keys(job).length > 0 && `${job.location.city}, ${job.location.country}` }</p>
        <p>{ job.description.substr(0, 300) }</p>
        <div className="actions">
        {
          job && (
            job.isBookmarked ?
              <Button onClick={ this.toggleBookmark } className="bookmarked">
                <img className="icon bookmark" src="/icons/bookmark.svg" alt="bookmarked" />
                Bookmark
              </Button>:
              <Button onClick={ this.toggleBookmark } className="bookmark">
                <img className="icon bookmark" src="/icons/bookmark.svg" alt="bookmark" />
                Bookmark
              </Button>
          )
        }
        { job && (
          job.applied ?
            <Button variant="raised" disabled className="applied">Applied</Button> :
            <Button variant="raised" color="primary" className="apply">Apply</Button>
        )
        }
        </div>

        <JobDescription />

      </div>
    )
  }
}

export default JobDetails