import React, { Component, Fragment } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';
import InfiniteScroll from '../../shared/basic/InfiniteScroll';
import Navigation from '../../modules/home-page/components/navigation';
import { showNotification } from '../../utils/Notifications';
import JobAdSummary from './JobAdSummary';
import JobAdd from './JobAdd';
import {
  getAppliedJobApplications,
  changeSelectedAppliedJobApplication,
} from './redux/actions';
import {
  bookmarkJob,
  unBookmarkJob,
} from '../home-page/redux/actions';
import BlockUi from 'react-block-ui';
import JobDetail from '../home-page/components/JobDetail';

class JobApplied extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      selected: null,
    }
    this.checkLoaderVisibility = this.checkLoaderVisibility.bind(this);
    this.getNextPage = this.getNextPage.bind(this);
    this.bookmarksJob = this.bookmarksJob.bind(this);
    this.unBookmarksJob = this.unBookmarksJob.bind(this);
  }

  selectJob = (job) => {
    this.props.changeSelectedAppliedJobApplication(job);
  }

  checkLoaderVisibility() {
    return this.props.appliedJobApplicationsCurrentPageNo === 0
      ? true
      : (this.props.totalAppliedJobApplications / (this.props.appliedJobApplicationsCurrentPageNo * this.props.appliedJobApplicationsCurrentPageSize)) > 1;
  }

  getNextPage() {
    this.props.getAppliedJobApplications(this.props.appliedJobApplicationsCurrentPageNo + 1);
  }

  bookmarksJob(event, value)
  {
    event.preventDefault();
    event.stopPropagation();
    if(value)
    {
      this.props.bookmarkJob({ "entity_type" : "job_position" , "entity_id": value })
      .catch((response) => {
        showNotification(response.message, 'error', 8000);
      });  
    }
  }

  unBookmarksJob(event, value)
  {
    event.preventDefault();    
    event.stopPropagation();
    if(value)
    {
      this.props.unBookmarkJob({ "entity_type" : "job_position" , "entity_id": value })
      .catch((response) => {
        showNotification(response.message, 'error', 8000);
      });       
    }
  }

  selectJob = (job) => {
    this.setState({ selected: job , open: true })
  }

  handleClose = () => {
    this.setState({open: false});
  };

  render() {
    const { appliedJobApplications, selectedAppliedJobApplication } = this.props;
    const selectedJobDetail = this.state && this.state.selected;
    return (
      <Fragment>
       <div className="page candidate">
        <header>
          <div className="container">
            <Navigation />
          </div>
        </header>
        <main className="search-results">
          <div className="container">
            <h1>{this.props.translate('myApplications')} ({this.props.totalAppliedJobApplications})</h1>
            <div className="jobs">
             <BlockUi className="full-width" blocking={this.props.appliedJobApplicationsLoading}>     
              <div className="list">
                {
                  appliedJobApplications.map((appliedJobApplication, i) =>
                    <a key={i} onClick={() => this.selectJob(appliedJobApplication) }>
                      <JobAdSummary
                        loading={this.props.activeJobId === appliedJobApplication.id && this.props.bookmarkedJobPositionsLoading}
                        id={appliedJobApplications && appliedJobApplication.job_position.id}
                        jobTitle={appliedJobApplications && appliedJobApplication.job_position && appliedJobApplication.job_position.job_description && appliedJobApplication.job_position.job_description.job_title}
                        location={appliedJobApplications && appliedJobApplication.job_position && appliedJobApplication.job_position.location && appliedJobApplication.job_position.location.country}
                        jobDescription={
                          appliedJobApplications && appliedJobApplication.job_position && appliedJobApplication.job_position.job_description
                          ? appliedJobApplication.job_position.job_description.description
                            ? appliedJobApplication.job_position.job_description.description 
                            : appliedJobApplication.job_position.job_description.employer
                              ? appliedJobApplication.job_position.job_description.employer
                              : 'No description available'
                          : 'No description available'
                        }
                        jobStartDate={String(appliedJobApplications && appliedJobApplication.job_position && appliedJobApplication.job_position.job_description && appliedJobApplication.job_position.job_description.job_start_date)}
                        isApplied={true}
                        isBookmarked={appliedJobApplications && appliedJobApplication.job_position.is_bookmarked}
                        bookmarksJob={this.bookmarksJob}
                        unBookmarksJob={this.unBookmarksJob}
                      />
                    </a>
                  )
                }
                {
                  this.checkLoaderVisibility() &&
                  <InfiniteScroll
                    onReachedBottom={() => this.getNextPage()}
                  />
                }
                {/* {
                  this.props.appliedJobApplicationsLoading
                  ? (
                    <div className="infinite-spinner">
                      {this.props.translate('pleaseWait')}
                    </div>
                  )
                  : this.checkLoaderVisibility() &&
                    <div className="btn-load-more-container">
                      <Button
                        className="btn-load-more"
                        onClick={() => this.getNextPage()}
                      >
                        {this.props.translate('loadMore')}
                      </Button>
                    </div>
                } */}
              </div>
            </BlockUi>              
              {
                selectedAppliedJobApplication && Object.keys(selectedAppliedJobApplication).length > 0 &&
                <div className="selected">
                  <JobAdd job={selectedAppliedJobApplication} />
                </div>
              }
            </div>
            <div>
              {
                this.state && this.state.selected &&
                <JobDetail
                  open={this.state ? this.state.open : false}
                  handleClose={this.handleClose}
                  id={selectedJobDetail && selectedJobDetail.job_position.id}
                  jobTitle={selectedJobDetail && selectedJobDetail.job_position && selectedJobDetail.job_position.job_description && selectedJobDetail.job_position.job_description.job_title}                
                  location={(selectedJobDetail && selectedJobDetail.job_position && selectedJobDetail.job_position.location && selectedJobDetail.job_position.location.country) || `${"No Location Found"}`}
                  jobDescription={
                    selectedJobDetail && selectedJobDetail.job_position && selectedJobDetail.job_position.job_description
                    ? selectedJobDetail.job_position.job_description.description
                      ? selectedJobDetail.job_position.job_description.description 
                      : selectedJobDetail.job_position.job_description.employer
                        ? selectedJobDetail.job_position.job_description.employer
                        : 'No description available'
                    : 'No description available'
                  }
                  jobStartDate={String(selectedJobDetail && selectedJobDetail.job_position && selectedJobDetail.job_position.job_description && selectedJobDetail.job_position.job_description.job_start_date)}
                  isApplied={true}
                  allowToApply={false}
                  isBookmarked={selectedJobDetail && selectedJobDetail.job_position.is_bookmarked}
                  bookmarksJob={this.bookmarksJob}
                  unBookmarksJob={this.unBookmarksJob}
                />
              }
            </div>
          </div>
        </main>
       </div>
      </Fragment>
    )
  }
}

JobApplied.propTypes = {
  translate: PropTypes.func.isRequired,
  getAppliedJobApplications: PropTypes.func.isRequired,
  selectedAppliedJobApplication:PropTypes.object,
  appliedJobApplications: PropTypes.arrayOf(PropTypes.any),
  appliedJobApplicationsCurrentPageNo: PropTypes.number,
  appliedJobApplicationsCurrentPageSize: PropTypes.number,
  totalAppliedJobApplications: PropTypes.number,
  appliedJobApplicationsLoading: PropTypes.bool,
  bookmarkedJobPositionsLoading: PropTypes.func,
  activeJobId: PropTypes.string,
  bookmarkJob: PropTypes.func,
  unBookmarkJob: PropTypes.func,
};

JobApplied.defaultProps = {
  appliedJobApplications: [],
  appliedJobApplicationsCurrentPageNo: 0,
  appliedJobApplicationsCurrentPageSize: 10,
  totalAppliedJobApplications: 0,
  appliedJobApplicationsLoading: false,
  bookmarkedJobPositionsLoading: false,
  activeJobId: '',
  bookmarkJob: () => {},
  unBookmarkJob: () => {},
}

const mapStateToProps = state => ({
  appliedJobApplications: state.jobs.appliedJobApplications,
  appliedJobApplicationsCurrentPageNo: state.jobs.appliedJobApplicationsCurrentPageNo,
  appliedJobApplicationsCurrentPageSize: state.jobs.appliedJobApplicationsCurrentPageSize,
  totalAppliedJobApplications: state.jobs.totalAppliedJobApplications,
  appliedJobApplicationsLoading: state.jobs.appliedJobApplicationsLoading,
  bookmarkedJobPositionsLoading: state.jobs.bookmarkedJobPositionsLoading,
  activeJobId: state.dashboard.activeJobId,
  selectedAppliedJobApplication: state.jobs.selectedAppliedJobApplication,
  // selectedJob: state.jobs.selectedJob,
});

const mapDispatchToProps = dispatch => ({
  getAppliedJobApplications: (pageNo, pageSize) => dispatch(getAppliedJobApplications(pageNo, pageSize)),
  changeSelectedAppliedJobApplication: (job) => dispatch(changeSelectedAppliedJobApplication(job)),
  bookmarkJob:(jobData) => dispatch(bookmarkJob(jobData)),
  unBookmarkJob:(jobData) => dispatch(unBookmarkJob(jobData)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(JobApplied));
