const languages = [{
  label: 'ENGLISH',
  locale: 'en',
}, {
  label: 'SPANISH',
  locale: 'es',
}];

export default languages;
