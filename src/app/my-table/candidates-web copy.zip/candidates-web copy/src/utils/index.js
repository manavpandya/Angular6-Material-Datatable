export const getOptions = (url, input) => {
  const token = `Bearer ${JSON.parse(localStorage.getItem('user_info'))}`;
  if (!input) {
    return Promise.resolve({ options: [] });
  }
  return fetch(url + input, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      Authorization: token,
    },
  }).then(response => response.json())
    .then(json => ({ options: json.terms }));
};

export function sortAll(arr, key = 'key', direction = 'asc', type = 'string') {
  return arr.sort((a, b) => {
    let keyA;
    let keyB;
    if (type === 'string') {
      keyA = a[key].toLowerCase();
      keyB = b[key].toLowerCase();
    }
    if (type === 'number') {
      keyA = parseInt(a[key], 2);
      keyB = parseInt(b[key], 2);
    }
    if (type === 'date') {
      keyA = new Date(a[key]);
      keyB = new Date(b[key]);
    }
    if (direction === 'desc') {
      if (keyA < keyB) return 1;
      if (keyA > keyB) return -1;
    } else {
      if (keyA < keyB) return -1;
      if (keyA > keyB) return 1;
    }
    return 0;
  });
}
