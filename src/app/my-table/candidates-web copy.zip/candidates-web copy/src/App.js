import React from 'react';
import 'normalize.css/normalize.css';
import { ToastContainer } from 'react-toastify'; // Initialize Notification Container
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import MomentUtils from 'material-ui-pickers/utils/moment-utils';
import MuiPickersUtilsProvider from 'material-ui-pickers/utils/MuiPickersUtilsProvider';
import 'react-block-ui/style.css';
import Routes from './routes';
import TalentXTheme from './assets/styles/TalentXTheme'; // Theme
import './assets/styles/talentx.sass'; // CSS

require('typeface-roboto');
require('typeface-roboto-condensed');
require('typeface-nunito');

const App = () => (
  <MuiPickersUtilsProvider utils={MomentUtils}>
    <MuiThemeProvider theme={TalentXTheme}>
      <ToastContainer id="forToast" />
      <Routes />
    </MuiThemeProvider>
  </MuiPickersUtilsProvider>
);

export default App;
