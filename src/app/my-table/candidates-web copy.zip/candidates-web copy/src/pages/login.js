import React from 'react';
import  LandingPage  from '../modules/auth/components/authLanding';

const Login = () => (
  <LandingPage />
);

export default Login;
