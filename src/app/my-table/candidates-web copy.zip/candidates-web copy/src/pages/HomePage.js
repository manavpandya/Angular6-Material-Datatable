import React from 'react';

import DashboardContainer from '../modules/home-page';

const Dashboard = () => (
  <DashboardContainer />
);

export default Dashboard;
