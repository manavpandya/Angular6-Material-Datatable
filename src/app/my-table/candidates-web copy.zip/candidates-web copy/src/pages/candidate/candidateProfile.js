import React, { Component } from 'react'
import { withRouter } from 'react-router';
import { Route, NavLink } from 'react-router-dom'
import { connect } from 'react-redux';
import Navigation from '../../modules/home-page/components/navigation';
import ProfileTab from '../../modules/candidate/fields/ProfileTab'
import Avatar from '../../modules/home-page/components/avatar';
import candidateProfileImage from '../../assets/images/candidate-profile.png';
// import profile from './data/profile'
import Sticky from 'react-sticky-el';

class CandidateProfile extends Component {
  componentWillMount () {
    if (!this.props.match.params.group) {
      this.props.history.push('/candidate/profile/current');
    }
  }

  render () {
    let { profile } = this.props;
    const MyProfile = profile ? profile.data : null;
    const contactInformation = MyProfile ? MyProfile.contact_information : null;
    const email = contactInformation ? contactInformation.email[0] : null;
    const personName = contactInformation && contactInformation.person_name ? contactInformation.person_name.FormattedName : null;
    const conatctNo = contactInformation && contactInformation.other_phone_no ? contactInformation.other_phone_no[0] : null;
    const experienceDetails = MyProfile ? MyProfile.experience_details : null ;
    const designation = experienceDetails ? experienceDetails.current_job_title || null : null;
    const company = experienceDetails ? experienceDetails.current_employer || null : null;
    return (
      <div className="page candidate">
        <header>
          <div className="container">
            <Navigation
              logout={this.props.logout}
              changeLanguages={this.changeLanguages}
            />
          </div>
        </header>
        {
          profile &&
          <main className="profile">
            <div className="container">
              <header>
                <section className="summary">
                  <div className="edit-avatar">
                    <Avatar avatar={candidateProfileImage} size={3} />
                  </div>
                  <div>
                    <h1>{personName}</h1>
                    <h2>{designation}</h2>
                    <h3>{company}</h3>
                  </div>
                  <div className="contact">
                    <div>
                    <img style={ { width: '1rem' } } src="/icons8-phone.svg" alt="email" className="email contact-icon" />
                    <span>{conatctNo}</span>
                    </div>
                    <div>
                    <img style={ { width: '1rem' } } src="/icons8-email.svg" alt="email" className="email contact-icon" />
                    <span>{email}</span>
                    </div>
                  </div>
                </section>
                <Sticky>
                  <nav>
                    {
                      profile && profile.config && profile.config.groups.map((g, i) =>
                        <NavLink key={i} to={ `/candidate/profile${g.path}` }>{ g.label }</NavLink>
                      )
                    }
                  </nav>
                </Sticky>
              </header>
              <Route path="/candidate/profile/:group"
                component={(props) => (<ProfileTab {...props} data={profile.data} config={profile.config} />)}/>
            </div>
          </main>
        }
      </div>
    )
  }
}

const mapStateToProps = state => ({
  profile: state.candidate.profile,
});

export default connect(mapStateToProps)(withRouter(CandidateProfile));

