export default {
  label: 'Preferences',
  name: 'current',
  path: '/current',
  fieldsets: [
    {
      fields: [
        { label: 'Availability', key: 'availability', data: 'location_details' },
        { label: 'Salary', key: 'current_salary', data: 'personal_information' },
        { label: 'ExpectedSalary', key: 'expected_salary', data: 'personal_information' }
      ],
    },
    // {
    //   legend: 'Preferred Contact',
    //   fields: [
    //     { label: 'Mobile', key: 'preferred_mobile', data: 'contact_methods' },
    //     { label: 'Email', key: 'preferred_email', data: 'contact_methods' },
    //     { label: 'Web Address', key: 'internet_web_address', data: 'contact_methods' }
    //   ]
    // },
    {
      legend: 'Location',
      fields: [
        { label: 'Current Location', key: 'current_location', data: 'location_details' },
        { label: 'Preferred Location', key: 'preferred_location', data: 'location_details' }
      ]
    }
  ]
}