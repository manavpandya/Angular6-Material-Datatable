export default {
  label: 'Skills',
  name: 'skills',
  path: '/skills',
  fieldsets: [
    {
      legend: 'Core Skills',
      fields: [
        { label: 'Skills', key: 'skills', data: 'qualifications' }
      ]
    },
    {
      legend: 'Other Skills',
      fields: [
        { label: 'Languages', key: 'language', data: 'language' }
      ]
    },
    // {
    //   legend: 'Licenses',
    //   fields: [
    //     { label: 'Licenses', key: 'licenses', data: 'licenses' },
    //   ]
    // },
    // {
    //   legend: 'Certificates',
    //   fields: [
    //     { label: 'Certificates', key: 'certificates', data: 'certificates' },
    //   ]
    // },
    {
      legend: 'License And Certifications',
      fields: [
        { label: 'License & Certifications', key: 'license_and_certifications', data: 'certification_license' },
      ]
    },
    {
      legend: 'Patents',
      fields: [
        { label: 'Patents', key: 'patents', data: 'patent' },
      ]
    },
    {
      legend: 'Publications',
      fields: [
        { label: 'Publications', key: 'publication_history', data: 'publication' },
      ]
    },
    {
      legend: 'Speaking Engagements',
      fields: [
        { label: 'Events', key: 'speaking_events_history', data: 'speaking_engagements' },
      ]
    }
  ]
}