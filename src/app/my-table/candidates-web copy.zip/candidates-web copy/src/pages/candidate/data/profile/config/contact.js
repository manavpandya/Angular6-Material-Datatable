export default {
  label: 'Contact',
  name: 'contact',
  path: '/contact',
  fieldsets: [
    {
      fields: [
        { label: 'Mobile', key: 'mobile', data: 'contact_information' },
        { label: 'Other Mobile', key: 'other_phone', data: 'contact_information' },
        { label: 'Email', key: 'email', data: 'contact_information' },
        // { label: 'Web Address', key: 'internet_web_address', data: 'internet_web_address' },
        { label: 'Social Network', key: 'social', data: 'contact_information' },
      ]
    },
    // {
    //   label: 'Address',
    //   fields: [
    //     { label: 'Postal Address', key: 'postal_address' },
    //   ]
    // }
  ]
}