export default {
  label: 'Education',
  name: 'education',
  path: '/education',
  fieldsets: [
    {
      fields: [
        { label: 'School', key: 'school', data: 'education_details' }
      ]
    }
  ]
}