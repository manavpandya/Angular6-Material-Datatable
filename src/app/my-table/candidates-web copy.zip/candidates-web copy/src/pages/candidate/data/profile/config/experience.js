export default {
  label: 'Work History',
  name: 'experience',
  path: '/experience',
  fieldsets: [
    {
      fields: [
        { label: 'Positions', key: 'all_job_titles', data: 'experience_details' }
      ]
    }
  ]
}