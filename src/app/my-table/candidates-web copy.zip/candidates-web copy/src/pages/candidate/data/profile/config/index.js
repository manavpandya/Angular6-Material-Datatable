import current from './current'
import skills from './skills'
import experience from './experience'
import education from './education'
import contact from './contact'
import personal_information from './personal_information'

export default {
  groups: [
    current,
    skills,
    experience,
    education,
    contact,
    personal_information
  ]
}