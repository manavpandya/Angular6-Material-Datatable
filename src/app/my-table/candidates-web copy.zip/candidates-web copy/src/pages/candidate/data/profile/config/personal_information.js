export default {
  label: 'Personal Information',
  name: 'personal_information',
  path: '/personal_information',
  fieldsets: [
    {
      fields: [
        { label: 'Full Name', key: 'person_name', data: 'contact_information' },
      ]
    },
    {
      fields: [
        { label: 'Date of Birth', key: 'date_of_birth' , data: 'personal_information' },
        { label: 'Gender', key: 'gender' , data: 'personal_information' },
        { label: 'Nationality', key: 'nationality', data: 'personal_information' }
      ]
    },
  ]
}