import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import { reducer as formReducer } from 'redux-form';
import { IntlReducer } from 'react-redux-multilingual';
import loginReducer from '../modules/auth/redux/reducer';
import CandidateReducer from '../modules/candidate/redux/reducer';
import dashboardReducer from '../modules/home-page/redux/reducer';
import clients from '../modules/jobs/data/client/clients';
import locations from '../modules/jobs/data/client/locations';
import projects from '../modules/jobs/data/client/projects';
import JobsReducer from '../modules/jobs/redux/reducer';

const rootReducer = combineReducers({
  form: formReducer,
  Intl: IntlReducer,
  routing: routerReducer,
  login : loginReducer,
  candidate : CandidateReducer ,
  dashboard: dashboardReducer,
  jobs : JobsReducer,
  clients,
  locations,
  projects,
});

export default rootReducer;
