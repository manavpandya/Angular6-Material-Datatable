import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import 'normalize.css/normalize.css';
// Authentication related pages
import login from './pages/login';

// Candidate Home Page
import HomePage from './pages/HomePage';
import CandidateProfile from './pages/candidate/candidateProfile';
// Auth HOC
import AuthProvider from './modules/auth/components/AuthenticationHOC';

import RenderResetPageContainer from './modules/auth/renderResetPageContainer';
import CandidateJobs from './modules/jobs/CandidateJobs';
import JobApplied from './modules/jobs/JobApplied';
import JobBookmarked from './modules/jobs/JobBookmarked';
import VerifyAccount from './modules/auth/components/VerifyAccount';

import Logout from './modules/auth/components/Logout';

// Theme
import './assets/styles/talentx.sass';
require('typeface-roboto');
require('typeface-roboto-condensed');

const Routes = () => (
  <BrowserRouter>
    <div>
      <Route exact path="/" component={(login)} />
      <Route exact path="/logout" component={Logout} />
      <Route
          exact
          path="/reset_password/:token?"
          name="Reset Password Page"
          component={RenderResetPageContainer}
        />
      <Route
        exact
        path="/account_verification/:token?"
        name="Account Verification"
        component={VerifyAccount}
      />
      {/* Candidate home page related router */}
      <Route exact path="/dashboard" component={AuthProvider(HomePage)} />
      <Route exact path="/candidate/search" component={AuthProvider(CandidateJobs)} />
      <Route exact path="/candidate/applications" component={AuthProvider(JobApplied)} />
      <Route exact path="/candidate/bookmarks" component={AuthProvider(JobBookmarked)} />
      <Route path="/candidate/profile/:group?" component={AuthProvider(CandidateProfile)} />
    </div>
  </BrowserRouter>
);

export default Routes;
