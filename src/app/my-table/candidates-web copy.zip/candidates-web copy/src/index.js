import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { IntlProvider } from 'react-redux-multilingual';
import _ from 'lodash';
import App from './App';
import configureStore from './store/configureStore';
import translations from './i18n/translations';

const store = configureStore();

const setIntercomConfig = () => {
  const state = store.getState().candidate;
  const hasToken = localStorage.getItem('user_info');
  if (!_.isEmpty(state.accountInfo)) {
    window.Intercom('boot', {
      app_id: 'm57ua0kc',
      name: state.accountInfo.username,
      email: state.accountInfo.email,
      created_at: 1312182000,
    });
  }

  if (!hasToken) {
    window.Intercom('shutdown');
  }
};
store.subscribe(setIntercomConfig);

ReactDOM.render(
    <Provider store={store}>
        <IntlProvider translations={translations}>
          <App />
        </IntlProvider>
    </Provider>
  ,
  document.getElementById('root'),
);
