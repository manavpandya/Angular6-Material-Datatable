export default {
  bar: {
    background: '#F06'
  }
}
