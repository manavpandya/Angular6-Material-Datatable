export default {
  root: {
    padding: 0
  },
  content: {
    margin: 0
  }
}
