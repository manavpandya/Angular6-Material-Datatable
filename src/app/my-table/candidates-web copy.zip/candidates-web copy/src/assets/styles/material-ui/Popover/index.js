export default {
  paper: {
    padding: '0.5rem'
  }
}
