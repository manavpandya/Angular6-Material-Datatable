export default {
  root: {
    whiteSpace: 'nowrap',
    minWidth: 'auto'
  }
}
