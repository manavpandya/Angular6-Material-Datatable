export default {
  paddingDefault: {
    padding: '0.25rem 1rem 0.25rem 0.25rem'
  }
}
