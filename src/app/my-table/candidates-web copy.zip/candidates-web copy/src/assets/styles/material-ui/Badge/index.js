export default {
  root: {
    '&.required span': {
      backgroundColor: '#D0011B',
      color: '#FFFFFF'
    },
    '&.mismatch span': {
      backgroundColor: '#F6A623',
      color: '#FFFFFF'
    },
    '&.match span': {
      backgroundColor: '#169421',
      color: '#FFFFFF'
    },
    '&.notification span': {
      backgroundColor: '#f48b03',
      color: '#FFFFFF',
      width: 16,
      height: 16,
      fontSize: 10,
      fontWeight: 'bold',
      top: '-8px',
      right: '-8px'
    }
  }
}
