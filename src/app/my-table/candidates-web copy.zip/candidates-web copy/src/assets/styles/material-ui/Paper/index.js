export default {
  root: {
    padding: '0.5rem 1rem 2rem',
    color: '#999'
  },
}
