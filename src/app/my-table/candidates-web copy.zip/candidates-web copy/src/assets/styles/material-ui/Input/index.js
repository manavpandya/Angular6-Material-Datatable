export default {
  root: {
    fontFamily: 'Nunito',
    fontWeight: 400,
    width: '100%',
  },
  underline: {
    '&:before': {
      backgroundColor: '#EEEEEE',
    },
  }
}
