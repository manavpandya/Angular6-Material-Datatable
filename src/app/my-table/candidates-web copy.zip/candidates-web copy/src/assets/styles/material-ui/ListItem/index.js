export default {
  root: {
    paddingLeft: 0,
  },
}
