export default {
  subheading: {
    fontFamily: '"Roboto Condensed"'
  }
}
