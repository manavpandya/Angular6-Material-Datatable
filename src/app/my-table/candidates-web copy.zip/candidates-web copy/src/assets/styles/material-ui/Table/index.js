export default {
  root: {
    overflow: 'visible',
    fontFamily: 'Nunito',
    fontWeight: 400
  }
}
