export default {
  root: {
    fontFamily: '"Nunito"'
  }
}
