export default {
  gutters: {
    paddingLeft: 0,
  }
}
