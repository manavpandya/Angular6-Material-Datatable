export default {
  root: {
    minWidth: '10rem',
    maxWidth: '40rem',
    width: '100%'
  }
}
