import { createMuiTheme } from 'material-ui/styles'
import MuiTheme from './material-ui/MuiTheme'
import MuiThemeOverrides from './material-ui/MuiThemeOverrides'
const theme = createMuiTheme(
  Object.assign(MuiThemeOverrides, MuiTheme)
);

export default theme;
