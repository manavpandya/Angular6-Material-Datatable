export default {
  root: {
    maxWidth: '30rem',
    padding: 0
  }
}
