import Badge from './Badge'
import Button from './Button'
import ExpansionPanel from './ExpansionPanel'
import ExpansionPanelSummary from './ExpansionPanelSummary'
import FormControl from './FormControl'
import FormLabel from './FormLabel'
import Input from './Input'
import LinearProgress from './LinearProgress'
import List from './List'
import ListItem from './ListItem'
import Paper from './Paper'
import Popover from './Popover'
import Table from './Table'
import TableCell from './TableCell'
import Toolbar from './Toolbar'
import Typography from './Typography'

const MuiThemeOverrides = {
  overrides: {
    MuiLinearProgress: LinearProgress,
    MuiButton: Button,
    MuiPopover: Popover,
    MuiToolbar: Toolbar,
    MuiTable: Table,
    MuiBadge: Badge,
    MuiList: List,
    MuiListItem: ListItem,
    MuiTypography: Typography,
    MuiPaper: Paper,
    MuiExpansionPanel: ExpansionPanel,
    MuiExpansionPanelSummary: ExpansionPanelSummary,
    MuiFormControl: FormControl,
    MuiFormLabel: FormLabel,
    MuiInput: Input,
    MuiTableCell: TableCell,
  }
}

export default MuiThemeOverrides
