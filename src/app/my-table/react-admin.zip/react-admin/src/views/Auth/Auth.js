import React, { Component } from "react";
import Notifications from "react-notification-system-redux";
import Loader from "../../components/Loader/Loader";
import Login from "./Login";
import LoginBackground from "../../assets/img/login.jpg"
import { style } from "../../variables/Variables";

class Auth extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true
    };
    this.handleSubmitForm = this.handleSubmitForm.bind(this);
  }
  componentDidMount() {
    setTimeout(
      () =>
        this.setState({
          loading: false
        }),
      600
    );
  }
  handleSubmitForm({ email, password }) {
    const { login } = this.props;
    login(email, password);
  }
  render() {
    const { loading } = this.state;
    return (
          <div className="off-canvas-sidebar">
              <Notifications notifications={this.props.notifications} style={style} />
              <div className="wrapper wrapper-full-page">
                  <div className="full-page login-page" data-filter-color="black">
            <div className="content">
                          <Login 
                {...this.props}
                handleSubmitForm={this.handleSubmitForm}
                              loading={loading}
              />
            </div>
                      <div className="full-page-background" style={{backgroundImage: `url(${LoginBackground})`}} />
            />
          </div>
        </div>
      </div>
    );
  }
}
export default Auth;
