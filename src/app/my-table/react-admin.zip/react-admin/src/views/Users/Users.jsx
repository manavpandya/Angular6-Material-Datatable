import React, { Component } from "react";
import PropTypes from "prop-types";
import { Grid, Col, Row } from "react-bootstrap";

import Form from "./Form/Form";

class Users extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectValue: "-- Selecte Roles --"
    };
    this.updateSelectedValue = this.updateSelectedValue.bind(this);
    this.handleSubmitForm = this.handleSubmitForm.bind(this);
  }

  componentWillMount() {
    const { match, fetchRoles } = this.props;
    if (match.params.id) {
      fetchRoles(match.params.id);
      this.setState({ key: match.params.id });
    }
  }

  updateSelectedValue(newValue) {
    this.setState({
      selectValue: newValue
    });
  }

  handleSubmitForm(value) {
    const { saveRole, history } = this.props;
    saveRole({ ...value, key: this.state.key }, () => history.push("/users"));
  }
  render() {
    const { handleSubmit, translate, roles } = this.props;
    const { isLoading } = roles;
    return (
      <Grid fluid>
        <Row>
          <Col sm={12}>
            <Form
              updateSelectedValue={this.updateSelectedValue}
              selectValue={this.state.selectValue}
              handleSubmit={handleSubmit}
              handleSubmitForm={this.handleSubmitForm}
              id={this.state.key}
              isLoading={isLoading}
              translate={translate}
            />
          </Col>
        </Row>
      </Grid>
    );
  }
}
Users.propTypes = {
  saveRole: PropTypes.func.isRequired,
  translate: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  fetchRoles: PropTypes.func.isRequired,
  match: PropTypes.objectOf(PropTypes.any),
  history: PropTypes.objectOf(PropTypes.any),
  roles: PropTypes.objectOf(PropTypes.any).isRequired
};
Users.defaultProps = {
  match: {},
  history: {}
};
export default Users;
