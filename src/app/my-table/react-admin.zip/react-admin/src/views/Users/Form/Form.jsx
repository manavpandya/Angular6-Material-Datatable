import React from "react";
import PropTypes from "prop-types";
import { Col, Row, Form, DropdownButton, MenuItem } from "react-bootstrap";
import { required } from "redux-form-validators";
import Loader from "halogen";
import BlockUi from "react-block-ui";
import "react-block-ui/style.css";
import { FormInputs } from "../../../components/FormInputs/FormInputs";
import Button from "../../../elements/CustomButton/CustomButton";
import { Card } from "../../../components/Card/Card";

const UsersForm = props => (
  <Form onSubmit={props.handleSubmit(props.handleSubmitForm)}>
    <Card
      cardHeader={
        <div className="card-header card-header-rose card-header-text">
          <div className="card-text" data-background-color="rose">
            <h4 className="card-title">
              {props.id
                ? props.translate("update_user_form")
                : props.translate("create_user_form")}
            </h4>
          </div>
        </div>
      }
      cardFooter={<div className="footer text-center" />}
    >
      <BlockUi
        tag="div"
        blocking={props.isLoading}
        loader={<Loader.ClipLoader color="#d81b60" />}
      >
        <FormInputs
          ncols={["col-md-12"]}
          proprieties={[
            {
              label: props.translate("user_name"),
              type: "text",
              name: "user_name",
              autoComplete: "off",
              validate: [required()]
            }
          ]}
        />
        <FormInputs
          ncols={["col-md-12"]}
          proprieties={[
            {
              label: props.translate("user_email"),
              type: "text",
              name: "user_email",
              autoComplete: "off",
              validate: [required()]
            }
          ]}
        />
        <FormInputs
          ncols={["col-md-12"]}
          proprieties={[
            {
              label: props.translate("user_password"),
              type: "password",
              name: "user_password",
              autoComplete: "off",
              validate: [required()]
            }
          ]}
        />
        <FormInputs
          ncols={["col-md-12"]}
          proprieties={[
            {
              label: props.translate("user_c_password"),
              type: "password",
              name: "user_c_password",
              autoComplete: "off",
              validate: [required()]
            }
          ]}
        />
        <DropdownButton
          onSelect={props.updateSelectedValue}
          bsStyle="info"
          title={props.selectValue}
        >
          <MenuItem eventKey="Action">Action</MenuItem>
          <MenuItem eventKey="Another action">Another action</MenuItem>
          <MenuItem eventKey="Active Item">Active Item</MenuItem>
          <MenuItem eventKey="Separated link">Separated link</MenuItem>
        </DropdownButton>
        <Row>
          <Col md={12}>
            <Button rose fill type="submit">
              {props.translate("submit")}
            </Button>
          </Col>
        </Row>
      </BlockUi>
    </Card>
  </Form>
);

UsersForm.propTypes = {
  translate: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  handleSubmitForm: PropTypes.func.isRequired,
  id: PropTypes.string,
  isLoading: PropTypes.bool,
  updateSelectedValue: PropTypes.func.isRequired,
  selectValue: PropTypes.string
};
UsersForm.defaultProps = {
  id: "",
  isLoading: false,
  selectValue: ""
};
export default UsersForm;
