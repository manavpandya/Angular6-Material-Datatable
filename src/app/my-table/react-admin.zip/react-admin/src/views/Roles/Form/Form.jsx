import _ from "lodash";
import React from "react";
import PropTypes from "prop-types";
import { Field } from "redux-form";
import { Col, Row, Form, ControlLabel, FormGroup } from "react-bootstrap";
import { required } from "redux-form-validators";
import Loader from "halogen";
import BlockUi from "react-block-ui";
import "react-block-ui/style.css";
import { FormInputs } from "../../../components/FormInputs/FormInputs";
import Button from "../../../elements/CustomButton/CustomButton";
import { Card } from "../../../components/Card/Card";

const field = ({ input, meta, options, defaultOptions }) => {
  const { name, onChange } = input;
  const { touched, error } = meta;
  const inputValue = input.value;
  const checkboxes = _.map(options, ({ key, permission_type }, index) => {
    const handleChange = event => {
      const arr = [...inputValue];
      if (event.target.checked) {
        arr.push(key);
      } else {
        arr.splice(arr.indexOf(key), 1);
      }
      return onChange(arr);
    };
    const checked = defaultOptions.includes(key);
    return (
      <label
        className="form-check-label"
        htmlFor={`checkbox-${index}`}
        key={`checkbox-${index}`}
      >
        <input
          id={`checkbox-${index}`}
          className="form-check-input"
          type="checkbox"
          name={`${name}[${index}]`}
          value={key}
          defaultChecked={checked}
          onChange={handleChange}
        />
        {permission_type}
        <span className="checkbox-material">
          <span className="check" />
        </span>
      </label>
    );
  });

  return (
    <Row>
      <Col sm={12}>
        <ControlLabel>Permission Lists</ControlLabel>
        <div className="checkbox">{checkboxes}</div>
        {touched && error && <p className="error">{error}</p>}
      </Col>
    </Row>
  );
};
const RolesForm = props => (
  <Form onSubmit={props.handleSubmit(props.handleSubmitForm)}>
    <Card
      cardHeader={
        <div className="card-header card-header-rose card-header-text">
          <div className="card-text" data-background-color="rose">
            <h4 className="card-title">
              {props.id
                ? props.translate("update_role_form")
                : props.translate("create_role_form")}
            </h4>
          </div>
        </div>
      }
      cardFooter={<div className="footer text-center" />}
    >
      <BlockUi
        tag="div"
        blocking={props.isLoading}
        loader={<Loader.ClipLoader color="#d81b60" />}
      >
        <FormInputs
          ncols={["col-md-12"]}
          proprieties={[
            {
              label: props.translate("role_name"),
              type: "text",
              name: "role_name",
              autoComplete: "off",
              validate: [required()]
            }
          ]}
        />
        <Field
          type="checkbox"
          name="permission"
          options={props.permissions}
          defaultOptions={props.hasPermission ? props.hasPermission : []}
          component={field}
        />
        <Row>
          <Col md={12}>
            <Button rose fill type="submit">
              {props.translate("submit")}
            </Button>
          </Col>
        </Row>
      </BlockUi>
    </Card>
  </Form>
);

RolesForm.propTypes = {
  translate: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  handleSubmitForm: PropTypes.func.isRequired,
  id: PropTypes.string,
  isLoading: PropTypes.bool,
  permissions: PropTypes.objectOf(PropTypes.any),
  hasPermission: PropTypes.objectOf(PropTypes.any)
};
RolesForm.defaultProps = {
  id: "",
  permissions: {},
  hasPermission: {},
  isLoading: false
};
export default RolesForm;
