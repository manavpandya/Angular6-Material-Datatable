module.exports = {
  en: {
    locale: "en-US",
    messages: {
      sitename: "FrondEnd Ninja",

      /** * App Links *** */

      dashboard: "Dashboard",
      userprofile: "User Profile",
      users: "Users",
      profile: "profile",
      roles: "Roles Management",
      role: "Roles",
      add_role: "Create a role",
      permission: "Permission",

      /** * App Links *** */

      /** *** Roles table feilds *** */

      r_name: "Role Name",
      r_created: "Created At",
      r_label: "Role",

      /** *** Permission table feilds *** */

      permission_type: "Permission Type",
      p_created: "Created At",
      p_label: "Permission",

      /** *** Users table feilds *** */
      u_label: "User",
      create_user_form: "Create User",
      update_user_form: "Update User {name}",
      user_name: "User Name",
      user_password: "Password",
      user_c_password: "Confirm Password",
      user_email: "Email",

      /** *** Roles table feilds *** */

      /** * Form Label Key ** */

      email: "Email Address",
      password: "Password",
      role_name: "Role Name",

      /** * Form Label Key ** */

      /** Form title */

      create_role_form: "Create Role",
      update_role_form: "Update Role",
      create_permission_form: "Create Permission",
      update_permission_form: "Update Permission",

      /** * Buttons ** */

      lets_go: "Let's go",
      or_be_classical: "Or Be Classical",
      login: "Login",
      submit: "Submit",

      /** **Common Table fields** */

      actions: "Actions",
      create_button: "Create a {name}",
      lists: "{name} lists"
    }
  },
  hi: {
    locale: "hi",
    messages: {
      sitename: "फ्रंट एंड निंजा",
      /** * App Links *** */
      dashboard: "डैशबोर्ड",
      userprofile: "उपयोगकर्ता प्रोफ़ाइल",
      users: "उपयोगकर्ताओं",
      /** * App Links *** */

      /** * Form Label Key ** */

      email: "ईमेल पता",
      password: "पारण शब्द",

      /** * Form Label Key ** */

      /** *** Roles table feilds *** */

      r_name: "Role Name",
      r_created: "Created At",
      r_label: "Role",

      /** *** Permission table feilds *** */

      permission_type: "Permission Type",
      p_created: "Created At",
      p_label: "Permission",

      /** *** Users table feilds *** */
      u_label: "User",
      create_user_form: "Create User",
      update_user_form: "Update User {name}",
      user_name: "User Name",
      user_password: "Password",
      user_c_password: "Confirm Password",
      user_email: "Email",

      /** *** Roles table feilds *** */

      /** * Buttons ** */

      lets_go: "चलिए चलते हैं",
      or_be_classical: "या क्लासिकल हो",
      login: "लॉग इन करें",

      /** Form title */

      create_role_form: "Create Role",
      create_permission_form: "Create Permission",

      /** * Buttons ** */

      /** **Common Table fields** */

      actions: "Actions",
      create_button: "Create a {name}",
      lists: "{name} lists"
    }
  },
  gu: {
    locale: "gu",
    messages: {
      sitename: "ફ્રન્ટ અંતે નીન્જા",
      /** * App Links *** */
      dashboard: "ડેશબોર્ડ",
      userprofile: "વપરાશકર્તા પ્રોફાઇલ",
      users: "વપરાશકર્તાઓ",
      /** * App Links *** */

      /** * Form Label Key ** */
      email: "ઈ - મેઈલ સરનામું",
      password: "પાસવર્ડ",
      /** * Form Label Key ** */

      /** * Buttons ** */
      lets_go: "ચાલો જઇએ",
      or_be_classical: "અથવા શાસ્ત્રીય રહો",
      login: "લૉગિન"
    }
  },
  ar: {
    locale: "ar",
    messages: {
      sitename: "الجبهة النينجا",

      /** * App Links *** */

      dashboard: "لوحة القيادة",
      userprofile: "الملف الشخصي للمستخدم",
      users: "المستخدمين",
      profile: "profile",
      roles: "Roles Management",
      role: "Roles",
      add_role: "Create a role",
      permission: "Permission",

      /** * App Links *** */

      /** * Form Label Key ** */
      email: "عنوان البريد الإلكتروني",
      password: "كلمه السر",
      role_name: "Role Name",
      /** * Form Label Key ** */

      /** * Buttons ** */
      lets_go: "لنذهب",
      or_be_classical: "أو كن كلاسيكي",
      login: "تسجيل الدخول",
      submit: "Submit",

      /** *** Roles table feilds *** */

      r_name: "Role Name",
      r_created: "Created At",
      r_label: "Role",

      /** *** Permission table feilds *** */

      permission_type: "Permission Type",
      p_created: "Created At",
      p_label: "Permission",

      /** *** Users table feilds *** */
      u_label: "User",
      create_user_form: "Create User",
      update_user_form: "Update User {name}",
      user_name: "User Name",
      user_password: "Password",
      user_c_password: "Confirm Password",
      user_email: "Email",
      /** *** Roles table feilds *** */

      /** Form title */

      create_role_form: "Create Role",
      update_role_form: "Update Role {name}",
      create_permission_form: "Create Permission",

      /** **Common Table fields** */

      actions: "Actions",
      create_button: "Create a {name}",
      lists: "{name} lists"
    }
  }
};
