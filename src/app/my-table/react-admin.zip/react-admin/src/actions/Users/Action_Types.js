export const actionTypes = {
  /* Fetch Users */
  fetchUsersRequested: "FETCH_Users_REQUESTED",
  fetchUsersRejected: "FETCH_Users_REJECTED",
  fetchUsersFulfilled: "FETCH_Users_FULFILLED",
  clearProductsRequestedAction: "CLEAR_Users",

  /* Save  Users */
  saveUserRequested: "SAVE_User_REQUESTED",
  saveUserRejected: "SAVE_User_REJECTED",
  saveUserFulfilled: "SAVE_User_FULFILLED",

  /* Delete Users */
  deleteUserRequested: "DELETE_User_REQUESTED",
  deleteUserRejected: "DELETE_User_REJECTED",
  deleteUserFulfilled: "DELETE_User_FULFILLED",

  /* Fetch Roles */
  fetchRolesRequested: "FETCH_ROLES_REQUESTED",
  fetchRolesRejected: "FETCH_ROLES_REJECTED",
  fetchRolesFulfilled: "FETCH_ROLES_FULFILLED"
};

export default actionTypes;
