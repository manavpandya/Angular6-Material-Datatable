const actionTypes = {
  loginRequested: "LOGIN_REQUESTED",
  loginRejected: "LOGIN_REJECTED",
  loginFulfilled: "LOGIN_FULFILLED",
  logoutRequested: "LOGOUT_REQUESTED",
  logoutRejected: "LOGOUT_REJECTED",
  logoutFulfilled: "LOGOUT_FULFILLED"
};
export default actionTypes;
