import { auth } from "../../config/firebase_config";
import ActionTypes from "./Auth_action_types";

/**
 * Login actions
 */
const loginRequestedAction = () => ({ type: ActionTypes.loginRequested });
const loginRejectedAction = e => ({
  type: ActionTypes.loginRejected,
  payload: e
});
const loginFulfilledAction = user => ({
  type: ActionTypes.loginFulfilled,
  payload: user
});

/**
 * Log in user based on provided user/pass
 * @param {*} user
 * @param {*} pass
 */

export const login = (user, pass) => dispatch =>
  new Promise((resolve, reject) => {
    dispatch(loginRequestedAction());
    const promise = auth().signInWithEmailAndPassword(user, pass);
    promise
      .then(user => {
        const uid = user.uid || user.user.uid;
        resolve(user);
      })
      .catch(e => {
        dispatch(loginRejectedAction(e));
        // dispatch(error(e));
        reject(e);
      });
  });
