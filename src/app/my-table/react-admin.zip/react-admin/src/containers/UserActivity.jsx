import React, { Component } from "react";
import LockScreen from "../views/Auth/Lock";

class UserActivity extends Component {
  constructor(props) {
    super(props);
    this.state = {
      lockScreen: true
    };
    this.goInactive = this.goInactive.bind(this);
  }
  componentDidMount() {
    window.addEventListener("mousemove", this.resetTimer.bind(this), false);
    window.addEventListener("mousedown", this.resetTimer.bind(this), false);
    window.addEventListener("keypress", this.resetTimer.bind(this), false);
    window.addEventListener(
      "DOMMouseScroll",
      this.resetTimer.bind(this),
      false
    );
    window.addEventListener("mousewheel", this.resetTimer.bind(this), false);
    window.addEventListener("touchmove", this.resetTimer.bind(this), false);
    window.addEventListener("MSPointerMove", this.resetTimer.bind(this), false);
    this.startTimer();
  }
  componentWillUnmount() {
    window.removeEventListener("mousemove", this.resetTimer.bind(this), false);
    window.removeEventListener("mousedown", this.resetTimer.bind(this), false);
    window.removeEventListener("keypress", this.resetTimer.bind(this), false);
    window.removeEventListener(
      "DOMMouseScroll",
      this.resetTimer.bind(this),
      false
    );
    window.removeEventListener("mousewheel", this.resetTimer.bind(this), false);
    window.removeEventListener("touchmove", this.resetTimer.bind(this), false);
    window.removeEventListener(
      "MSPointerMove",
      this.resetTimer.bind(this),
      false
    );
    window.clearTimeout(this.timeoutId);
  }
  startTimer() {
    this.timeoutId = window.setTimeout(this.goInactive, 250000);
  }
  resetTimer(e) {
    window.clearTimeout(this.timeoutId);
    this.goActive();
  }
  goInactive() {
    console.log("enter....");
    this.setState({ lockScreen: false });
  }
  goActive() {
    this.startTimer();
  }
  render() {
    const { lockScreen } = this.state;
    if (lockScreen) {
      return this.props.children;
    }
    return <LockScreen />;
  }
}
export default UserActivity;
