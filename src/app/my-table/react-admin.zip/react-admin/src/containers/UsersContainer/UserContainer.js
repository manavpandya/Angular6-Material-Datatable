import _ from "lodash";
import { connect } from "react-redux";
import { reduxForm } from "redux-form";
import * as a from "../../actions/Roles/Roles_actions";
import Users from "../../views/Users/Users";

const mapDispatchToProps = dispatch => ({
  fetchRoles: params => dispatch(a.fetchRoles(params))
});
const mapStateToProps = state => ({
  roles: state.roles,
  initialValues: {
    role_name: _.isEmpty(state.roles.data) ? "" : state.roles.data.role_name
  }
});
const mergeProps = (state, actions, ownProps) => ({
  ...state,
  ...actions,
  ...ownProps
});

export default connect(mapStateToProps, mapDispatchToProps, mergeProps)(
  reduxForm({
    form: "UsersForm",
    enableReinitialize: true
  })(Users)
);
