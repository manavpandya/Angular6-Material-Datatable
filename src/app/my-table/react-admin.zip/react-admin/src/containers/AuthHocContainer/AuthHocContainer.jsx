import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
// import NotificationSystem from "react-notification-system";
import Notifications from "react-notification-system-redux";
import Header from "../../components/Header/Header";
import Footer from "../../components/Footer/Footer";
import Sidebar from "../../components/Sidebar/Sidebar";
import { style } from "../../variables/Variables";

export default function(WrappedComponent, passedProps) {
  class Authentication extends Component {
    constructor(props) {
      super(props);
      this.componentDidMount = this.componentDidMount.bind(this);
    }
    componentDidMount() {}
    componentDidUpdate(e) {
      if (
        window.innerWidth < 993 &&
        e.history.location.pathname !== e.location.pathname &&
        document.documentElement.className.indexOf("nav-open") !== -1
      ) {
        document.documentElement.classList.toggle("nav-open");
      }
    }
    render() {
      const props = { ...passedProps, ...this.props };
      return (
        <div className="wrapper">
          <Notifications
            notifications={this.props.notifications}
            style={style}
          />
          <Sidebar {...props} />
          <div id="main-panel" className="main-panel">
            <Header {...props} />
            <div className="main-content">
              <WrappedComponent {...props} />
            </div>
            <Footer />
          </div>
        </div>
      );
    }
  }
  const mapDispatchToProps = dispatch => ({
    success: message =>
      dispatch(
        Notifications.success({
          title: <span data-notify="icon" className="pe-7s-check" />,
          message,
          position: "tr",
          autoDismiss: 3
        })
      ),
    error: message =>
      dispatch(
        Notifications.error({
          title: (
            <span data-notify="icon" className="material-icons">
              thumb_down
            </span>
          ),
          message,
          position: "tr",
          autoDismiss: 3
        })
      )
  });
  const mapStateToProps = state => ({
    notifications: state.notifications
  });
  Authentication.contextTypes = {
    store: PropTypes.object
  };
  Authentication.propTypes = {
    notifications: PropTypes.array
  };

  Authentication.defaultProps = {
    notifications: []
  };
  return connect(mapStateToProps, mapDispatchToProps)(Authentication);
}
