import { connect } from 'react-redux';
import { reduxForm } from 'redux-form';
import * as a from '../../actions/Auth/Auth_actions';
import Auth from '../../views/Auth/Auth';

const mapDispatchToProps = (dispatch) => ({
    login: (email,password) => dispatch(a.login(email,password))
});
const mapStateToProps = (state) => ({
    auth: state.auth,
    notifications:state.notifications
});
const mergeProps = (state,actions,ownProps) => ({
    ...state,
    ...actions,
    ...ownProps,
    login:( email,password ) => {
        actions.login(email,password).then((user) => {
            ownProps.history
            .push("/dashboard");
        });
    }
});

export default connect(mapStateToProps,mapDispatchToProps,mergeProps)(reduxForm({
    form: 'AuthForm'
})(Auth));