export const googleTranslate = require('google-translate')('AIzaSyB_LBY65pretYRsgDbKcHxiWGOWjfPLpMQ');
