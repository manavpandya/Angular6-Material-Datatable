import React, {Component} from 'react';
import {Provider} from 'react-redux';
import {HashRouter,Route,Switch,Router} from 'react-router-dom';
import PropTypes from 'prop-types';
import AppContainer from '../containers/AppContainer/AppContainer';
import {IntlProvider} from 'react-redux-multilingual';

export default class Root extends Component {
    render() {
        const {store} = this.props;
        return (
                <Provider store={store}>
                    <IntlProvider translations={translations}>
                        <HashRouter>
                            <Switch>
                                <AppContainer/>
                            </Switch>       
                        </HashRouter>
                    </IntlProvider>
                </Provider>
                )
    }
}
Root.propTypes = {
    store: PropTypes.object
};
