import ActionTypes from "../actions/Auth/Auth_action_types";

const INITIAL_STATE = {};
export default (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case ActionTypes.loginRequested: {
      return Object.assign({}, state, {
        isLoading: true,
        error: "",
        success: ""
      });
    }
    case ActionTypes.loginRejected: {
      return Object.assign({}, state, {
        isLoading: false,
        statusChecked: true,
        error: action.payload
      });
    }
    case ActionTypes.loginFulfilled: {
      return {
        ...state,
        isLoading: false,
        success: true,
        auth: action.payload
      };
    }
    default:
      return state;
  }
};
