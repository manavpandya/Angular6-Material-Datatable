import React, {Component} from 'react';
class Loader extends Component {
    constructor(props) {
        super(props);
        this.state = {
            delayed: props.delay > 0
        }
    }
    render() {
        return (
            <div className="loader">
                <svg
                    className="circular"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0">
                    <circle
                        className="path"
                        fill="none"
                        stroke-width="12"
                        stroke-linecap="round"
                        cx="30"
                        cy="30"
                        r="30"></circle>
                </svg>
            </div>
        )
    }
}

export default Loader;