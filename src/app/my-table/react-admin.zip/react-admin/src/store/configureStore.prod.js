import { createStore, applyMiddleware, compose } from 'redux';
import thunk from 'redux-thunk';
import { persistState } from 'redux-devtools';
import rootReducer from '../reducers';
import DevTools from '../root/DevTools';

const middleware = [
    thunk
];
const enhancer = [];
const composedEnhancers = compose(
        applyMiddleware(...middleware),
        ...enhancer
        );
export default function configureStore(initialState) {
    return createStore(rootReducer, initialState, composedEnhancers);
}