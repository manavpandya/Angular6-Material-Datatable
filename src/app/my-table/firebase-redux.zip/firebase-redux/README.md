# redux-firebase-demo
Demo of using Redux and Firebase together.

[CodeMentor Tutorial] (https://www.codementor.io/vijayst/using-firebase-with-redux-for-building-a-react-app-du1086puw)
