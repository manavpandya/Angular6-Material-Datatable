import React from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import 'normalize.css/normalize.css';
// import PropTypes from 'prop-types';
import AuthProvider from './modules/auth/components/AuthenticationHOC';

// Pages (Routes)
import CandidateProfile from './pages/candidate-area/CandidateProfile';
import CandidateRegistration from './pages/candidate-area/CandidateRegistration';
import verifyAccount from './modules/auth/components/verifyAccount';

// MAIN COMPONENTS
import Taxonomy from './pages/Taxonomy';
import NormalizeTaxonomy from './pages/NormalizeTaxonomy';
import Users from './pages/Users';
import Customers from './pages/Customers';
import Login from './pages/Login';
import Logout from './modules/auth/components/Logout';
import Recruiter from './pages/Recruiter';
import RenderResetPageContainer from './modules/auth/renderResetPageContainer';

// CANDIDATES-AREA
import DashboardContainer from './pages/candidate-area/DashboardContainer';

// CUSTOMER_AREA
import CustomerArea from './pages/customer-area';

// INTER COMPONENTS
import Candidates from './modules/candidates';
import CandidatesSearch from './modules/candidates/search';
import RecruiterNewJobMatches from './modules/jobs/matches';
import RecruiterNewJob from './modules/jobs/new';
import JobDetails from './modules/jobs/JobDetails';
import CustomerJobDetails from './modules/customer-area/components/CustomerJobDetails';

import BookmarkedCandidates from './modules/candidates/bookmarkedCandidates';

// NOT FOUND
import NotFound from './shared/basic/NotFound';
import AccessDenied from './shared/basic/AccessDenied';

const Routes = () => (
  <BrowserRouter>
    <div>
      <Switch>
        <Route exact path="/" component={Login} />
        <Route exact path="/login" component={Login} />
        <Route exact path="/recruiter" component={AuthProvider(Recruiter)} />
        <Route exact path="/candidate/register" component={CandidateRegistration} />
        <Route
          exact
          path="/candidate/profile"
          name="Candidate Profile"
          component={CandidateProfile}
        />
        <Route
          exact
          path="/reset_password/:token?"
          name="Reset Password Page"
          component={RenderResetPageContainer}
        />
        <Route
          exact
          path="/account_verification/:token?"
          name="Account Verification"
          component={verifyAccount}
        />
        <Route exact path="/customer" component={AuthProvider(CustomerArea)} />
        <Route exact path="/manage/taxonomy" component={AuthProvider(Taxonomy)} />
        <Route
          exact
          path="/manage/taxonomy/normalize"
          component={AuthProvider(NormalizeTaxonomy)}
        />
        <Route exact path="/manage/users" component={AuthProvider(Users)} />
        <Route exact path="/manage/customers" component={AuthProvider(Customers)} />
        <Route exact path="/recruiter/jobs/job/:id" component={AuthProvider(JobDetails)} />
        <Route exact path="/customer/jobs/job/:id" component={AuthProvider(CustomerJobDetails)} />
        <Route exact path="/recruiter/candidates" component={AuthProvider(Candidates)} />
        <Route
          exact
          path="/recruiter/candidates/search"
          component={AuthProvider(CandidatesSearch)}
        />
        <Route
          exact
          path="/recruiter/candidates/results/starred"
          component={AuthProvider(BookmarkedCandidates)}
        />
        <Route
          exact
          path="/recruiter/jobs/new/matches"
          component={AuthProvider(RecruiterNewJobMatches)}
        />
        <Route exact path="/recruiter/jobs/new" component={AuthProvider(RecruiterNewJob)} />
        <Route exact path="/recruiter/jobs/edit/:id" component={AuthProvider(RecruiterNewJob)} />
        {/* Candidates Area related router */}
        <Route exact path="/candidate/dashboard" component={AuthProvider(DashboardContainer)} />
        <Route exact path="/logout" component={Logout} />
        <Route exact path="/access-denied" component={AuthProvider(AccessDenied)} />
        <Route path="*" component={AuthProvider(NotFound)} />
      </Switch>
    </div>
  </BrowserRouter>
);

export default Routes;
