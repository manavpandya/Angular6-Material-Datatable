const MuiThemeOverrides = {
  overrides: {
    MuiLinearProgress: {
      bar: {
        background: '#F06',
      },
    },
    MuiButton: {
      root: {
        whiteSpace: 'nowrap',
        minWidth: 'auto',
      },
    },
    MuiPopover: {
      paper: {
        padding: '0.5rem',
      },
    },
    MuiToolbar: {
      gutters: {
        paddingLeft: 0,
      },
    },
    MuiTable: {
      root: {
        overflow: 'visible',
      },
    },
    MuiBadge: {
      root: {
        '&.required span': {
          backgroundColor: '#D0011B',
          color: '#FFFFFF',
        },
        '&.mismatch span': {
          backgroundColor: '#F6A623',
          color: '#FFFFFF',
        },
        '&.match span': {
          backgroundColor: '#169421',
          color: '#FFFFFF',
        },
        '&.notification span': {
          backgroundColor: '#f48b03',
          color: '#FFFFFF',
          width: 16,
          height: 16,
          fontSize: 10,
          fontWeight: 'bold',
          top: '-8px',
          right: '-8px',
        },
      },
    },
    MuiList: {
      root: {
        maxWidth: '30rem',
        padding: 0,
      },
    },
    MuiListItem: {
      root: {
        paddingLeft: 0,
      },
    },
    MuiTypography: {
      subheading: {
        fontFamily: '"Nunito"',
      },
    },
    MuiPaper: {
      root: {
        padding: '0.5rem 1rem 2rem',
        color: '#999',
      },
    },
    MuiExpansionPanel: {
      root: {
        padding: '0.5rem 2rem 0rem',
        color: '#999',
      },
    },
    MuiExpansionPanelSummary: {
      root: {
        padding: 0,
      },
      content: {
        margin: 0,
      },
    },
    MuiFormControl: {
      root: {
        minWidth: '10rem',
        maxWidth: '40rem',
        width: '100%',
      },
    },
    MuiFormLabel: {
      root: {
        fontFamily: '"Nunito"',
      },
    },
    MuiInput: {
      root: {
        fontFamily: '"Nunito"',
        fontWeight: 400,
        width: '100%',
      },
      underline: {
        '&:before': {
          backgroundColor: '#EEEEEE',
        },
      },
    },
    MuiTableCell: {
      paddingDefault: {
        padding: '0.25rem 0.25rem 0.25rem 0.25rem',
      },
    },
  },
};

export default MuiThemeOverrides;
