import { createMuiTheme } from 'material-ui/styles';
import MuiTheme from './jss/MuiTheme';
import MuiThemeOverrides from './jss/MuiThemeOverrides';

const theme = createMuiTheme(Object.assign(MuiThemeOverrides, MuiTheme));

export default theme;

