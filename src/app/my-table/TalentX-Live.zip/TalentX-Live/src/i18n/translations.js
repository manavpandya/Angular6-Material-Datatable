import english from './english.json';
import spanish from './spanish.json';

const translations = {
  en:
    {
      ...english,
    },
  es:
    {
      ...spanish,
    },
};

export default translations;

