import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import { reducer as formReducer } from 'redux-form';
import { IntlReducer } from 'react-redux-multilingual';
import loginReducer from '../modules/auth/redux/reducer';
import recruiterReducer from '../modules/jobs/redux/reducer';
import customerAreaReducer from '../modules/customer-area/redux/reducer';
import taxonomyReducer from '../modules/manage-taxonomy/redux/reducer';
import profileReducer from '../modules/candidates/redux/reducer';
import usersReducer from '../modules/manage-users/redux/reducer';
import customersReducer from '../modules/manage-customers/redux/reducer';
import registerCandidateReducer from '../modules/candidate-area/redux/reducer';
import normalizeTaxonomyReducer from '../modules/NormalizeTaxonomy/redux/reducer';

const appReducer = combineReducers({
  form: formReducer,
  Intl: IntlReducer,
  routing: routerReducer,
  login: loginReducer,
  recruiter: recruiterReducer,
  taxonomy: taxonomyReducer,
  profiles: profileReducer,
  users: usersReducer,
  customers: customersReducer,
  customerArea: customerAreaReducer,
  registerCandidate: registerCandidateReducer,
  normalizeTaxonomy: normalizeTaxonomyReducer,
});

const rootReducer = (state, action) => {
  if (action.type === 'LOGOUT_SUCCESS') {
    return appReducer(undefined, action);
  }
  return appReducer(state, action);
};

export default rootReducer;
