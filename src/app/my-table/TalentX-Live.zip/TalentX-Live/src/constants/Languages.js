const languages = [
  {
    value: 'Abkhaz',
    label: 'аҧсуа',
  },
  {
    value: 'Afar',
    label: 'Afaraf',
  },
  {
    value: 'Afrikaans',
    label: 'Afrikaans',
  },
  {
    value: 'Akan',
    label: 'Akan',
  },
  {
    value: 'Albanian',
    label: 'Shqip',
  },
  {
    value: 'Amharic',
    label: 'አማርኛ',
  },
  {
    value: 'Arabic',
    label: 'العربية',
  },
  {
    value: 'Aragonese',
    label: 'Aragonés',
  },
];
export default languages;
