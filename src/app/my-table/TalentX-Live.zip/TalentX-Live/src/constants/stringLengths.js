export const IDENTIFIER = '20';
export const SHORT = '15';
export const MEDIUM = '50';
export const LONG = '255';
export const CUSTOM_IDENTIFIER = '50';
export const TEXT = '';
