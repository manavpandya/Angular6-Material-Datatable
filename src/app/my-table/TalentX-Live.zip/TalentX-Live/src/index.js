import React from 'react';
import ReactDOM from 'react-dom';
import _ from 'lodash';
import 'babel-polyfill';
import { Provider } from 'react-redux';
import { IntlProvider } from 'react-redux-multilingual';

import App from './App';
import configureStore from './store/configureStore';
import translations from './i18n/translations';

require('typeface-nunito'); // eslint-disable-line
const tenant = localStorage.getItem('tenant') || 'ERG';
require(`./assets/styles/themes/${tenant.toLowerCase()}-theme.sass`); // eslint-disable-line

const store = configureStore();

const setIntercomConfig = () => {
  const state = store.getState().recruiter;
  const hasToken = localStorage.getItem('user_info');
  if (!_.isEmpty(state.accountInfo)) {
    window.Intercom('boot', {
      app_id: 'm57ua0kc',
      name: state.accountInfo.username,
      email: state.accountInfo.email,
      created_at: 1312182000,
      totalSearches: state.intercomSearch && state.intercomSearch.total,
      lastSearchDate: state.intercomSearch && state.intercomSearch.last_date ? state.intercomSearch.last_date : '',
      totalJobsCreated: state.intercomCreate && state.intercomCreate.total,
      lastJobCreatedDate: state.intercomCreate && state.intercomCreate.last_date ? state.intercomCreate.last_date : '',
    });
  }

  if (!hasToken) {
    window.Intercom('shutdown');
  }
};
store.subscribe(setIntercomConfig);

ReactDOM.render(
  <Provider store={store}>
    <IntlProvider translations={translations}>
      <App />
    </IntlProvider>
  </Provider>,
  document.getElementById('root'),
);
