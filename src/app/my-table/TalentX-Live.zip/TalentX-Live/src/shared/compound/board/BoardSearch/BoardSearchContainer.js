import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import BoardSearch from './BoardSearch';
import { getCustomers, searchCustomers, setSearchItem } from '../../../../modules/manage-customers/redux/actions';
import { searchTalent, setFilter, flushAllCandidates, fetchFacet, resetFilterParams } from '../../../../modules/candidates/redux/actions';
import { flushAllJobs, getDraftedJobs, getPostedJobs, getQualifiedJobs, getPresentedJobs, getClosedJobs, setSearchedJobTitle, resetFilterParamsMatched } from '../../../../modules/jobs/redux/actions';

class BoardSearchContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      searchBoxText: '',
      showResetButton: false,
    };
    this.setSearchBoxText = this.setSearchBoxText.bind(this);
    this.searchKeyPress = this.searchKeyPress.bind(this);
    this.searchClick = this.searchClick.bind(this);
    this.setShowResetButton = this.setShowResetButton.bind(this);
    this.resetJobs = this.resetJobs.bind(this);
    this.fireSearch = this.fireSearch.bind(this);
    this.automaticConversion = this.automaticConversion.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.searchedJobTitle !== nextProps.searchedJobTitle) {
      this.props.flushAllJobs();
      this.props.getDraftedJobs(
        1,
        nextProps.draftJobsSortedBy,
        this.props.searchedEmployer,
        nextProps.searchedJobTitle,
      );
      this.props.getPostedJobs(
        1,
        nextProps.postedJobsSortedBy,
        this.props.searchedEmployer,
        nextProps.searchedJobTitle,
      );
      this.props.getQualifiedJobs(
        1,
        nextProps.qualifiedJobsSortedBy,
        this.props.searchedEmployer,
        nextProps.searchedJobTitle,
      );
      this.props.getPresentedJobs(
        1,
        nextProps.presentedJobsSortedBy,
        this.props.searchedEmployer,
        nextProps.searchedJobTitle,
      );
      this.props.getClosedJobs(
        1,
        nextProps.closedJobsSortedBy,
        this.props.searchedEmployer,
        nextProps.searchedJobTitle,
      );
    }
  }

  componentWillUnmount() {
    this.props.resetFilterParams();
    this.props.resetFilterParamsMatched();
  }

  setSearchBoxText(event) {
    if (this.props.clientPage) {
      this.setState({
        searchBoxText: event.target.value,
      });
    }
    this.setState({
      searchBoxText: event.target.value.replace(/'/g, '"'),
    });
  }

  setShowResetButton(flag) {
    this.setState({
      showResetButton: flag,
    });
  }

  resetJobs() {
    this.setState({ searchBoxText: '' }, () => {
      if (this.props.clientPage) {
        this.props.getCustomers(1);
        this.props.setSearchItem();
      } else {
        this.props.setSearchedJobTitle(this.state.searchBoxText);
      }
      this.setShowResetButton(false);
    });
  }
  fireSearch() {
    if (this.props.homepage) {
      if (this.state.searchBoxText !== '') {
        this.props.setSearchedJobTitle(this.state.searchBoxText);
        this.setShowResetButton(true);
        return;
      }
    }
    this.props.setFilter({ query: this.state.searchBoxText });
    this.props.fetchFacet(this.state.searchBoxText)
      .then(() => {
        this.props.searchTalent(this.state.searchBoxText, '');
      });
  }
  searchKeyPress(event) {
    if (event.key === 'Enter') {
      if (this.props.clientPage) {
        this.props.searchCustomers(this.state.searchBoxText);
        this.setShowResetButton(true);
      } else {
        this.automaticConversion();
        this.fireSearch();
      }
    } else if (event.key === ' ' && !this.props.clientPage) {
      this.automaticConversion();
    }
  }

  automaticConversion() {
    const convertText = this.state.searchBoxText.split(' ');
    convertText.forEach((text) => {
      if (text.toLowerCase() === 'and' || text.toLowerCase() === 'or' || text.toLowerCase() === 'not') {
        this.setState({
          searchBoxText: this.state.searchBoxText.replace(text, text.toUpperCase()),
        });
      } else if (text === '/') {
        this.setState({
          searchBoxText: this.state.searchBoxText.replace(text, 'OR'),
        });
      }
    });
  }

  searchClick(reload = false) {
    if (reload === true) {
      this.setState({
        searchBoxText: '',
      }, () => {
        setTimeout(() => {
          this.props.resetFilterParams();
          this.props.fetchFacet()
            .then(() => {
              this.props.searchTalent(this.state.searchBoxText, '');
            });
        }, 300);
      });
    } else if (this.props.clientPage) {
      this.props.searchCustomers(this.state.searchBoxText);
      this.setShowResetButton(true);
    } else {
      this.fireSearch();
    }
  }

  render() {
    return (
      <div>
        <BoardSearch
          currentPath={this.props.match.path}
          searchedValue={this.props.searchedValue}
          filterParam={this.props.filterParam}
          searchBoxText={this.state.searchBoxText}
          setSearchBoxText={this.setSearchBoxText}
          searchKeyPress={this.searchKeyPress}
          searchClick={this.searchClick}
          showResetButton={this.state.showResetButton}
          homepage={this.props.homepage}
          resetJobs={this.resetJobs}
          matchPath={this.props.match.path}
          clientPage={this.props.clientPage}
        />
      </div>
    );
  }
}

BoardSearchContainer.propTypes = {
  setFilter: PropTypes.func.isRequired,
  resetFilterParams: PropTypes.func.isRequired,
  resetFilterParamsMatched: PropTypes.func.isRequired,
  flushAllJobs: PropTypes.func,
  getDraftedJobs: PropTypes.func,
  getPostedJobs: PropTypes.func,
  getQualifiedJobs: PropTypes.func,
  getPresentedJobs: PropTypes.func,
  getClosedJobs: PropTypes.func,
  setSearchedJobTitle: PropTypes.func,
  searchedEmployer: PropTypes.string,
  searchedJobTitle: PropTypes.string,
  searchTalent: PropTypes.func,
  match: PropTypes.object, // eslint-disable-line
  draftJobsSortedBy: PropTypes.string,
  postedJobsSortedBy: PropTypes.string,
  qualifiedJobsSortedBy: PropTypes.string,
  presentedJobsSortedBy: PropTypes.string,
  closedJobsSortedBy: PropTypes.string,
  searchedValue: PropTypes.string,
  filterParam: PropTypes.string,
  fetchFacet: PropTypes.func,
  homepage: PropTypes.bool,
  clientPage: PropTypes.bool,
  searchCustomers: PropTypes.func,
  getCustomers: PropTypes.func,
  setSearchItem: PropTypes.func,
};

BoardSearchContainer.defaultProps = {
  flushAllJobs: () => {},
  getDraftedJobs: () => {},
  getPostedJobs: () => {},
  getQualifiedJobs: () => {},
  getPresentedJobs: () => {},
  getClosedJobs: () => {},
  setSearchedJobTitle: () => {},
  searchedEmployer: '',
  searchedJobTitle: '',
  searchTalent: () => {},
  match: {},
  draftJobsSortedBy: 'none',
  postedJobsSortedBy: 'none',
  qualifiedJobsSortedBy: 'none',
  presentedJobsSortedBy: 'none',
  closedJobsSortedBy: 'none',
  searchedValue: '',
  filterParam: '',
  fetchFacet: () => {},
  homepage: false,
  clientPage: false,
  searchCustomers: () => {},
  getCustomers: () => {},
  setSearchItem: () => {},
};

const mapStateToProps = state => ({
  searchedValue: state.profiles.searchedValue,
  filterParam: state.profiles.filterParam,
  searchedEmployer: state.recruiter.searchedEmployer,
  searchedJobTitle: state.recruiter.searchedJobTitle,
  searchedTalent: state.profiles.searchedTalent,
  draftJobsSortedBy: state.recruiter.draftJobsSortedBy,
  postedJobsSortedBy: state.recruiter.postedJobsSortedBy,
  qualifiedJobsSortedBy: state.recruiter.qualifiedJobsSortedBy,
  presentedJobsSortedBy: state.recruiter.presentedJobsSortedBy,
  closedJobsSortedBy: state.recruiter.closedJobsSortedBy,
});

const mapDispatchToProps = dispatch => ({
  flushAllJobs: () =>
    dispatch(flushAllJobs()),
  resetFilterParams: () =>
    dispatch(resetFilterParams()),
  resetFilterParamsMatched: () =>
    dispatch(resetFilterParamsMatched()),
  fetchFacet: searchedValue =>
    dispatch(fetchFacet(searchedValue)),
  getDraftedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getDraftedJobs(pageNo, sortBy, employer, key, perPage)),
  getPostedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getPostedJobs(pageNo, sortBy, employer, key, perPage)),
  getQualifiedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getQualifiedJobs(pageNo, sortBy, employer, key, perPage)),
  getPresentedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getPresentedJobs(pageNo, sortBy, employer, key, perPage)),
  getClosedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getClosedJobs(pageNo, sortBy, employer, key, perPage)),
  setSearchedJobTitle: text => dispatch(setSearchedJobTitle(text)),
  searchTalent: (talent, filterParam) => dispatch(searchTalent(talent, filterParam)),
  setFilter: talent => dispatch(setFilter(talent)),
  flushAllCandidates: () => dispatch(flushAllCandidates()),
  searchCustomers: (searchItem, pageNo, pageSize) =>
    dispatch(searchCustomers(searchItem, pageNo, pageSize)),
  getCustomers: pageNo => dispatch(getCustomers(pageNo)),
  setSearchItem: () => dispatch(setSearchItem()),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(BoardSearchContainer));
