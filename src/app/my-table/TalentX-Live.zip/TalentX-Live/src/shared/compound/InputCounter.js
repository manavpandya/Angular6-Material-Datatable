import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import AddIcon from 'material-ui-icons/AddCircleOutline';
import SubtractIcon from 'material-ui-icons/RemoveCircleOutline';
import IconButton from 'material-ui/IconButton';
import Input from 'material-ui/Input';

class Counter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      min: this.props.min,
      max: this.props.max,
      value: this.props.min,
    };
  }

  decrement() {
    if (this.state.value !== this.state.min) {
      this.setState({ value: this.state.value - 1 });
    }
  }

  increment() {
    if (this.state.value !== this.state.max) {
      this.setState({ value: this.state.value + 1 });
    }
  }

  render() {
    return (
      <div className="input-counter">
        <Input
          type="text"
          placeholder={this.props.placeholder || 'Find more ...'}
          className="input-counter__input"
        />
        <IconButton className="input-counter__icon-button" onClick={this.decrement}>
          <SubtractIcon />
        </IconButton>
        <h2>{ this.state.value }
        </h2>
        <IconButton style={{ width: '2rem', height: '2rem' }} onClick={this.increment}>
          <AddIcon />
        </IconButton>
        <h2 style={{
          marginTop: 0, color: '#666', fontSize: '1rem', marginLeft: '1rem', height: '2rem', lineHeight: '2rem',
          }}
        >Years
        </h2>
      </div>
    );
  }
}

Counter.propTypes = {
  placeholder: PropTypes.string.isRequired,
  min: PropTypes.number.isRequired,
  max: PropTypes.number.isRequired,
};

export default Counter;
