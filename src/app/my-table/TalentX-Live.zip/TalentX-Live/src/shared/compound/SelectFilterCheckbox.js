import React, { Component } from 'react';
import _ from 'lodash';
import { PropTypes } from 'prop-types';
import DeleteSweep from 'material-ui-icons/DeleteSweep';
import Autocomplete from '../../modules/candidates/components/Autocomplete';
import { sortAll, getMultiSortedValues } from './../../utils/index';

class SelectFilterCheckbox extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedList: getMultiSortedValues(this.props.values, 'key', 'doc_count').slice(0, 5),
    };
    this.onChange = this.onChange.bind(this);
    this.updatedList = this.updatedList.bind(this);
    this.reset = this.reset.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.values !== nextProps.values && this.props.isNewSearch) {
      this.setState({
        selectedList: getMultiSortedValues(nextProps.values, 'key', 'doc_count').slice(0, 5),
      }, () => {
        if (this.props.isNewSearch || nextProps.isNewSearch) {
          this.props.setNewSearch(false);
        }
      });
    }
  }

  onChange(event, label) {
    event.persist();
    this.props.setCheckedFilters(label, event.target.value);
    setTimeout(() => this.props.passTalent(event.target));
  }

  updatedList(params) {
    const list = this.state.selectedList;
    const checkDuplicate = list.find(v => v.key === params.key);
    if (checkDuplicate === undefined) list.push(params);
    this.setState({
      selectedList: sortAll([...this.state.selectedList, ...params], 'doc_count', 'asc', 'number'),
    });
  }

  reset(id) {
    if (this.props.filterParam) {
      this.props.resetFilter(id);
      this.props.reset();
    }
  }

  render() {
    let isDisabled = 'disabled';
    const checkDisabled = this.props.checkedFilters &&
      this.props.checkedFilters[this.props.id];
    if (checkDisabled === undefined || checkDisabled.length === 0) {
      isDisabled = 'disabled';
    } else {
      isDisabled = '';
    }
    return (
      <div className="input-multiselect">
        { !this.props.isMeta &&
        <DeleteSweep className="pointer reset-filter" onClick={() => this.reset(this.props.id)} /> }
        { this.props.isMeta ?
          <ul className={isDisabled}>
            {this.props.values.map((v) => {
              let render = '';
              if (v.key !== '') {
                render = (
                  <label htmlFor={`${this.props.id}-${v.key}`} key={v.key} className="checkbox">
                    <input type="checkbox" id={`${this.props.id}-${v.key}`} onChange={e => this.onChange(e, this.props.id)} value={v.value} checked={_.includes(this.props.checkedFilters[this.props.id], v.value) || false} />
                    <span>{v.key}</span>
                  </label>
                );
              }
              return render !== '' ? render : null;
            })}
          </ul>
        :
          <ul className="input-lists">
            {this.state.selectedList.map((v) => {
              let render = '';
              if (v.key !== '') {
                render = (
                  <label htmlFor={`${this.props.id}-${v.key}`} key={v.key} className="checkbox">
                    {v.key &&
                      <input id={`${this.props.id}-${v.key}`} type="checkbox" onChange={e => this.onChange(e, this.props.id)} value={v.key} checked={_.includes(this.props.checkedFilters[this.props.id] || '', v.key) || false} />
                    }
                    <span>{v.key}{this.state.value} ({v.doc_count})</span>
                  </label>
              );
            }
            return render !== '' ? render : null;
            })}
          </ul>
        }
        { !this.props.isMeta && ((this.props.id === 'current_location' || 'preferred_location') || (this.props.values.length > 5)) &&
          <Autocomplete
            searchedValue={this.props.searchedValue}
            fetchLocalFilterSearch={this.props.fetchLocalFilterSearch}
            currentFilterType={this.props.currentFilterType}
            addToList={this.updatedList}
            suggestionsLoading={this.props.suggestionsLoading}
            suggestions={this.props.localFilterSuggestions || []}
          />
        }
      </div>
    );
  }
}

SelectFilterCheckbox.propTypes = {
  passTalent: PropTypes.func,
  values: PropTypes.arrayOf(Object).isRequired,
  reset: PropTypes.func,
  resetFilter: PropTypes.func,
  id: PropTypes.string,
  fetchLocalFilterSearch: PropTypes.func,
  currentFilterType: PropTypes.string,
  localFilterSuggestions: PropTypes.arrayOf(Object),
  suggestionsLoading: PropTypes.bool,
  setNewSearch: PropTypes.func,
  isNewSearch: PropTypes.bool,
  checkedFilters: PropTypes.object.isRequired, // eslint-disable-line
  setCheckedFilters: PropTypes.func.isRequired,
  searchedValue: PropTypes.string,
  isMeta: PropTypes.bool.isRequired,
  filterParam: PropTypes.string,
};
SelectFilterCheckbox.defaultProps = {
  resetFilter: () => {},
  passTalent: () => {},
  suggestionsLoading: false,
  reset: () => {},
  id: '',
  fetchLocalFilterSearch: () => {},
  currentFilterType: '',
  localFilterSuggestions: [],
  searchedValue: '',
  filterParam: '',
  isNewSearch: false,
  setNewSearch: () => {},
};

export default SelectFilterCheckbox;
