import React, { Component } from 'react';
import Button from 'material-ui/Button';
import Paper from 'material-ui/Paper';
import PropTypes from 'prop-types';
import { Manager, Target } from 'react-popper';
import Grow from 'material-ui/transitions/Grow';
import ClickAwayListener from 'material-ui/utils/ClickAwayListener';

const stylePaper = {
  popup: {
    position: 'absolute',
    top: '100%',
    right: 0,
    zIndex: 2000,
    padding: '0.5rem',
  },
};

class Menu extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };
    this.handleClick = this.handleClick.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }
  shouldComponentUpdate(nextProps, nextState) {
    const hasPropsChanged = nextState.open !== this.state.open
      || nextProps.isDisabled !== this.props.isDisabled;
    return hasPropsChanged;
  }
  handleClick() {
    this.setState({ open: !this.state.open });
  }

  handleClose() {
    this.setState({ open: false });
  }

  render() {
    const { open } = this.state;
    return (
      <div>
        {
          this.state.open === false
          ?
            <div className={`position-relative ${this.props.isDisabled ? 'disabled' : ''}`}>
              <Manager>
                <Target>
                  <Button onClick={() => this.handleClick()} className="btn-white">
                    { this.props.iconPrefix }
                    { this.props.label }
                    { this.props.iconSuffix }
                  </Button>
                </Target>
              </Manager>
            </div>
          :
            <div className="position-relative">
              <Button onClick={() => this.handleClick()} className="btn-white">
                { this.props.iconPrefix }
                { this.props.label }
                { this.props.iconSuffix }
              </Button>
              <ClickAwayListener onClickAway={this.handleClose}>
                <Grow in={open} className="transformOrigin">
                  <Paper
                    style={this.props.menuStyle || stylePaper.popup}
                    elevation={4}
                    onClick={this.handleClick}
                  >
                    { this.props.popup }
                  </Paper>
                </Grow>
              </ClickAwayListener>
            </div>
        }
      </div>
    );
  }
}


Menu.propTypes = {
  iconPrefix: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  iconSuffix: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
  popup: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
    PropTypes.object,
    PropTypes.symbol,
  ]).isRequired,
  menuStyle: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
    PropTypes.object,
  ]),
  isDisabled: PropTypes.bool,
};

Menu.defaultProps = {
  iconPrefix: '',
  label: '',
  iconSuffix: '',
  menuStyle: null,
  isDisabled: false,
};

export default Menu;
