import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withStyles } from 'material-ui/styles';
import IconButton from 'material-ui/IconButton';
import FirstPageIcon from 'material-ui-icons/FirstPage';
import KeyboardArrowLeft from 'material-ui-icons/KeyboardArrowLeft';
import KeyboardArrowRight from 'material-ui-icons/KeyboardArrowRight';
import LastPageIcon from 'material-ui-icons/LastPage';
import { Field, reduxForm } from 'redux-form';
import TextField from 'material-ui/TextField';
import { matchRegEx } from '../../utils/validators';

const actionsStyles = theme => ({
  root: {
    flexShrink: 0,
    color: theme.palette.text.secondary,
    marginLeft: theme.spacing.unit * 2.5,
    display: 'flex',
  },
});

const renderField = ({ input, label, onKeyUp, className, InputProps, defaultValue, type, meta: { touched, error } }) => { //eslint-disable-line
  return (
    <TextField
      {...input}
      className={className}
      InputProps={InputProps}
      onKeyUp={onKeyUp}
      defaultValue={defaultValue}
      placeholder={label}
    />
  );
};

class TablePaginationActions extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: false,
    };

    this.handleFirstPageButtonClick = this.handleFirstPageButtonClick.bind(this);
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
    this.handleNextButtonClick = this.handleNextButtonClick.bind(this);
    this.handleLastPageButtonClick = this.handleLastPageButtonClick.bind(this);
    this.handleGoToPageInput = this.handleGoToPageInput.bind(this);
  }
  componentDidMount() {
    this.props.change('pageName', '1');
  }

  handleGoToPageInput(event) {
    if (matchRegEx(event.target.value, /^(?!(?:0)$)\d{1,10}$/) && event.target.value
    <= Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage))) {
      this.setState({
        error: false,
      });
    } else {
      this.setState({
        error: true,
      });
    }
    if (event.key === 'Enter') {
      if (matchRegEx(event.target.value, /^(?!(?:0)$)\d{1,10}$/) && event.target.value
        <= Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage))) {
        this.props.onChangePage('goto', parseInt(event.target.value, 10)); // 10 is radix
      } else {
        this.setState({
          error: true,
        });
      }
    }
  }
  handleFirstPageButtonClick() {
    this.props.dispatch(this.props.change('pageName', 1));
    this.props.onChangePage('gotoFirst', 1);
  }

  handleBackButtonClick(event) {
    this.props.dispatch(this.props.change('pageName', this.props.page));
    this.props.onChangePage(event, this.props.page - 1);
  }

  handleNextButtonClick(event) {
    this.props.dispatch(this.props.change('pageName', this.props.page + 2));
    this.props.onChangePage(event, this.props.page + 1);
  }

  handleLastPageButtonClick(event) {
    this.props.dispatch(this.props.change('pageName', Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage) - 1) + 1));
    this.props.onChangePage(
      event,
      Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage) - 1),
    );
  }

  render() {
    const {
      classes, count, page, rowsPerPage,
    } = this.props;
    return (
      <div className={classes.root}>
        <IconButton
          onClick={this.handleFirstPageButtonClick}
          disabled={page === 0}
          aria-label="First Page"
        >
          <FirstPageIcon />
        </IconButton>
        <IconButton
          onClick={this.handleBackButtonClick}
          disabled={page === 0}
          aria-label="Previous Page"
        >
          <KeyboardArrowLeft />
        </IconButton>
        {/* <Form onSubmit={this.props.handleSubmit(this.handleSubmit)} > */}
        <Field
          onKeyUp={this.handleGoToPageInput}
          className="goto-page"
          defaultValue={1}
          id="page"
          name="pageName"
          InputProps={{
            className: `goto-input ${this.state.error ? ' error-field' : ''} `,
            disableUnderline: true,
            classes: {
              root: classes.bootstrapRoot,
              input: classes.bootstrapInput,
            },
          }}
          component={renderField}
        />
        {/* </Form> */}
        <IconButton
          onClick={this.handleNextButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="Next Page"
        >
          <KeyboardArrowRight />
        </IconButton>
        <IconButton
          onClick={this.handleLastPageButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="Last Page"
        >
          <LastPageIcon />
        </IconButton>
      </div>
    );
  }
}

TablePaginationActions.propTypes = {
  classes: PropTypes.object.isRequired, //eslint-disable-line
  count: PropTypes.number.isRequired,
  onChangePage: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
  theme: PropTypes.object.isRequired, //eslint-disable-line
  change: PropTypes.func.isRequired,
  dispatch: PropTypes.func.isRequired,
  // handleSubmit: PropTypes.func.isRequired,
};

const mapStateToProps = () => ({});
// export default withStyles(actionsStyles)(TablePaginationActions);
// export default TablePaginationActions;
export default connect(mapStateToProps, null)(reduxForm({
  form: 'gotoForm',
  enableReinitialize: true,
})(withStyles(actionsStyles)(TablePaginationActions)));

