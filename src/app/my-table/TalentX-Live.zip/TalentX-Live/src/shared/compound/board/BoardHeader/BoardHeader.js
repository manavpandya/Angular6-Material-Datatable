import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
// import NotificationIcon from 'material-ui-icons/Notifications';
// import ToDoIcon from 'material-ui-icons/Assignment';
import HomeIcon from 'material-ui-icons/Home';
import FileUploadIcon from 'material-ui-icons/FileUpload';
// import ZoomInIcon from 'material-ui-icons/ZoomIn';
// import ZoomOutIcon from 'material-ui-icons/ZoomOut';
// import Badge from 'material-ui/Badge';
import Button from 'material-ui/Button';

import Loader from '../../../basic/InlineLoader';
import Logo from '../../../../logo.png';
import { showNotification } from '../../../../utils/Notifications';
import AvatarMenu from '../../../../shared/compound/AvatarMenu';
import { HomeSubHeader, SourcingSubHeader } from '../headers/';
import { uploadCandidateProfiles } from '../../../../modules/candidates/redux/actions';
import LanguageOptions from '../../LanguageOptions';
import languages from '../../../../i18n/languages';

const chooseSubHeader = (title, setShowCreateNewJob, showBookmarkedCandidates, clientPage) => {
  switch (title) {
    case '3000🚀': {
      return <HomeSubHeader setShowCreateNewJob={setShowCreateNewJob} />;
    }
    case '3002🚀': {
      return (<SourcingSubHeader
        showBookmarkedCandidates={showBookmarkedCandidates}
        clientPage={clientPage}
      />);
    }
    default: {
      return null;
    }
  }
};

class AppHeader extends Component {
  constructor(props) {
    super(props);
    this.onFilesSelected = this.onFilesSelected.bind(this);
  }

  onFilesSelected(event) {
    const { files } = event.target;
    const filesArray = Array.from(files);
    Promise.all(filesArray.map((file) => {
      const formData = new FormData();
      formData.append('file', file);
      return this.props.uploadCandidateProfiles(formData);
    })).then(() => {
      if (filesArray.length > 0) {
        showNotification(`${filesArray.length} ${this.props.translate('profile')}${filesArray.length === 1 ? '' : 's'} ${this.props.translate('uploadedSuccesfully')}`, 'success', 8000);
      }
    }).catch((err) => {
      showNotification(err, 'error', 8000);
    });
  }

  render() {
    return (
      <header className="app-header">
        <div className="app-header-content">
          <div className="app-header-items-container">
            <div className="item-group primary">
              <AvatarMenu
                logout={this.props.logout}
                accountInfo={this.props.accountInfo}
              />
            </div>
            <div className="item-group active">
              <Link to="/recruiter">
                <HomeIcon />
              </Link>
            </div>
            {/* <div className="item-group active">
              <Badge badgeContent={4} className="notification">
                <NotificationIcon />
              </Badge>
            </div>
            <div className="item-group active">
              <Badge badgeContent={2} className="notification">
                <ToDoIcon />
              </Badge>
            </div> */}
            {
              chooseSubHeader(
                this.props.title,
                this.props.setShowCreateNewJob,
                this.props.showBookmarkedCandidates,
                this.props.clientPage,
              )
            }
          </div>
          {/* {
              props.zoomin &&
              <div className="item-group zoom-btn-container">
                <div className="zoom">
                  <Button onClick={() => props.zoomout()}><ZoomOutIcon /></Button>&nbsp;&nbsp;&nbsp;
                  <Button onClick={() => props.zoomin()}><ZoomInIcon /></Button>
                </div>
              </div>} */}
        </div>
        <LanguageOptions
          dispatch={this.props.dispatch}
          languages={languages}
          color="#ffffff"
        />
        <input
          type="file"
          ref={(ref) => { this.multiFileUpload = ref; }}
          className="invisible"
          multiple
          accept=".doc,.docx,.pdf"
          onChange={this.onFilesSelected}
        />
        <Button className="file-upload-button" onClick={() => this.multiFileUpload.click()}>
          {
            this.props.candidateProfilesLoading ? <Loader /> : <FileUploadIcon />
          }
          {this.props.translate('uploadProfile')}
        </Button>
        <div className="logo-container">
          <Link to="/recruiter">
            <h1 className="logo"><img src={Logo} alt="logo" /></h1>
          </Link>
        </div>
      </header>
    );
  }
}

AppHeader.propTypes = {
  translate: PropTypes.func,
  // zoomin: PropTypes.func,
  // zoomout: PropTypes.func,
  dispatch: PropTypes.func.isRequired,
  logout: PropTypes.func,
  setShowCreateNewJob: PropTypes.func,
  title: PropTypes.string,
  accountInfo: PropTypes.object, // eslint-disable-line
  showBookmarkedCandidates: PropTypes.bool,
  uploadCandidateProfiles: PropTypes.func,
  candidateProfilesLoading: PropTypes.bool,
  clientPage: PropTypes.bool,
};

AppHeader.defaultProps = {
  translate: () => {},
  // zoomin: () => {},
  // zoomout: () => {},
  logout: () => {},
  setShowCreateNewJob: () => {},
  title: '3000🚀',
  accountInfo: {},
  showBookmarkedCandidates: false,
  uploadCandidateProfiles: () => {},
  candidateProfilesLoading: false,
  clientPage: false,
};

const mapStateToProps = state => ({
  candidateProfilesLoading: state.profiles.candidateProfilesLoading,
});

const mapDispatchToProps = dispatch => ({
  uploadCandidateProfiles: formData => dispatch(uploadCandidateProfiles(formData)),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(AppHeader));
