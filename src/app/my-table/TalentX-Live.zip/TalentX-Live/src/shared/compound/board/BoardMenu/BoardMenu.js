import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import ExpandMoreIcon from 'material-ui-icons/ExpandMore';
import { MenuList, MenuItem } from 'material-ui/Menu';
import Menu from '../../../../shared/compound/Menu';
import Loader from '../../../../shared/basic/Loader';

const style = {
  menuItem: {
    padding: '1rem 1rem',
    minWidth: '10rem',
    whiteSpace: 'nowrap',
    display: 'block',
  },
  menuItemLast: {
    padding: '1rem 1rem',
    minWidth: '10rem',
    display: 'block',
  },
  popup: {
    position: 'absolute',
    top: '100%',
    right: 'auto',
    zIndex: 2000,
    padding: '0.5rem',
  },
};

const BoardMenu = props => (
  <Fragment>
    <div className="select-employer">
      <Menu
        menuStyle={style.popup}
        label={
          <h1 className="menu-label">
            {props.selectedMenuItemText}
          </h1>
        }
        iconSuffix={<ExpandMoreIcon style={{ color: '#FFFFFF', width: '16px', marginRight: '0.25rem' }} />}
        popup={
          <MenuList role="menu">
            {
              props.loading
                ? <Loader />
                : props.employers.map(employer =>
                    employer.key &&
                    <MenuItem
                      key={employer.key}
                      style={
                        employer.key === props.employers[props.employers.length - 1].key
                        ? style.menuItemLast
                        : style.menuItem
                      }
                      onClick={() => {
                        props.selectEmployer(employer.key);
                      }}
                    >
                      {employer.key}
                    </MenuItem>)
            }
          </MenuList>
        }
      />
    </div>
    <div className="select-employer">
      <Menu
        menuStyle={style.popup}
        label={
          <h1 className="menu-label">
            {props.selectedLocationText}
          </h1>
        }
        iconSuffix={<ExpandMoreIcon style={{ color: '#FFFFFF', width: '16px', marginRight: '0.25rem' }} />}
        popup={
          <MenuList role="menu">
            {
              props.loading
                ? <Loader />
                : props.locations.map(location =>
                    location.key &&
                    <MenuItem
                      key={location.key}
                      style={
                        location.key === props.locations[props.locations.length - 1].key
                        ? style.menuItemLast
                        : style.menuItem
                      }
                      onClick={() => {
                        props.selectLocation(location.key);
                      }}
                    >
                      {location.key}
                    </MenuItem>)
            }
          </MenuList>
        }
      />
    </div>
  </Fragment>
);

BoardMenu.propTypes = {
  selectedMenuItemText: PropTypes.string,
  selectedLocationText: PropTypes.string,
  employers: PropTypes.arrayOf(PropTypes.object),
  locations: PropTypes.arrayOf(PropTypes.object),
  loading: PropTypes.bool,
};

BoardMenu.defaultProps = {
  selectedMenuItemText: '',
  selectedLocationText: '',
  employers: [],
  locations: [],
  loading: false,
};

export default BoardMenu;
