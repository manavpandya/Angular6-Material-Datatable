import React from 'react';
import { Link } from 'react-router-dom';
import ArrowBack from 'material-ui-icons/ArrowBack';
import AppBar from 'material-ui/AppBar';
import PropTypes from 'prop-types';

const AppBarContent = props => (
  <AppBar className="appbar alt" position="absolute">
    <div className="flex-center app-bar-content">
      <div className="app-bar-content-left">
        <Link to="/recruiter" className="back-arrow">
          <ArrowBack />
        </Link>
        <h1>{props.header}</h1>
      </div>
      {props.appBarButtons}
    </div>
  </AppBar>
);

AppBarContent.propTypes = {
  appBarButtons: PropTypes.element,
  classes: PropTypes.object, // eslint-disable-line
  header: PropTypes.string.isRequired,
};

AppBarContent.defaultProps = {
  classes: {},
  appBarButtons: <div />,
};

export default AppBarContent;
