import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import Button from 'material-ui/Button';
import AddIcon from 'material-ui-icons/Add';
import DeleteIcon from 'material-ui-icons/Delete';
import PropTypes from 'prop-types';

const AppBarButtons = props => (
  <div className="app-bar-content-right">
    <Button
      variant="raised"
      color="primary"
      className="add-user"
      onClick={props.addUser}
    >
      <AddIcon />
      {props.translate('addRecord')}
    </Button>
    <Button
      variant="raised"
      color="secondary"
      className="add-user"
      onClick={props.deleteSelectedUsers}
      disabled={props.disabled}
    >
      <DeleteIcon />
      {props.translate('deleteRecord')}
    </Button>
  </div>
);

AppBarButtons.propTypes = {
  translate: PropTypes.func.isRequired,
  addUser: PropTypes.func,
  deleteSelectedUsers: PropTypes.func,
  disabled: PropTypes.bool,
};

AppBarButtons.defaultProps = {
  addUser: () => {},
  deleteSelectedUsers: () => {},
  disabled: false,
};

export default withTranslate(AppBarButtons);
