import React from 'react';
import { PropTypes } from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';
import Button from 'material-ui/Button';
import AddIcon from 'material-ui-icons/Add';
import BoardMenu from '../BoardMenu/BoardMenuContainer';
import BoardSearch from '../BoardSearch/BoardSearchContainer';

const HomeSubHeader = props => (
  <div className="board-actions-container">
    <BoardMenu />
    <BoardSearch homepage />
    <Button className="add-button" onClick={() => props.setShowCreateNewJob(true)}>
      <AddIcon />
      { props.translate('newJob') }
    </Button>
  </div>
);

HomeSubHeader.propTypes = {
  setShowCreateNewJob: PropTypes.func.isRequired,
  translate: PropTypes.func.isRequired,
};

export default withTranslate(HomeSubHeader);
