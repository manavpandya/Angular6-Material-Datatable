import React, { Component, Fragment } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import { PropTypes } from 'prop-types';
import Dialog, { DialogContent, DialogTitle } from 'material-ui/Dialog';
import IconButton from 'material-ui/IconButton';
import CloseIcon from 'material-ui-icons/Close';

import { logoutFunction } from '../../../../modules/auth/redux/actions';
import BoardHeader from './BoardHeader';
import CreateNewJobContainer from '../../../../modules/jobs/components/CreateNewJob/CreateNewJobContainer';
import { getJobPositions, getAccountMe } from '../../../../modules/jobs/redux/actions';

class BoardHeaderContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showCreateNewJob: false,
    };
    this.logout = this.logout.bind(this);
    this.setShowCreateNewJob = this.setShowCreateNewJob.bind(this);
  }

  componentDidMount() {
    this.props.getJobPositions();
    this.props.getAccountMe();
  }

  setShowCreateNewJob(show) {
    this.setState({
      showCreateNewJob: show,
    });
  }

  logout() {
    this.props.logout();
  }

  render() {
    return (
      <Fragment>
        <BoardHeader
          title={this.props.headerName}
          logout={this.props.logout}
          accountInfo={this.props.accountInfo}
          setShowCreateNewJob={this.setShowCreateNewJob}
          showBookmarkedCandidates={this.props.showBookmarkedCandidates}
          clientPage={this.props.clientPage}
        />
        <Dialog
          open={this.state.showCreateNewJob}
          onClose={() => this.setShowCreateNewJob(false)}
          autoFocus
          maxWidth="md"
          aria-labelledby="new-job-dialog-title"
          aria-describedby="new-job-dialog-description"
        >
          <DialogTitle id="new-job-dialog-title">
            <div className="dialog-header">
              <span>{this.props.translate('createNewJob')}</span>
              <IconButton onClick={() => this.setShowCreateNewJob(false)}>
                <CloseIcon />
              </IconButton>
            </div>
          </DialogTitle>
          <DialogContent>
            <div id="new-job-dialog-description">
              <CreateNewJobContainer setShowCreateNewJob={this.setShowCreateNewJob} />
            </div>
          </DialogContent>
        </Dialog>
      </Fragment>
    );
  }
}

BoardHeaderContainer.propTypes = {
  translate: PropTypes.func,
  logout: PropTypes.func,
  getJobPositions: PropTypes.func,
  headerName: PropTypes.string,
  getAccountMe: PropTypes.func,
  accountInfo: PropTypes.object, // eslint-disable-line
  showBookmarkedCandidates: PropTypes.bool,
  clientPage: PropTypes.bool,
};

BoardHeaderContainer.defaultProps = {
  translate: () => {},
  headerName: '',
  logout: () => {},
  getJobPositions: () => {},
  getAccountMe: () => {},
  accountInfo: {},
  showBookmarkedCandidates: false,
  clientPage: false,
};

const mapStateToProps = state => ({
  accountInfo: state.recruiter.accountInfo,
});

const mapDispatchToProps = dispatch => ({
  logout: () => dispatch(logoutFunction()),
  getJobPositions: () => dispatch(getJobPositions()),
  getAccountMe: () => dispatch(getAccountMe()),
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(BoardHeaderContainer));
