import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { withStyles } from 'material-ui/styles';
import SearchIcon from 'material-ui-icons/Search';
import TextField from 'material-ui/TextField';
import IconButton from 'material-ui/IconButton';
import PropTypes from 'prop-types';
import Button from 'material-ui/Button';


const styles = {
  button: {
    margin: 0,
  },
  input: {
    display: 'none',
  },
};

const BoardSearch = props => (
  <div style={{ display: 'flex', flexWrap: 'none', alignItems: 'center' }}>
    <TextField
      className="search-box"
      placeholder={`${props.translate('search')}...`}
      value={props.searchBoxText}
      onChange={props.setSearchBoxText}
      onKeyPress={props.searchKeyPress}
    />
    <IconButton
      disabled={props.searchBoxText.length === 0}
      className={props.classes.button}
      onClick={props.searchClick}
      aria-label="Delete"
    >
      <SearchIcon
        style={
        {
          color: '#FFFFFF',
          width: '20px',
          marginRight: '0.25rem',
          cursor: 'pointer',
        }
      }
      />
    </IconButton>
    {
      ((props.matchPath === '/recruiter/candidates') && (props.searchedValue || props.filterParam)) &&
      <Button
        size="small"
        variant="raised"
        color="secondary"
        className={props.classes.button}
        onClick={() => props.searchClick(true)}
      >
        {props.translate('reset')}
      </Button>
    }
    {
      ((props.homepage || props.clientPage) && props.showResetButton) &&
      <Button
        size="small"
        variant="raised"
        color="secondary"
        className={props.classes.button}
        onClick={props.resetJobs}
      >
        {props.translate('reset')}
      </Button>
    }
  </div>
);


BoardSearch.propTypes = {
  classes: PropTypes.objectOf(Object).isRequired,
  translate: PropTypes.func.isRequired,
  setSearchBoxText: PropTypes.func,
  searchBoxText: PropTypes.string,
  searchKeyPress: PropTypes.func,
  searchClick: PropTypes.func,
  searchedValue: PropTypes.string,
  filterParam: PropTypes.string,
  homepage: PropTypes.bool,
  showResetButton: PropTypes.bool,
  resetJobs: PropTypes.func,
  matchPath: PropTypes.object, // eslint-disable-line
  clientPage: PropTypes.bool,
};

BoardSearch.defaultProps = {
  setSearchBoxText: () => {},
  searchBoxText: '',
  searchKeyPress: () => {},
  searchClick: () => {},
  searchedValue: '',
  filterParam: '',
  homepage: false,
  showResetButton: false,
  resetJobs: () => {},
  matchPath: {},
  clientPage: false,
};


export default withStyles(styles)(withTranslate(BoardSearch));
