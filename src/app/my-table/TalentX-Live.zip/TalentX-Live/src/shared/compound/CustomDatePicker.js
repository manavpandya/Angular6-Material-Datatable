import React from 'react';
import PropTypes from 'prop-types';
import { DatePicker } from 'material-ui-pickers';
import moment from 'moment';

const CustomDatePicker = (props) => {
  const { input, label, meta } = props;
  const { error } = meta;
  return (
    <div>
      <DatePicker
        onChange={(event) => {
          if (input.onChange && event != null) {
            input.onChange(moment(event.toDate()).format('YYYY-MM-DD'));
          } else {
            input.onChange(null);
          }
        }}
        {...props}
        error={error ? true : false} // eslint-disable-line
        keyboard
        clearable
        label={label}
        format="MMM DD YYYY"
        value={input.value ? input.value : moment(new Date()).format('YYYY-MM-DD')}
      />
      {
        error &&
        <p className="error">{error}</p>
      }
    </div>
  );
};


CustomDatePicker.propTypes = {
  meta: PropTypes.object, // eslint-disable-line
  input: PropTypes.objectOf(PropTypes.string),
  label: PropTypes.string.isRequired,
};


CustomDatePicker.defaultProps = {
  meta: {},
  input: {},
};

export default CustomDatePicker;
