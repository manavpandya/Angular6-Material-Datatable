import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import Select from 'material-ui/Select';
import Input from 'material-ui/Input';
import { MenuItem } from 'material-ui/Menu';

class InputSelect extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: props.value,
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event) {
    this.setState({ value: event.target.value });
  }

  render() {
    return (
      <div className="input-select">
        <Select
          value={this.state.value}
          onChange={this.handleChange}
          displayEmpty
          name="value"
          input={
            <Input type="text" className="input-select__input" />
          }
        >
          {this.props.values.map(v => (
            <MenuItem key={v} value={v} className="input-select__menu-item">
              {v}
            </MenuItem>
            ))}
        </Select>
      </div>
    );
  }
}

InputSelect.propTypes = {
  value: PropTypes.string.isRequired,
  values: PropTypes.arrayOf.isRequired,
};

export default InputSelect;
