import React from 'react';
import Autocomplete from '../../modules/candidates/components/Autocomplete';

const suggestions = [
  { key: 'Afghanistan' },
  { key: 'Aland Islands' },
  { key: 'Albania' },
  { key: 'Algeria' },
  { key: 'American Samoa' },
  { key: 'Andorra' },
  { key: 'Angola' },
  { key: 'Anguilla' },
  { key: 'Antarctica' },
  { key: 'Antigua and Barbuda' },
  { key: 'Argentina' },
  { key: 'Armenia' },
  { key: 'Aruba' },
  { key: 'Australia' },
  { key: 'Austria' },
  { key: 'Azerbaijan' },
  { key: 'Bahamas' },
  { key: 'Bahrain' },
  { key: 'Bangladesh' },
  { key: 'Barbados' },
  { key: 'Belarus' },
  { key: 'Belgium' },
  { key: 'Belize' },
  { key: 'Benin' },
  { key: 'Bermuda' },
  { key: 'Bhutan' },
  { key: 'Bolivia, Plurinational State of' },
  { key: 'Bonaire, Sint Eustatius and Saba' },
  { key: 'Bosnia and Herzegovina' },
  { key: 'Botswana' },
  { key: 'Bouvet Island' },
  { key: 'Brazil' },
  { key: 'British Indian Ocean Territory' },
  { key: 'Brunei Darussalam' },
];
const InputAutoComplete = () => (
  <Autocomplete suggestions={suggestions} />
);

InputAutoComplete.defaultProps = {
  passTalent: () => {},
};

export default InputAutoComplete;
