import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { withStyles } from 'material-ui/styles';
import { PropTypes } from 'prop-types';
import { connect } from 'react-redux';
import Button from 'material-ui/Button';
import Dialog, {
  DialogActions,
} from 'material-ui/Dialog';
import Input, { InputAdornment } from 'material-ui/Input';
import Slide from 'material-ui/transitions/Slide';
import IconButton from 'material-ui/IconButton';
import SearchIcon from 'material-ui-icons/Search';
import { showNotification } from '../../utils/Notifications';
import { getPostedJobsForCandidates, flushPostedJobsForCandidates } from '../../modules/jobs/redux/actions';
import { addToJob, addToJobMultiple, selectAllCandidates } from '../../modules/candidates/redux/actions';
import Loader from '../basic/Loader';
import MomentTranslate from '../../shared/basic/MomentTranslate';

const pageSize = 10;

function Transition(props) {
  return <Slide direction="up" {...props} />;
}

const styles = {
  dialogAction: {
    marginTop: 0,
    marginBottom: 0,
    marginRight: 4,
    marginLeft: 4,
  },
  dialogActionButton: {
    paddingTop: 25,
  },
};

class AddToJobDialog extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isSelected: false,
      jobId: '',
      jobTitle: '',
      profileId: '',
      profileName: '',
      searchBoxText: '',
      fullScreen: false,
    };

    this.selectJob = this.selectJob.bind(this);
    this.setSearchBoxText = this.setSearchBoxText.bind(this);
    this.searchKeyPress = this.searchKeyPress.bind(this);
    this.searchClick = this.searchClick.bind(this);
    this.checkLoaderVisibility = this.checkLoaderVisibility.bind(this);
    this.getNextPage = this.getNextPage.bind(this);
    this.handleScroll = this.handleScroll.bind(this);
    this.handleClickFullScreen = this.handleClickFullScreen.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleAddToJob = this.handleAddToJob.bind(this);
    this.onComponentEnter = this.onComponentEnter.bind(this);
    this.onComponentExit = this.onComponentExit.bind(this);
  }

  componentDidMount() {
    if (this.props.postedJobsForCandidates && this.props.postedJobsForCandidates.length) return;
    this.props.getPostedJobsForCandidates(1);
  }

  onComponentExit() {
    if (this.mainBottom) {
      this.mainBottom.removeEventListener('scroll', this.handleScroll);
    }
    this.setState({ ...this.state, jobId: '' });
  }

  onComponentEnter() {
    if (this.mainBottom) {
      this.mainBottom.addEventListener('scroll', this.handleScroll);
      this.handleScroll();
    }
  }

  setSearchBoxText(event) {
    this.setState({
      searchBoxText: event.target.value,
    });
  }

  getNextPage() {
    if (!this.props.postedJobsForCandidatesLoading) {
      this.props
        .getPostedJobsForCandidates((this.props.postedJobsForCandidatesCurrentPage || 0) + 1);
    }
  }

  checkLoaderVisibility() {
    if (this.props.postedJobsForCandidatesLoading) return false;
    return this.props.postedJobsForCandidatesCurrentPage === 0
      ? true
      : (this.props.totalPostedJobsForCandidates /
        (this.props.postedJobsForCandidatesCurrentPage * pageSize)) > 1;
  }

  searchKeyPress(event) {
    if (event.key === 'Enter') {
      this.props.flushPostedJobsForCandidates();
      this.props.getPostedJobsForCandidates(1, undefined, '', this.state.searchBoxText).then((() => {
        const el = document.querySelectorAll('#candidates-list-container ul li')[0];
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }));
    }
  }

  searchClick() {
    this.props.flushPostedJobsForCandidates();
    this.props.getPostedJobsForCandidates(1, undefined, '', this.state.searchBoxText).then((() => {
      const el = document.querySelectorAll('#candidates-list-container ul li')[0];
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }));
  }

  selectJob(isSelected, jobId, jobTitle, profileId, singleProfileName) {
    const profileName = this.props.addtoJobCandidatesMultiple.length > 1
      ? `${`${singleProfileName} and ${this.props.addtoJobCandidatesMultiple.length - 1}`} more...`
      : singleProfileName;
    this.setState({
      isSelected,
      jobId,
      jobTitle,
      profileId,
      profileName,
    });
  }

  handleScroll() {
    const { totalPostedJobsForCandidates, postedJobsForCandidates } = this.props;
    const bottomReached = (this.mainBottom.scrollTop + this.mainBottom.clientHeight)
      >= this.mainBottom.scrollHeight;
    if (bottomReached && postedJobsForCandidates.length < totalPostedJobsForCandidates) {
      this.getNextPage();
    }
  }

  handleClickFullScreen() {
    this.setState({ fullScreen: true });
  }

  handleClose() {
    this.setState({ fullScreen: false });
    this.props.closeAddToJobDialog();
  }

  handleAddToJob() {
    if (this.state.jobId === undefined || this.state.profileId === undefined) {
      this.handleClose();
      showNotification(this.props.translate('candidateShouldSelected'), 'error', 8000);
    } else {
      this.props.addToJob(
        this.state.jobId,
        this.props.addtoJobCandidatesMultiple.length > 0
          ? this.props.addtoJobCandidatesMultiple : this.state.profileId,
        this.props.addtoJobCandidatesMultiple.length > 0,
      ).then(() => {
        this.handleClose();
        this.props.selectAllCandidates([]);
        showNotification(`${this.state.profileName} ${this.props.translate('isSuccesfullyAddedTo')} ${this.state.jobTitle}`, 'success', 8000);
      })
        .catch(() => {
          this.handleClose();
          showNotification(`${this.state.profileName} is already shortlisted`, 'error', 8000);
        });
    }
  }

  render() {
    const profileName = this.props.addtoJobCandidatesMultiple.length > 1
      ? `${`${this.props.addtoJobCandidates.name} and ${this.props.addtoJobCandidatesMultiple.length - 1}`} more...`
      : this.props.addtoJobCandidates.name;
    return (
      <Dialog
        maxWidth={false}
        fullScreen={this.state.fullScreen}
        transition={Transition}
        open={this.props.isAddToJobDialogOpen}
        onEntered={this.onComponentEnter}
        onClose={this.handleClose}
        onExited={this.onComponentExit}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <div className="job-list-dialog">
          {
            this.props.addtoJobCandidates.name
            &&
            <header>
              <h2 className="job-dialog-title">{`Add ${profileName} to ...`}</h2>
            </header>
          }
          <Input
            placeholder="Search currently open jobs"
            value={this.state.searchBoxText}
            onChange={this.setSearchBoxText}
            onKeyPress={this.searchKeyPress}
            className="search-add-to-job"
            endAdornment={
              <InputAdornment position="end">
                <IconButton disabled={this.state.searchBoxText === ''} onClick={this.searchClick} aria-label="Delete">
                  <SearchIcon />
                </IconButton>
              </InputAdornment>
            }
          />
          <main ref={(ref) => { this.mainBottom = ref; }} id="candidates-list-container">
            <ul >
              {
                this.props.postedJobsForCandidates.map((postedJob) => {
                  const jobId = postedJob.id;
                  const jobTitle = postedJob.job_description.job_title;
                  return (
                    <li key={jobId}>
                      <button
                        className={`job ${this.state.jobId === jobId ? 'selected' : ''}`}
                        onClick={() => this.selectJob(
                          true,
                          jobId,
                          jobTitle,
                          this.props.addtoJobCandidates.id,
                          this.props.addtoJobCandidates.name,
                        )}
                      >
                        <h2 className={`${this.state.jobId === jobId ? 'selected' : ''}`}>
                          {postedJob.job_description.job_title}
                        </h2>
                        <span className="posted">
                          <MomentTranslate
                            fromNow={postedJob.created_at}
                          />
                        </span>
                      </button>
                    </li>
                  );
                })
              }
              {
                this.props.postedJobsForCandidatesLoading && <Loader />
              }
            </ul>
          </main>
        </div>
        <DialogActions className={this.props.classes.dialogAction}>
          <div className={this.props.classes.dialogActionButton}>
            <Button onClick={this.handleClose} color="primary" autoFocus>
              {this.props.translate('closeWindow')}
            </Button>
            <Button
              disabled={!this.state.isSelected}
              onClick={this.handleAddToJob}
              color="primary"
              autoFocus
            >
              {this.props.translate('addToJob')}
            </Button>
          </div>
        </DialogActions>
      </Dialog>
    );
  }
}

AddToJobDialog.propTypes = {
  classes: PropTypes.objectOf(PropTypes.any),
  translate: PropTypes.func,
  addtoJobCandidates: PropTypes.object, //eslint-disable-line
  addtoJobCandidatesMultiple: PropTypes.array, //eslint-disable-line
  getPostedJobsForCandidates: PropTypes.func,
  postedJobsForCandidates: PropTypes.array, //eslint-disable-line
  postedJobsForCandidatesLoading: PropTypes.bool,
  totalPostedJobsForCandidates: PropTypes.number,
  postedJobsForCandidatesCurrentPage: PropTypes.number,
  flushPostedJobsForCandidates: PropTypes.func,
  addToJob: PropTypes.func,
  isAddToJobDialogOpen: PropTypes.bool,
  closeAddToJobDialog: PropTypes.func,
  selectAllCandidates: PropTypes.func,
};

AddToJobDialog.defaultProps = {
  classes: {},
  translate: () => {},
  addtoJobCandidates: {},
  addtoJobCandidatesMultiple: [],
  getPostedJobsForCandidates: () => { },
  postedJobsForCandidates: [],
  postedJobsForCandidatesLoading: false,
  totalPostedJobsForCandidates: 0,
  postedJobsForCandidatesCurrentPage: 0,
  flushPostedJobsForCandidates: () => { },
  addToJob: () => { },
  isAddToJobDialogOpen: false,
  closeAddToJobDialog: () => { },
  selectAllCandidates: () => { },
};

const mapStateToProps = state => ({
  postedJobsForCandidates: state.recruiter.postedJobsForCandidates,
  postedJobsForCandidatesLoading: state.recruiter.postedJobsForCandidatesLoading,
  totalPostedJobsForCandidates: state.recruiter.totalPostedJobsForCandidates,
  postedJobsForCandidatesCurrentPage: state.recruiter.postedJobsForCandidatesCurrentPage,
  addToJobLoading: state.profiles.addToJobLoading,
});

const mapDispatchToProps = dispatch => ({
  flushPostedJobsForCandidates: () =>
    dispatch(flushPostedJobsForCandidates()),
  getPostedJobsForCandidates: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getPostedJobsForCandidates(pageNo, sortBy, employer, key, perPage)),
  addToJob: (jobId, profileId, multiple) => (multiple
    ? dispatch(addToJobMultiple(jobId, profileId.map(candidate => candidate.id)))
    : dispatch(addToJob(jobId, profileId))),
  selectAllCandidates: candidates => dispatch(selectAllCandidates(candidates)),
});

export default
connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(withTranslate(AddToJobDialog)));

