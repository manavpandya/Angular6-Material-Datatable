import React, { Component } from 'react';
import ExpandIcon from 'material-ui-icons/Add';
import CollapseIcon from 'material-ui-icons/Remove';
import PropTypes from 'prop-types';

class ExpandField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };
    this.toggle = this.toggle.bind(this);
    this.onClick = this.onClick.bind(this);
  }
  onClick(e) {
    this.props.reset(e);
  }
  toggle() {
    this.setState({ open: !this.state.open });
  }


  render() {
    return (
      <section className="expand-field">
        <header>
          <label
            role="presentation"
            onClick={this.toggle}
            onKeyDown={() => {}}
            htmlFor="nothing"
          >
            {this.state.open ? <CollapseIcon /> : <ExpandIcon />}
            <h2>{this.props.label}</h2>
          </label>
        </header>
        <main style={{ display: this.state.open ? 'block' : 'none' }}>
          {this.props.children}
        </main>
      </section>
    );
  }
}

ExpandField.propTypes = {
  label: PropTypes.string.isRequired,
  children: PropTypes.element,
  reset: PropTypes.func,
};

ExpandField.defaultProps = {
  children: <div />,
  reset: () => {},
};

export default ExpandField;
