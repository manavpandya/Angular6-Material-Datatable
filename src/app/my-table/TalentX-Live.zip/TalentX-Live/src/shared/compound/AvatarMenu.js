import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import MenuIcon from 'material-ui-icons/Menu';
// import SearchIcon from 'material-ui-icons/Search';
// import AddIcon from 'material-ui-icons/Add';
// import Divider from 'material-ui/Divider';
import MuiAvatar from 'material-ui/Avatar';
import Menu from './Menu';
import ActionControl from '../../modules/auth/components/ActionControl';
import icon from '../../assets/images/man.svg';

const AvatarIcon = (
  <MuiAvatar
    className="avatar-icon"
  >{<img src={icon} alt="user icon" />}
  </MuiAvatar>
);

class AvatarMenu extends Component {
  render() {
    return (
      <Menu
        ref={(menu) => { this.menu = menu; }}
        label={AvatarIcon}
        iconPrefix={<MenuIcon className="avatar-menu-icon" />}
        menuStyle={{
            position: 'absolute',
            top: '0.25rem',
            paddingTop: '0.25rem',
            left: 0,
            zIndex: 2000,
        }}
        popup={
          <div className="fat-menu">
            <header>
              <div
                role="presentation"
                className="home-btn"
                onClick={() => this.menu.handleClose()}
                onKeyDown={() => {}}
              >
                <MenuIcon className="popup-menu-icon" />
                {AvatarIcon}
              </div>
              <div className="id">
                <h2>{this.props.accountInfo.username}</h2>
                <h3>{this.props.accountInfo.title}</h3>
              </div>
              <footer>
                {/* <Link to="/recruiter"
              className="avatar-menu-item">{this.props.translate('profile')}</Link> */}
                <Link
                  to="/logout"
                  className="avatar-menu-item"
                >{this.props.translate('logout')}
                </Link>
              </footer>
            </header>
            <main>
              <section>
                <h4>{this.props.translate('jobBoard')}</h4>
                <div>
                  <Link to="/recruiter" className="avatar-menu-item">{this.props.translate('allActiveJobs')}</Link>
                  {/* <Link to="recruiter" className="avatar-menu-item">Shell Jobs</Link>
                  <Link to="recruiter" className="avatar-menu-item">Worley Parsons Jobs</Link>
                  <Link to="recruiter" className="avatar-menu-item">Manager Jobs</Link>
                  <Link to="recruiter" className="avatar-menu-item">Engineer Jobs</Link> */}
                </div>
                {/* <footer>
                  <Divider />
                  <Link to="recruiter" className="avatar-menu-item">
                    <AddIcon className="footer-item-icon" />
                    New board
                  </Link>
                </footer> */}
              </section>
              <section>
                <h4>{this.props.translate('sourcing')}</h4>
                <div>
                  <Link to="/recruiter/candidates" className="avatar-menu-item">
                    {this.props.translate('allCandidates')}
                  </Link>
                  <Link
                    to="/recruiter/candidates/results/starred"
                    className="avatar-menu-item"
                  >
                    {this.props.translate('myBookmarks')}
                  </Link>
                  {/* <Link to="/recruiter/candidates/results/recent" className="avatar-menu-item">
                    Recently Registered
                  </Link>
                  <Link to="/recruiter/candidates/results/filtered" className="avatar-menu-item">
                    Prelude
                  </Link> */}
                </div>
                {/* <footer>
                  <Divider />
                  <Link to="recruiter" className="avatar-menu-item">
                    <SearchIcon className="footer-item-icon" />
                    Advanced Search
                  </Link>
                </footer> */}
              </section>
              {/* <section>
                <h4>Clients</h4>
                <div>
                  <Link to="/recruiter/client" className="avatar-menu-item">
                    <img src="/logos/shell.svg" alt="Shell" className="client-logo" />
                    Shell
                  </Link>
                  <Link to="/recruiter/client" className="avatar-menu-item">
                    <img src="/logos/shell.svg" alt="Chevron" className="client-logo" />
                    Chevron
                  </Link>
                </div>
              </section> */}
              <section>
                <h4>{this.props.translate('manage')}</h4>
                <div>
                  <Link to="/manage/customers" className="avatar-menu-item">{this.props.translate('client')}</Link>
                  <ActionControl actionName="team">
                    <Link to="/manage/users" className="avatar-menu-item">{this.props.translate('team')}</Link>
                  </ActionControl>
                  <ActionControl actionName="taxonomy">
                    <Link to="/manage/taxonomy" className="avatar-menu-item">{this.props.translate('taxonomy')}</Link>
                  </ActionControl>
                </div>
              </section>
            </main>
          </div>
        }
      />
    );
  }
}

AvatarMenu.propTypes = {
  translate: PropTypes.func,
  accountInfo: PropTypes.object, // eslint-disable-line
};

AvatarMenu.defaultProps = {
  translate: () => {},
  accountInfo: {},
};

export default withTranslate(AvatarMenu);
