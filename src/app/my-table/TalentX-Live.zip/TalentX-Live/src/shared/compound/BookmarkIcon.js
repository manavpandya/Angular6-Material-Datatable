import React from 'react';
import PropTypes from 'prop-types';
import IconButton from 'material-ui/IconButton';
import StarIcon from 'material-ui-icons/StarBorder';
import StarredIcon from 'material-ui-icons/Star';

const BookmarkIcon = props => (
  <IconButton onClick={() => props.handleBookmark(props.candidate)}>
    {
      props.candidate.is_bookmarked
      ?
        <StarredIcon className="starred-gold-icon" />
      :
        <StarIcon className="starred-icon-gray" />
    }
  </IconButton>
);

BookmarkIcon.propTypes = {
  handleBookmark: PropTypes.func,
  candidate: PropTypes.object, // eslint-disable-line
};

BookmarkIcon.defaultProps = {
  handleBookmark: () => {},
  candidate: {},
};

export default BookmarkIcon;
