import React, { Component, Fragment } from 'react';
import { PropTypes } from 'prop-types';
import _ from 'lodash';
import Case from 'case';
import LinkButton from '../basic/LinkButton';

const renderHighlights = (highlights, requiredSkills) => highlights && highlights.map(item =>
  (
    <li className={`item ${requiredSkills === 'partial' ? 'orange-tick' : requiredSkills === true && 'green-tick'}`} key={item}>
      {Case.title(item)}
    </li>
  ));
class SmartList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showMore: false,
      showMoreHighlights: false,
      showMoreGroups: false,
    };
    this.showMore = this.showMore.bind(this);
    this.showMoreHighlights = this.showMoreHighlights.bind(this);
    this.showMoreGroups = this.showMoreGroups.bind(this);
  }

  showMore() {
    this.setState({ showMore: !this.state.showMore });
  }
  showMoreHighlights() {
    this.setState({ showMoreHighlights: !this.state.showMoreHighlights });
  }
  showMoreGroups() {
    this.setState({ showMoreGroups: !this.state.showMoreGroups });
  }

  render() {
    let { highlight } = this.props;
    highlight = highlight.filter((skill, index, self) =>
      self.findIndex(t =>
        t.toLowerCase() === skill.toLowerCase()) === index);
    const requireSkills = this.props.requiredSkills || '';
    return (
      <Fragment>
        {
          <ul className="smart-list highlights">
            {this.state.showMoreHighlights ? renderHighlights(highlight, requireSkills) :
              _.slice(renderHighlights(highlight, requireSkills), 0, 20)}
            {
              (highlight.length > 20) ?
                <li className="item">
                  <strong>
                    <LinkButton onClick={this.showMoreHighlights}>
                      {this.state.showMoreHighlights ? '- Show less' : highlight.length > 5 &&
                      `+${(highlight.length - 20)} more` }
                    </LinkButton>
                  </strong>
                </li> :
                <li />
            }
          </ul>
        }
      </Fragment>
    );
  }
}

SmartList.propTypes = {
  requiredSkills: PropTypes.string.isRequired,
  highlight: PropTypes.instanceOf(Array).isRequired,
};


export default SmartList;
