import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';

import BoardMenu from './BoardMenu';
import {
  getDraftedJobs,
  getPostedJobs,
  getQualifiedJobs,
  getPresentedJobs,
  getClosedJobs,
  getEmployersCount,
  setSearchedEmployer,
  getLocationsCount,
  setSearchedLocation,
} from '../../../../modules/jobs/redux/actions';

class BoardMenuContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      employers: [],
      locations: [],
      selectedMenuItem: props.translate('allJobOpenings'),
      selectedLocation: props.translate('allJobLocations'),
    };
    this.selectEmployer = this.selectEmployer.bind(this);
    this.selectLocation = this.selectLocation.bind(this);
  }

  componentDidMount() {
    this.props.getEmployersCount();
    this.props.getLocationsCount();
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.searchedEmployer !== nextProps.searchedEmployer
      || this.props.searchedLocation !== nextProps.searchedLocation) {
      this.props.getDraftedJobs(
        1,
        nextProps.draftJobsSortedBy,
        nextProps.searchedEmployer,
        this.props.searchedJobTitle,
        10,
        nextProps.searchedLocation,
      );
      this.props.getPostedJobs(
        1,
        nextProps.postedJobsSortedBy,
        nextProps.searchedEmployer,
        this.props.searchedJobTitle,
        10,
        nextProps.searchedLocation,
      );
      this.props.getQualifiedJobs(
        1,
        nextProps.qualifiedJobsSortedBy,
        nextProps.searchedEmployer,
        this.props.searchedJobTitle,
        10,
        nextProps.searchedLocation,
      );
      this.props.getPresentedJobs(
        1,
        nextProps.presentedJobsSortedBy,
        nextProps.searchedEmployer,
        this.props.searchedJobTitle,
        10,
        nextProps.searchedLocation,
      );
      this.props.getClosedJobs(
        1,
        nextProps.closedJobsSortedBy,
        nextProps.searchedEmployer,
        this.props.searchedJobTitle,
        10,
        nextProps.searchedLocation,
      );
    }
    this.setState({
      selectedMenuItem: nextProps.searchedEmployer === '' ? this.props.translate('allJobOpenings') : nextProps.searchedEmployer,
      selectedLocation: nextProps.searchedLocation === '' ? this.props.translate('allJobLocations') : nextProps.searchedLocation,
    });
    if (this.props.employers !== nextProps.employers) {
      this.setState({
        employers: [{ key: this.props.translate('allJobOpenings') }, ...nextProps.employers],
      });
    }
    if (this.props.locations !== nextProps.locations) {
      this.setState({
        locations: [{ key: this.props.translate('allJobLocations') }, ...nextProps.locations],
      });
    }
  }

  selectEmployer(employer) {
    this.props.setSearchedEmployer(employer === this.props.translate('allJobOpenings') ? '' : employer);
  }

  selectLocation(location) {
    this.props.setSearchedLocation(location === this.props.translate('allJobLocations') ? '' : location);
  }

  render() {
    return (
      <BoardMenu
        employers={this.state.employers}
        locations={this.state.locations}
        loading={this.props.employersLoading || this.props.locationsLoading}
        selectEmployer={this.selectEmployer}
        selectLocation={this.selectLocation}
        selectedMenuItemText={this.state.selectedMenuItem}
        selectedLocationText={this.state.selectedLocation}
      />
    );
  }
}

BoardMenuContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  getDraftedJobs: PropTypes.func,
  getPostedJobs: PropTypes.func,
  getQualifiedJobs: PropTypes.func,
  getPresentedJobs: PropTypes.func,
  getClosedJobs: PropTypes.func,
  getEmployersCount: PropTypes.func,
  setSearchedEmployer: PropTypes.func,
  employers: PropTypes.arrayOf(PropTypes.object),
  employersLoading: PropTypes.bool,
  searchedEmployer: PropTypes.string,
  getLocationsCount: PropTypes.func,
  setSearchedLocation: PropTypes.func,
  locations: PropTypes.arrayOf(PropTypes.object),
  locationsLoading: PropTypes.bool,
  searchedLocation: PropTypes.string,
  searchedJobTitle: PropTypes.string,
  draftJobsSortedBy: PropTypes.string,
  postedJobsSortedBy: PropTypes.string,
  qualifiedJobsSortedBy: PropTypes.string,
  presentedJobsSortedBy: PropTypes.string,
  closedJobsSortedBy: PropTypes.string,
};

BoardMenuContainer.defaultProps = {
  getDraftedJobs: () => { },
  getPostedJobs: () => { },
  getQualifiedJobs: () => { },
  getPresentedJobs: () => { },
  getClosedJobs: () => { },
  getEmployersCount: () => { },
  setSearchedEmployer: () => { },
  employers: [],
  employersLoading: false,
  searchedEmployer: '',
  getLocationsCount: () => { },
  setSearchedLocation: () => { },
  locations: [],
  locationsLoading: false,
  searchedLocation: '',
  searchedJobTitle: '',
  draftJobsSortedBy: 'none',
  postedJobsSortedBy: 'none',
  qualifiedJobsSortedBy: 'none',
  presentedJobsSortedBy: 'none',
  closedJobsSortedBy: 'none',
};

const mapStateToProps = state => ({
  employers: state.recruiter.employers,
  employersLoading: state.recruiter.employersLoading,
  searchedEmployer: state.recruiter.searchedEmployer,
  locations: state.recruiter.locations,
  locationsLoading: state.recruiter.locationsLoading,
  searchedLocation: state.recruiter.searchedLocation,
  searchedJobTitle: state.recruiter.searchedJobTitle,
  draftJobsSortedBy: state.recruiter.draftJobsSortedBy,
  postedJobsSortedBy: state.recruiter.postedJobsSortedBy,
  qualifiedJobsSortedBy: state.recruiter.qualifiedJobsSortedBy,
  presentedJobsSortedBy: state.recruiter.presentedJobsSortedBy,
  closedJobsSortedBy: state.recruiter.closedJobsSortedBy,
});

const mapDispatchToProps = dispatch => ({
  getDraftedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getDraftedJobs(pageNo, sortBy, employer, key, perPage, location)),
  getPostedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getPostedJobs(pageNo, sortBy, employer, key, perPage, location)),
  getQualifiedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getQualifiedJobs(pageNo, sortBy, employer, key, perPage, location)),
  getPresentedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getPresentedJobs(pageNo, sortBy, employer, key, perPage, location)),
  getClosedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getClosedJobs(pageNo, sortBy, employer, key, perPage, location)),
  getEmployersCount: () => dispatch(getEmployersCount()),
  setSearchedEmployer: text => dispatch(setSearchedEmployer(text)),
  getLocationsCount: () => dispatch(getLocationsCount()),
  setSearchedLocation: text => dispatch(setSearchedLocation(text)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(BoardMenuContainer));
