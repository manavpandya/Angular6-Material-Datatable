import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import Table, { TableBody, TableCell, TableHead, TableRow, TableFooter, TablePagination } from 'material-ui/Table';
import Button from 'material-ui/Button';
// import { Link } from 'react-router-dom';
import Checkbox from 'material-ui/Checkbox';
import PropTypes from 'prop-types';
import DownloadIcon from 'material-ui-icons/FileDownload';
import { withStyles } from 'material-ui/styles';
import Tooltip from 'material-ui/Tooltip';
import Call from 'material-ui-icons/Call';
import Email from 'material-ui-icons/Email';
// import AdvancedSearchPanel from '../../../../shared/compound/AdvancedSearchPanel';
import Distribution from '../../../modules/candidates/components/Distribution';
import CandidateProfile from '../CandidateProfile';
import MessageFormDialog from '../MessageFormDialog';
import CandidateActions from '../../../modules/candidates/components/CandidateActions';
import JobCandidateActions from '../../../modules/jobs/components/CandidateActions';
import LoaderOnDownload from '../../basic/LoaderForSearch';
import AddToJobDialog from '../AddToJobDialog';
import BookmarkIcon from '../BookmarkIcon';
import TablePaginationActions from '../TablePaginationActions';

const styles = theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
    overflowX: 'auto',
  },
  table: {
    minWidth: 700,
    borderCollapse: 'initial',
    fontFamily: 'Nunito',
  },
});

const initialValues = {};

class CandidateList extends React.Component { // eslint-disable-line
  render() {
    initialValues.page = this.props.recruiterJobPage
      ? this.props.currentPageNo : this.props.page;
    return (
      <div className="list">
        {
        this.props.recruiterJobPage ?
          <div />
        :
          <div>
            {
              this.props.showBookmarkedCandidates
              ?
                this.props.title &&
                <h1>{this.props.title}</h1>
              :
                this.props.title &&
                <h1>{this.props.title}&nbsp;&nbsp;<Distribution /></h1>
            }
          </div>
      }
        { this.props.filters }
        <div className="display-flex">
          <div className="manage-table">
            <Table className={this.props.classes.table}>
              <TableHead className="table-header">
                <TableRow>
                  <TableCell padding="checkbox" className="checkbox-cell">
                    <Checkbox
                      indeterminate={
                        this.props.selectedCandidates.length > 0 &&
                        this.props.selectedCandidates.length < this.props.candidates.length
                      }
                      checked={
                        this.props.selectedCandidates.length > 0 &&
                        this.props.selectedCandidates.length === this.props.candidates.length
                      }
                      onChange={
                        (evt, checked) =>
                          this.props.selectAllCandidates(evt, checked, this.props.candidates)
                      }
                    />
                  </TableCell>
                  <TableCell className="bookmark-width">
                    {this.props.translate('candidateBookmark')}
                  </TableCell>
                  <TableCell className="fixed-width">{this.props.translate('candidateName')}</TableCell>
                  <TableCell className="fixed-width">{this.props.translate('candidateTitle')}</TableCell>
                  <TableCell className="fixed-width">{this.props.translate('candidateCompany')}</TableCell>
                  <TableCell>{this.props.translate('candidateLocation')}</TableCell>
                  {/* {
                    this.props.recruiterJobPage &&
                    this.props.currentTabKey === 'shortlist' &&
                    <Fragment>
                      <TableCell>Match %</TableCell>
                    </Fragment>
                  } */}
                  <TableCell>{this.props.translate('candidateContact')}</TableCell>
                  <TableCell>{this.props.translate('candidateDownload')}</TableCell>
                  <TableCell />
                  { this.props.matchpercent && <TableCell className="table-cell" /> }
                  <TableCell />
                </TableRow>
              </TableHead>
              <TableBody>
                {
                  this.props.candidates
                    .map(candidate => (
                      <TableRow
                        key={candidate.id}
                        hover
                        role="checkbox"
                        tabIndex={-1}
                        aria-checked={
                          Boolean(this.props.selectedCandidates
                            .find(candidatex => candidatex.id === candidate.id))
                        }
                        selected={
                          Boolean(this.props.selectedCandidates
                            .find(candidatex => candidatex.id === candidate.id))
                        }
                      >
                        <TableCell padding="checkbox" className="checkbox-cell">
                          <Checkbox
                            checked={
                              Boolean(this.props.selectedCandidates
                                .find(candidatex => candidatex.id === candidate.id))
                            }
                            onClick={evt => this.props.selectCandidate(evt, candidate)}
                          />
                        </TableCell>
                        <TableCell padding="none" className="star-cell">
                          <div className="done-star">
                            <BookmarkIcon
                              handleBookmark={this.props.handleBookmark}
                              candidate={candidate}
                            />
                            {/* <IconButton onClick={() => this.props.handleBookmark(candidate)}>
                              {
                                candidate.is_bookmarked
                                ?
                                  <StarredIcon className="starred-gold-icon" />
                                :
                                  <StarIcon className="starred-icon-gray" />
                              }
                            </IconButton> */}
                          </div>
                        </TableCell>
                        <TableCell>
                          <CandidateProfile
                            jobId={this.props.job.id}
                            candidate={candidate}
                            openAddToJobDialog={this.props.openAddToJobDialog}
                          />
                        </TableCell>
                        <TableCell>{candidate.job_title || '-'}</TableCell>
                        <TableCell>{candidate.company || '-'}</TableCell>
                        <TableCell>{candidate.location || '-'}</TableCell>
                        {/* {
                          this.props.recruiterJobPage &&
                          this.props.currentTabKey === 'shortlist' &&
                          <TableCell>{`${`${candidate.match_percentage}%` || '-'}`}</TableCell>
                        } */}
                        <TableCell>
                          <div className="contact-info">
                            {/* <Message
                              className={`chat contact-icon pointer
                                ${this.props.job.status === 'closed' ? 'disabled' : ''}`}
                              onClick={() =>
                                this.props.handlerShowMessageDialog('message',
                                'dummyUserId', 'dummyUser2Id', true)}
                            /> */}
                            {
                              candidate.contact_methods
                              &&
                              (candidate.contact_methods.mobile
                              || candidate.contact_methods.other_phone_no)
                              && (candidate.contact_methods.mobile.length > 0
                              || candidate.contact_methods.other_phone_no.length > 0)
                              && this.props.job.status !== 'closed'
                                ?
                                (
                                  <Tooltip
                                    id="tooltip-phone"
                                    className="multiline-tooltip"
                                    title={candidate.contact_methods.mobile.join('\n') || candidate.contact_methods.other_phone_no.join('\n')}
                                  >
                                    {/* <a href={`call:${candidate.phone}`}> */}
                                    <Call className="phone contact-icon" />
                                    {/* </a> */}
                                  </Tooltip>
                                )
                                :
                                (
                                  <Call className="phone contact-icon disabled" />
                                )
                            }
                            {
                              candidate.contact_methods
                              && (candidate.contact_methods.email
                                || candidate.contact_methods.work_email)
                              && (candidate.contact_methods.email.length > 0
                              || candidate.contact_methods.work_email > 0)
                              && this.props.job.status !== 'closed'
                              ?
                              (
                                <Tooltip
                                  id="tooltip-email"
                                  className="multiline-tooltip"
                                  title={candidate.contact_methods.email.join('\n') || candidate.contact_methods.work_email.join('\n')}
                                >
                                  <Email
                                    // onClick={() => this.props.handlerShowMessageDialog('email',
                                    // 'dummy@email.com', 'test@mail.com', true)}
                                    className="email contact-icon pointer"
                                  />
                                </Tooltip>
                              )
                              :
                              (
                                <Email className="email contact-icon disabled" />
                              )
                            }
                            {
                              candidate.contact_methods
                              && candidate.contact_methods.social_network_links
                              && candidate.contact_methods.social_network_links.length > 0
                              && this.props.job.status !== 'closed'
                                ?
                                (
                                  <Tooltip
                                    id="tooltip-linkedin"
                                    className="multiline-tooltip"
                                    title={candidate.contact_methods.social_network_links.join('\n')}
                                  >
                                    {/* <Link
                                      target="_blank"
                                      to={candidate.linkedIn}
                                    > */}
                                    <img
                                      src="/icons8-linkedin.svg"
                                      alt="linkedin"
                                      className="linkedin contact-icon"
                                    />
                                    {/* </Link> */}
                                  </Tooltip>
                                )
                                :
                                (
                                  <img
                                    src="/icons8-linkedin.svg"
                                    alt="linkedin"
                                    className="linkedin contact-icon disabled-image"
                                  />
                                )
                            }
                          </div>
                        </TableCell>
                        <TableCell>
                          {
                            this.props.isResumeLoading && this.props.hasLoading === candidate.id
                              ?
                                <LoaderOnDownload
                                  className="multiline-tooltip download-info"
                                  forDownload
                                />
                            :
                                <Tooltip
                                  id="tooltip-linkedin"
                                  className="multiline-tooltip download-info"
                                  title="Download Profile"
                                >
                                  <DownloadIcon
                                    onClick={() => this.props.downloadResume(candidate.id)}
                                    className="pointer download-icon"
                                  />
                                </Tooltip>
                          }
                        </TableCell>

                        {
                          this.props.matchpercent && this.props.matchpercent[0] ?
                            <TableCell>
                              <span title={`${this.props.matchpercent[0]} % matched`}>{this.props.matchpercent[0]}%</span>
                            </TableCell>
                          :
                            <TableCell />
                        }
                        <TableCell>
                          {
                            this.props.recruiterJobPage ?
                              <JobCandidateActions
                                menuItems={this.props.getMenuItems(
                                  this.props.tabs,
                                  this.props.currentTabKey,
                                  this.props.currentSubTabKeys,
                                )}
                                candidate={candidate}
                                isDisabled={this.props.job.status === 'closed'}
                              />
                            :
                              <CandidateActions
                                candidates={candidate}
                                openAddToJobDialog={this.props.openAddToJobDialog}
                              />
                          }
                        </TableCell>
                        <TableCell />
                      </TableRow>
                    ))
                }
                {
                  !(this.props.candidatesLoading || this.props.loadingProfiles) &&
                  this.props.candidates.length === 0 &&
                  <TableRow>
                    <TableCell className="no-data-cell" colSpan="11">
                      <div className="no-data">{this.props.translate('dataNotAvailable')}</div>
                    </TableCell>
                  </TableRow>
                }
                {
                  (this.props.recruiterJobPage && this.props.totalMatchedCandidates > 100)
                  && (this.props.currentPageNo === 0 && this.props.currentTabKey === 'shortlist') &&
                  !this.props.candidatesLoading &&
                  (
                  <TableRow>
                    <TableCell colSpan="11">
                      <div className="load-more-btn-div">
                        <Button
                          color="black"
                          onClick={() => {
                            this.props.handleChangePage('gotoSecond', 2);
                          }}
                        >
                          Show more matches
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                  )
                }
              </TableBody>
              {
                !this.props.recruiterJobPage || this.props.currentPageNo > 0 ?
                (
                  <TableFooter>
                    <TableRow>
                      <TablePagination
                        labelRowsPerPage={this.props.translate('rowsPerPage')}
                        colSpan={6}
                        className="pagination footer-sticky-"
                        rowsPerPageOptions={this.props.recruiterJobPage ? [] : [25, 50, 100]}
                        count={this.props.recruiterJobPage ?
                          this.props.totalMatchedCandidates : Number(this.props.totalCandidates)}
                        rowsPerPage={
                          this.props.recruiterJobPage ?
                            this.props.currentPageSize
                            :
                            this.props.resultsPerPage
                        }
                        page={
                          this.props.recruiterJobPage ?
                            this.props.currentPageNo
                            :
                            this.props.page
                        }
                        backIconButtonProps={{
                          'aria-label': 'Previous Page',
                        }}
                        nextIconButtonProps={{
                          'aria-label': 'Next Page',
                        }}
                        onChangePage={
                          this.props.recruiterJobPage ?
                          (event, page) => this.props.handleChangePage(event, page)
                          :
                          (event, page) => this.props.handlePagination(event, page)
                        }
                        onChangeRowsPerPage={this.props.handleChangeRowsPerPage}
                        Actions={TablePaginationActions}
                      />
                    </TableRow>
                  </TableFooter>
                )
                : null
              }
            </Table>
          </div>
          <MessageFormDialog
            initialValues={this.props.chatType}
            chatType={this.props.chatType}
            handleSubmitMessage={this.props.handleSubmitMessage}
            showMessageDialog={this.props.showMessageDialog}
            handlerShowMessageDialog={this.props.handlerShowMessageDialog}
          />
          <AddToJobDialog
            addtoJobCandidates={this.props.addtoJobCandidates}
            isAddToJobDialogOpen={this.props.isAddToJobDialogOpen}
            closeAddToJobDialog={this.props.closeAddToJobDialog}
          />
        </div>
      </div>
    );
  }
}

CandidateList.propTypes = {
  translate: PropTypes.func.isRequired,
  chatType: PropTypes.object,  // eslint-disable-line
  title: PropTypes.string,
  filters: PropTypes.element,
  candidates: PropTypes.array, // eslint-disable-line
  totalCandidates: PropTypes.number,
  totalMatchedCandidates: PropTypes.number,
  candidatesLoading: PropTypes.bool,
  selectAllCandidates: PropTypes.func,
  currentPageNo: PropTypes.number,
  currentPageSize: PropTypes.number,
  handleChangePage: PropTypes.func,
  handleChangeRowsPerPage: PropTypes.func,
  selectedCandidates: PropTypes.array, // eslint-disable-line
  showMessageDialog: PropTypes.bool,
  handlerShowMessageDialog: PropTypes.func,
  handleSubmitMessage: PropTypes.func,
  job: PropTypes.object, // eslint-disable-line
  classes: PropTypes.object.isRequired, // eslint-disable-line
  candidateLoading: PropTypes.bool, // eslint-disable-line
  isResumeLoading: PropTypes.bool.isRequired,
  matchpercent: PropTypes.array, // eslint-disable-line
  showBookmarkedCandidates: PropTypes.bool,
  recruiterJobPage: PropTypes.bool,
  handlePagination: PropTypes.func,
  resultsPerPage: PropTypes.number.isRequired,
  page: PropTypes.number,
  addtoJobCandidates: PropTypes.object, // eslint-disable-line
  isAddToJobDialogOpen: PropTypes.bool,
  openAddToJobDialog: PropTypes.func,
  closeAddToJobDialog: PropTypes.func,
  hasLoading: PropTypes.string,
  handleBookmark: PropTypes.func,
  downloadResume: PropTypes.func,
  selectCandidate: PropTypes.func,
  getMenuItems: PropTypes.func,
  tabs: PropTypes.arrayOf(PropTypes.object),
  currentTabKey: PropTypes.string,
  currentSubTabKeys: PropTypes.arrayOf(PropTypes.string),
  loadingProfiles: PropTypes.bool,
};

CandidateList.defaultProps = {
  title: '',
  filters: <div />,
  candidates: [],
  totalCandidates: 0,
  totalMatchedCandidates: 0,
  candidatesLoading: false,
  selectAllCandidates: () => { },
  currentPageNo: 0,
  currentPageSize: 100,
  handleChangePage: () => {},
  handleChangeRowsPerPage: () => {},
  selectedCandidates: [],
  showMessageDialog: false,
  handlerShowMessageDialog: () => {},
  handleSubmitMessage: () => {},
  chatType: {},
  job: {},
  matchpercent: [],
  showBookmarkedCandidates: false,
  recruiterJobPage: false,
  handlePagination: () => {},
  addtoJobCandidates: {},
  isAddToJobDialogOpen: false,
  openAddToJobDialog: () => {},
  closeAddToJobDialog: () => {},
  hasLoading: '',
  handleBookmark: () => {},
  downloadResume: () => {},
  selectCandidate: () => {},
  getMenuItems: () => {},
  tabs: [],
  currentTabKey: '',
  currentSubTabKeys: [],
  loadingProfiles: false,
  page: 0,
};

export default withStyles(styles)(withTranslate(CandidateList));
