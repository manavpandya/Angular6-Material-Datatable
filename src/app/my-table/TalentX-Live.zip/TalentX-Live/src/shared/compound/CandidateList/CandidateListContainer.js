import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { change } from 'redux-form';
import ReduxBlockUI from 'react-block-ui';
import CandidateList from './CandidateList';
import { getMatchedCandidates, getJobApplicationList } from '../../../modules/jobs/redux/actions';
import { getBookmarkedCandidates, fetchProfile, setFilter, bookmarkCandidate, removeBookmarkCandidate, flushAllCandidates, resetFilterParams, getTempToken, selectAllCandidates, selectCandidate, deselectCandidate } from '../../../modules/candidates/redux/actions';
import { showNotification } from '../../../utils/Notifications';
import BASE_URL from '../../../constants';

class CandidateListContainer extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      resultsPerPage: 100,
      bookmarksPerPage: 100,
      // open: false,
      page: 0,
      selected: [],
      addtoJobCandidates: {},
      isAddToJobDialogOpen: false,
      hasLoading: '',
    };

    this.setPaginationHelper = this.setPaginationHelper.bind(this);
    this.handleChangePage = this.handleChangePage.bind(this);
    this.handlePagination = this.handlePagination.bind(this);
    this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this);
    this.selectAllCandidates = this.selectAllCandidates.bind(this);
    this.selectCandidate = this.selectCandidate.bind(this);
    this.bookmarkCandidate = this.bookmarkCandidate.bind(this);
    this.removeBookmark = this.removeBookmark.bind(this);
    // this.openMenu = this.openMenu.bind(this);
    this.handleSelectAllClick = this.handleSelectAllClick.bind(this);
    this.openAddToJobDialog = this.openAddToJobDialog.bind(this);
    this.closeAddToJobDialog = this.closeAddToJobDialog.bind(this);
    this.downloadResume = this.downloadResume.bind(this);
    this.handleBookmark = this.handleBookmark.bind(this);
    this.getCurrentPage = this.getCurrentPage.bind(this);
  }

  componentDidMount() {
    if (this.props.showBookmarkedCandidates) {
      this.props.getBookmarkedCandidates();
    } else if (!this.props.recruiterJobPage) {
      this.props.fetchProfile({
        search: '',
        per_page: this.state.resultsPerPage,
        page: 1,
      });
    } else if (this.props.currentSubTabKey === 'shortlist-matched') {
      this.handleChangePage('gotoFirst', 0, true);
      this.props.dispatch(change('gotoForm', 'pageName', 1));
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.isPageSetToZero !== nextProps.isPageSetToZero ||
       this.props.isRecentSearched !== nextProps.isRecentSearched) {
      this.getCurrentPage(nextProps);
    }
    if (this.props.clearFilters !== nextProps.clearFilters) {
      this.props.dispatch(change('gotoForm', 'pageName', 1));
    }
    if (this.props.filterParamMatched !== nextProps.filterParamMatched) {
      this.props.dispatch(change('gotoForm', 'pageName', 1));
      this.handleChangePage('gotoFirst', 0, true);
    }
  }
  componentWillUnmount() {
    this.props.resetFilterParams();
    this.props.flushAllCandidates();
    this.props.selectAllCandidates([]);
  }

  setPaginationHelper(state, isReset) {
    this.props.setPagination(state, () => {
      if (this.props.currentSubTabKey === 'shortlist-matched') {
        if (!isReset) {
          setTimeout(() =>
            this.props.getMatchedCandidates(
              this.props.job.id,
              this.props.pagination[this.props.currentTabKey][this.props.currentSubTabKey]
                .pageNo + 1,
              this.props.pagination[this.props.currentTabKey][this.props.currentSubTabKey]
                .pageSize,
              this.props.filterParamMatched,
            ), 1);
        }
      } else {
        setTimeout(() =>
          this.props.getJobApplicationList(
            this.props.job.id,
            // camelize(this.props.currentSubTabKey),
            this.props.tabs.find(tab => tab.originalKey === this.props.currentTabKey)
              .steps.find(step => step.originalKey === this.props.currentSubTabKey).key,
            this.props.pagination[this.props.currentTabKey][this.props.currentSubTabKey].pageNo + 1,
            this.props.pagination[this.props.currentTabKey][this.props.currentSubTabKey].pageSize,
          ), 1);
      }
    });
  }

  getCurrentPage(props) {
    if (props.isPageSetToZero === true ||
      props.isRecentSearched === true || this.state.page < 0) {
      this.setState({
        page: 0,
      });
    }
  }

  // openMenu(checked) {
  //   this.setState({
  //     open: checked,
  //   });
  // }

  handleChangePage(event, nextPageNo, isReset) {
    if (event === 'gotoFirst') {
      this.setPaginationHelper({
        pageNo: {
          $set: 0,
        },
      }, isReset);
    } else if (event === 'gotoSecond') {
      this.setState({
        page: 2,
      });
      this.setPaginationHelper({
        pageNo: {
          $set: nextPageNo - 1,
        },
      });
      setTimeout(() => this.props.dispatch(change('gotoForm', 'pageName', 2)), 500);
    } else if (event === 'goto') {
      this.setPaginationHelper({
        pageNo: {
          $set: nextPageNo - 1,
        },
      });
    } else {
      this.setPaginationHelper({
        pageNo: {
          $set: nextPageNo,
        },
      });
    }
    if (!event) return false;
    return true;
  }

  handleChangeRowsPerPage(event) {
    if (this.props.recruiterJobPage === false && this.props.showBookmarkedCandidates === false) {
      this.setState({ resultsPerPage: event.target.value, page: 0 }, () => {
        this.props.fetchProfile({
          search: this.props.searchedValue,
          per_page: this.state.resultsPerPage,
          page: 1,
          filterParam: this.props.filterParam,
        });
        // this.props.fetchFacet();
      });
    } else if (this.props.showBookmarkedCandidates) {
      this.setState({ resultsPerPage: event.target.value }, () => {
        this.props.getBookmarkedCandidates({ page: 1, perPage: this.state.resultsPerPage });
      });
    } else {
      this.setPaginationHelper({
        pageSize: {
          $set: event.target.value,
        },
        pageNo: {
          $set: 0,
        },
      });
    }
  }

  handlePagination(event, page) {
    if (event) {
      if (event === 'gotoFirst') {
        this.setState({
          page: 0,
        });
        // hit api for gotoFirst
        const query = {
          search: this.props.searchedValue,
          page: 1,
          per_page: this.state.resultsPerPage,
          filterParam: this.props.filterParam,
        };
        const bookmarksQuery = {
          page: 1,
          perPage: this.state.resultsPerPage,
        };
        if (this.props.showBookmarkedCandidates) {
          this.props.getBookmarkedCandidates(bookmarksQuery);
        } else {
          this.props.fetchProfile(query)
            .then(res => (res.data))
            .catch((err) => {
              showNotification(err.message, 'error', 8000);
            });
        }
      } else if (event === 'goto') { // hit api for goto any page
        this.setState({
          page: page - 1,
        });
        const query = {
          search: this.props.searchedValue,
          page,
          per_page: this.state.resultsPerPage,
          filterParam: this.props.filterParam,
        };
        const bookmarksQuery = {
          page,
          perPage: this.state.resultsPerPage,
        };
        if (this.props.showBookmarkedCandidates) {
          this.props.getBookmarkedCandidates(bookmarksQuery);
        } else {
          this.props.fetchProfile(query)
            .then()
            .catch((err) => {
              showNotification(err.message, 'error', 8000);
            });
        }
      } else if (page > this.state.page) { // hit api for next page data
        this.setState({
          page,
        });
        const query = {
          search: this.props.searchedValue,
          page: page + 1,
          per_page: this.state.resultsPerPage,
          filterParam: this.props.filterParam,
        };
        const bookmarksQuery = {
          page: page + 1,
          perPage: this.state.resultsPerPage,
        };
        if (this.props.showBookmarkedCandidates) {
          this.props.getBookmarkedCandidates(bookmarksQuery);
        } else {
          this.props.fetchProfile(query)
            .catch((err) => {
              showNotification(err.message, 'error', 8000);
            });
        }
      } else {
        this.setState({
          page: page <= 0 ? 0 : page,
        });
        // hit api for previous page data
        const query = {
          search: this.props.searchedValue,
          page: page < 0 ? 0 : page + 1,
          per_page: this.state.resultsPerPage,
          filterParam: this.props.filterParam,
        };
        const bookmarksQuery = {
          page: this.state.page < 0 ? 0 : page,
          perPage: this.state.resultsPerPage,
        };
        if (this.props.showBookmarkedCandidates) {
          this.props.getBookmarkedCandidates(bookmarksQuery);
        } else if (this.state.page !== page) {
          this.props.fetchProfile(query)
            .catch((err) => {
              showNotification(err.message, 'error', 8000);
            });
        }
      }
    } else {
      return false;
    }
    return true;
  }

  selectAllCandidates(event, checked, candidates) {
    if (checked) {
      this.props.selectAllCandidates(candidates);
    } else {
      this.props.selectAllCandidates([]);
    }
  }

  selectCandidate(event, candidate) {
    if (!this.props.selectedCandidates.find(candidatex => candidatex.id === candidate.id)) {
      this.props.selectCandidate(candidate);
    } else {
      this.props.deselectCandidate(candidate.id);
    }
  }

  bookmarkCandidate(params) {
    setTimeout(() =>
      this.props.bookmarkCandidate(params, this.props.recruiterJobPage ? 'RecruiterJob' : 'CandidateProfiles').then(() => {
        showNotification(this.props.translate('candidateBookmarked'), 'success', 8000);
      }), 1);
  }

  removeBookmark(id) {
    setTimeout(() =>
      this.props.removeBookmarkCandidate(id, this.props.recruiterJobPage ? 'RecruiterJob' : 'CandidateProfiles').then(() => {
        showNotification(this.props.translate('removedBookmark'), 'success', 8000);
        if (this.props.showBookmarkedCandidates) {
          this.props.getBookmarkedCandidates({
            page: this.state.page + 1,
            perPage: this.state.bookmarksPerPage,
          });
        }
      }), 1);
  }

  handleSelectAllClick(event, checked) {
    if (checked) {
      this.setState({ selected: this.props.candidates.map(n => n.id) });
      this.openMenu(checked);
      return;
    }
    this.openMenu(false);
    this.setState({ selected: [] });
  }

  isSelected(id) {
    return this.state.selected.indexOf(id) !== -1;
  }

  handleClick(event, id) {
    let { selected } = this.state;
    if (!selected.includes(id)) {
      selected.push(id);
      if (selected.length > 1) {
        this.openMenu(true);
      }
    } else {
      if (selected.length === 2) {
        this.openMenu(false);
      }
      selected = selected.filter(item => item !== id);
    }
    this.setState({ selected });
  }

  openAddToJobDialog(candidateInfo) {
    this.setState({ addtoJobCandidates: candidateInfo, isAddToJobDialogOpen: true });
  }

  closeAddToJobDialog() {
    this.setState({ isAddToJobDialogOpen: false });
  }

  downloadResume(id) {
    this.setState({ hasLoading: id });
    this.props.getTempToken(id).then(() => {
      window.open(`${BASE_URL}profile/${id}/download?token=${this.props.tempToken}`);
    }).catch((err) => {
      showNotification(err, 'error', 8000);
      this.setState({ hasLoading: '' });
    });
  }

  handleBookmark(candidate) {
    if (candidate.is_bookmarked === true) {
      this.removeBookmark(candidate.id);
    } else {
      this.bookmarkCandidate(candidate.id);
    }
  }

  render() {
    return (
      <ReduxBlockUI
        tag="div"
        blocking={
          this.props.candidatesLoading ||
          this.props.candidatesProfilesLoading ||
          this.props.loadingProfiles ||
          this.props.moveJobApplicationLoading ||
          this.props.shortlistJobApplicationLoading ||
          this.props.profilesBookmarking ||
          this.props.recruiterBookmarking ||
          this.props.addToJobLoading ||
          this.props.facetsLoading
        }
        className="list"
        renderChildren
      >
        <CandidateList
          chatType={this.props.chatType}
          handleSubmitMessage={this.props.handleSubmitMessage}
          showMessageDialog={this.props.showMessageDialog}
          handlerShowMessageDialog={this.props.handlerShowMessageDialog}
          filters={this.props.filters}
          candidates={this.props.candidates}
          totalCandidates={this.props.totalCandidates}
          totalMatchedCandidates={this.props.totalMatchedCandidates}
          candidatesLoading={this.props.candidatesLoading}
          selectAllCandidates={this.selectAllCandidates}
          selectCandidate={this.selectCandidate}
          selectedCandidates={this.props.selectedCandidates}
          page={this.state.page}
          handleChangePage={this.handleChangePage}
          handleChangeRowsPerPage={this.handleChangeRowsPerPage}
          currentPageNo={
            this.props.currentTabKey &&
              this.props.currentSubTabKey &&
              this.props.pagination[this.props.currentTabKey] &&
              this.props.pagination[this.props.currentTabKey][this.props.currentSubTabKey]
            ? this.props.pagination[this.props.currentTabKey][this.props.currentSubTabKey].pageNo
            : 0
          }
          currentPageSize={
            this.props.currentTabKey &&
              this.props.currentSubTabKey &&
              this.props.pagination[this.props.currentTabKey] &&
              this.props.pagination[this.props.currentTabKey][this.props.currentSubTabKey]
            ? this.props.pagination[this.props.currentTabKey][this.props.currentSubTabKey].pageSize
            : 100
          }
          job={this.props.job}
          isResumeLoading={this.props.isResumeLoading}
          getTempToken={this.props.getTempToken}
          resultsPerPage={this.state.resultsPerPage}
          handlePagination={this.handlePagination}
          showBookmarkedCandidates={this.props.showBookmarkedCandidates}
          title={
            ((this.props.showBookmarkedCandidates && this.props.translate('bookmarkedCandidates')) ||
            ((this.props.filterParam || this.props.searchedValue) && this.props.translate('searchCandidates'))) || this.props.translate('allCandidates')
          }
          recruiterJobPage={this.props.recruiterJobPage}
          addtoJobCandidates={this.state.addtoJobCandidates}
          isAddToJobDialogOpen={this.state.isAddToJobDialogOpen}
          openAddToJobDialog={this.openAddToJobDialog}
          closeAddToJobDialog={this.closeAddToJobDialog}
          handleBookmark={this.handleBookmark}
          downloadResume={this.downloadResume}
          hasLoading={this.state.hasLoading}
          tabs={this.props.tabs}
          getMenuItems={this.props.getMenuItems}
          currentTabKey={this.props.currentTabKey}
          currentSubTabKeys={this.props.currentSubTabKeys}
          loadingProfiles={this.props.loadingProfiles}
        />
      </ReduxBlockUI>
    );
  }
}

CandidateListContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  setPagination: PropTypes.func,
  currentSubTabKey: PropTypes.string,
  getMatchedCandidates: PropTypes.func,
  job: PropTypes.object, // eslint-disable-line
  pagination: PropTypes.object, // eslint-disable-line
  currentTabKey: PropTypes.string,
  getJobApplicationList: PropTypes.func,
  tabs: PropTypes.arrayOf(PropTypes.object),
  bookmarkCandidate: PropTypes.func,
  removeBookmarkCandidate: PropTypes.func,
  fetchProfile: PropTypes.func,
  chatType: PropTypes.object,  // eslint-disable-line
  handleSubmitMessage: PropTypes.func,
  showMessageDialog: PropTypes.bool,
  handlerShowMessageDialog: PropTypes.func,
  filters: PropTypes.element,
  candidates: PropTypes.array, // eslint-disable-line
  totalCandidates: PropTypes.number,
  totalMatchedCandidates: PropTypes.number,
  candidatesLoading: PropTypes.bool,
  recruiterBookmarking: PropTypes.bool,
  profilesBookmarking: PropTypes.bool,
  showBookmarkedCandidates: PropTypes.bool,
  isResumeLoading: PropTypes.bool,
  getTempToken: PropTypes.func,
  // searchedTalent: PropTypes.bool,
  match: PropTypes.object, // eslint-disable-line
  loadingProfiles: PropTypes.bool,
  shortlistJobApplicationLoading: PropTypes.bool,
  moveJobApplicationLoading: PropTypes.bool,
  addToJobLoading: PropTypes.bool,
  tempToken: PropTypes.string,
  getBookmarkedCandidates: PropTypes.func,
  filterParam: PropTypes.string,
  filterParamMatched: PropTypes.string,
  resetFilterParams: PropTypes.func,
  flushAllCandidates: PropTypes.func,
  recruiterJobPage: PropTypes.bool,
  searchedValue: PropTypes.string,
  candidatesProfilesLoading: PropTypes.bool,
  isRecentSearched: PropTypes.bool,
  facetsLoading: PropTypes.bool,
  isPageSetToZero: PropTypes.bool,
  currentCandidate: PropTypes.object, // eslint-disable-line
  getMenuItems: PropTypes.func,
  dispatch: PropTypes.func,
  // change: PropTypes.func,
  currentSubTabKeys: PropTypes.arrayOf(PropTypes.string),
  clearFilters: PropTypes.bool,
  selectAllCandidates: PropTypes.func,
  selectCandidate: PropTypes.func,
  selectedCandidates: PropTypes.arrayOf(PropTypes.any),
  deselectCandidate: PropTypes.func,
};

CandidateListContainer.defaultProps = {
  dispatch: () => {},
  // change: () => {},
  searchedValue: '',
  setPagination: () => {},
  currentSubTabKey: '',
  getMatchedCandidates: () => {},
  job: {},
  pagination: {},
  currentTabKey: '',
  getJobApplicationList: () => {},
  tabs: [],
  bookmarkCandidate: () => {},
  removeBookmarkCandidate: () => {},
  fetchProfile: () => {},
  chatType: {},
  handleSubmitMessage: () => {},
  showMessageDialog: false,
  handlerShowMessageDialog: () => {},
  filters: <div />,
  candidates: [],
  totalCandidates: 0,
  totalMatchedCandidates: 0,
  candidatesLoading: false,
  recruiterBookmarking: false,
  profilesBookmarking: false,
  showBookmarkedCandidates: false,
  isResumeLoading: false,
  getTempToken: () => {},
  // searchedTalent: false,
  match: {},
  loadingProfiles: false,
  shortlistJobApplicationLoading: false,
  moveJobApplicationLoading: false,
  addToJobLoading: false,
  tempToken: '',
  getBookmarkedCandidates: () => {},
  filterParam: '',
  filterParamMatched: '',
  resetFilterParams: () => {},
  flushAllCandidates: () => {},
  recruiterJobPage: false,
  candidatesProfilesLoading: false,
  isRecentSearched: false,
  facetsLoading: false,
  isPageSetToZero: false,
  currentCandidate: {},
  getMenuItems: () => {},
  currentSubTabKeys: [],
  clearFilters: false,
  selectAllCandidates: () => {},
  selectCandidate: () => {},
  deselectCandidate: () => {},
  selectedCandidates: [],
};

const mapStateToProps = state => ({
  clearFilters: state.profiles.clearFilters,
  matchedCandidates: state.recruiter.matchedCandidates,
  candidatesLoading: state.recruiter.candidatesLoading,
  candidatesProfilesLoading: state.profiles.candidatesLoading,
  recruiterBookmarking: state.recruiter.recruiterBookmarking,
  profilesBookmarking: state.profiles.profilesBookmarking,
  shortlistJobApplicationLoading: state.recruiter.shortlistJobApplicationLoading,
  moveJobApplicationLoading: state.recruiter.moveJobApplicationLoading,
  isResumeLoading: state.profiles.isResumeLoading,
  tempToken: state.profiles.tempToken,
  isPageSetToZero: state.profiles.isPageSetToZero,
  filterParam: state.profiles.filterParam,
  filterParamMatched: state.recruiter.filterParam,
  searchedValue: state.profiles.searchedValue,
  selectedCandidates: state.profiles.selectedCandidates,
});

const mapDispatchToprops = dispatch => ({
  dispatch,
  getBookmarkedCandidates: obj => dispatch(getBookmarkedCandidates(obj)),
  getMatchedCandidates: (id, pageNo, size, filterParam) =>
    dispatch(getMatchedCandidates(id, pageNo, size, filterParam)),
  getJobApplicationList: (id, key, pageNo, size) =>
    dispatch(getJobApplicationList(id, key, pageNo, size)),
  fetchProfile: query => dispatch(fetchProfile(query)),
  setFilter: () => dispatch(setFilter()),
  bookmarkCandidate: (param, data) => dispatch(bookmarkCandidate(param, data)),
  removeBookmarkCandidate: (id, type) => dispatch(removeBookmarkCandidate(id, type)),
  flushAllCandidates: () => dispatch(flushAllCandidates()),
  resetFilterParams: () => dispatch(resetFilterParams()),
  getTempToken: id => dispatch(getTempToken(id)),
  selectAllCandidates: candidates => dispatch(selectAllCandidates(candidates)),
  selectCandidate: candidate => dispatch(selectCandidate(candidate)),
  deselectCandidate: candidateID => dispatch(deselectCandidate(candidateID)),
});


export default connect(mapStateToProps, mapDispatchToprops)(withTranslate(CandidateListContainer));
