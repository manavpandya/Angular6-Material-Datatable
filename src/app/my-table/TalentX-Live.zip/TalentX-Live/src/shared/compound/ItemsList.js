import React from 'react';
import PropTypes from 'prop-types';

class ItemList extends React.PureComponent {
  render() {
    return (
      <div className="items list">
        { this.props.search && this.props.search }
        { this.props.items }
      </div>
    );
  }
}

ItemList.propTypes = {
  search: PropTypes.object.isRequired, // eslint-disable-line
  items: PropTypes.object.isRequired,  // eslint-disable-line
};

export default ItemList;
