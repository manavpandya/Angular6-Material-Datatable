import React, { Component } from 'react';
import PropTypes from 'prop-types';
import green from 'material-ui/colors/green';
import Switch from 'material-ui/Switch';
import { withStyles } from 'material-ui/styles';

const styles = {
  bar: {},
  checked: {
    color: green[500],
    '& + $bar': {
      backgroundColor: green[500],
    },
  },
};

class InputToggle extends Component {
  constructor() {
    super();
    this.state = {
      checked: false,
    };
  }

  handleChange(name) {
    return (event, checked) => {
      this.setState({ [name]: checked });
    };
  }
  render() {
    const { classes } = this.props;

    return (
      <div className="input-toggle">
        <Switch
          classes={{
           checked: classes.checked,
           bar: classes.bar,
         }}
          checked={this.state.checked}
          onChange={this.handleChange('checked')}
          color="green"
        />

        <h2>{ this.props.label }</h2>
      </div>
    );
  }
}

InputToggle.propTypes = {
  classes: PropTypes.objectOf.isRequired,
  label: PropTypes.string.isRequired,
};

export default withStyles(styles)(InputToggle);
