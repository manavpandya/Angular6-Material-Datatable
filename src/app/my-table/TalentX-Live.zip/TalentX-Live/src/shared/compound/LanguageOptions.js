import React from 'react';
import { PropTypes } from 'prop-types';
import { IntlActions } from 'react-redux-multilingual';
import LanguageIcon from 'material-ui-icons/Language';
import { MenuList, MenuItem } from 'material-ui/Menu';

import Menu from './Menu';

const LanguageOptions = props => (
  <div className="candidate-actions">
    <Menu
      label=""
      iconPrefix={<LanguageIcon className="more-vert" style={{ color: props.color }} />}
      popup={
        <MenuList role="menu">
          {
            props.languages.map(language => (
              <MenuItem
                key={language.label}
                className="menu-item"
                onClick={() => {
                  props.dispatch(IntlActions.setLocale(language.locale));
                  localStorage.setItem('currentLanguage', language.locale);
                }}
              >
                {language.label}
              </MenuItem>
            ))
          }
        </MenuList>
      }
    />
  </div>
);

LanguageOptions.propTypes = {
  // dispatch: PropTypes.func.isRequired,
  languages: PropTypes.arrayOf(PropTypes.object),
  color: PropTypes.string,
};

LanguageOptions.defaultProps = {
  languages: [],
  color: '#333333',
};

export default LanguageOptions;
