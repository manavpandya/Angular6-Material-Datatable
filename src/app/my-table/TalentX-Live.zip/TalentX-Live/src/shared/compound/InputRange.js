import React from 'react';
import TextField from 'material-ui/TextField';

const InputRange = () => (
  <div className="input-range">
    <TextField id="number" label="From" type="number" width={100} />
    <TextField id="number" label="To" type="number" width={100} />
  </div>
);

export default InputRange;
