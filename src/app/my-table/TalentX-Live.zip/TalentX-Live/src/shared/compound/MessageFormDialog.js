import React from 'react';
import { Field, reduxForm } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import { withStyles } from 'material-ui/styles';
import PropTypes from 'prop-types';
import Dialog, {
  DialogActions,
  DialogContent,
  DialogTitle,
} from 'material-ui/Dialog';
import Button from 'material-ui/Button';
import { required } from '../../utils/validators';

const styles = theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
  },
  menu: {
    width: 200,
  },
});


function MultiLineInput(props) {
  const { classes, ...other } = props; //eslint-disable-line
  return (
    <TextField
      id="multiline-static"
      label="Multiline"
      multiline
      rows="4"
      fullWidth
      margin="normal"
      {...other}
    />
  );
}

function HiddenTextField(props) {
  const { hiddenValue, type, classes, input, ...other } = props; //eslint-disable-line
  return (
    <div className="hidden">
      <input type="hidden" name={input.name} value={hiddenValue} />
    </div>
  );
}

const MessageForm = props => (
  <Dialog
    onSubmit={(e) => {
      e.preventDefault();
      e.stopPropagation();
    }}
    fullWidth
    maxWidth="sm"
    open={props.showMessageDialog}
    onClose={() => props.handlerShowMessageDialog(false)}
    aria-labelledby="form-dialog-title"
  >
    <DialogTitle id="form-dialog-title">{props.chatType.type === 'email' ? 'Email' : 'Message'}</DialogTitle>
    <DialogContent>
      <form id="MessageForm" onSubmit={props.handleSubmit(props.handleSubmitMessage)} >
        <div className="message-form">
          {props.chatType.type === 'email' &&
            <div className="subject-fields">
              <Field
                fullWidth
                id="subject"
                name="subject"
                label="Subject"
                className="subjecet-form-field"
                component={TextField}
                validate={required}
              />
              <Field
                type="hidden"
                name="messageFrom"
                hiddenValue={props.chatType.MessageForm}
                value={props.chatType.MessageForm}
                component={HiddenTextField}
              />
              <Field
                type="hidden"
                name="emailTo"
                hiddenValue={props.chatType.emailTo}
                value={props.chatType.emailTo}
                component={HiddenTextField}
              />
            </div>
          }
          <div className="message-fields">
            <Field
              fullWidth
              id="message"
              name="message"
              label="Write here"
              className="message-form-field"
              component={MultiLineInput}
              validate={required}
            />
          </div>
        </div>
      </form>
    </DialogContent>
    <DialogActions>
      <Button onClick={() => props.handlerShowMessageDialog(false)} color="primary" >
        Cancel
      </Button>
      <Button
        type="submit"
        form="MessageForm"
        variant="raised"
        color="primary"
      >
        Send
      </Button>
    </DialogActions>
  </Dialog>
);


MessageForm.propTypes = {
  chatType: PropTypes.object, // eslint-disable-line
  handleSubmit: PropTypes.func.isRequired,
  handleSubmitMessage: PropTypes.func,
  classes: PropTypes.object.isRequired, // eslint-disable-line
  showMessageDialog: PropTypes.bool,
  handlerShowMessageDialog: PropTypes.func,
};

MessageForm.defaultProps = {
  chatType: {},
  showMessageDialog: PropTypes.bool,
  handlerShowMessageDialog: PropTypes.func,
  handleSubmitMessage: () => {},
  // change: () => {},
};

export default reduxForm({
  form: 'MessageForm', enableReinitialize: true, keepDirtyOnReinitialize: true,
})(withStyles(styles)(MessageForm));

