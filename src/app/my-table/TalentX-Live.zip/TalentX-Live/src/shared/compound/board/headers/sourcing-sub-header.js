import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import BoardSearch from '../BoardSearch/BoardSearchContainer';

const HomeSubHeader = props => (
  <div className="board-actions-container">
    <h1>{props.translate('sourcing')}</h1>
    {
      props.showBookmarkedCandidates === false && <BoardSearch clientPage={props.clientPage} />
    }
  </div>
);

HomeSubHeader.propTypes = {
  translate: PropTypes.func.isRequired,
  showBookmarkedCandidates: PropTypes.bool.isRequired,
  clientPage: PropTypes.bool.isRequired,
};

export default withTranslate(HomeSubHeader);
