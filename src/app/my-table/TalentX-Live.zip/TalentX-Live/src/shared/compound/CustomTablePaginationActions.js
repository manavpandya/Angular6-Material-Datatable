import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Field, reduxForm, change } from 'redux-form';
import { withStyles } from 'material-ui/styles';
import IconButton from 'material-ui/IconButton';
import FirstPageIcon from 'material-ui-icons/FirstPage';
import KeyboardArrowLeft from 'material-ui-icons/KeyboardArrowLeft';
import KeyboardArrowRight from 'material-ui-icons/KeyboardArrowRight';
import LastPageIcon from 'material-ui-icons/LastPage';
import { TextField } from 'redux-form-material-ui';
import { matchRegEx } from '../../utils/validators';

const actionsStyles = theme => ({
  root: {
    flexShrink: 0,
    color: theme.palette.text.secondary,
    marginLeft: theme.spacing.unit * 2.5,
    display: 'flex',
  },
});

let pageChanged = false;

class TablePaginationActions extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: false,
    };

    this.handleFirstPageButtonClick = this.handleFirstPageButtonClick.bind(this);
    this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
    this.handleNextButtonClick = this.handleNextButtonClick.bind(this);
    this.handleLastPageButtonClick = this.handleLastPageButtonClick.bind(this);
    this.handleGoToPageInput = this.handleGoToPageInput.bind(this);
  }
  componentDidMount() {
    this.props.change('gotoForm', 'pageNo', '1');
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.rowsPerPage !== nextProps.rowsPerPage) {
      this.props.change('gotoForm', 'pageNo', '1');
      this.setState({
        error: false,
      });
    } else if (this.props.page !== nextProps.page && !pageChanged) {
      this.props.change('gotoForm', 'pageNo', nextProps.page + 1);
      this.setState({
        error: false,
      });
    } else if (this.props.page !== nextProps.page && pageChanged) {
      pageChanged = false;
    }
  }

  handleGoToPageInput(event) {
    if (matchRegEx(event.target.value, /^(?!(?:0)$)\d{1,10}$/) && event.target.value
    <= Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage))) {
      this.setState({
        error: false,
      });
    } else {
      this.setState({
        error: true,
      });
    }
    if (event.key === 'Enter') {
      if (matchRegEx(event.target.value, /^(?!(?:0)$)\d{1,10}$/) && event.target.value
        <= Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage))) {
        this.props.onChangePage('goto', parseInt(event.target.value - 1, 10)); // 10 is radix
      } else {
        this.setState({
          error: true,
        });
      }
    }
  }
  handleFirstPageButtonClick() {
    pageChanged = true;
    this.setState({
      error: false,
    });
    this.props.change('gotoForm', 'pageNo', '1');
    // if (this.props.searchItem) {
    //   this.props.handleSearchPagination(0, this.props.rowsPerPage);
    // } else {
    this.props.onChangePage('gotoFirst', 0);
    // }
  }

  handleBackButtonClick(event) {
    pageChanged = true;
    this.setState({
      error: false,
    });
    this.props.change('gotoForm', 'pageNo', String(this.props.page));
    // if (this.props.searchItem) {
    //   this.props.handleSearchPagination(this.props.page - 1, this.props.rowsPerPage);
    // } else {
    this.props.onChangePage(event, this.props.page - 1);
    // }
  }

  handleNextButtonClick(event) {
    pageChanged = true;
    this.setState({
      error: false,
    });
    this.props.change('gotoForm', 'pageNo', String(this.props.page + 2));
    // if (this.props.searchItem) {
    //   this.props.handleSearchPagination(this.props.page + 1, this.props.rowsPerPage);
    // } else {
    this.props.onChangePage(event, this.props.page + 1);
    // }
  }

  handleLastPageButtonClick(event) {
    const newPageNo = Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage) - 1);
    pageChanged = true;
    this.setState({
      error: false,
    });
    this.props.change('gotoForm', 'pageNo', String(Math.max(0, Math.ceil(this.props.count / this.props.rowsPerPage) - 1) + 1));
    // if (this.props.searchItem) {
    //   this.props.handleSearchPagination(newPageNo, this.props.rowsPerPage);
    // } else {
    this.props.onChangePage(event, newPageNo);
    // }
  }

  render() {
    const {
      classes, count, page, rowsPerPage,
    } = this.props;
    return (
      <div className={classes.root}>
        <IconButton
          onClick={this.handleFirstPageButtonClick}
          disabled={page === 0}
          aria-label="First Page"
        >
          <FirstPageIcon />
        </IconButton>
        <IconButton
          onClick={this.handleBackButtonClick}
          disabled={page === 0}
          aria-label="Previous Page"
        >
          <KeyboardArrowLeft />
        </IconButton>
        <Field
          onKeyUp={this.handleGoToPageInput}
          className="goto-page"
          id="pageNo"
          name="pageNo"
          InputProps={{
            className: `goto-input ${this.state.error ? ' error-field' : ''} `,
            disableUnderline: true,
            classes: {
              root: classes.bootstrapRoot,
              input: classes.bootstrapInput,
            },
          }}
          component={TextField}
        />
        <IconButton
          onClick={this.handleNextButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="Next Page"
        >
          <KeyboardArrowRight />
        </IconButton>
        <IconButton
          onClick={this.handleLastPageButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="Last Page"
        >
          <LastPageIcon />
        </IconButton>
      </div>
    );
  }
}

TablePaginationActions.propTypes = {
  classes: PropTypes.objectOf(PropTypes.any).isRequired,
  change: PropTypes.func.isRequired,
  count: PropTypes.number,
  rowsPerPage: PropTypes.number,
  page: PropTypes.number,
  onChangePage: PropTypes.func,
  // searchItem: PropTypes.string,
  // handleSearchPagination: PropTypes.func,
};

TablePaginationActions.defaultProps = {
  count: 0,
  rowsPerPage: 100,
  page: 0,
  // searchItem: '',
  // handleSearchPagination: () => {},
  onChangePage: () => {},
};

const mapDispatchToProps = dispatch => ({
  change: (formName, fieldName, value) => dispatch(change(formName, fieldName, value)),
});

export default reduxForm({
  form: 'gotoForm',
  enableReinitialize: true,
})(withStyles(actionsStyles)(connect(null, mapDispatchToProps)(TablePaginationActions)));

