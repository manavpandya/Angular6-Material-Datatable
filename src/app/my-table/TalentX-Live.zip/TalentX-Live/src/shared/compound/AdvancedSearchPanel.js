import React from 'react';
import { connect } from 'react-redux';
import { withTranslate } from 'react-redux-multilingual';
import { change } from 'redux-form';
import { PropTypes } from 'prop-types';
import InputRangeFilter from './InputRangeFilter';
import ExpandField from './ExpandField';
import InputAutoComplete from './InputAutoComplete';
import SelectFilterCheckbox from './SelectFilterCheckbox';
import {
  fetchFacet,
  profileSearch,
  setCheckedFilters,
  fetchLocalFilterSearch,
  unsetClearFilter,
  resetFilter,
  setNewSearch,
  resetFilterParams,
} from '../../modules/candidates/redux/actions';
import {
  fetchFacetMatched,
  profileSearchMatched,
  setCheckedFiltersMatched,
  fetchLocalFilterSearchMatched,
  // unsetClearFilter,
  resetFilterParamsMatched,
  resetFilterMatched,
  unsetClearFilterMatched,
  // setNewSearch,
} from '../../modules/jobs/redux/actions';
import { sortAll, convertString, minMax } from './../../utils/index';

let filtersToApply = {};
const setFilters = (contentInfo, target = {}, specialChecks) => {
  if (contentInfo.clearFilters) {
    filtersToApply = {};
    contentInfo.unsetClearFilter();
  }
  // Check if we already have filter data for this type of key
  filtersToApply[contentInfo.key] = filtersToApply[contentInfo.key] || {};
  const currentFilter = filtersToApply[contentInfo.key]; // Assign it to a local variable
  // If we already have filters object use it, else fetch it from facet meta info
  currentFilter.filters =
    currentFilter.filters || contentInfo.filters;
  if (specialChecks) { // If this is a special checks, like current and past
    currentFilter.specialChecks
      = currentFilter.specialChecks || {};
    const checkType = target.id.indexOf('Current') >= 0 ? 'current' : 'past'; // Know if the current checkbox is of which type
    if (target.checked) {
      currentFilter.specialChecks[checkType] = target.checked; // Set as true if selected
    } else {
      delete currentFilter.specialChecks[checkType]; // Remove if its not selected
    }
    currentFilter.filter = currentFilter.filters.all;
    // By default set the filter to use of type "all"
    if (currentFilter.specialChecks.current
      && currentFilter.specialChecks.past) {
      // If both current and past items are selected, use type "all"
      currentFilter.filter = currentFilter.filters.all;
    } else if (currentFilter.specialChecks.current) {
      // Use of type "current" of only current is selected
      currentFilter.filter = currentFilter.filters.current;
    } else if (currentFilter.specialChecks.past) {
      // Use of type "past" of only past is selected
      currentFilter.filter = currentFilter.filters.past;
    }
  } else {
    if (contentInfo.type === 'slider') {
      currentFilter.items = '' || {};
    } else {
      currentFilter.items = currentFilter.items || {};
    }
    if (target.checked) {
      currentFilter.items[target.value] = true;
    } else {
      delete currentFilter.items[target.value];
    }
    if (contentInfo.type === 'slider') {
      if (target.value) {
        currentFilter.items[`${target.value.min}..${target.value.max}`] = true;
      } else {
        delete currentFilter.items[`${target.value.min}..${target.value.max}`];
      }
    }
    // Check if current filter type has special checks
    const hasSpecialChecks = currentFilter.specialChecks
      && Object.keys(currentFilter.specialChecks).length > 0;
    if (!hasSpecialChecks) {
      // If we dont have special checks, reset filters to type "all"
      currentFilter.filter = currentFilter.filters.all;
    }
    const hasItems = currentFilter.items
      && Object.keys(currentFilter.items).length > 0;
    if (!hasItems) {
      // If we dont have special checks, reset filters to type "all"
      delete filtersToApply[contentInfo.key];
    }
  }
  contentInfo.profileSearch(filtersToApply, contentInfo.query, contentInfo.jobId);
  contentInfo.dispatch(change('gotoForm', 'pageName', 1));
  return filtersToApply;
};

const reset = (contentInfo) => {
  delete filtersToApply[contentInfo.key];
  contentInfo.profileSearch(filtersToApply, contentInfo.query, contentInfo.jobId);
  // Apply filter
};

const generateContent = (contentInfo) => {
  let generatedContent;
  switch (contentInfo.type) {
    case 'checkbox':
      generatedContent = (
        <div className="multi">
          <main>
            <SelectFilterCheckbox
              searchedValue={contentInfo.searchedValue}
              resetFilter={contentInfo.resetFilter}
              setCheckedFilters={contentInfo.setCheckedFilters}
              checkedFilters={contentInfo.checkedFilters}
              setNewSearch={contentInfo.setNewSearch}
              isNewSearch={contentInfo.isNewSearch}
              id={contentInfo.key}
              values={contentInfo.data.length === 0 ? [] : contentInfo.data}
              reset={() => reset(contentInfo)}
              passTalent={target =>
                setFilters(contentInfo, target)}
              currentFilterType={contentInfo.filters.all}
              fetchLocalFilterSearch={contentInfo.fetchLocalFilterSearch}
              localFilterSuggestions={contentInfo.localFilterSuggestions}
              suggestionsLoading={contentInfo.suggestionsLoading}
              filterParam={contentInfo.filterParam}
              component={contentInfo.component}
              isMeta={false}
            />
          </main>
          <aside>
            {contentInfo.filters && contentInfo.filters.current && contentInfo.filters.past &&
              <SelectFilterCheckbox
                setCheckedFilters={contentInfo.setCheckedFilters}
                checkedFilters={contentInfo.checkedFilters}
                id={contentInfo.key}
                reset={() => reset(contentInfo)}
                values={[{
                  key: 'Current',
                  value: contentInfo.filters.current,
                },
                {
                  key: 'Past',
                  value: contentInfo.filters.past,
                }]}
                filterParam={contentInfo.filterParam}
                passTalent={target =>
                  setFilters(contentInfo, target, true)
                }
                isMeta
              />
            }
          </aside>
        </div>
      );
      break;
    case 'slider':
      generatedContent = (<InputRangeFilter
        isNewSearch={contentInfo.isNewSearch}
        clearFilters={contentInfo.clearFilters}
        filterParam={contentInfo.filterParam}
        reset={() => {
            reset(contentInfo);
          }
        }
        mode="range"
        placeholder="Sector"
        min={minMax(contentInfo.data, 'key').min}
        max={minMax(contentInfo.data, 'key').max}
        passTalent={(target) => {
            setFilters(contentInfo, target);
          }
        }
      />);
      break;
    case 'input':
      generatedContent = (
        <div className="input-multiselect">
          <InputAutoComplete placeholder="Search Locations" />
        </div>
      );
      break;
    default:
      generatedContent = (
        <div className="multi">
          <main>
            <SelectFilterCheckbox
              values={sortAll(contentInfo.data, 'doc_count', 'asc', 'number')}
              passTalent={target =>
                setFilters(contentInfo, target)}
            />
          </main>
        </div>
      );
      break;
  }
  return generatedContent;
};

function generateProps(curFacet, facetData, meta = {}) {
  const curFacetKey = curFacet.key;
  const curFacetMeta = meta[curFacetKey] || {};
  return {
    key: curFacetKey,
    type: curFacet.type,
    data: facetData[curFacetKey].data,
    filters: { all: facetData[curFacetKey].filter, current: curFacetMeta.current || '', past: curFacetMeta.past || '' },
  };
}

function getHeader(header, translate) {
  switch (header) {
    case 'companies':
      return translate('company');
    case 'current_location':
      return translate('location');
    case 'preferred_location':
      return translate('preferredLocation');
    case 'experience':
      return translate('experience');
    case 'job_titles':
      return translate('jobTitle');
    case 'qualifications':
      return translate('qualifications');
    case 'skills':
      return translate('skills');
    case 'spoken_language':
      return translate('spokenLanguage');
    default:
      return header;
  }
}
function getLabel(label, translate) {
  switch (label) {
    case 'companies':
      return translate('companyIncludes');
    case 'exclude_companies':
      return translate('excludeCompanies');
    case 'current_location':
      return translate('currentLocation');
    case 'preferred_location':
      return translate('preferredLocation');
    case 'experience':
      return translate('experience');
    case 'job_titles':
      return translate('jobTitle');
    case 'qualifications':
      return translate('qualifications');
    case 'skills':
      return translate('requiredSkills');
    case 'spoken_language':
      return translate('spokenLanguage');
    default:
      return label;
  }
}

class AdvancedSearchPanel extends React.PureComponent {
  constructor(props) {
    super(props);
    this.renderFilters = this.renderFilters.bind(this);
  }
  componentDidMount() {
    if (this.props.isMatched && this.props.jobId) {
      this.props.fetchFacetMatched('', this.props.jobId)
        .then(() => {
          this.props.resetFilterParamsMatched();
        });
    } else {
      this.props.fetchFacet('')
        .then(() => {
          this.props.resetFilterParams();
        });
    }
  }

  renderFilters(filterProps) {
    let renderFilterArray = [];
    const returnVal = (facet, index) => (
      <div className="expand-with-reset">
        <ExpandField
          reset={() => reset(facet.key)}
          label={convertString(getLabel(facet.key, this.props.translate))}
        >
          {this.props.facets[facet.key] && this.props.facets[facet.key].data && generateContent({
              ...generateProps(this.props.showFacets[index], this.props.facets, this.props.meta),
              profileSearch: filterProps.profileSearch,
              query: this.props.filter.query,
              fetchLocalFilterSearch: filterProps.fetchLocalFilterSearch,
              filterType: this.props.facets[facet.key],
              localFilterSuggestions: this.props.localFilterSuggestions, // eslint-disable-line
              suggestionsLoading: this.props.suggestionsLoading, // eslint-disable-line
              setNewSearch: this.props.setNewSearch,
              isNewSearch: this.props.isNewSearch,
              setCheckedFilters: filterProps.setCheckedFilters,
              resetFilter: filterProps.resetFilter,
                checkedFilters: this.props.checkedFilters,
              filterParam: filterProps.filterParam,
              clearFilters: filterProps.clearFilters,
              unsetClearFilter: filterProps.unsetClearFilter,
              searchedValue: this.props.searchedValue,
              component: facet.component,
              dispatch: this.props.dispatch,
              jobId: this.props.jobId,
          })}
        </ExpandField>
      </div>
    );
    this.props.showFacets.map((facet, index) => {
      const foundFilter = renderFilterArray
        .find(filter => filter.key && filter.key === facet.component);
      if (!foundFilter) {
        renderFilterArray.push({
          key: facet.component,
          header: facet.key,
          components: [
            returnVal(facet, index),
          ],
        });
      } else {
        foundFilter.components = [
          ...foundFilter.components,
          returnVal(facet, index),
        ];
        renderFilterArray = [
          ...renderFilterArray.filter(filter => filter.header !== foundFilter.header),
          foundFilter,
        ];
      }
      return renderFilterArray;
    });
    return renderFilterArray.map(filter => (filter.header ? (
      <div>
        <h2>{convertString(getHeader(filter.header, this.props.translate))}</h2>
        {filter.components}
        <div className="filter-border" />
      </div>
    ) : null));
  }

  render() {
    const filterProps = {};
    if (this.props.isMatched) {
      filterProps.filterParam = this.props.filterParamMatched;
      filterProps.totalCandidates = this.props.totalMatchedCandidates;
      filterProps.setCheckedFilters = this.props.setCheckedFiltersMatched;
      filterProps.fetchLocalFilterSearch = this.props.fetchLocalFilterSearchMatched;
      filterProps.profileSearch = this.props.profileSearchMatched;
      filterProps.resetFilter = this.props.resetFilterMatched;
      filterProps.clearFilters = this.props.clearFiltersMatched;
      filterProps.unsetClearFilter = this.props.unsetClearFilterMatched;
    } else {
      filterProps.filterParam = this.props.filterParam;
      filterProps.totalCandidates = this.props.totalCandidates;
      filterProps.setCheckedFilters = this.props.setCheckedFilters;
      filterProps.fetchLocalFilterSearch = this.props.fetchLocalFilterSearch;
      filterProps.profileSearch = this.props.profileSearch;
      filterProps.resetFilter = this.props.resetFilter;
      filterProps.clearFilters = this.props.clearFilters;
      filterProps.unsetClearFilter = this.props.unsetClearFilter;
    }
    return (
      <aside className="advanced-search-panel">
        <h3>
          <div className="flex-spacebetween">
            <span>{this.props.translate('advancedSearch')} </span>
            <span>{filterProps.filterParam && filterProps.totalCandidates}</span>
          </div>
        </h3>
        <div className="scroll-bar">
          {this.props.facets && Object.keys(this.props.facets).length > 0 &&
            this.renderFilters(filterProps)}
        </div>
      </aside>
    );
  }
}


AdvancedSearchPanel.propTypes = {
  translate: PropTypes.func,
  facets: PropTypes.object, // eslint-disable-line
  meta: PropTypes.object, // eslint-disable-line
  filter: PropTypes.object, // eslint-disable-line
  fetchLocalFilterSearch: PropTypes.func, // eslint-disable-line
  setNewSearch: PropTypes.func,
  isNewSearch: PropTypes.bool,
  setCheckedFilters: PropTypes.func,
  resetFilter: PropTypes.func,
  checkedFilters: PropTypes.object, // eslint-disable-line
  clearFilters: PropTypes.bool,
  clearFiltersMatched: PropTypes.bool,
  unsetClearFilter: PropTypes.func,
  unsetClearFilterMatched: PropTypes.func,
  filterParam: PropTypes.string,
  filterParamMatched: PropTypes.string,
  searchedValue: PropTypes.string,
  showFacets: PropTypes.arrayOf(PropTypes.object),
  fetchFacet: PropTypes.func,
  dispatch: PropTypes.func,
  profileSearch: PropTypes.func,
  totalCandidates: PropTypes.number.isRequired,
  // isMatched
  totalMatchedCandidates: PropTypes.number.isRequired,
  isMatched: PropTypes.bool.isRequired,
  profileSearchMatched: PropTypes.func,
  fetchFacetMatched: PropTypes.func,
  setCheckedFiltersMatched: PropTypes.func,
  fetchLocalFilterSearchMatched: PropTypes.func,
  resetFilterMatched: PropTypes.func,
  resetFilterParamsMatched: PropTypes.func,
  jobId: PropTypes.string,
  resetFilterParams: PropTypes.func,
};

AdvancedSearchPanel.defaultProps = {
  dispatch: () => {},
  facets: {},
  filter: {},
  fetchLocalFilterSearch: () => {},
  translate: () => {},
  setNewSearch: () => {},
  isNewSearch: false,
  setCheckedFilters: () => {},
  resetFilter: () => {},
  checkedFilters: {}, // eslint-disable-line
  clearFilters: true,
  clearFiltersMatched: true,
  unsetClearFilter: () => {},
  unsetClearFilterMatched: () => {},
  filterParam: '',
  filterParamMatched: '',
  searchedValue: '',
  showFacets: [],
  fetchFacet: () => {},
  profileSearch: () => {},
  // isMatched
  profileSearchMatched: () => {},
  fetchFacetMatched: () => {},
  setCheckedFiltersMatched: () => {},
  fetchLocalFilterSearchMatched: () => {},
  resetFilterMatched: () => {},
  resetFilterParams: () => {},
  resetFilterParamsMatched: () => {},
  jobId: '',
};

const mapStateToProps = state => ({
  totalCandidates: state.profiles.totalCandidates,
  totalMatchedCandidates: state.recruiter.totalCandidates,
  checkedFilters: state.profiles.checkedFilters,
  filterParam: state.profiles.filterParam,
  filterParamMatched: state.recruiter.filterParam,
  clearFilters: state.profiles.clearFilters,
  clearFiltersMatched: state.recruiter.clearFilters,
  isNewSearch: state.profiles.isNewSearch,
  suggestionsLoading: state.profiles.suggestionsLoading,
  localFilterSuggestions: state.profiles.localFilterSuggestions,
  filter: state.profiles.filter,
  facets: state.profiles.facets,
  meta: state.profiles.meta,
  searchedValue: state.profiles.searchedValue,
});

const mapDispatchToProps = dispatch => ({
  dispatch,
  resetFilterParams: () => dispatch(resetFilterParams()),
  resetFilterParamsMatched: () => dispatch(resetFilterParamsMatched()),
  fetchFacet: searchedValue => dispatch(fetchFacet(searchedValue)),
  profileSearch: (filter, query, filterParam) =>
    dispatch(profileSearch(filter, query, filterParam)),
  setCheckedFilters: (key, value) => dispatch(setCheckedFilters(key, value)),
  unsetClearFilter: () => dispatch(unsetClearFilter()),
  unsetClearFilterMatched: () => dispatch(unsetClearFilterMatched()),
  resetFilter: id => dispatch(resetFilter(id)),
  setNewSearch: isNewSearch => dispatch(setNewSearch(isNewSearch)),
  fetchLocalFilterSearch: (searchValue, filterType, mainSearchedValue) =>
    dispatch(fetchLocalFilterSearch(searchValue, filterType, mainSearchedValue)),
  // For isMatched Candidates
  fetchFacetMatched: (searchedValue, jobId) => dispatch(fetchFacetMatched(searchedValue, jobId)),
  profileSearchMatched: (filter, query, jobId) =>
    dispatch(profileSearchMatched(filter, query, jobId)),
  setCheckedFiltersMatched: (key, value) => dispatch(setCheckedFiltersMatched(key, value)),
  fetchLocalFilterSearchMatched: (searchValue, filterType, mainSearchedValue) =>
    dispatch(fetchLocalFilterSearchMatched(searchValue, filterType, mainSearchedValue)),
  resetFilterMatched: id => dispatch(resetFilterMatched(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(AdvancedSearchPanel));
