import React from 'react';
import classnames from 'classnames';
import PropTypes from 'prop-types';
import Card, { CardHeader, CardContent } from 'material-ui/Card';
import Collapse from 'material-ui/transitions/Collapse';
import IconButton from 'material-ui/IconButton';
import ExpandMoreIcon from 'material-ui-icons/ExpandMore';

const Expander = props => (
  <Card style={{ overflow: 'visible' }}>
    <CardHeader
      onClick={() => props.handleExpandClick(props.name)}
      className={props.className}
      action={
        <IconButton
          className={classnames(props.classes.expand, {
            [props.classes.expandOpen]: props.expanded.includes(props.name),
          })}
          aria-expanded={props.expanded}
          aria-label="Show more"
        >
          <ExpandMoreIcon />
        </IconButton>
      }
      subheader={props.heading}
    />
    {props.expanded.includes(props.name) ? null : <p className="contentPreview">{props.preview}</p>}
    <Collapse
      style={{ overflow: 'visible' }}
      classes={{ container: props.classes.container }}
      in={props.expanded.includes(props.name)}
      timeout="auto"
    >
      <CardContent>
        <div className={!props.expanded.includes(props.name) ? 'invisible' : ''}>
          {props.children}
        </div>
      </CardContent>
    </Collapse>
  </Card>
);

Expander.propTypes = {
  name: PropTypes.string,
  className: PropTypes.string,
  heading: PropTypes.string,
  children: PropTypes.element,
  classes: PropTypes.object.isRequired, // eslint-disable-line
  handleExpandClick: PropTypes.func,
  expanded: PropTypes.arrayOf(PropTypes.string),
  preview: PropTypes.string,
};

Expander.defaultProps = {
  name: '',
  className: '',
  heading: '',
  children: <div />,
  handleExpandClick: () => { },
  expanded: [],
  preview: '',
};

export default Expander;
