/*
eslint-disable
*/
import classNames from 'classnames';
import React, { Component, Fragment } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { PropTypes } from 'prop-types';
import { connect } from 'react-redux';
import _ from 'lodash';
import Button from 'material-ui/Button';
import Dialog, {
  DialogContent,
} from 'material-ui/Dialog';
import ReduxBlockUI from 'react-block-ui';
import Tooltip from 'material-ui/Tooltip';
import Slide from 'material-ui/transitions/Slide';
import { withStyles } from 'material-ui/styles';
import FullscreenIcon from 'material-ui-icons/Fullscreen';
import FullscreenExitIcon from 'material-ui-icons/FullscreenExit';
import DownloadIcon from 'material-ui-icons/FileDownload';
import CloseIcon from 'material-ui-icons/Close';
import { showNotification } from './../../utils/Notifications';
import Call from 'material-ui-icons/Call';
import Email from 'material-ui-icons/Email';
import Home from 'material-ui-icons/Home';
// import Avatar from '../basic/Avatar';
import MomentTranslate from '../basic/MomentTranslate';
import SmartList from './SmartList';
import UnmatchedList from './UnmatchedList';
import CandidateActions from './../../modules/candidates/components/CandidateActions';
import CustomerActions from './../../modules/customer-area/components/CustomerActions';
import LinkButton from '../basic/LinkButton';
import { getProfileInfo, flushSelectedCandidateProfile } from '../../modules/jobs/redux/actions';
import { getTempToken } from '../../modules/candidates/redux/actions';
import { moveJobApplication, getJobApplicationListCustomer } from '../../modules/customer-area/redux/actions';
import { sortAll } from './../../utils/index';
import BASE_URL from '../../constants/';

const styles = theme => ({
  root: {
    display: 'flex',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  chip: {
    margin: theme.spacing.unit,
  },
  rootForExpansion: {
    display: 'inline-block',
    width: '100%',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },

});

function Transition(props) {
  return <Slide direction="up" {...props} />;
}

const FormatCandidateProfile = profile => ({
  company: profile.experience_details ? profile.experience_details.current_employer : '-',
  id: profile.id,
  job_title: profile.experience_details ? profile.experience_details.current_job_title : '-',
  location: profile.location ? profile.location : '-',
  name: profile.name || '-',
  matchPercent: 88,
  skills: profile.skills ? profile.skills : [],
  quaSkills: profile.qualifications ? _.uniqBy(
    profile.qualifications.skills,
    obj => obj.display_value.toLowerCase(),
  ) : [],
  experience: profile.experience_summary || '-',
  qualifications: profile.education_details ? profile.education_details : [],
  contact_information: profile.contact_information,
  certification_licence: profile.certification_licence ? profile.certification_licence.license_and_certifications.LicenseOrCertification : '-',
  lastUpdated: profile.updated_at || '-',
  available: profile.available,
  unmatched: profile.unmatched,
  previousJobsTitle: profile.experience_details ? profile.experience_details.previous_job_titles : [],//eslint-disable-line
});


class CandidateProfile extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hasLoading: null,
      open: false,
      fullScreen: false,
      showMoreTitles: false,
    };
    this.handleClickFullScreen = this.handleClickFullScreen.bind(this);
    this.handleClickOpen = this.handleClickOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.showMore = this.showMore.bind(this);
    this.showMoreTitles = this.showMoreTitles.bind(this);
    this.downloadResume = this.downloadResume.bind(this);
  }

  handleClickFullScreen() {
    this.setState({ fullScreen: !this.state.fullScreen });
  }
  showMore() {
    this.setState({ showMore: !this.state.showMore });
  }

  handleClickOpen(profileId) {
    this.props.flushSelectedCandidateProfile();
    this.props.getProfileInfo(this.props.jobId, profileId);
    this.setState({ open: true });
  }

  handleClose() {
    this.setState({ fullScreen: false });
    this.setState({ open: false });
  }

  showMoreTitles() {
    this.setState({ showMoreTitles: !this.state.showMoreTitles });
  }

  renderJobTitles(elem) {
    const jobTitles = this.props.selectedCandidateProfile.experience_details ?
      this.props.selectedCandidateProfile.experience_details.previous_job_titles : [];
    const jobtitlesLength = jobTitles.length;
    const renderedItem = _.join(this.state.showMoreTitles ? jobTitles : _.slice(jobTitles, 0, 5), ',');
    return (
      <ul className="prev-job-titles">{renderedItem }
        {(jobtitlesLength > 5) ?
          <li className="item">
            <strong>
              <LinkButton onClick={this.showMoreTitles}>
                {this.state.showMoreTitles ? '- Show less' : jobtitlesLength > 1 &&
                        `+${(jobtitlesLength - 5)} more` }
              </LinkButton>
            </strong>
          </li> :
          <li />
        }
        {elem}
      </ul>);
  }

  downloadResume(id) {
    this.setState({ hasLoading: id });
    this.props.getTempToken(id).then((res) => {
      window.open(`${BASE_URL}profile/${id}/download?token=${res.value.tempToken}`);
    }).catch((err) => {
      showNotification(err, 'error', 8000);
      this.setState({ hasLoading: '' });
    });
  }


  render() {
    const profileInfo = this.props.selectedCandidateProfile
      && FormatCandidateProfile(this.props.selectedCandidateProfile);
    const SortedQualifySkills = sortAll(profileInfo.quaSkills.map(o => ({ value: o.display_value })), 'value', 'asc', 'string');
    const otherContact = profileInfo.contact_information &&
      profileInfo.contact_information.other_phone_no
      &&
      profileInfo.contact_information.other_phone_no
        .length > 0
      ? profileInfo.contact_information.other_phone_no
        .join(', ')
      : 'NA';
    let previousJobTitles = ''; //eslint-disable-line
    let jobTitle = '';
    let requiredSkills = '';
    let unmatchedSkills = [];
    if (profileInfo.unmatched) {
      unmatchedSkills = profileInfo.unmatched.map((o) => {
        if (o.group) {
          return {
            ...o,
          };
        }
        return true;
      });
    }
    if (this.props.candidate.matched_queries) {
      this.props.candidate.matched_queries.map((o) => {
        if (o.previous_job_titles) {
          previousJobTitles = o.previous_job_titles;
        }
        if (o.job_title) {
          jobTitle = o.job_title;
        }
        if (o.required_skills) {
          requiredSkills = o.required_skills;
        }
        return true;
      });
    }
    return (
      <span className="candidate-profile">
        <LinkButton
          onClick={() => {
            this.handleClickOpen(this.props.candidate.id);
          }
          }
          className="launcher"
        >
          {this.props.candidate.name}
        </LinkButton>
        <Dialog
          maxWidth="md"
          fullScreen={this.state.fullScreen}
          transition={Transition}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <ReduxBlockUI
            tag="div"
            blocking={this.props.candidateProfileLoading}
            className="dialog"
            renderChildren
          >
            <DialogContent className="candidate-profile-dialog dark-gray">
              <main>
                <div className="id">
                  {/* <Avatar avatar="https://s3.amazonaws.com/uifaces/faces/twitter/derekcramer/128.jpg" alt="avatar" size={2} /> */}
                  <div className="details">
                    <h1>{this.props.candidate.name}</h1>
                    <h3 className={`${jobTitle === 'partial' ? 'partial_match' : jobTitle === true}`}>{this.props.candidate.job_title}</h3>
                    {
                      (previousJobTitles === 'partial' || previousJobTitles === true) &&
                      (
                        <div className="smart-list highlights job-titles-list">
                          {this.renderJobTitles((<span className={`${previousJobTitles === 'partial' ? 'partial_match' : previousJobTitles === true}`} />))}
                        </div>
                      )
                    }
                    <div className="contact">
                      <Call className="phone contact-icon" />{' '}{' '}
                      <span>{(profileInfo.contact_information &&
                      profileInfo.contact_information.mobile &&
                      profileInfo.contact_information.mobile.length > 0
                      ? profileInfo.contact_information.mobile.join(', ')
                      : otherContact)}
                      </span>
                      <Email className="email contact-icon" />{' '}{' '}
                      <span>
                        {
                          profileInfo.contact_information &&
                            profileInfo.contact_information.email &&
                            profileInfo.contact_information.email.length > 0
                            ? profileInfo.contact_information.email.join(', ')
                            : 'NA'
                        }
                      </span>
                      {
                        profileInfo.location && profileInfo.location.city &&
                          <Fragment>
                            <Home className="home contact-icon" />
                            <span>
                              {/* {
                                profileInfo.location &&
                                  profileInfo.location.city && profileInfo.location.country
                                  ?
                                    <Fragment>
                                      {`${profileInfo.location.city}, ${profileInfo.location.country}`}
                                    </Fragment>
                                  : profileInfo.location.city
                              } */}
                              {
                                !(profileInfo.location.city && profileInfo.location.country) && 'NA'
                              }
                              {
                                `${profileInfo.location.city ? profileInfo.location.city : ''}${profileInfo.location.city && profileInfo.location.country ? ', ' : ''}${profileInfo.location.country ? profileInfo.location.country : ''}`
                              }
                            </span>
                          </Fragment>
                      }
                    </div>
                  </div>
                  {
                    this.props.candidate && this.props.candidate.sector &&
                    <div className="sector-rectangle-small right">
                      {this.props.candidate.sector.primary}
                    </div>
                  }
                  <div className="actions">
                    { //  Action Menu
                      Object.keys(this.props.actionMenuItems || {}).length > 0 ?
                      <Fragment>
                        <Tooltip
                          id="tooltip-linkedin"
                          className="multiline-tooltip download-info"
                          title="Download Profile"
                        >
                          <Button aria-label="add" size="sm">
                            <DownloadIcon
                              className="pointer downloadBtn"
                              onClick={() => this.downloadResume(this.props.candidate.id)}
                            />
                          </Button>
                        </Tooltip>
                        <CustomerActions
                          getData={this.props.getData}
                          getJobApplicationListCustomer={this.props.getJobApplicationListCustomer}
                          moveJobApplication={this.props.moveJobApplication}
                          actionMenuItems={this.props.actionMenuItems[this.props.label]}
                          appId={this.props.appId}
                        />
                      </Fragment>
                      :
                        <CandidateActions
                          candidates={this.props.candidate}
                          openAddToJobDialog={this.props.openAddToJobDialog}
                        />
                    }
                    <Button onClick={this.handleClickFullScreen}>
                      { this.state.fullScreen ?
                        <FullscreenExitIcon style={{ color: '#333', width: '1em', height: '1em' }} /> :
                        <FullscreenIcon style={{ color: '#333', width: '1em', height: '1em' }} /> }
                    </Button>
                    <Button onClick={this.handleClose} color="primary" autoFocus>
                      <CloseIcon style={{ color: '#333', width: '1em', height: '1em' }} />
                    </Button>
                  </div>
                </div>
                <div className={classNames('skills', { 'list-margin': this.state.showMoreTitles, 'list-rev-margin': !this.state.showMoreTitles })}>
                  <label htmlFor="label" className="label">{this.props.translate('skills')}</label>
                  <div className="value">

                    { !this.props.jobId ?
                      <div>
                        {this.state.showMore ? SortedQualifySkills.map(o => (o.value)).join(', ') :
                          SortedQualifySkills.map(o => (o.value)).slice(0, 20).join(', ')}
                        {
                          (profileInfo.quaSkills.length >= 20) ?
                            <strong>
                              <LinkButton onClick={this.showMore}>
                                {this.state.showMore ? '- Show less' : profileInfo.quaSkills.length > 20 &&
                                `+${(profileInfo.quaSkills.length - 20)} more` }
                              </LinkButton>
                            </strong>
                            :
                          null
                        }
                      </div>
                    :
                      <SmartList
                        requiredSkills={requiredSkills}
                        highlight={sortAll(profileInfo.skills, 'value', 'asc', 'string').map(skill => (skill.value))}
                        skills={sortAll(profileInfo.skills, 'value', 'asc', 'string')}
                      />
                    }
                  </div>
                </div>
                <div className="skills">
                  <label htmlFor="label" className="label" />
                  <div className="value">
                    <UnmatchedList
                      requiredSkills={unmatchedSkills}
                      skills={sortAll(profileInfo.skills, 'value', 'asc', 'string')}
                    />
                  </div>
                </div>
                {
                  this.state.fullScreen &&
                  <Fragment>
                    <div className="skills">
                      <label htmlFor="qualification" className="label">{this.props.translate('qualifications')}</label>
                      <div className="value">
                        { profileInfo.qualifications.map(q => (q.degree)).join(', ') || 'NA'}
                      </div>
                    </div>
                    <div className="skills">
                      <label htmlFor="certifications" className="label">{this.props.translate('candidateCertification')}</label>
                      <div className="value">
                        { profileInfo.certification_licence.Name || 'NA' }
                      </div>
                    </div>
                  </Fragment>
                }
              </main>
              {this.state.fullScreen &&
              <aside>
                <h3>Last Updated: <strong>{profileInfo.lastUpdated ? <MomentTranslate fromNow={profileInfo.lastUpdated} /> : '-'}</strong></h3>
                <h3>Available: <strong>{profileInfo.available ? 'Available' : 'Not Available'}</strong></h3>
              </aside>
              }

            </DialogContent>
          </ReduxBlockUI>
        </Dialog>
      </span>
    );
  }
}

CandidateProfile.propTypes = {
  translate: PropTypes.func.isRequired,
  getProfileInfo: PropTypes.func,
  candidate: PropTypes.object, // eslint-disable-line
  actionMenuItems: PropTypes.objectOf(PropTypes.any), // eslint-disable-line
  selectedCandidateProfile: PropTypes.object, // eslint-disable-line
  classes: PropTypes.object.isRequired, // eslint-disable-line
  candidateProfileLoading: PropTypes.bool,
  flushSelectedCandidateProfile: PropTypes.func,
  openAddToJobDialog: PropTypes.func,
  getJobApplicationListCustomer: PropTypes.func,
  getData: PropTypes.func.isRequired,
  moveJobApplication: PropTypes.func.isRequired,
  jobId: PropTypes.string,
  label: PropTypes.string,
  appId: PropTypes.string,
};

CandidateProfile.defaultProps = {
  openAddToJobDialog: () => {},
  getJobApplicationListCustomer: () => {},
  getData: () => {},
  candidateProfileLoading: false,
  getProfileInfo: () => {},
  candidate: {},
  selectedCandidateProfile: {},
  flushSelectedCandidateProfile: () => {},
  jobId: '',
  type: '',
  label: '',
  appId: '',
  actionMenuItems: {},
};

const mapDispatchToProps = dispatch => ({
  getProfileInfo: (jobId, profileId) => dispatch(getProfileInfo(jobId, profileId)),
  moveJobApplication: (jobId, status) => dispatch(moveJobApplication(jobId, status)),
  flushSelectedCandidateProfile: () => dispatch(flushSelectedCandidateProfile()),
  getTempToken: (id) => dispatch(getTempToken(id)),
  getJobApplicationListCustomer: (jobId, status, pageNo, pageSize) =>
    dispatch(getJobApplicationListCustomer(jobId, status, pageNo, pageSize))
});

function mapStateToProps(state) {
  return ({
    selectedCandidateProfile: state.recruiter.selectedCandidateProfile,
    candidateProfileLoading: state.recruiter.candidateProfileLoading,
  });
}

export default
connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(withTranslate(CandidateProfile)));
