import React, { Component, Fragment } from 'react';
import { PropTypes } from 'prop-types';
import _ from 'lodash';
import LinkButton from '../basic/LinkButton';
import { sortAll } from '../../utils/index';

class UnmatchedList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showMore: false,
      showMoreHighlights: false,
      showMoreGroups: false,
      showChildValues: false,
      selectedGroup: '',
      childValues: [],
    };
    this.showMore = this.showMore.bind(this);
    this.showMoreHighlights = this.showMoreHighlights.bind(this);
    this.showMoreGroups = this.showMoreGroups.bind(this);
    this.renderGroups = this.renderGroups.bind(this);
  }

  showMore() {
    this.setState({ showMore: !this.state.showMore });
  }
  showMoreHighlights() {
    this.setState({ showMoreHighlights: !this.state.showMoreHighlights });
  }
  showMoreGroups() {
    this.setState({ showMoreGroups: !this.state.showMoreGroups });
  }

  showChildValues(items, group) {
    this.setState({ showChildValues: true, selectedGroup: group, childValues: items }, () => {
      if (this.unmatchedSkillsSection) {
        if (!this.dialogParent) {
          let elem = this.unmatchedSkillsSection;
          while (elem.className !== 'dialog') {
            elem = elem.parentNode;
          }
          this.dialogParent = elem.parentNode;
        }
        this.dialogParent.scrollTo(0, this.unmatchedSkillsSection.offsetTop);
      }
    });
  }

  hideChildValues() {
    this.setState({ showChildValues: false, selectedGroup: null, childValues: [] });
  }

  renderGroups() {
    const { requiredSkills } = this.props;
    const groupSkills = _.groupBy(requiredSkills, 'group') || '';
    const groupData = _.sortBy(_.map(groupSkills, (group, index) => (
      {
        name: index,
        items: sortAll(_.uniqBy([...group], obj => obj.value.toLowerCase()), 'value', 'asc'),
      }
    )), 'name');
    return groupData.filter(data => data.items.length >= 3).map(group =>
      (
        <li key={group.name} className="item">
          <strong> {group.name}
            <button className="count-btn" onClick={() => this.showChildValues(group.items, group.name)}>{`[${group.items.length}]`}</button>
          </strong>
        </li>
      ));
  }


  render() {
    const { requiredSkills } = this.props;
    const groupSkills = _.groupBy(requiredSkills, 'group') || '';
    const groupLength = (Object.keys(groupSkills).length);
    return (
      <Fragment>
        {
          <div>
            <ul className="smart-list highlights">
              {this.state.showMoreHighlights ? this.renderGroups() :
              _.slice(this.renderGroups(), 0, 15)}
              {
              (groupLength > 15) ?
                <li className="item">
                  <strong>
                    <LinkButton onClick={this.showMoreHighlights}>
                      {this.state.showMoreHighlights ? '- Show less' : groupLength > 5 &&
                      `+${(groupLength - 15)} more` }
                    </LinkButton>
                  </strong>
                </li> :
                <li />
            }
            </ul>
            <div>
              {
                this.state.showChildValues &&
                <div
                  className="unmatched-skills"
                  ref={(section) => { this.unmatchedSkillsSection = section; }}
                >
                  <div>
                    <h2>{this.state.selectedGroup}</h2>
                    <button onClick={() => this.hideChildValues()} className="close-button">
                      x
                    </button>
                  </div>
                  <strong>{
                    this.state.childValues.map((item, index) => `${item.value}${(this.state.childValues.length - 1 !== index) ? ',' : ''} `)
                  }
                  </strong>
                </div>
              }
            </div>
          </div>
        }
      </Fragment>
    );
  }
}

UnmatchedList.propTypes = {
  requiredSkills: PropTypes.instanceOf(Object).isRequired,
};

export default UnmatchedList;
