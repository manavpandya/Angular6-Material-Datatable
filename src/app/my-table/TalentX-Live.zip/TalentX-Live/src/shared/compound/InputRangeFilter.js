import React, { Component } from 'react';
import { PropTypes } from 'prop-types';
import DeleteSweep from 'material-ui-icons/DeleteSweep';
import AddIcon from 'material-ui-icons/AddCircleOutline';
import SubtractIcon from 'material-ui-icons/RemoveCircleOutline';
import MoreIcon from 'material-ui-icons/MoreHoriz';
import IconButton from 'material-ui/IconButton';
import ClickAwayListener from 'material-ui/utils/ClickAwayListener';
import InputRange from 'react-input-range';
import 'react-input-range/lib/css/index.css';

class InputRangeFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      min: this.props.min,
      max: this.props.max,
      value: { min: 0, max: 0 },
      open: false,
    };
    this.handleClick = this.handleClick.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.startFilter = this.startFilter.bind(this);
    this.reset = this.reset.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.clearFilters) {
      this.setState({
        min: nextProps.min,
        max: nextProps.max,
        value: { min: 0, max: 0 },
      });
    }
  }

  handleClick() {
    this.setState({ open: !this.state.open });
  }

  summarize() {
    if (this.props.mode === 'range') {
      return this.hasSummary() ?
        <span className="summary">{this.state.value.min} - {this.state.value.max} y</span>
        :
        <MoreIcon />;
    }
    return this.hasSummary() ?
      <span className="summary">{this.state.value.min} y</span>
      :
      <MoreIcon />;
  }

  hasSummary() {
    return this.props.mode === 'range' ?
      this.state.value.min !== 0 || this.state.value.max !== 0 :
      this.state.value.min !== 0 && this.state.value.max !== 0;
  }

  handleClose() {
    this.setState({ open: false });
  }

  decrement() {
    if (this.state.value.min !== this.state.min) {
      const value = this.state.value.min - 1;
      this.setState({ value: { min: value, max: value } });
    }
  }

  increment() {
    if (this.state.value.min !== this.state.max) {
      const value = this.state.value.min + 1;
      this.setState({ value: { min: value, max: value } });
    }
  }
  startFilter(values) {
    this.props.passTalent(values);
  }

  reset() {
    if (this.props.filterParam) {
      this.setState({ value: { min: 0, max: 0 } });
      this.props.reset();
    }
  }

  renderRange() {
    return (
      <InputRange
        formatLabel={value => `${value}`}
        maxValue={this.state.max}
        minValue={this.state.min}
        value={this.state.value}
        onChange={value => this.setState({ value })}
        onChangeComplete={value => this.startFilter({ value })}
      />
    );
  }

  renderCounter() {
    return (
      <div className="counter">
        <IconButton className="decrement-btn" onClick={this.decrement}>
          <SubtractIcon />
        </IconButton>
        <h3>{this.state.vale.min }</h3>
        <IconButton className="increment-btn" onClick={this.increment}>
          <AddIcon />
        </IconButton>
        <h3>Years</h3>
      </div>
    );
  }

  render() {
    return (
      <div className="input-number years">
        <div className="extra">
          <IconButton className="btn" onClick={this.handleClick}>
            { this.summarize() }
          </IconButton>
          { this.state.open &&
            <ClickAwayListener onClickAway={this.handleClose}>
              <div className="popup">
                { this.props.mode === 'range' ? this.renderRange() : this.renderCounter() }
              </div>
            </ClickAwayListener>
          }
        </div>
        <DeleteSweep className="pointer" onClick={this.reset} />
      </div>
    );
  }
}

InputRangeFilter.propTypes = {
  min: PropTypes.number.isRequired,
  max: PropTypes.number.isRequired,
  mode: PropTypes.string.isRequired,
  passTalent: PropTypes.func,
  reset: PropTypes.func.isRequired,
  filterParam: PropTypes.string,
  // isNewSearch: PropTypes.bool,
  clearFilters: PropTypes.bool,
};
InputRangeFilter.defaultProps = {
  passTalent: () => {},
  filterParam: '',
  // isNewSearch: true,
  clearFilters: false,
};


export default InputRangeFilter;
