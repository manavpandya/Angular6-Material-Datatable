import React from 'react';
import Input from 'material-ui/Input';

const MultiSelect = () => (
  <div>
    <Input
      type="text"
      placeholder={this.props.placeholder}
      className="input-auto-complete"
    />
  </div>
);

export default MultiSelect;
