import React from 'react';
import protoType from 'prop-types';

const Avatar = (props) => {
  let {
    avatar, alt, size, border, // eslint-disable-line
  } = props;
  border = border || '#333333';
  size = size || 1;
  return (
    <img
      src={avatar}
      alt={alt}
      className="avatar"
      style={{
width: `${size * 2}rem`, height: `${size * 2}rem`, border: `1px solid ${border}`, overflow: 'hidden',
}}
    />
  );
};

Avatar.protoType = {
  avatar: protoType.string.isRequired,
  alt: protoType.string.isRequired,
  size: protoType.number.isRequired,
  border: protoType.number.isRequired,
};

export default Avatar;
