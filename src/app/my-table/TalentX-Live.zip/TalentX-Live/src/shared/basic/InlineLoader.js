import React from 'react';
import PropTypes from 'prop-types';

const InlineLoader = (props) => {
  const defaultColor = props.inverted ? '#0c0c0c' : '#f3f3f3';
  const color = props.color ? props.color : defaultColor;
  return (
    <div className={`inline-loader-container ${props.className}`} style={props.style}>
      <div
        className="inline-loader"
        style={{
          borderColor: props.inverted ? 'rgba(0, 0, 0, 0.2)' : 'rgba(255, 255, 255, 0.2)',
          borderWidth: props.thickness,
          borderTopColor: color,
          // borderTopWidth: props.thickness - 1,
          height: props.height,
          width: props.width,
        }}
      />
    </div>
  );
};

InlineLoader.propTypes = {
  color: PropTypes.string,
  inverted: PropTypes.bool,
  thickness: PropTypes.number,
  height: PropTypes.number,
  width: PropTypes.number,
  className: PropTypes.string,
  style: PropTypes.objectOf(PropTypes.any),
};

InlineLoader.defaultProps = {
  color: '#f3f3f3',
  inverted: false,
  thickness: 2,
  height: 12,
  width: 12,
  className: '',
  style: {},
};

export default InlineLoader;
