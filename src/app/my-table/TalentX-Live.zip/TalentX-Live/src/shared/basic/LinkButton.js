import React from 'react';
import PropTypes from 'prop-types';

const LinkButton = props => (
  <button {...props} className={`link-button ${props.className}`} />
);

LinkButton.propTypes = {
  className: PropTypes.string,
};

LinkButton.defaultProps = {
  className: '',
};

export default LinkButton;
