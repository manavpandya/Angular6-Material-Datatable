// import React from 'react';
import { connect } from 'react-redux';
import moment from 'moment';
import 'moment/locale/en-gb';
import 'moment/locale/es';

const MomentTranslate = props => (
  moment(props.fromNow).lang(props.locale).fromNow()
);

const mapStateToProps = state => ({
  ...state.Intl,
});

export default connect(mapStateToProps, null)(MomentTranslate);

