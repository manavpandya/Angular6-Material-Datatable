import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { withTranslate } from 'react-redux-multilingual';
import Paper from 'material-ui/Paper';
import { logoutFunction } from '../../modules/auth/redux/actions';

const AccessDenied = props => (
  <Paper className="authentication widget">
    <div className="authentication-header">
      <div className="not-found">
        <h1>403</h1>
        <br />
        <p>{props.translate('accessDenied')}</p>
        <br />
        <Link to="/" onClick={props.logout}>{props.translate('logout')}</Link>
      </div>
    </div>
  </Paper>
);

const mapDispatchToProps = dispatch => ({
  logout: () => dispatch(logoutFunction()),
});

AccessDenied.propTypes = {
  logout: PropTypes.func,
  translate: PropTypes.func,
};

AccessDenied.defaultProps = {
  logout: () => {},
  translate: () => {},
};

export default connect(null, mapDispatchToProps)(withTranslate(AccessDenied));
