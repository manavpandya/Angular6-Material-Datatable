import React, { Component } from 'react';
import PropTypes from 'prop-types';
// import approx from 'approximate-number';

// const format = (num) => {
//   if (num >= 1000) {
//     return approx(num).toUpperCase();
//   }
//   return num.toString();
// };

class Metric extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { htmlFor, value, label } = this.props;
    return (
      <div className="metrics">
        <label htmlFor={htmlFor}>
          <strong>{ (value <= 100) ? value.toString() : '100+' }</strong>
          <span>{label}</span>
        </label>
      </div>
    );
  }
}

Metric.propTypes = {
  htmlFor: PropTypes.string,
  value: PropTypes.number,
  label: PropTypes.string,
};

Metric.defaultProps = {
  htmlFor: '',
  value: 0,
  label: '',
};

export default Metric;
