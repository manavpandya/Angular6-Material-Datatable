import React from 'react';

const LoaderForSearch = ({ forDownload = false, className }) => <div className={`loaderForSearch ${forDownload && ' forDownload'} ${className}`} />; //eslint-disable-line

export default LoaderForSearch;
