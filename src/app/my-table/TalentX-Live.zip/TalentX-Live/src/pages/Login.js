import React from 'react';
import { LoginContainer } from '../modules/auth';

const Login = () => (
  <LoginContainer />
);

export default Login;
