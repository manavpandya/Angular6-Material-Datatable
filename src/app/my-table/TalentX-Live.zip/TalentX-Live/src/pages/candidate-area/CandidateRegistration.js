import React from 'react';
import CandidateRegistrationContainer from '../../modules/candidate-area/CandidateRegistrationContainer';

const CandidateRegistration = () => (
  <CandidateRegistrationContainer />
);

export default CandidateRegistration;
