import React from 'react';
import CandidateProfileContainer from '../../modules/candidate-area/candidateProfileContainer';

const CandidateProfile = () => (
  <CandidateProfileContainer />
);

export default CandidateProfile;
