import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Typography from 'material-ui/Typography';
import { change } from 'redux-form';
import Button from 'material-ui/Button';
import AddSkillsFormForDashboard from '../../modules/candidate-area/components/AddSkillsFormForDashboard';
import BoardHeader from '../../shared/compound/board/BoardHeader';
import CardBoxWithPicture from '../../modules/candidate-area/components/CardBoxWithPicture';
import ProfileCard from '../../modules/candidate-area/components/ProfileCard';

const saveSkills = ({ values }) => { // eslint-disable-line
  // write actions here for saving code !!
};

class DashboardContainer extends Component {
  constructor(props) {
    super(props);
    this.handleChangeMultiSkills = this.handleChangeMultiSkills.bind(this);

    this.state = {
      multiSkillsValue: null,
    };
  }

  handleChangeMultiSkills(multiSkillsValue) {
    this.props.dispatch(change('AddSkillsForm', 'multiSkills', multiSkillsValue));
    this.setState({ multiSkillsValue });
  }

  render() {
    return (
      <div className="page">
        <BoardHeader />
        <div className="bg-white">
          <section className="section-container">
            <div className="profile-cards-container-header">
              <Typography variant="headline" component="h2">
              Jobs that match your profile
              </Typography>
              <Button size="medium" >
              VIEW ALL JOBS
              </Button>
            </div>
            <div className="profile-cards-container">
              <CardBoxWithPicture imageSrc="http://via.placeholder.com/350x150" value="55%" title="JOB XYZ" description="from props, checkout." /> {/* example to send props */}
              <CardBoxWithPicture />
              <CardBoxWithPicture />
              <CardBoxWithPicture />
              <CardBoxWithPicture />
            </div>
          </section>

          <section className="section-container for-profile-form">
            <div className="profile-cards-container-header">
              <Typography variant="headline" component="h2">
              Get better matches
              </Typography>
            </div>
            <div className="view-profile-with-container-form">
              <ProfileCard ImageSrc="http://i.pravatar.cc/350" />
              <AddSkillsFormForDashboard
                multiSkillsValue={this.state.multiSkillsValue}
                handleChangeMultiSkills={this.handleChangeMultiSkills}
                saveSkills={saveSkills}
              />
              <div className="highest-possible-match-container">
                <Typography component="p">
                Highest match possible
                </Typography>
                <Typography className="highest-possible-match">
                72.3%
                </Typography>
              </div>
            </div>
          </section>

          <section className="section-container">
            <div className="profile-cards-container-header">
              <Typography variant="headline" component="h2">
                Upcoming Projects
              </Typography>
            </div>
            <div className="profile-cards-container">
              <CardBoxWithPicture
                imageSrc="http://via.placeholder.com/350x150"
                value="300+ Positions"
                title="JOB XYZ"
                description="from props, checkout."
              />
              <CardBoxWithPicture />
              <CardBoxWithPicture />
              <CardBoxWithPicture />
              <CardBoxWithPicture />
            </div>
          </section>
        </div>
      </div>
    );
  }
}

DashboardContainer.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapDispatchToProps = dispatch => ({
  dispatch,
});

export default connect(null, mapDispatchToProps)(DashboardContainer);
