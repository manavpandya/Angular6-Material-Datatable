import React from 'react';
import NormalizeTaxonomyContainer from '../modules/NormalizeTaxonomy';

const NormalizeTaxonomy = () => (<NormalizeTaxonomyContainer />);

export default NormalizeTaxonomy;
