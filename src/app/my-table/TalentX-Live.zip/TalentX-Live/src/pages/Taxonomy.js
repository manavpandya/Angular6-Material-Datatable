import React from 'react';
import TaxonomyContainer from '../modules/manage-taxonomy';

const Taxonomy = () => (
  <TaxonomyContainer />
);

export default Taxonomy;
