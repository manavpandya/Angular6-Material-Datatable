import React from 'react';
import CustomerHeader from '../modules/customer-area/components/SuperCustomerHeader';
import CustomerDashboardContainer from '../modules/customer-area/components/CustomerDashboard/CustomerDashboardContainer';

const CustomerArea = props => (
  <div>
    <CustomerHeader {...props} />
    <CustomerDashboardContainer />
  </div>
);

export default CustomerArea;
