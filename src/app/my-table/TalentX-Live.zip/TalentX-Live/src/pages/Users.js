import React from 'react';

import UsersContainer from '../modules/manage-users';

const Users = () => (
  <UsersContainer />
);

export default Users;
