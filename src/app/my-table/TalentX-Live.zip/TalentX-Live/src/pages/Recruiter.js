import React from 'react';
import RecruiterContainer from '../modules/jobs/RecruiterContainer';

const Recruiter = () => (<RecruiterContainer />);

export default Recruiter;
