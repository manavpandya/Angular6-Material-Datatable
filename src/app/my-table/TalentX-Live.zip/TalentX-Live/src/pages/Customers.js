import React from 'react';

import CustomersContainer from '../modules/manage-customers';

const Customers = () => (
  <CustomersContainer />
);

export default Customers;
