export default function (term) {
  const path = term.taxonomy_path;
  let level;
  if (path) {
    const pathSplit = path.split('/');
    level = pathSplit.length + 1;
  } else {
    level = 1;
  }
  return level;
}
