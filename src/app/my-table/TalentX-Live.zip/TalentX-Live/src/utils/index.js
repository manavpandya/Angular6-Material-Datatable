export const camelize = str => str.replace(/(?:^\w|[A-Z]|\b\w)/g, (letter, index) => {
  if (index === 0) return letter.toLowerCase();
  return letter.toUpperCase();
}).replace(/\s+/g, '');

export function sortAll(arr, key = 'key', direction = 'asc', type = 'string') {
  return arr.sort((a, b) => {
    let keyA;
    let keyB;
    if (type === 'string') {
      keyA = a[key].toLowerCase();
      keyB = b[key].toLowerCase();
    }
    if (type === 'number') {
      keyA = parseInt(a[key], 2);
      keyB = parseInt(b[key], 2);
    }
    if (type === 'date') {
      keyA = new Date(a[key]);
      keyB = new Date(b[key]);
    }
    if (direction === 'desc') {
      if (keyA < keyB) return 1;
      if (keyA > keyB) return -1;
    } else {
      if (keyA < keyB) return -1;
      if (keyA > keyB) return 1;
    }
    return 0;
  });
}

export const convertFirstLetterToUppercase = (word) => {
  const fuc = word[0].toUpperCase();
  return fuc.concat(word.slice(1, word.length));
};

export const getMultiSortedValues = (arr, key, num) =>
  arr.sort((a, b) => {
    if (a[num] === b[num]) return a[key].localeCompare(b[key]);
    return b[num] - a[num];
  });

export const convertString = (key) => {
  const words = key.split('_');
  let fullName = '';
  words.map((word) => {
    fullName = fullName.concat(convertFirstLetterToUppercase(word));
    fullName = fullName.concat(' ');
    return fullName;
  });
  return fullName;
};

export const minMax = (array, prop) => {
  let min = '';
  let max = '';
  if ((array.length > 0 && prop)) {
    min = parseInt(array[0][prop], 10) || 0;
    max = parseInt(array[0][prop], 10) || 0;
    array.forEach((obj) => {
      if (parseInt(obj[prop], 10) > max) {
        max = obj[prop];
      }
      if (parseInt(obj[prop], 10) < min) {
        min = obj[prop];
      }
    });
  }
  return { min, max };
};


export const roundToClosest = (number, closeTo) => Math.round(number / closeTo) * closeTo;
export const formatMatched = num => ((num <= 100) ? `${num}` : '100+');

export const getOptions = (url, key, input) => {
  const token = `Bearer ${JSON.parse(localStorage.getItem('user_info'))}`;
  if (!input) {
    return Promise.resolve({ options: [] });
  }
  return fetch(url + input, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      Authorization: token,
    },
  }).then(response => response.json())
    .then(json => ({ options: json[key] }));
};
