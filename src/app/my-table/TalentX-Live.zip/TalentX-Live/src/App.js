import React from 'react';
import PropTypes from 'prop-types';
import moment from 'moment';
import { connect } from 'react-redux';
import 'normalize.css/normalize.css';
import { ToastContainer } from 'react-toastify'; // Initialize Notification Container
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import MomentUtils from 'material-ui-pickers/utils/moment-utils';
import MuiPickersUtilsProvider from 'material-ui-pickers/utils/MuiPickersUtilsProvider';
import 'react-block-ui/style.css';
import Routes from './routes';
import TalentXTheme from './assets/styles/TalentXTheme'; // Theme

const App = (props) => {
  moment.locale(props.locale);
  return (
    <MuiPickersUtilsProvider utils={MomentUtils} moment={moment} locale={props.locale}>
      <MuiThemeProvider theme={TalentXTheme}>
        <ToastContainer id="forToast" />
        <Routes />
      </MuiThemeProvider>
    </MuiPickersUtilsProvider>
  );
};

const mapStateToProps = state => ({
  locale: state.Intl.locale,
});

App.propTypes = {
  locale: PropTypes.string.isRequired,
};

export default connect(mapStateToProps)(App);
