import _ from 'lodash';
import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import Button from 'material-ui/Button';
import ClearIcon from 'material-ui-icons/Clear';
import SearchIcon from 'material-ui-icons/Search';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import BlockUi from 'react-block-ui';
import { fetchTaxonomyTree } from '../redux/actions';
import TaxonomyTreeFolder from './TaxonomyTreeFolder';

class TaxonomyTree extends Component {
  constructor(props) {
    super(props);
    this.state = {
      hoveredTerm: null,
      expandTree: true,
      loading: false,
      searchString: '',
      showSearchBar: false,
    };
    this.passSearchPhrase = this.passSearchPhrase.bind(this);
    this.debouncedPassPhrase = _.debounce(this.passPhrase, 2000);
    this._onHover = this._onHover.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.fetchTreeLoading) {
      this.setState({
        loading: false,
      });
    }
  }

  _onHover(value) {
    this.setState({
      hoveredTerm: value,
    });
  }
  handleSearch() {
    this.setState({
      showSearchBar: !this.state.showSearchBar,
    });
  }
  passPhrase() {
    this.setState({
      loading: false,
    });
    this.props.onSearch(this.state.searchString);
  }
  passSearchPhrase(e) {
    this.setState({
      loading: true,
      searchString: e.target.value,
    });
    this.debouncedPassPhrase();
  }

  renderItems() {
    return _.map(this.props.taxonomy, (termitem, termIndex) => {
      const term = { ...termitem };
      term.index = termIndex;
      return (
        <li
          key={term.id}
        >
          <TaxonomyTreeFolder
            isSearchTaxonomy={this.props.isSearchTaxonomy}
            selectedTreeId={this.props.selectedTreeId}
            updateSelectedTreeId={this.props.updateSelectedTreeId}
            deleteTermSuccess={this.props.deleteTermSuccess}
            deleteTermError={this.props.deleteTermError}
            term={term}
            onHover={this._onHover}
            hoveredTerm={this.state.hoveredTerm}
            onTermSelect={this.props.onTermSelect}
            onNewTermParentSelect={this.props.onNewTermParentSelect}
            expandTree={this.state.expandTree}
            updateSelectedTreeItem={this.props.updateSelectedTreeItem}
            fetchTreeLoading={this.props.fetchTreeLoading}
            fetchNodeSuccess={this.props.fetchNodeSuccess}
            selectedTerm={this.props.selectedTerm}
            createTermSuccess={this.props.createTermSuccess}
            updateTermLoading={this.props.updateTermLoading}
            deleteTaxonomyTerm={this.props.deleteTaxonomyTerm}
          />
        </li>
      );
    });
  }

  render() {
    const {
      searchInput, searchPhrase, resetTaxonomyState,
    } = this.props;
    const taxonomyTree = !this.props.taxonomy.length ? <h1>No Result Found</h1> :
      this.renderItems();
    return (
      <div>
        <TextField
          className={`search ${this.state.showSearchBar ? 'showSearch' : 'hideSearch'}`}
          style={{ marginLeft: '10px', marginTop: '10px' }}
          id="taxonomy"
          autoFocus
          value={this.state.searchString}
          onInput={this.passSearchPhrase}
          onChange={(e) => {
            searchInput(e.target.value);
            }}
        />
        {
            searchPhrase ?
              <Button
                className="search-button"
                size="small"
                onClick={() => {
                  this.setState({ searchString: '' });
                  resetTaxonomyState();
                  searchInput('');
                  this.props.onSearch('');
                  }
                }
              > <ClearIcon />
              </Button>
            :
              <Button
                className="search-button"
                size="small"
              >
                <SearchIcon />
              </Button>
          }
        <ul className="tree taxonomy">
          {this.props.fetchTreeLoading ? <h1>Loading...</h1> :
          <BlockUi blocking={this.state.loading || this.props.updateTermLoading}>
            {!this.props.searchingTaxonomy && taxonomyTree}
          </BlockUi>}
        </ul>
      </div>
    );
  }
}

TaxonomyTree.propTypes = {
  taxonomy: PropTypes.arrayOf(PropTypes.any),
  onTermSelect: PropTypes.func.isRequired,
  onNewTermParentSelect: PropTypes.func.isRequired,
  onSearch: PropTypes.func.isRequired,
  deleteTermSuccess: PropTypes.bool,
  deleteTermError: PropTypes.bool,
  selectedTreeId: PropTypes.objectOf(Object).isRequired,
  updateSelectedTreeId: PropTypes.func,
  updateSelectedTreeItem: PropTypes.func.isRequired,
  fetchNodeSuccess: PropTypes.bool,
  selectedTerm: PropTypes.objectOf(PropTypes.any),
  createTermSuccess: PropTypes.bool.isRequired,
  deleteTaxonomyTerm: PropTypes.func.isRequired,
  isSearchTaxonomy: PropTypes.bool.isRequired,
  updateTermLoading: PropTypes.bool.isRequired,
  fetchTreeLoading: PropTypes.bool.isRequired,
  searchingTaxonomy: PropTypes.bool.isRequired,
  searchInput: PropTypes.func.isRequired,
  searchPhrase: PropTypes.string.isRequired,
  resetTaxonomyState: PropTypes.func.isRequired,
};

TaxonomyTree.defaultProps = {
  taxonomy: [],
  selectedTerm: null,
  deleteTermSuccess: false,
  deleteTermError: false,
  updateSelectedTreeId: () => {},
  fetchNodeSuccess: false,
};

function mapStateToProps(state) {
  return {
    search: state.search,
    searchingTaxonomy: state.taxonomy.searchingTaxonomy,
    fetchTreeLoading: state.taxonomy.fetchTreeLoading,
    isSearchTaxonomy: state.taxonomy.searchingTaxonomy,
    selectedTreeId: state.taxonomy.selectedTreeId,
    fetchNodeSuccess: state.taxonomy.fetchNodeSuccess,
  };
}

export default connect(mapStateToProps, { fetchTaxonomyTree })(TaxonomyTree);
