import _ from 'lodash';
import React, { Component } from 'react';
import { change } from 'redux-form';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
// import TaxonomyHeader from '../../modules/manage/TaxonomyHeader';
import { TaxonomyEdit, TaxonomyNew, TaxonomyTree } from './components';
import { fetchTaxonomyTree, setSelectedTerm, setNewTermParent, deleteTaxonomyTerm,
  updateTaxonomyTerm, createTaxonomyTerm, updateSelectedTreeId, updateSelectedTreeItem, resetTaxonomyState, searchTree } from './redux/actions';
import BoardHeader from '../../shared/compound/board/BoardHeader';
import { logoutFunction } from '../auth/redux/actions';
import { showNotification } from '../../utils/Notifications';
import detectTreeLevel from '../../utils/detectTreeLevel';

class Taxonomy extends Component {
  constructor(props) {
    super(props);

    this.setSelectedTerm = this.setSelectedTerm.bind(this);
    this.setNewTermParent = this.setNewTermParent.bind(this);
    this.updateTaxonomyTerm = this.updateTaxonomyTerm.bind(this);
    this.createTaxonomyTerm = this.createTaxonomyTerm.bind(this);
    this.onSearch = this.onSearch.bind(this);
    this.deleteTaxonomyTerm = this.deleteTaxonomyTerm.bind(this);
    this.searchInput = this.searchInput.bind(this);
    this.resetAndGetData = this.resetAndGetData.bind(this);
    this.state = {
      searchPhrase: '',
    };
  }


  componentDidMount() {
    this.props.fetchTaxonomyTree();
  }
  componentWillReceiveProps(nextProps) {
    // On Initial Tree Load
    // QUICK FIX FOR EXPANDING TAXONOMY TREE IF ONLY ONE RECORD |  && nextProps.taxonomy.length
    if (nextProps.fetchTreeSuccess) {
      this.props.resetTaxonomyState();
      this.props.updateSelectedTreeId({
        data: {
          GGPid: null,
        },
        index: {
          GGPid: 0,
        },
        level: 1,
      });
      this.props.updateSelectedTreeItem(nextProps.taxonomy[0].id);
    }

    // When Term updated
    if (nextProps.updateTermLoaded) {
      showNotification(this.props.translate('taxonomyUpdated'), 'success', 8000);
      const level = detectTreeLevel(nextProps.newlyCreatedTerm);
      switch (level) {
        case 1: {
          this.props.resetTaxonomyState();
          this.props.updateSelectedTreeItem(nextProps.newlyCreatedTerm.parent_id);
          break;
        }
        case 2: {
          this.props.resetTaxonomyState();
          this.props.updateSelectedTreeId({
            data: {
              GGPid: nextProps.newlyCreatedTerm.parent_id,
              GPid: null,
            },
            level: 1,
          });
          this.props.updateSelectedTreeItem(nextProps.newlyCreatedTerm.parent_id);
          break;
        }
        case 3: {
          this.props.resetTaxonomyState();
          this.props.updateSelectedTreeId({
            data: {
              GPid: nextProps.newlyCreatedTerm.parent_id,
              Pid: null,
            },
            level: 2,
          });
          this.props.updateSelectedTreeItem(nextProps.newlyCreatedTerm.parent_id);
          break;
        }
        case 4: {
          this.props.resetTaxonomyState();
          this.props.updateSelectedTreeId({
            data: {
              id: null,
            },
            level: 3,
          });
          this.props.updateSelectedTreeItem(this.props.selectedTreeId.Pid);
          break;
        }
        default:
          break;
      }
      // this.props.setSelectedTerm(null);
    }
    // When new Term Created
    if (nextProps.createTermSuccess) {
      showNotification(this.props.translate('taxonomyAdded'), 'success', 8000);
      const level = detectTreeLevel(nextProps.newlyCreatedTerm) - 1;
      switch (level) {
        case 1:
          this.props.updateSelectedTreeId({
            data: {
              GGPid: nextProps.newlyCreatedTerm.parent_id,
            },
            level,
          });
          this.props.updateSelectedTreeItem(nextProps.newlyCreatedTerm.parent_id);
          break;
        case 2:
          this.props.updateSelectedTreeId({
            data: {
              GPid: nextProps.newlyCreatedTerm.parent_id,
            },
            level,
          });
          this.props.updateSelectedTreeItem(nextProps.newlyCreatedTerm.parent_id);
          break;
        case 3:
          this.props.updateSelectedTreeId({
            data: {
              Pid: nextProps.newlyCreatedTerm.parent_id,
            },
            level,
          });
          this.props.updateSelectedTreeItem(nextProps.newlyCreatedTerm.parent_id);
          break;
        case 4:
          // THIS NEED TO BE TEST
          // this.props.updateSelectedTreeId({
          //   data: {
          //     Pid: nextProps.newlyCreatedTerm.parent_id,
          //     id: nextProps.newlyCreatedTerm.id,
          //   },
          //   level,
          // });
          // this.props.updateSelectedTreeItem(nextProps.newlyCreatedTerm.parent_id);
          break;
        default:
          break;
      }
      this.props.setNewTermParent(null);
    }
    // When new Term Deleted
    if (nextProps.deleteTermSuccess) {
      showNotification(this.props.translate('taxonomyDeleted'), 'success', 8000);
      this.props.resetTaxonomyState();
      this.props.updateSelectedTreeItem(nextProps.deletedTerm.parentId);
      this.props.updateSelectedTreeId({
        level: nextProps.deletedTerm.level - 1,
      });
    }
  }

  onSearch(phrase) {
    this.setState({
      searchPhrase: phrase,
    });
    if (phrase.length) {
      this.props.searchTree(phrase);
    } else {
      this.props.fetchTaxonomyTree();
    }
  }
  setSelectedTerm(selectedTerm) {
    this.props.setNewTermParent(null);
    this.props.setSelectedTerm(selectedTerm);
  }
  setNewTermParent(parentTerm) {
    this.props.setSelectedTerm(null);
    this.props.setNewTermParent(parentTerm);
  }
  deleteTaxonomyTerm(id, deletedTerm) {
    this.props.deleteTaxonomyTerm(id, deletedTerm);
  }
  updateTaxonomyTerm(id, values) {
    this.props.updateTaxonomyTerm(id, values)
      .catch(() => showNotification(this.props.translate('taxonomyFailedToUpdate'), 'error', 8000));
  }
  createTaxonomyTerm(values) {
    this.props.createTaxonomyTerm(values);
  }

  searchInput(v) {
    this.setState({
      searchPhrase: v || '',
    });
  }

  resetAndGetData() {
    this.props.resetSynonyms();
    this.searchInput('');
    this.props.dispatch(change('searchForm', 'search_term', null));
    this.props.getAllSynonymsAction();
  }

  render() {
    return (
      <div className="page">
        {/* <TaxonomyHeader /> */}
        <BoardHeader logoutFunction={this.props.logoutFunction} />
        <div className="page taxonomy">
          <section className="board">
            <aside>
              <TaxonomyTree
                taxonomy={
                    this.props.searchTaxonomy
                      ? this.props.searchedTree
                      : this.props.taxonomy
                  }
                updateTermLoading={this.props.updateTermLoading}
                searchPhrase={this.state.searchPhrase}
                onTermSelect={this.setSelectedTerm}
                onSearch={this.onSearch}
                onNewTermParentSelect={this.setNewTermParent}
                deleteTermSuccess={this.props.deleteTermSuccess}
                deleteTermError={this.props.deleteTermError}
                deleteTaxonomyTerm={this.deleteTaxonomyTerm}
                createTermSuccess={this.props.createTermSuccess}
                updateSelectedTreeId={this.props.updateSelectedTreeId}
                updateSelectedTreeItem={this.props.updateSelectedTreeItem}
                search={this.state.search}
                searchInput={this.searchInput}
                resetTaxonomyState={this.props.resetTaxonomyState}
              />
            </aside>
            {
                !_.isEmpty(this.props.newTermParent) &&
                <TaxonomyNew
                  newTermParent={this.props.newTermParent}
                  onNewTermParentSelect={this.setNewTermParent}
                  createTaxonomyTerm={this.createTaxonomyTerm}
                  selectedTreeId={this.props.selectedTreeId}
                  updateSelectedTreeId={this.props.updateSelectedTreeId}
                />
              }
            {
                !_.isEmpty(this.props.selectedTerm) &&
                <TaxonomyEdit
                  taxonomy={this.props.taxonomy}
                  selectedTerm={this.props.selectedTerm}
                  onTermSelect={this.setSelectedTerm}
                  updateTaxonomyTerm={this.updateTaxonomyTerm}
                  deleteTaxonomyTerm={this.deleteTaxonomyTerm}
                  updateTermLoading={this.props.updateTermLoading}
                  fetchNodeSuccess={this.props.fetchNodeSuccess}
                  selectedTreeId={this.props.selectedTreeId}
                  updateSelectedTreeId={this.props.updateSelectedTreeId}
                  updateSelectedTreeItem={this.props.updateSelectedTreeItem}
                  nextFolder={this.props.nextFolder}
                  fetchNodeLoading={this.props.fetchNodeLoading}
                />
              }
          </section>
        </div>
      </div>
    );
  }
}

Taxonomy.propTypes = {
  translate: PropTypes.func.isRequired,
  deletedTerm: PropTypes.bool.isRequired,
  taxonomy: PropTypes.arrayOf(PropTypes.any).isRequired,
  selectedTerm: PropTypes.objectOf(PropTypes.any),
  newTermParent: PropTypes.objectOf(PropTypes.any),
  fetchTaxonomyTree: PropTypes.func.isRequired,
  setSelectedTerm: PropTypes.func.isRequired,
  setNewTermParent: PropTypes.func.isRequired,
  updateTaxonomyTerm: PropTypes.func.isRequired,
  createTaxonomyTerm: PropTypes.func.isRequired,
  updateTermLoading: PropTypes.bool.isRequired,
  updateTermLoaded: PropTypes.bool.isRequired,
  createTermSuccess: PropTypes.bool.isRequired,
  deleteTermSuccess: PropTypes.bool.isRequired,
  deleteTermError: PropTypes.bool.isRequired,
  deleteTaxonomyTerm: PropTypes.func.isRequired,
  logoutFunction: PropTypes.func.isRequired,
  selectedTreeId: PropTypes.objectOf(Object).isRequired,
  updateSelectedTreeId: PropTypes.func.isRequired,
  updateSelectedTreeItem: PropTypes.func.isRequired,
  newlyCreatedTerm: PropTypes.objectOf(Object).isRequired,
  resetTaxonomyState: PropTypes.func.isRequired,
  fetchNodeSuccess: PropTypes.bool.isRequired,
  fetchTreeSuccess: PropTypes.bool.isRequired,
  // searchingTaxonomy: PropTypes.bool.isRequired,
  searchedTree: PropTypes.arrayOf(Object).isRequired,
  searchTree: PropTypes.func.isRequired,
  searchTaxonomy: PropTypes.bool.isRequired,
  nextFolder: PropTypes.arrayOf(Object).isRequired,
  fetchNodeLoading: PropTypes.bool.isRequired,
  resetSynonyms: PropTypes.func,
  dispatch: PropTypes.func,
  getAllSynonymsAction: PropTypes.func,
};

Taxonomy.defaultProps = {
  selectedTerm: null,
  newTermParent: null,
  resetSynonyms: () => {},
  dispatch: () => {},
  getAllSynonymsAction: () => {},
};

function mapStateToProps(state) {
  return {
    taxonomy: state.taxonomy.tree,
    nextFolder: state.taxonomy.nextFolder,
    updateTermLoading: state.taxonomy.updateTermLoading,
    updateTermLoaded: state.taxonomy.updateTermLoaded,
    createTermSuccess: state.taxonomy.createTermSuccess,
    deleteTermSuccess: state.taxonomy.deleteTermSuccess,
    deleteTermError: state.taxonomy.deleteTermError,
    selectedTerm: state.taxonomy.setTerm,
    newTermParent: state.taxonomy.newTerm,
    newlyCreatedTerm: state.taxonomy.newlyCreatedTerm,
    selectedTreeId: state.taxonomy.selectedTreeId,
    fetchNodeSuccess: state.taxonomy.fetchNodeSuccess,
    deletedTerm: state.taxonomy.deletedTerm,
    fetchTreeSuccess: state.taxonomy.fetchTreeSuccess,
    searchingTaxonomy: state.taxonomy.searchingTaxonomy,
    searchedTree: state.taxonomy.searchedTree,
    searchTaxonomy: state.taxonomy.searchTaxonomy,
    fetchNodeLoading: state.taxonomy.fetchNodeLoading,
  };
}

export default connect(
  mapStateToProps,
  {
    fetchTaxonomyTree,
    setSelectedTerm,
    setNewTermParent,
    updateTaxonomyTerm,
    deleteTaxonomyTerm,
    createTaxonomyTerm,
    logoutFunction,
    updateSelectedTreeId,
    updateSelectedTreeItem,
    resetTaxonomyState,
    searchTree,
  },
)(withTranslate(Taxonomy));
