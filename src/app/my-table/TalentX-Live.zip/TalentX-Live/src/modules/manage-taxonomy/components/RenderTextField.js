import React from 'react';
import PropTypes from 'prop-types';
import TextField from 'material-ui/TextField';

const RenderTextField = (props) => {
  const { label, input, meta: { touched, error } } = props;
  return (<TextField
    label={label}
    error={touched && error}
    name={input.name}
    {...input}
    inputProps={{
      maxLength: props.maxlength,
    }}
  />);
};

RenderTextField.propTypes = {
  input: PropTypes.objectOf.isRequired,
  label: PropTypes.string.isRequired,
  meta: PropTypes.objectOf.isRequired,
  inputProps: PropTypes.objectOf.isRequired,
  maxlength: PropTypes.string.isRequired,
};

export default RenderTextField;
