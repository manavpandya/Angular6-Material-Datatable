import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { Field, reduxForm } from 'redux-form';
import { connect } from 'react-redux';
import Dialog, {
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from 'material-ui/Dialog';
import BlockUi from 'react-block-ui';
import Button from 'material-ui/Button';
import IconButton from 'material-ui/IconButton';
import KeyboardBackspace from 'material-ui-icons/KeyboardBackspace';
import Clear from 'material-ui-icons/Clear';
import PropTypes from 'prop-types';
import { RenderTextField } from './';
import { fetchSubFolders } from '../redux/actions';
import FoldersList from './FoldersList';
// import update from 'immutability-helper';
// import { submitEmail } from '../../auth/redux/actions';
import detectTreeLevel from '../../../utils/detectTreeLevel';
import { MEDIUM } from '../../../constants/stringLengths';

class TaxonomyEdit extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
      moveToTerm: false,
      moveHere: false,
      taxonomyId: null,
      taxonomyIndex: null,
      folderId: null, // ID of the folder selected in move context menu
      folderName: '',
      parentId: null,
      parentIndex: 0,
      next: 0,
      parentFolderName: '',
    };
    this._onSubmit = this._onSubmit.bind(this);
    this._onCancel = this._onCancel.bind(this);
    this.deleteTaxonomyTerm = this.deleteTaxonomyTerm.bind(this);
    this.handleClickOpen = this.handleClickOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleMoveTo = this.handleMoveTo.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.selectedFolder = this.selectedFolder.bind(this);
    this.nextSubFolder = this.nextSubFolder.bind(this);
    this.moveHere = this.moveHere.bind(this);
    this.renderList = this.renderList.bind(this);
    this.backFolder = this.backFolder.bind(this);
  }
  componentDidMount() {
    const {
      display_value, preferred_term, scope_notes, active, approved,
    } = this.props.selectedTerm;
    this.props.initialize({
      display_value, preferred_term, scope_notes, active, approved,
    });
  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.selectedTerm && this.props.selectedTerm !== nextProps.selectedTerm) {
      const {
        display_value, preferred_term, scope_notes, active, approved,
      } = nextProps.selectedTerm;
      this.props.initialize({
        display_value, preferred_term, scope_notes, active, approved,
      });
    }
  }
  deleteTaxonomyTerm(level = 4) {
    this.props.deleteTaxonomyTerm(
      this.props.selectedTerm.id,
      { parentId: this.props.selectedTerm.parent_id, level },
    );
    this.handleClose();
  }

  handleClickOpen() {
    this.setState({
      open: true,
    });
  }
  // Open Move Context Menu
  handleMoveTo() {
    this.setState({
      moveToTerm: true,
    });
  }
  handleCancel() {
    this.setState({
      moveToTerm: false,
      moveHere: false,
      folderId: null,
      next: 0,
      taxonomyId: null,
    });
    this.props.fetchSubFolders();
  }
  handleClose() {
    this.setState({ open: false });
  }
  // Set Target folder
  selectedFolder(id, index) {
    if (this.props.taxonomy.map(data => data.id === id)) {
      this.setState({
        moveHere: true,
        taxonomyId: id,
        taxonomyIndex: index,
      });
    }
  }
  // Get child folder of Selected folder in Context menu
  nextSubFolder(term) {
    const {
      id, display_value: displayValue, parent_id: parentId, index,
    } = term;
    let parentID;
    let parentName;
    switch (this.state.next) {
      case 0:
        parentID = null;
        parentName = displayValue;
        break;
      case 1:
        parentID = parentId;
        parentName = this.state.folderName;
        break;
      case 2:
        parentName = this.state.folderName;
        parentID = this.state.parentId;
        break;
      default:
        parentID = null;
        parentName = null;
        break;
    }
    this.props.fetchSubFolders(id);
    this.setState({
      folderId: id,
      folderName: displayValue,
      parentFolderName: parentName,
      parentId: parentID,
      parentIndex: index,
      next: this.state.next + 1,
    });
  }
  // Move Source To Target
  moveHere() {
    this.setState({
      moveToTerm: false,
      next: 0,
      parentId: null,
      folderId: null,
    });
    this.props.updateSelectedTreeId({
      index: { GGPid: this.state.parentIndex, GPid: this.state.taxonomyIndex },
      data: { GGPid: this.state.folderId, GPid: this.state.taxonomyId },
      level: this.state.next,
    });
    this.props.updateTaxonomyTerm(this.props.selectedTerm.id, { parent_id: this.state.taxonomyId });
    this.props.fetchSubFolders();
  }
  _onSubmit(values) {
    this.props.updateTaxonomyTerm(this.props.selectedTerm.id, values);
  }
  // Get Parent folder
  backFolder() {
    let parentID;
    switch (this.state.next) {
      case 0:
        parentID = null;
        break;
      case 1:
        parentID = null;
        break;
      case 2:
        parentID = this.state.parentId;
        this.setState({
          folderName: this.state.parentFolderName,
        });
        break;
      default:
        parentID = null;
        break;
    }


    this.props.fetchSubFolders(parentID);
    // const payload = { data: null, index: null };
    this.setState({
      next: this.state.next - 1,
      folderId: this.state.next <= 1 ? null : this.state.folderId,
    });
  }
  _onCancel() {
    this.props.onTermSelect(null);
  }
  // Render the list of folders in context menu
  renderList() {
    const { nextFolder } = this.props;
    return (
      <div>
        {nextFolder.map((list, index) => {
          const term = { ...list };
          term.index = index;
          return (
            <FoldersList
              key={term.id}
              handleCancel={this.handleCancel}
              onSelectedFolder={this.selectedFolder}
              term={term}
              taxonomyId={this.state.taxonomyId}
              onNext={this.nextSubFolder}
              level={this.state.next}
            />
          );
        })}
      </div>
    );
  }
  render() {
    const { handleSubmit, fullScreen } = this.props;
    const term = this.props.selectedTerm;
    const level = detectTreeLevel(term);
    return (
      <div className="taxonomy-edit">
        <h1>{ term.taxonomy_path ? term.taxonomy_path.replace('-', '\u2192') : '' }</h1>

        <form onSubmit={handleSubmit(this._onSubmit)}>
          <div className="form-field">
            <Field
              name="preferred_term"
              component={RenderTextField}
              label={this.props.translate('preferredTerm')}
              maxlength={MEDIUM}
            />
          </div>

          <div className="form-field">
            <Field
              name="display_value"
              component={RenderTextField}
              label={this.props.translate('displayValue')}
              maxlength={MEDIUM}
            />
          </div>

          <div className="form-field">
            <Field
              name="scope_notes"
              component={RenderTextField}
              label={this.props.translate('scopeNotes')}
              multiLine
              rows={2}
            />
          </div>
          <br />
          {/* <div className="form-field">
            <Field name="active" component={RenderCheckbox} label="Active" />
            <label htmlFor="active">Active</label>
          </div>

          <div className="form-field">
            <Field name="approved" component={RenderCheckbox} label="Approved" />
            <label htmlFor="approved">Approved</label>
          </div> */}

          <div className="form-field">
            <Button
              disabled={this.props.updateTermLoading}
              type="submit"
              className="btn btn-primary"
            >{this.props.translate('updateTaxonomy')}
            </Button>
            <Button
              disabled={this.props.updateTermLoading}
              className="btn btn-primary"
              onClick={this.handleClickOpen}
            >
              {this.props.translate('taxonomyDelete')}
            </Button>
            {level < 4 &&
              <Button
                disabled={this.props.updateTermLoading}
                className="btn btn-primary"
                onClick={this.handleMoveTo}
              >
                {this.props.translate('taxonomyMove')}
              </Button>
            }
            <Button
              disabled={this.props.updateTermLoading}
              className="btn btn-warning"
              onClick={this._onCancel}
            >{this.props.translate('cancelButton')}
            </Button>
          </div>
        </form>
        <Dialog
          maxWidth="md"
          onEntering={this.handleEntering}
          open={this.state.moveToTerm}
          aria-labelledby="confirmation-dialog-title"
        >
          <div style={{ width: '70vh', height: '90vh' }}>
            <DialogTitle id="confirmation-dialog-title">
              {this.state.folderId ?
                <IconButton>
                  <KeyboardBackspace onClick={this.backFolder} />
                </IconButton>
              :
                <IconButton />
              }
              {this.state.next > 0 ? this.state.folderName : 'Taxonomy Folder'}
              <IconButton variant="fab" className="clear-button">
                <Clear onClick={this.handleCancel} />
              </IconButton>
            </DialogTitle>
            <DialogContent style={{ height: '63vh' }}>
              <BlockUi blocking={this.props.fetchNodeLoading}>
                {this.renderList()}
              </BlockUi>
            </DialogContent>
            <DialogActions>
              {this.state.moveHere &&
                <Button onClick={this.moveHere}> {this.props.translate('taxonomyMoveHere')}</Button>
              }
              <Button variant="raised" onClick={this.handleCancel} color="primary">
                {this.props.translate('cancelButton')}
              </Button>
            </DialogActions>
          </div>
        </Dialog>
        <Dialog
          fullScreen={fullScreen}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle id="responsive-dialog-title">{this.props.translate('deleteTerm')}</DialogTitle>
          <DialogContent>
            <DialogContentText>
              {this.props.translate('deleteTermInstruction')}
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              {this.props.translate('btnNo')}
            </Button>
            <Button
              onClick={() => { this.deleteTaxonomyTerm(level); }}
              color="primary"
              autoFocus
            >
              {this.props.translate('btnYes')}
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

TaxonomyEdit.propTypes = {
  translate: PropTypes.func.isRequired,
  taxonomy: PropTypes.arrayOf(Object).isRequired,
  fullScreen: PropTypes.bool,
  selectedTerm: PropTypes.objectOf(Object),
  handleSubmit: PropTypes.func.isRequired,
  updateTaxonomyTerm: PropTypes.func.isRequired,
  initialize: PropTypes.func.isRequired,
  deleteTaxonomyTerm: PropTypes.func.isRequired,
  onTermSelect: PropTypes.func.isRequired,
  updateTermLoading: PropTypes.bool.isRequired,
  nextFolder: PropTypes.arrayOf(Object).isRequired,
  fetchNodeLoading: PropTypes.bool.isRequired,
  fetchSubFolders: PropTypes.func.isRequired,
  updateSelectedTreeId: PropTypes.func.isRequired,
};

TaxonomyEdit.defaultProps = {
  selectedTerm: null,
  fullScreen: false,
};

function validate(values) {
  const errors = {};

  const requiredFields = [
    'preferred_term',
    'display_value',
  ];

  requiredFields.forEach((field) => {
    if (!values[field]) {
      errors[field] = 'Required';
    }
  });

  return errors;
}

export default reduxForm({
  validate,
  form: 'TaxonomyEdit',
  fields: ['display_value', 'preferred_term'],
})(connect(null, { fetchSubFolders })(withTranslate(TaxonomyEdit)));
