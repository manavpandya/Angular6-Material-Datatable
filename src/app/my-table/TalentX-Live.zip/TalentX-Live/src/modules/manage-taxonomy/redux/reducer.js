import { FETCH_TREE, FETCH_TERM, UPDATE_TERM, SET_SELECTED_TERM, SET_NEW_TERM_PARENT, DELETED_TERM, CREATE_TERM, DELETE_TERM, UPDATE_SELECTED_TREE_ID, FETCH_TREE_NODES, RESET_TAXONOMY_STATE, SEARCH_TREE, FETCH_ALL_NODE } from './actions';
import detectTreeLevel from '../../../utils/detectTreeLevel';

const initialState = {
  tree: [],
  nextFolder: [],
  children: [],
  updateTermLoading: false,
  updateTermLoaded: false,
  createTermLoading: false,
  createTermLoaded: false,
  createTermError: false,
  createTermSuccess: false,
  deleteTermSuccess: false,
  deleteTermError: false,
  deletedTerm: false,
  newTerm: {},
  setTerm: {},
  selectedTreeId: {
    id: null,
    Pid: null,
    GPid: null,
    GGPid: null,
    level: null,
  },
  selectedTreeIndex: {
    id: null,
    Pid: null,
    GPid: null,
    GGPid: null,
  },
  expandTree: false,
  fetchTreeSuccess: false,
  fetchTreeLoading: false,
  fetchTreeError: null,
  fetchTermError: null,
  updateSelectedTreeId: null,
  fetchNodeLoading: false,
  fetchNodeSuccess: false,
  fetchNodeError: false,
  newlyCreatedTerm: {},
  searchingTaxonomy: false, // For Loading taxonomy search data
  searchedTree: [],
  searchTaxonomy: false, // Flag to check whekther client searching for taxonomy
};

export default function (state = initialState, action) {
  switch (action.type) {
    case `${FETCH_TREE}_LOADING`:
      return {
        ...state,
        fetchTreeLoading: true,
      };
    case `${FETCH_TREE}_SUCCESS`:
      return {
        ...state,
        tree: action.payload.data.taxonomy,
        nextFolder: action.payload.data.taxonomy,
        deleteTermSuccess: false,
        setTerm: null,
        newTerm: null,
        deleteTermError: false,
        fetchTreeSuccess: true,
        fetchNodeSuccess: false,
        fetchTreeLoading: false,
        searchTaxonomy: false,
        searchingTaxonomy: false,
        searchedTree: [],
      };
    case `${FETCH_TREE}_ERROR`:
      return {
        ...state,
        fetchTreeLoading: false,
        fetchTreeError: action.payload,
      };
    case `${FETCH_TERM}_SUCCESS`:
      return { ...state, [action.payload.taxonomy.id]: action.payload.taxonomy };
    case `${FETCH_TERM}_ERROR`:
      return {
        ...state,
        fetchTermError: action.payload,
      };
    case SET_SELECTED_TERM: {
      return {
        ...state, updateTermLoading: false, updateTermLoaded: false, setTerm: action.payload,
      };
    }
    case `${CREATE_TERM}_LOADING`:
      return { ...state, createTermSuccess: false };
    case `${CREATE_TERM}_ERROR`:
      return { ...state, createTermError: true };
    case `${CREATE_TERM}_SUCCESS`: {
      let tree = state.tree; //eslint-disable-line
      let sti;
      let level = detectTreeLevel(action.payload.data); //eslint-disable-line
      let newIndex;
      const { GGPid, GPid, Pid } = state.selectedTreeIndex; //eslint-disable-line
      switch (level) {
        case 1:
          tree[GGPid].children = action.payload.data.taxonomy;
          break;
        case 2:
          state.tree.forEach((item, index) => {
            if (item.id === action.payload.data.parent_id) {
              newIndex = { GGPid: index };
            }
          });
          sti = { ...state.selectedTreeId, GGPid: action.payload.data.parent_id };
          break;
        case 3:
          state.tree[GGPid].children.forEach((item, index) => {
            if (item.id === action.payload.data.parent_id) {
              newIndex = { GPid: index };
            }
          });
          sti = { ...state.selectedTreeId, GPid: action.payload.data.parent_id };
          break;
        case 4:
          state.tree[GGPid].children[GPid].children.forEach((item, index) => {
            if (item.id === action.payload.data.parent_id) {
              newIndex = { Pid: index };
            }
          });
          sti = { ...state.selectedTreeId, Pid: action.payload.data.parent_id };
          break;
        default:
          break;
      }
      return {
        ...state,
        selectedTreeId: { ...sti },
        selectedTreeIndex: { ...state.selectedTreeIndex, ...newIndex },
        updateSelectedTreeId: action.payload.data.parent_id,
        setTerm: action.payload.data,
        createTermSuccess: true,
        expandTree: true,
        newlyCreatedTerm: action.payload.data,
      };
    }
    case SET_NEW_TERM_PARENT:
      return {
        ...state,
        newTerm: action.payload,
        createTermSuccess: false,
        createTermLoaded: false,
        createTermLoading: false,
      };
    case `${UPDATE_TERM}_LOADING`: {
      return { ...state, updateTermLoading: true, updateTermLoaded: false };
    }
    case `${UPDATE_TERM}_SUCCESS`: {
      return {
        ...state,
        updateTermLoading: false,
        updateTermLoaded: true,
        newlyCreatedTerm: action.payload.data,
      };
    }
    case UPDATE_SELECTED_TREE_ID: {
      return {
        ...state,
        selectedTreeId: { ...state.selectedTreeId, ...action.payload.data, level: action.payload.level }, //eslint-disable-line
        selectedTreeIndex: {
          ...state.selectedTreeIndex, ...action.payload.index,
        },
        createTermSuccess: false,
      };
    }
    case `${DELETE_TERM}_ERROR`: {
      return {
        ...state,
        deleteTermError: true,
      };
    }
    case `${DELETE_TERM}_SUCCESS`: {
      return {
        ...state,
        deleteTermSuccess: true,
      };
    }
    case `${FETCH_TREE_NODES}_LOADING`: {
      return {
        ...state,
        fetchNodeSuccess: false,
        fetchNodeLoading: true,
      };
    }
    case `${SEARCH_TREE}_LOADING`:
      return {
        ...state,
        searchingTaxonomy: true,
        searchTaxonomy: true,
        searchedTree: [],
      };
    case `${SEARCH_TREE}_SUCCESS`: {
      return {
        ...state,
        searchingTaxonomy: false,
        searchedTree: action.payload.data,
      };
    }
    case `${FETCH_TREE_NODES}_SUCCESS`: {
      action.payload.data.taxonomy.sort((firstTaxonomy, secondTaxonomy) => {
        const a = firstTaxonomy.display_value.toLowerCase();
        const b = secondTaxonomy.display_value.toLowerCase();
        if (a < b) return -1; // ascending order
        if (a > b) return 1; // descending order
        return 0;
      });
      if (action.payload.data.taxonomy.length) {
        let tree = state.tree; //eslint-disable-line
        const { GGPid, GPid, Pid } = state.selectedTreeIndex;
        switch (state.selectedTreeId.level) {
          case 1:
            tree = tree.map((items) => {
              const term = { ...items };
              if (items.id === state.selectedTreeId.GGPid) {
                term.children = action.payload.data.taxonomy;
                return term;
              }
              return items;
            });
            break;
          case 2:
            tree = tree.map((items) => {
              const term = { ...items };
              if (items.id === state.selectedTreeId.GPid) {
                term.children = action.payload.data.taxonomy;
                tree[GGPid].children[GPid].children = term.children;
                return tree[GGPid].children[GPid].children;
              }
              return items;
            });
            tree[GGPid].children[GPid].children = action.payload.data.taxonomy;
            break;
          case 3:
            tree = tree.map((items) => {
              const term = { ...items };
              if (items.id === state.selectedTreeId.Pid) {
                term.children = action.payload.data.taxonomy;
                tree[GGPid].children[GPid].children[Pid].children = term.children;
                return tree[GGPid].children[GPid].children[Pid].children;
              }
              return items;
            });
            tree[GGPid].children[GPid].children[Pid].children = action.payload.data.taxonomy;//eslint-disable-line
            break;
          case 4:
            tree = tree.map((items) => {
              const term = { ...items };
              if (items.id === state.selectedTreeId.id) {
                term.children = action.payload.data;
                tree[GGPid].children[GPid].children[Pid].children = term.children;
                return tree[GGPid].children[GPid].children[Pid].children;
              }
              return items;
            });
            tree[GGPid].children[GPid].children[Pid].children = action.payload.data.taxonomy;
            break;
          default:
            break;
        }
        return {
          ...state,
          tree,
          fetchNodeLoading: false,
          fetchNodeSuccess: true,
          searchingTaxonomy: false,
          deleteTermSuccess: false,
        };
      }
      const tree = state.tree; //eslint-disable-line
      const { GGPid, GPid, Pid } = state.selectedTreeIndex;
      switch (state.selectedTreeId.level) {
        case 1:
          tree[GGPid].children = [];
          break;
        case 2:
          tree[GGPid].children[GPid].children = [];
          break;
        case 3:
          tree[GGPid].children[GPid].children[Pid].children = [];
          break;
        case 4:
          tree[GGPid].children[GPid].children[Pid].children = [];
          break;
        default:
          break;
      }
      return {
        ...state,
        tree,
        fetchNodeLoading: false,
        fetchNodeSuccess: true,
        searchingTaxonomy: false,
        deleteTermSuccess: false,
      };
    }
    case `${FETCH_ALL_NODE}_SUCCESS`: {
      return {
        ...state,
        nextFolder: action.payload.data.taxonomy,
        children: action.payload.data.taxonomy,
      };
    }
    case RESET_TAXONOMY_STATE: {
      return {
        ...state,
        deleteTermSuccess: false,
        setTerm: null,
        newTerm: null,
        deleteTermError: false,
        fetchTreeSuccess: false,
        fetchNodeSuccess: false,
        updateTermLoaded: false,
        deletedTerm: false,
        searchingTaxonomy: false,
        searchTaxonomy: false,
      };
    }
    case DELETED_TERM: {
      return {
        ...state,
        deletedTerm: action.payload,
      };
    }
    case 'UPDATE_SEARCH':
      return {
        ...state,
        searchingTaxonomy: false,
      };
    default:
      return state;
  }
}
