import React from 'react';
import PropTypes from 'prop-types';
import List, {
  ListItem,
  ListItemAvatar,
  ListItemSecondaryAction,
  ListItemText,
} from 'material-ui/List';
import Avatar from 'material-ui/Avatar';
import FolderIcon from 'material-ui-icons/Folder';
import KeyboardArrowRight from 'material-ui-icons/KeyboardArrowRight';
import IconButton from 'material-ui/IconButton';

const FoldersList = ({
  term, onSelectedFolder, taxonomyId, onNext, level,
}) => (
  <List dense={false}>
    <ListItem
      button
      className={taxonomyId === term.id ? 'active-folder' : ''}
    >
      <ListItemAvatar>
        <Avatar>
          <FolderIcon />
        </Avatar>
      </ListItemAvatar>
      <ListItemText
        onClick={() => onSelectedFolder(term.id, term.index)}
        primary={term.display_value}
      />
      <ListItemSecondaryAction>
        {level < 1 &&
          <IconButton>
            <KeyboardArrowRight onClick={() => onNext(term)} />
          </IconButton>
        }
      </ListItemSecondaryAction>
    </ListItem>
  </List>
);

FoldersList.propTypes = {
  term: PropTypes.objectOf(Object).isRequired,
  onSelectedFolder: PropTypes.func.isRequired,
  onNext: PropTypes.func.isRequired,
  level: PropTypes.number.isRequired,
  taxonomyId: PropTypes.number.isRequired,
};

export default FoldersList;
