import React, { Component } from 'react';
import PropTypes from 'prop-types';
import TextIcon from 'material-ui-icons/ShortText';

class TaxonomyTreeLeaf extends Component {
  constructor(props) {
    super(props);

    this._handleClick = this._handleClick.bind(this);
    this._handleKeyPress = this._handleKeyPress.bind(this);
  }

  _handleClick() {
    this.props.onTermSelect(this.props.term);
  }

  _handleKeyPress() {
    this._handleClick();
  }

  render() {
    return (
      <div>
        {this.props.selectedTreeId.Pid === this.props.term.parent_id &&
        <div
          role="button"
          tabIndex={0}
          className="tree-node"
          onClick={this._handleClick}
          onKeyPress={this._handleKeyPress}
        >
          <span>
            <span className="tree-leaf">
              <TextIcon className="icon node" />
              {this.props.term.display_value}
            </span>
            <span className="actions" />
          </span>
        </div>
        }
      </div>
    );
  }
}

TaxonomyTreeLeaf.propTypes = {
  term: PropTypes.objectOf(PropTypes.object),
  selectedTreeId: PropTypes.objectOf(PropTypes.object).isRequired,
  onTermSelect: PropTypes.func.isRequired,
};

TaxonomyTreeLeaf.defaultProps = {
  term: null,
};

export default TaxonomyTreeLeaf;
