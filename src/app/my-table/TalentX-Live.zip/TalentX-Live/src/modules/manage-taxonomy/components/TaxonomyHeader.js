import React from 'react';
import { Link } from 'react-router-dom';
import BackIcon from 'material-ui-icons/ArrowBack';

const TaxonomyHeader = () => (
  <header style={{ display: 'flex', justifyContent: 'space-between' }}>
    <div style={{
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-start',
    }}
    >
      <Link to="/recruiter">
        <BackIcon style={{
          color: '#333',
          width: 30,
          height: 30,
          marginRight: '2rem',
        }}
        />
      </Link>
      <h1 style={{ whiteSpace: 'nowrap' }}>Manage Taxonomy</h1>
    </div>
  </header>
);

export default TaxonomyHeader;
