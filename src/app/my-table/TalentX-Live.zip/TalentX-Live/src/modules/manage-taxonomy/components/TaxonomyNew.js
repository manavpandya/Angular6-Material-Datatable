import _ from 'lodash';
import { withTranslate } from 'react-redux-multilingual';
import React, { Component } from 'react';
import { Field, reduxForm } from 'redux-form';
// import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { RenderTextField } from './';
import { MEDIUM } from '../../../constants/stringLengths';

class TaxonomyNew extends Component {
  constructor(props) {
    super(props);

    this._onSubmit = this
      ._onSubmit
      .bind(this);
    this._onCancel = this
      ._onCancel
      .bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.newTermParent && this.props.newTermParent !== nextProps.newTermParent) {
      this
        .props
        .initialize({ parent_id: nextProps.newTermParent.id });
    }
  }

  _onSubmit(values) {
    const data = _.cloneDeep(values);
    // FIXME is there a better way to pass hidden values with Redux form?
    data.parent_id = this.props.newTermParent.id;
    data.tenant_id = this.props.newTermParent.tenant_id;
    // FIXME Construct Taxonomy path in the backend
    data.taxonomy_path = `${this.props.newTermParent.preferred_term}-${data.preferred_term}`;
    this
      .props
      .createTaxonomyTerm(data);
  }

  _onCancel() {
    this
      .props
      .onNewTermParentSelect(null);
  }


  render() {
    const { handleSubmit } = this.props;
    const parent = this.props.newTermParent;
    if (!_.isEmpty(parent)) {
      return (
        <div className="taxonomy-new">
          <h1>{parent.preferred_term}</h1>

          <form onSubmit={handleSubmit(this._onSubmit)}>
            <div className="form-field">
              <Field
                name="preferred_term"
                component={RenderTextField}
                label={this.props.translate('preferredTerm')}
                maxlength={MEDIUM}
              />
            </div>

            <div className="form-field">
              <Field
                name="display_value"
                component={RenderTextField}
                label={this.props.translate('displayValue')}
                maxlength={MEDIUM}
              />
            </div>

            <div className="form-field">
              <Field
                name="scope_notes"
                component={RenderTextField}
                label={this.props.translate('scopeNotes')}
                multiLine
                rows={2}
              />
            </div>
            <br />
            {/* <div className="form-field">
            <Field name="active" component={RenderCheckbox} label="Active" />
            <label htmlFor="active">Active</label>
          </div>

          <div className="form-field">
            <Field name="approved" component={RenderCheckbox} label="Approved" />
            <label htmlFor="approved">Approved</label>
          </div> */}

            <div className="form-field">
              <button type="submit" className="btn btn-primary">{this.props.translate('createTaxonomy')}</button>
              <button className="btn btn-warning" onClick={this._onCancel}>{this.props.translate('cancelButton')}</button>
            </div>

          </form>
        </div>
      );
    }

    return (
      <div className="taxonomy-new">{this.props.translate('newTerm')}</div>
    );
  }
}

TaxonomyNew.propTypes = {
  translate: PropTypes.func.isRequired,
  newTermParent: PropTypes.objectOf,
  handleSubmit: PropTypes.func.isRequired,
  createTaxonomyTerm: PropTypes.func.isRequired,
  initialize: PropTypes.func.isRequired,
  onNewTermParentSelect: PropTypes.func.isRequired,
};

TaxonomyNew.defaultProps = {
  newTermParent: null,
};

function validate(values) {
  const errors = {};

  const requiredFields = ['preferred_term', 'display_value'];

  requiredFields.forEach((field) => {
    if (!values[field]) {
      errors[field] = 'Required';
    }
  });

  return errors;
}


export default reduxForm({
  validate,
  form: 'TaxonomyNew',
})(withTranslate(TaxonomyNew));
