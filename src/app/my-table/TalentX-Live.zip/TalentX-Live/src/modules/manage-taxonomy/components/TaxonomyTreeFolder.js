import _ from 'lodash';
import React, { Component } from 'react';
import ExpandLess from 'material-ui-icons/ExpandLess';
import ExpandMore from 'material-ui-icons/ExpandMore';
import FolderIcon from 'material-ui-icons/Folder';
import AddCircle from 'material-ui-icons/AddCircle';
import Dialog, {
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from 'material-ui/Dialog';
import Delete from 'material-ui-icons/Delete';
import ModeEdit from 'material-ui-icons/ModeEdit';
import PropTypes from 'prop-types';
import Button from 'material-ui/Button';
import TaxonomyTreeLeaf from './TaxonomyTreeLeaf';
import detectTreeLevel from '../../../utils/detectTreeLevel';


class TaxonomyTreeFolder extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: false,
      level: null,
      hoveredTerm: null,
      open: false,
      termId: null,
      parentId: null,
    };
    this._onCreate = this._onCreate.bind(this);
    this._onDelete = this._onDelete.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.renderItems = this.renderItems.bind(this);
    this._onEdit = this._onEdit.bind(this);
    this.handleClickOpen = this.handleClickOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }

  componentDidMount() {
    this.getLevel();
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.selectedTreeId === this.props.term.id) {
      this.setState({
        expanded: true,
      });
    }
  }

  getLevel() {
    this.setState({ level: detectTreeLevel(this.props.term) });
  }

  _onCreate() {
    this.props.onNewTermParentSelect(this.props.term);
  }

  _onEdit(id) {
    this.props.onTermSelect(id);
  }

  _onDelete(id, deletedTerm) {
    this.props.deleteTaxonomyTerm(id, deletedTerm);
    this.handleClose();
  }

  _onHover(value) {
    this.setState({
      hoveredTerm: value,
    });
  }

  handleClickOpen(term) {
    this.setState({
      open: true,
      termId: term.id,
      parentId: term.parent_id,
    });
  }
  handleClose() {
    this.setState({ open: false });
  }

  handleClick(ids, indexOfTerm) {
    const payload = { data: null, index: null };
    switch (this.state.level) {
      case 1:
        payload.level = this.state.level;
        payload.data = {
          GGPid: ids, GPid: null, Pid: null, id: null,
        };
        payload.index = {
          GGPid: indexOfTerm, GPid: null, Pid: null, id: null,
        };
        break;
      case 2:
        payload.level = this.state.level;
        payload.data = { GPid: ids, Pid: null, id: null };
        payload.index = { GPid: indexOfTerm, Pid: null, id: null };
        break;
      case 3:
        payload.level = this.state.level;
        payload.data = { Pid: ids, id: null };
        payload.index = { Pid: indexOfTerm, id: null };
        break;
      case 4:
        payload.level = this.state.level;
        payload.data = { id: ids };
        payload.index = { id: indexOfTerm };
        break;
      default:
        break;
    }
    this.props.updateSelectedTreeId(payload);
    if (ids) this.props.updateSelectedTreeItem(ids);
  }

  renderItems() {
    const { term } = this.props;
    let condition = false;
    switch (this.state.level) {
      case 1:
        condition = this.props.selectedTreeId.GGPid === this.props.term.id;
        break;
      case 2:
        condition = this.props.selectedTreeId.GPid === this.props.term.id;
        break;
      case 3:
        condition = this.props.selectedTreeId.Pid === this.props.term.id;
        break;
      case 4:
        condition = this.props.selectedTreeId.id === this.props.term.id;
        break;
      default:
        break;
    }

    return condition ?
      <ul className="tree-folder">
        <span
          onMouseEnter={() => { this._onHover(term.id); }}
          onMouseLeave={() => { this._onHover(null); }}
        >
          <Button
            disabled={this.props.fetchNodeLoading}
            onClick={() => { this.handleClick(null, null); }}
          >
            <ExpandLess
              className="icon expand-less"
            />
          </Button>
          <span><FolderIcon className="icon" />{this.props.term.display_value}</span>
          {
            this.state.hoveredTerm === term.id &&
            <span>
              { this.state.level !== 1 &&
                <ModeEdit onClick={() => this._onEdit(this.props.term)} />}
              <AddCircle onClick={this._onCreate} />
              { this.state.level !== 1 &&
                <Delete onClick={() => this.handleClickOpen(term)} />}
            </span>
          }
        </span>
        {_.map(term.children, (termitem, termIndex) => {
          const termItem = { ...termitem };
          termItem.index = termIndex;
          return this.state.level <= 2 ?
            <li
              key={termItem.id}
            >
              <TaxonomyTreeFolder
                term={termItem}
                onHover={this._onHover}
                onTermSelect={this.props.onTermSelect}
                expandTree={this.state.expanded}
                hoveredTerm={this.state.hoveredTerm}
                onNewTermParentSelect={this.props.onNewTermParentSelect}
                selectedTreeId={this.props.selectedTreeId}
                updateSelectedTreeId={this.props.updateSelectedTreeId}
                deleteTermSuccess={this.props.deleteTermSuccess}
                deleteTermError={this.props.deleteTermError}
                updateSelectedTreeItem={this.props.updateSelectedTreeItem}
                fetchNodeLoading={this.props.fetchNodeLoading}
                fetchNodeSuccess={this.props.fetchNodeSuccess}
                selectedTerm={this.props.selectedTerm}
                deleteTaxonomyTerm={this.props.deleteTaxonomyTerm}
                createTermSuccess={this.props.createTermSuccess}
              />
            </li> :
            <li key={termItem.id} >
              <TaxonomyTreeLeaf
                {...term}
                term={termItem}
                onTermSelect={this.props.onTermSelect}
                selectedTreeId={this.props.selectedTreeId}
              />
            </li>;
        })}
      </ul>
      :
      <ul className="tree-folder">
        <span
          onMouseEnter={() => { this._onHover(term.id); }}
          onMouseLeave={() => { this._onHover(null); }}
        >
          <Button
            disabled={this.props.fetchNodeLoading}
            onClick={() => { this.handleClick(this.props.term.id, this.props.term.index); }}
          >
            <ExpandMore
              className="icon expand-more"
            />
          </Button>
          <span><FolderIcon className="icon" />{this.props.term.display_value}</span>
          {
            this.state.hoveredTerm === term.id &&
            <span>
              { this.state.level !== 1 &&
                <ModeEdit onClick={() => this._onEdit(this.props.term)} />}
              <AddCircle onClick={this._onCreate} />
              { this.state.level !== 1 &&
                <Delete onClick={() => this.handleClickOpen(term)} />}
            </span>
          }
        </span>
      </ul>;
  }

  render() {
    const { fullScreen } = this.props;
    return (
      <div>
        { this.renderItems() }
        <Dialog
          fullScreen={fullScreen}
          open={this.state.open}
          onClose={this.handleClose}
          aria-labelledby="responsive-dialog-title"
        >
          <DialogTitle id="responsive-dialog-title">Do you want to delete this Term ?
          </DialogTitle>
          <DialogContent>
            <DialogContentText>
              After deletion this term will not be available any more.
              Are you sure you want to delete this Term?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              No
            </Button>
            <Button
              onClick={() => this._onDelete(
                this.state.termId,
                { parentId: this.state.parentId, level: this.state.level },
              )}
              color="primary"
              autoFocus
            >
              Yes
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

TaxonomyTreeFolder.propTypes = {
  term: PropTypes.objectOf(Object).isRequired,
  onTermSelect: PropTypes.func.isRequired,
  onNewTermParentSelect: PropTypes.func.isRequired,
  selectedTreeId: PropTypes.objectOf(Object).isRequired,
  updateSelectedTreeId: PropTypes.func,
  updateSelectedTreeItem: PropTypes.func.isRequired,
  onHover: PropTypes.func,
  expandTree: PropTypes.bool.isRequired,
  hoveredTerm: PropTypes.string,
  deleteTermSuccess: PropTypes.bool,
  deleteTermError: PropTypes.bool,
  fetchNodeLoading: PropTypes.bool,
  fetchNodeSuccess: PropTypes.bool,
  selectedTerm: PropTypes.objectOf(PropTypes.any),
  deleteTaxonomyTerm: PropTypes.func.isRequired,
  createTermSuccess: PropTypes.bool.isRequired,
  fullScreen: PropTypes.bool,
};

TaxonomyTreeFolder.defaultProps = {
  selectedTerm: null,
  updateSelectedTreeId: () => {},
  hoveredTerm: null,
  deleteTermSuccess: false,
  deleteTermError: false,
  onHover: null,
  fetchNodeLoading: false,
  fetchNodeSuccess: false,
  fullScreen: false,
};

export default TaxonomyTreeFolder;
