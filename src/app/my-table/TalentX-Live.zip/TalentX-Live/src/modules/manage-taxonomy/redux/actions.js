import api from '../../../shared/api';

export const FETCH_TREE = 'FETCH_TREE';
export const FETCH_TREE_NODES = 'FETCH_TREE_NODES';
export const FETCH_TERM = 'FETCH_TERM';
export const SET_SELECTED_TERM = 'SET_SELECTED_TERM';
export const SET_NEW_TERM_PARENT = 'SET_NEW_TERM_PARENT';
export const CREATE_TERM = 'CREATE_TERM';
export const UPDATE_TERM = 'UPDATE_TERM';
export const DELETE_TERM = 'DELETE_TERM';
export const UPDATE_SELECTED_TREE_ID = 'UPDATE_SELECTED_TREE_ID';
export const RESET_TAXONOMY_STATE = 'RESET_TAXONOMY_STATE';
export const CLOSE_DAILOG = 'CLOSE_DAILOG';
export const DELETED_TERM = 'DELETED_TERM';
export const SEARCH_TREE = 'SEARCH_TREE';
export const FETCH_ALL_NODE = 'FETCH_ALL_NODE';

export function fetchTaxonomyTree() {
  return {
    type: FETCH_TREE,
    payload: api.get('/terms/tree'),
  };
}

export function fetchTaxonomyTerm(id) {
  return {
    type: FETCH_TERM,
    payload: api.get(`/terms/${id}`),
  };
}

export function setSelectedTerm(selectedTerm) {
  return {
    type: SET_SELECTED_TERM,
    payload: selectedTerm,
  };
}

export function setNewTermParent(parentTerm) {
  return {
    type: SET_NEW_TERM_PARENT,
    payload: parentTerm,
  };
}

export function createTaxonomyTerm(values) {
  const request = api.post('/terms', values);
  return {
    type: CREATE_TERM,
    payload: request,
  };
}

export function deleteTaxonomyTerm(id, deletedTerm) {
  const request = api.delete(`/terms/${id}`);
  return (dispatch) => {
    const action1 = {
      type: DELETE_TERM,
      payload: request,
    };
    dispatch(action1);
    dispatch({ type: DELETED_TERM, payload: deletedTerm });
  };
}

export function updateTaxonomyTerm(id, values) {
  const request = api.put(`/terms/${id}`, values);

  return {
    type: UPDATE_TERM,
    payload: request,
  };
}

export function updateSelectedTreeId(payload) {
  return {
    type: UPDATE_SELECTED_TREE_ID,
    payload,
  };
}

export function updateSelectedTreeItem(values) {
  return (dispatch) => {
    setTimeout(() => {
      const payload = api.get(`/terms/tree?id=${values}`);
      dispatch({
        type: FETCH_TREE_NODES,
        payload,
      });
    }, 500);
  };
}
export function resetTaxonomyState() {
  return {
    type: RESET_TAXONOMY_STATE,
  };
}

export function searchTree(query) {
  return {
    type: SEARCH_TREE,
    payload: api.get(`/terms/tree/search?key=${query}`),
  };
}

export function fetchSubFolders(values = null) {
  if (values === null) {
    return {
      type: FETCH_ALL_NODE,
      payload: api.get('/terms/tree'),
    };
  }
  return (dispatch) => {
    setTimeout(() => {
      const payload = api.get(`/terms/tree?id=${values}`);
      dispatch({
        type: FETCH_ALL_NODE,
        payload,
      });
    }, 500);
  };
}
