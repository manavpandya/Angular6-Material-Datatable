import React from 'react';
import PropTypes from 'prop-types';
import Checkbox from 'material-ui/Checkbox';

const RenderCheckbox = (props) => {
  const { input, label } = props;
  return (
    <Checkbox
      label={label}
      checked={input.value || false}
      onChange={input.onChange}
      name={input.name}
      disabled
    />
  );
};

RenderCheckbox.propTypes = {
  input: PropTypes.objectOf.isRequired,
  label: PropTypes.string.isRequired,
};

export default RenderCheckbox;
