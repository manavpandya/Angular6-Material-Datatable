import _ from 'lodash';
import React, { Component } from 'react';
import { change } from 'redux-form';
import { connect } from 'react-redux';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import Button from 'material-ui/Button';
import Dialog, {
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
} from 'material-ui/Dialog';
import ReduxBlockUI from 'react-block-ui/redux';
import BoardHeader from '../../shared/compound/board/BoardHeader/index';
import Sidebar from './components/Sidebar';
import SubHeader from './components/subHeader';
import FormContainer from './components/FormContainer';
import { resetSynonyms, getAllSynonymsAction, ViewSynonymAction, CreateSynonymAction, DeleteSynomymAction, SearchSynonymsAction, UpdateSynonymAction } from './redux/actions';
import { showNotification } from '../../utils/Notifications';

let initialValues = {};
class NormalizeTaxonomyContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isEditing: false,
      search: '',
      open: false,
      OffSetHeight: 500,
    };
    this.EditForm = this.EditForm.bind(this);
    this.resetAndGetData = this.resetAndGetData.bind(this);
    this.searchInput = this.searchInput.bind(this);
    this.saveOrUpdateSynonym = this.saveOrUpdateSynonym.bind(this);
    this.handleConfirmDeleteDialog = this.handleConfirmDeleteDialog.bind(this);
    this.debouncedLoadSuggestions = _.debounce(this.fireDebounceForSearch, 500);
    this.updateDimensions = this.updateDimensions.bind(this);
    this.fireDebounceForSearch = this.fireDebounceForSearch.bind(this);
  }
  componentDidMount() {
    // this.props.getAllSynonymsAction();
    this.updateDimensions();
    window.addEventListener('resize', this.updateDimensions);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.selectedSynonym !== nextProps.selectedSynonym) {
      initialValues = nextProps.selectedSynonym;
    }
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.updateDimensions);
  }

  updateDimensions() {
    const taxoNormalize = document.getElementById('taxonomy-normalize') ? document.getElementById('taxonomy-normalize').offsetHeight : 0;
    const header = document.getElementById('header') ? document.getElementById('header').offsetHeight : 0;
    const inputNbutton = document.getElementById('input-n-button') ? document.getElementById('input-n-button').offsetHeight : 0;
    const item1 = document.getElementById('item1') ? document.getElementById('item1').offsetHeight : 0;
    const hrFixedHeight = document.getElementById('hr-fixed-height') ? document.getElementById('hr-fixed-height').offsetHeight : 0;

    const OffSetHeight = ((((taxoNormalize - header) - inputNbutton) - item1) - hrFixedHeight) - 18;
    this.setState({
      OffSetHeight,
    });
  }

  handleConfirmDeleteDialog(action) {
    this.setState({ open: action });
  }

  EditForm(bool) {
    this.setState({
      isEditing: bool,
    });
    if (!bool) {
      initialValues = {};
    }
  }

  searchInput(v) {
    this.setState({
      search: v,
    });
  }

  saveOrUpdateSynonym(values, id) {
    if (this.state.isEditing) {
      this.props.UpdateSynonymAction({ ...values }, id)
        .then(() => {
          this.setState({
            isEditing: false,
          }, () => {
            this.resetAndGetData();
            showNotification(this.props.translate('synonymUpdatedSuccessfully'), 'success');
          });
        })
        .catch((response) => {
          showNotification(response.data, 'error');
        });
    } else {
      this.props.CreateSynonymAction({ ...values })
        .then(() => {
          this.resetAndGetData();
          showNotification(this.props.translate('synonymAddedSuccessfully'), 'success');
        })
        .catch((response) => {
          showNotification(response.data, 'error');
        });
    }
  }


  fireDebounceForSearch(keyword) {
    if (keyword === '') {
      this.props.getAllSynonymsAction();
    } else {
      this.props.SearchSynonymsAction(keyword);
    }
  }

  resetAndGetData() {
    this.props.resetSynonyms();
    this.searchInput('');
    this.props.dispatch(change('searchForm', 'search_term', null));
    this.props.getAllSynonymsAction();
  }
  render() {
    return (
      <div>
        <BoardHeader />
        <div className="page taxonomy-normalize" id="taxonomy-normalize">
          <SubHeader />
          <ReduxBlockUI tag="div" blocking={this.props.loading}>
            <main>
              <Sidebar
                items={this.props.allSynonyms}
                ViewSynonymAction={(id) => {
                  this.props.ViewSynonymAction(id);
                  this.setState({
                    isEditing: true,
                  });
                  }
                }
                OffSetHeight={this.state.OffSetHeight}
                search={this.state.search}
                searchLoading={this.props.searchLoading}
                loading={this.props.loading}
                isEditing={this.state.isEditing}
                selectedSynonym={this.props.selectedSynonym}
                EditForm={this.EditForm}
                searchInput={this.searchInput}
                getNextPage={this.getNextPage}
                debounceSearchAction={v => this.debouncedLoadSuggestions(v)}
                getAllSynonymsAction={this.props.getAllSynonymsAction}
                currentPage={this.props.currentPage}
                currentSearchPageNo={this.props.currentSearchPageNo}
                totalSynonyms={this.props.totalSynonyms}
                SearchSynonymsAction={this.props.SearchSynonymsAction}
                resetSynonyms={this.props.resetSynonyms}
                dispatch={this.props.dispatch}
              />
              <FormContainer
                saveOrUpdateSynonym={this.saveOrUpdateSynonym}
                initialValues={initialValues}
                selectedSynonym={this.props.selectedSynonym}
                isEditing={this.state.isEditing}
                handleConfirmDeleteDialog={this.handleConfirmDeleteDialog}
              />
              <Dialog
                open={this.state.open}
                onClose={() => this.handleConfirmDeleteDialog(false)}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
              >
                <DialogTitle id="alert-dialog-title">
                Confirm
                </DialogTitle>
                <DialogContent>
                  <DialogContentText id="alert-dialog-description">
                    Are you sure, you want to delete this Term ?
                  </DialogContentText>
                </DialogContent>
                <DialogActions>
                  <Button onClick={() => this.handleConfirmDeleteDialog(false)} color="primary">
                    CANCEL
                  </Button>
                  <Button
                    onClick={() => {
                    this.EditForm(false);
                    this.props.DeleteSynomymAction(this.props.selectedSynonym.id)
                      .then(() => {
                        this.resetAndGetData();
                        showNotification('Term deleted successfully', 'success');
                      });
                      this.handleConfirmDeleteDialog(false);
                    }
                  }
                    color="primary"
                    autoFocus
                  >
                    DELETE
                  </Button>
                </DialogActions>
              </Dialog>
            </main>
          </ReduxBlockUI>
        </div>
      </div>
    );
  }
}

NormalizeTaxonomyContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  getAllSynonymsAction: PropTypes.func,
  UpdateSynonymAction: PropTypes.func,
  ViewSynonymAction: PropTypes.func,
  DeleteSynomymAction: PropTypes.func,
  CreateSynonymAction: PropTypes.func,
  SearchSynonymsAction: PropTypes.func,
  allSynonyms: PropTypes.arrayOf(PropTypes.object),
  selectedSynonym: PropTypes.object, // eslint-disable-line
  loading: PropTypes.bool,
  searchLoading: PropTypes.bool,
  currentPage: PropTypes.number,
  currentSearchPageNo: PropTypes.number,
  totalSynonyms: PropTypes.number.isRequired,
  resetSynonyms: PropTypes.func,
  dispatch: PropTypes.func,
};

NormalizeTaxonomyContainer.defaultProps = {
  dispatch: () => {},
  resetSynonyms: () => {},
  getAllSynonymsAction: () => {},
  UpdateSynonymAction: () => {},
  SearchSynonymsAction: () => {},
  ViewSynonymAction: () => {},
  DeleteSynomymAction: () => {},
  CreateSynonymAction: () => {},
  allSynonyms: [],
  selectedSynonym: {},
  loading: false,
  searchLoading: false,
  currentPage: 0,
  currentSearchPageNo: 0,
};

const mapStateToProps = state => ({
  totalSynonyms: state.normalizeTaxonomy.totalSynonyms,
  currentPage: state.normalizeTaxonomy.currentPageNo,
  currentSearchPageNo: state.normalizeTaxonomy.currentSearchPageNo,
  allSynonyms: state.normalizeTaxonomy.allSynonyms,
  loading: state.normalizeTaxonomy.loading,
  searchLoading: state.normalizeTaxonomy.searchLoading,
  selectedSynonym: state.normalizeTaxonomy.selectedSynonym,
});
const mapDispatchToProps = dispatch => ({
  resetSynonyms: () => dispatch(resetSynonyms()),
  CreateSynonymAction: formData => dispatch(CreateSynonymAction(formData)),
  UpdateSynonymAction: (formData, id) => dispatch(UpdateSynonymAction(formData, id)),
  getAllSynonymsAction: page => dispatch(getAllSynonymsAction(page)),
  ViewSynonymAction: id => dispatch(ViewSynonymAction(id)),
  DeleteSynomymAction: id => dispatch(DeleteSynomymAction(id)),
  SearchSynonymsAction: (keyword, pageNo) => dispatch(SearchSynonymsAction(keyword, pageNo)),
  dispatch,
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(withTranslate(NormalizeTaxonomyContainer));
