import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';
import { TextField } from 'redux-form-material-ui';
import { Form, Field, reduxForm } from 'redux-form';
import SearchIcon from 'material-ui-icons/Search';
import ClearIcon from 'material-ui-icons/Clear';
import { LinearProgress } from 'material-ui/Progress';
import Button from 'material-ui/Button';
import c from 'classnames';
import MomentTranslate from '../../../shared/basic/MomentTranslate';
import ItemsList from '../../../shared/compound/ItemsList';
import InfiniteScroll from '../../../shared/basic/InfiniteScroll';


const Sidebar = ({
  getAllSynonymsAction,
  debounceSearchAction,
  searchLoading,
  search,
  searchInput,
  isEditing,
  items,
  ViewSynonymAction,
  EditForm,
  selectedSynonym,
  SearchSynonymsAction,
  currentPage,
  currentSearchPageNo,
  handleSubmit,
  submit,
  change,
  OffSetHeight,
  totalSynonyms,
  loading,
  translate,
  resetSynonyms,
}) => (
  <aside>
    <ItemsList
      items={
        <Fragment>
          <div className="item" id="item1">
            <h3
              role="presentation"
              onKeyDown={() => {}}
              onClick={() => EditForm(false)}
            >{translate('createNewPlus')}
            </h3><span className="inCircle">{translate('total')}: {loading || searchLoading ? '...' : totalSynonyms} </span>
          </div>
          { searchLoading ?
            <LinearProgress color="primary" />
            :
            <div className="hr-fixed-height" id="hr-fixed-height" />
          }
          <div className="scroll-items" style={{ height: OffSetHeight }}>
            {items.length > 0 ?
              <Fragment>
                {
                  items.map((item, i) => (
                    <div
                      key={item.id + i} // eslint-disable-line
                      className={c('item', 'pointer', { selected: item.id === selectedSynonym.id && isEditing })}
                      role="presentation"
                      onKeyDown={() => {}}
                      onClick={() => {
                        ViewSynonymAction(item.id);
                        EditForm(true);
                        }
                    }
                    >
                      <h3 className="text-overflow-ellipsis">
                        {item.preferred_term}
                      </h3>
                      <small>
                        <MomentTranslate
                          fromNow={item.updated_at}
                        />
                      </small>
                    </div>))
                }
              </Fragment>
            :
              (totalSynonyms === 0 &&
              <div
                className="item notfound"
                role="presentation"
              >
                <p>
                  { translate('noItemFound') }
                </p>
              </div>)

            }
            <InfiniteScroll
              onReachedBottom={() => {
                setTimeout(() => {
                  if (search && (totalSynonyms / (currentSearchPageNo * 20) > 1)) {
                    SearchSynonymsAction(search, currentSearchPageNo + 1);
                  } else if ((totalSynonyms / (currentPage * 20) > 1) && search === '') {
                    getAllSynonymsAction(currentPage + 1);
                  }
                });
              }
            }
            />

          </div>
        </Fragment>
      }
      search={
        <div className="input-n-button" id="input-n-button">
          <Form className="width-100" onSubmit={handleSubmit(submit)} >
            <Field
              fullWidth
              id="search_term"
              name="search_term"
              className="search-term-field"
              component={TextField}
              placeholder={translate('search')}
              onChange={(e) => {
                EditForm(false);
                resetSynonyms();
                searchInput(e.target.value);
                  debounceSearchAction(e.target.value);
                }
              }
            />
          </Form>
          {
            search ?
              <Button
                size="small"
                onClick={() => {
                  EditForm(false);
                  searchInput('');
                  resetSynonyms();
                  change('search_term', '');
                  getAllSynonymsAction();
                  }
                }
              > <ClearIcon />
              </Button>
            :
              <Button
                size="small"
              >
                <SearchIcon />
              </Button>
          }
        </div>
      }
    />
  </aside>
);

Sidebar.propTypes = {
  translate: PropTypes.func.isRequired,
  items: PropTypes.array.isRequired, // eslint-disable-line
  getAllSynonymsAction: PropTypes.func.isRequired,
  resetSynonyms: PropTypes.func.isRequired,
  change: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  submit: PropTypes.func.isRequired,
  debounceSearchAction: PropTypes.func.isRequired,
  ViewSynonymAction: PropTypes.func.isRequired,
  EditForm: PropTypes.func.isRequired,
  selectedSynonym: PropTypes.object.isRequired, // eslint-disable-line
  isEditing: PropTypes.bool.isRequired,
  searchInput: PropTypes.func.isRequired,
  SearchSynonymsAction: PropTypes.func.isRequired,
  search: PropTypes.string.isRequired,
  searchLoading: PropTypes.bool.isRequired,
  loading: PropTypes.bool.isRequired,
  totalSynonyms: PropTypes.number,
  currentPage: PropTypes.number,
  currentSearchPageNo: PropTypes.number,
  OffSetHeight: PropTypes.number,
};

Sidebar.defaultProps = {
  OffSetHeight: 500,
  currentPage: 0,
  currentSearchPageNo: 0,
  totalSynonyms: 20,
};

export default reduxForm({
  form: 'searchForm',
  enableReinitialize: true,
})(withTranslate(Sidebar));
