import React from 'react';
import PropTypes from 'prop-types';
import { NavLink } from 'react-router-dom';
import BackIcon from 'material-ui-icons/ArrowBack';
import { withTranslate } from 'react-redux-multilingual';


const SubHeader = props => (
  <header className="header" id="header">
    <NavLink to="/recruiter" className="back">
      <BackIcon />
    </NavLink>
    <h1>{props.translate('manageTaxonomyNormalize')}</h1>
  </header>
);

SubHeader.propTypes = {
  translate: PropTypes.func.isRequired,
};

export default withTranslate(SubHeader);
