import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';
import { TextField } from 'redux-form-material-ui';
import Button from 'material-ui/Button';
import { Form, Field, reduxForm, reset } from 'redux-form';
import MomentTranslate from '../../../shared/basic/MomentTranslate';
import { required } from '../../../utils/validators';
import { MEDIUM } from '../../../constants/stringLengths';


const FormContainer = props => (
  <div style={{ flex: 1, padding: '1rem' }} className="form">
    <h1>{props.isEditing ? props.selectedSynonym.preferred_term : props.translate('createSynonym')}</h1>
    <Form onSubmit={props.handleSubmit(values =>
      props.saveOrUpdateSynonym(values, props.initialValues.id))}
    >
      <div className="field">
        <Field
          fullWidth
          id="preferred_term"
          name="preferred_term"
          label={props.translate('preferredTerm')}
          className="preferred-term-field"
          component={TextField}
          inputProps={{
            maxLength: MEDIUM,
          }}
        />
      </div>
      <div className="field">
        <Field
          fullWidth
          multiline
          id="non_preferred_terms"
          name="non_preferred_terms"
          label={props.translate('aliases')}
          rows={3}
          className="aliases-field"
          component={TextField}
        />

      </div>
      { props.isEditing ?
        <Fragment>
          <div className="field">
            <label htmlFor="created-by" >{props.translate('createdBy')}</label>
            <p className="input">{props.initialValues.created_by}</p>
          </div>
          <div className="field">
            <label htmlFor="last-updated">{props.translate('lastUpdatedBy')}</label>
            <p className="input">
              <MomentTranslate
                fromNow={props.initialValues.updated_at}
              />
            </p>
          </div>
        </Fragment> : null
      }
      <Button type="submit" variant="raised" color="primary">{ props.isEditing ? props.translate('update') : props.translate('create') }</Button>
      { props.isEditing ?
        <Button onClick={() => props.handleConfirmDeleteDialog(true)} >{props.translate('delete')} </Button> : null }
    </Form>
  </div>
);


FormContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  items: PropTypes.array, // eslint-disable-line
  handleSubmit: PropTypes.func.isRequired,
  handleConfirmDeleteDialog: PropTypes.func.isRequired,
  saveOrUpdateSynonym: PropTypes.func,
  selectedSynonym: PropTypes.object, // eslint-disable-line
  initialValues: PropTypes.object, // eslint-disable-line
  isEditing: PropTypes.bool,
};

FormContainer.defaultProps = {
  saveOrUpdateSynonym: () => {},
  selectedSynonym: {},
  initialValues: {},
  items: [],
  isEditing: false,
};

const afterSubmit = (result, dispatch) =>
  dispatch(reset('normalizeTaxonomyForm'));

const validate = (values) => {
  const errors = {};
  const preferredTerm = values.preferred_term;
  const nonPreferredTerms = values.non_preferred_terms;

  errors.preferred_term = required(preferredTerm) || (preferredTerm.trim().length === 0 && 'Invalid Preferred Term');
  errors.non_preferred_terms = required(nonPreferredTerms) || (nonPreferredTerms.trim().length === 0 && 'Invalid Aliases');

  return errors;
};

export default reduxForm({
  form: 'normalizeTaxonomyForm',
  validate,
  enableReinitialize: true,
  onSubmitSuccess: afterSubmit,
})(withTranslate(FormContainer));
