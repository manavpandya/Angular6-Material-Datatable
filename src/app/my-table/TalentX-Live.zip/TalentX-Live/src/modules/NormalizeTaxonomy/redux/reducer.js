import * as actionTypes from '../redux/actionTypes';

const initialState = {
  allSynonyms: [],
  selectedSynonym: {},
  searchLoading: false,
  loading: false,
  currentPageNo: 0,
  currentSearchPageNo: 0,
  totalSynonyms: 20,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case `${actionTypes.GET_ALL_SYNONYMS}_SUCCESS`: {
      return {
        ...state,
        allSynonyms: [...state.allSynonyms, ...action.payload.allSynonyms],
        currentPageNo: action.payload.currentPageNo,
        totalSynonyms: action.payload.total,
        loading: false,
      };
    }
    case `${actionTypes.GET_ALL_SYNONYMS}_LOADING`: {
      return {
        ...state,
        loading: true,
      };
    }
    case `${actionTypes.VIEW_SYNONYM}_SUCCESS`: {
      return {
        ...state,
        selectedSynonym: action.payload.data.synonym,
        loading: false,
      };
    }
    case `${actionTypes.VIEW_SYNONYM}_LOADING`: {
      return {
        ...state,
        loading: true,
      };
    }
    case `${actionTypes.CREATE_SYNONYM}_SUCCESS`: {
      return {
        ...state,
        allSynonyms: [...state.allSynonyms, action.payload.data],
        selectedSynonym: {},
        loading: false,
      };
    }
    case `${actionTypes.CREATE_SYNONYM}_LOADING`: {
      return {
        ...state,
        selectedSynonym: {},
        loading: true,
      };
    }
    case `${actionTypes.DELETE_SYNONYM}_SUCCESS`: {
      return {
        ...state,
        selectedSynonym: {},
        loading: false,
      };
    }
    case `${actionTypes.DELETE_SYNONYM}_LOADING`: {
      return {
        ...state,
        loading: true,
      };
    }
    case `${actionTypes.SEARCH_SYNONYMS}_SUCCESS`: {
      return {
        ...state,
        allSynonyms: [...state.allSynonyms, ...action.payload.allSynonyms],
        currentSearchPageNo: action.payload.currentSearchPageNo,
        totalSynonyms: action.payload.total,
        searchLoading: false,
      };
    }
    case `${actionTypes.SEARCH_SYNONYMS}_LOADING`: {
      return {
        ...state,
        searchLoading: true,
      };
    }
    case `${actionTypes.UPDATE_SYNONYM}_SUCCESS`: {
      return {
        ...state,
        loading: false,
        selectedSynonym: action.payload.data,
      };
    }
    case `${actionTypes.UPDATE_SYNONYM}_LOADING`: {
      return {
        ...state,
        loading: true,
      };
    }
    case actionTypes.RESET_SYNONYMS: {
      return {
        ...state,
        allSynonyms: [],
        currentPageNo: 0,
        currentSearchPageNo: 0,
        totalSynonyms: '...',
        selectedSynonym: {},
      };
    }
    default:
      return state;
  }
}
