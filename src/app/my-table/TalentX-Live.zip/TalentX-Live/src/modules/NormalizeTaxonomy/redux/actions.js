import api from '../../../shared/api';
import * as constants from './actionTypes';

export function getAllSynonymsAction(pageNo = 1) {
  return {
    type: constants.GET_ALL_SYNONYMS,
    payload: api.get(`synonyms?page=${pageNo}&per_page=20`)
      .then(res => ({
        allSynonyms: res.data.synonyms,
        currentPageNo: res.data.page,
        total: res.data.total,
      })),
  };
}

export function resetSynonyms() {
  return {
    type: constants.RESET_SYNONYMS,
    payload: [],
  };
}

export function ViewSynonymAction(id) {
  return {
    type: constants.VIEW_SYNONYM,
    payload: api.get(`synonyms/${id}`),
  };
}

export function CreateSynonymAction(formData) {
  return {
    type: constants.CREATE_SYNONYM,
    payload: api.post('synonyms', formData),
  };
}

export function UpdateSynonymAction(formData, id) {
  return {
    type: constants.UPDATE_SYNONYM,
    payload: api.put(`synonyms/${id}`, formData),
  };
}

export function DeleteSynomymAction(id) {
  return {
    type: constants.DELETE_SYNONYM,
    payload: api.delete(`synonyms/${id}`),
  };
}

export function SearchSynonymsAction(keyword, pageNo = 1) {
  return {
    type: constants.SEARCH_SYNONYMS,
    payload: api.get(`synonyms/search?q=${keyword}&page=${pageNo}&per_page=20`)
      .then(res => ({
        allSynonyms: res.data.synonyms,
        currentSearchPageNo: res.data.page,
        total: res.data.total,
      })),
  };
}
