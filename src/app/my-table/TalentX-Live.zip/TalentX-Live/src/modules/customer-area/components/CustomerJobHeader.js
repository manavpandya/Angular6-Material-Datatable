import React from 'react';
import { Link } from 'react-router-dom';
import BackIcon from 'material-ui-icons/ArrowBack';
import PrevIcon from 'material-ui-icons/KeyboardArrowLeft';
import NextIcon from 'material-ui-icons/KeyboardArrowRight';
import ActionsIcon from 'material-ui-icons/MoreVert';
import IconButton from 'material-ui/IconButton';
import Menu from './../../../shared/compound/Menu';

const CustomerJobHeader = prop => (
  <div className="job-header">
    <div>
      <Link to="/customer">
        <BackIcon />
      </Link>
      <h1>{prop.jobTitle}</h1>
      <Menu
        isDisabled
        popup={
          <div className="link-list">
            <a href>Share Job</a>
            <a href>Cancel Job</a>
            <a href>Request Candidates</a>
          </div>
      }
        iconPrefix={<ActionsIcon style={{ height: '1rem', color: '#333' }} />}
      />
    </div>
    <div>
      <IconButton title="Previous Job">
        <PrevIcon />
      </IconButton>
      <IconButton title="Next Job">
        <NextIcon />
      </IconButton>
    </div>
  </div>
);

export default CustomerJobHeader;
