import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
// import faker from 'faker';
// import MuiAvatar from 'material-ui/Avatar'
// import Badge from 'material-ui/Badge'
// import NotificationIcon from 'material-ui-icons/Notifications'
import JobMenuExpandField from './JobMenuExpandField';
import CandidateProfile from '../../../shared/compound/CandidateProfile';
import InfiniteScroll from '../../../shared/basic/InfiniteScroll';
import Loader from '../../../shared/basic/LoaderForSearch';

const menuItems = {
  presented: [
    {
      label: 'Interview',
      key: 'interview',
    },
    {
      label: 'Reject',
      key: 'reject',
    },
    {
      label: 'More Info',
      key: 'moreInfo',
    },
  ],
  interview: [
    {
      label: 'Offer',
      key: 'offer',
    },
    {
      label: 'Reject',
      key: 'reject',
    },
  ],
  offered: [
    {
      label: 'Hire',
      key: 'hire',
    },
  ],
  hired: [],
  reject: [],
};

class CustomerJobMenu extends Component {
  constructor(props) {
    super(props);
    this.state = {
      active: 'inbox',
    };

    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(value) {
    this.setState({
      active: value,
    });
  }
  render() {
    const {
      getTotalCounts,
      getLoadingState,
      inbox,
      interviewing,
      offered,
      rejected,
      hired,
      checkLoaderVisibilityForCandidates,
    } = this.props;

    // interviewedApplicantsLoading,
    // inboxApplicantsLoading,
    // offeredApplicantsLoading,
    // hiredApplicantsLoading,
    // rejectedApplicantsLoading,

    return (
      <Fragment>
        <JobMenuExpandField onChange={() => this.handleChange('inbox')} open={this.state.active === 'inbox'} summary={getTotalCounts.inboxApplicantsTotal} label="inbox">
          <div className="candidates">
            {inbox.length === 0 ? <h3 className="no-data">No candidates</h3> :
                  inbox.map(candidate => (
                    <h3 className="id" key={candidate.id}>
                      <CandidateProfile
                        getData={this.props.getData}
                        label="presented"
                        actionMenuItems={menuItems}
                        appId={candidate.id}
                        candidate={candidate.profile}
                        launcher={candidate.profile}
                      />
                      <small>{candidate.profile.job_title}</small>
                    </h3>
                  ))
            }
            {
              getLoadingState.inboxApplicantsLoading && (
                <Loader className="customer-menu-loading" />
              )
            }
            {
                checkLoaderVisibilityForCandidates('presented') &&
                <InfiniteScroll
                  onReachedBottom={() => this.props.getNextPageForApplicants('presented')}
                />
            }
          </div>
        </JobMenuExpandField>
        <JobMenuExpandField onChange={() => this.handleChange('interviewing')} open={this.state.active === 'interviewing'} summary={getTotalCounts.interviewedApplicantsTotal} label="interviewing">
          <div className="candidates">
            {interviewing.length === 0 ? <h3 className="no-data">No candidates</h3> :
                interviewing.map(candidate => (
                  <h3 className="id" key={candidate.id}>
                    <CandidateProfile
                      label="interview"
                      getData={this.props.getData}
                      actionMenuItems={menuItems}
                      appId={candidate.id || ''}
                      candidate={candidate.profile}
                      launcher={candidate.profile}
                    />
                    <small>{candidate.profile.job_title}</small>
                  </h3>
                ))
            }
            {
              getLoadingState.interviewedApplicantsLoading && (
                <Loader className="customer-menu-loading" />
              )
            }
            {
              checkLoaderVisibilityForCandidates('interviewed') &&
              <InfiniteScroll
                onReachedBottom={() => this.props.getNextPageForApplicants('interviewed')}
              />
            }

          </div>
        </JobMenuExpandField>
        <JobMenuExpandField onChange={() => this.handleChange('offered')} open={this.state.active === 'offered'} summary={getTotalCounts.offeredApplicantsTotal} label="offered">
          <div className="candidates">
            {offered.length === 0 ? <h3 className="no-data">No candidates</h3> :
              offered.map(candidate => (
                <h3 className="id" key={candidate.id}>
                  <CandidateProfile
                    label="offered"
                    getData={this.props.getData}
                    actionMenuItems={menuItems}
                    appId={candidate.id || ''}
                    candidate={candidate.profile}
                    launcher={candidate.profile}
                  />
                  <small>{candidate.profile.job_title}</small>
                </h3>
              ))
            }
            {
              getLoadingState.offeredApplicantsLoading && (
                <Loader className="customer-menu-loading" />
              )
            }
            {
              checkLoaderVisibilityForCandidates('offered') &&
              <InfiniteScroll
                onReachedBottom={() => this.props.getNextPageForApplicants('offered')}
              />
            }
          </div>
        </JobMenuExpandField>
        <JobMenuExpandField onChange={() => this.handleChange('hired')} open={this.state.active === 'hired'} summary={getTotalCounts.hiredApplicantsTotal} label="hired">
          <div className="candidates">
            {hired.length === 0 ? <h3 className="no-data">No candidates</h3> :
            hired.map(candidate => (
              <h3 className="id" key={candidate.id}>
                <CandidateProfile
                  label="hired"
                  getData={this.props.getData}
                  actionMenuItems={menuItems}
                  appId={candidate.id || ''}
                  candidate={candidate.profile}
                  launcher={candidate.profile}
                />
                <small>{candidate.profile.job_title}</small>
              </h3>
            ))
            }
            {
              getLoadingState.hiredApplicantsLoading && (
                <Loader className="customer-menu-loading" />
              )
            }
            {
              checkLoaderVisibilityForCandidates('hired') &&
              <InfiniteScroll
                onReachedBottom={() => this.props.getNextPageForApplicants('hired')}
              />
            }
          </div>
        </JobMenuExpandField>
        <JobMenuExpandField onChange={() => this.handleChange('rejected')} open={this.state.active === 'rejected'} summary={getTotalCounts.rejectedApplicantsTotal} label="rejected">
          <div className="candidates">
            {rejected.length === 0 ? <h3 className="no-data">No candidates</h3> :
            rejected.map(candidate => (
              <h3 className="id" key={candidate.id}>
                <CandidateProfile
                  label="reject"
                  getData={this.props.getData}
                  actionMenuItems={menuItems}
                  appId={candidate.id || ''}
                  candidate={candidate.profile}
                  launcher={candidate.profile}
                />
                <small>{candidate.profile.job_title}</small>
              </h3>
            ))
            }
            {
              getLoadingState.rejectedApplicantsLoading && (
                <Loader className="customer-menu-loading" />
              )
            }
            {
              checkLoaderVisibilityForCandidates('rejected') &&
              <InfiniteScroll
                onReachedBottom={() => this.props.getNextPageForApplicants('rejected')}
              />
            }
          </div>
        </JobMenuExpandField>
      </Fragment>
    );
  }
}

CustomerJobMenu.propTypes = {
  getTotalCounts: PropTypes.objectOf(PropTypes.any).isRequired,
  getLoadingState: PropTypes.objectOf(PropTypes.any).isRequired,
  inbox: PropTypes.arrayOf(PropTypes.object).isRequired,
  interviewing: PropTypes.arrayOf(PropTypes.object).isRequired,
  offered: PropTypes.arrayOf(PropTypes.object).isRequired,
  hired: PropTypes.arrayOf(PropTypes.object).isRequired,
  rejected: PropTypes.arrayOf(PropTypes.object).isRequired,
  getData: PropTypes.func.isRequired,
  checkLoaderVisibilityForCandidates: PropTypes.func.isRequired,
  getNextPageForApplicants: PropTypes.func.isRequired,
};
export default CustomerJobMenu;
