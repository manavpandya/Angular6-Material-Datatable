import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import PropTypes from 'prop-types';
import CustomerDashboard from './CustomerDashboard';
import {
  flushAllJobs,
  getHiredJobs,
  getInterviewedJobs,
  getPresentedJobs,
  getOfferedJobs,
  uploadJob,
  moveJobLocal,
  moveJob,
  getJobtemplate,
  setSortedState,
} from './../../redux/actions';
import { showNotification } from '../../../../utils/Notifications';

const pageSize = 10;

class CustomerDashboardContainer extends Component {
  constructor(props) {
    super(props);
    this.onDragEnd = this.onDragEnd.bind(this);
    this.getNextPage = this.getNextPage.bind(this);
    this.checkLoaderVisibility = this.checkLoaderVisibility.bind(this);
    this.refresh = this.refresh.bind(this);
    this.sortStage = this.sortStage.bind(this);
  }

  onDragEnd(result) {
    // result.source.droppableId - will give us source stage's Id
    // result.destination.droppableId - will give us destination stage's Id
    // result.draggableId - will give us currently dragged element's Id (job's Id in this case)

    // dropped outside the list
    if (!result.destination) {
      return;
    }

    if (result.destination.droppableId === result.source.droppableId) {
      return;
    }

    this.props.moveJobLocal(
      result.draggableId,
      result.source.droppableId,
      result.destination.droppableId,
    );

    this.props.moveJob(
      result.draggableId,
      result.source.droppableId,
      result.destination.droppableId,
    ).then(() => {
      // never do flushAllJobs here. It will give you unexpected results.
      showNotification(this.props.translate('positionChanges'), 'success', 8000);
      setTimeout(() => {
        this.refresh(result.source.droppableId);
        this.refresh(result.destination.droppableId);
      }, 500);
    }).catch((err) => {
      showNotification(err.message, 'error', 8000);
    });
  }

  getNextPage(stageKey) {
    if (!this.props.isMoving) {
      switch (stageKey) {
        case 'hired':
          this.props.getHiredJobs(
            this.props.hiredJobsCurrentPage + 1,
            this.props.hiredJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
          );
          break;
        case 'interviewed':
          this.props.getInterviewedJobs(
            this.props.interviewedJobsCurrentPage + 1,
            this.props.interviewedJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
          );
          break;
        case 'offered':
          this.props.getOfferedJobs(
            this.props.offeredJobsCurrentPage + 1,
            this.props.offeredJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
          );
          break;
        case 'presented':
          this.props.getPresentedJobs(
            this.props.presentedJobsCurrentPage + 1,
            this.props.presentedJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
          );
          break;
        default:
          break;
      }
    }
  }

  refresh(sourceOrDestination) {
    switch (sourceOrDestination) {
      case 'hired':
        this.props.getHiredJobs(1, this.props.hiredJobsSortedBy);
        break;
      case 'interviewed':
        this.props.getInterviewedJobs(1, this.props.interviewedJobsSortedBy);
        break;
      case 'presented':
        this.props.getPresentedJobs(1, this.props.presentedJobsSortedBy);
        break;
      case 'offered':
        this.props.getOfferedJobs(1, this.props.offeredJobsSortedBy);
        break;
      default:
        break;
    }
  }

  checkLoaderVisibility(stageKey) {
    switch (stageKey) {
      case 'hired':
        return this.props.hiredJobsCurrentPage === 0
          ? true
          : (this.props.totalHiredJobs /
              (this.props.hiredJobsCurrentPage * pageSize)) > 1;
      case 'interviewed':
        return this.props.interviewedJobsCurrentPage === 0
          ? true
          : (this.props.totalInterviewedJobs /
              (this.props.interviewedJobsCurrentPage * pageSize)) > 1;
      case 'presented':
        return this.props.presentedJobsCurrentPage === 0
          ? true
          : (this.props.totalPresentedJobs /
              (this.props.presentedJobsCurrentPage * pageSize)) > 1;
      case 'offered':
        return this.props.offeredJobsCurrentPage === 0
          ? true
          : (this.props.totalOfferedJobs /
              (this.props.offeredJobsCurrentPage * pageSize)) > 1;
      default:
        return true;
    }
  }

  sortStage(key, sortBy) {
    const { searchedEmployer, searchedJobTitle } = this.props;
    this.props.setSortedState(key, sortBy);
    switch (key) {
      case 'hired':
        this.props.getHiredJobs(1, sortBy, searchedEmployer, searchedJobTitle);
        break;
      case 'interviewed':
        this.props.getInterviewedJobs(1, sortBy, searchedEmployer, searchedJobTitle);
        break;
      case 'presented':
        this.props.getPresentedJobs(1, sortBy, searchedEmployer, searchedJobTitle);
        break;
      case 'offered':
        this.props.getOfferedJobs(1, sortBy, searchedEmployer, searchedJobTitle);
        break;
      default:
        break;
    }
  }

  render() {
    return (
      <CustomerDashboard
        flushAllJobs={this.props.flushAllJobs}
        hiredJobs={this.props.hiredJobs}
        hiredJobsCurrentPage={this.props.hiredJobsCurrentPage}
        totalHiredJobs={this.props.totalHiredJobs}
        hiredJobsLoading={this.props.hiredJobsLoading}
        interviewedJobs={this.props.interviewedJobs}
        interviewedJobsCurrentPage={this.props.interviewedJobsCurrentPage}
        totalInterviewedJobs={this.props.totalInterviewedJobs}
        interviewedJobsLoading={this.props.interviewedJobsLoading}
        presentedJobs={this.props.presentedJobs}
        presentedJobsCurrentPage={this.props.presentedJobsCurrentPage}
        totalPresentedJobs={this.props.totalPresentedJobs}
        presentedJobsLoading={this.props.presentedJobsLoading}
        offeredJobs={this.props.offeredJobs}
        offeredJobsCurrentPage={this.props.offeredJobsCurrentPage}
        totalOfferedJobs={this.props.totalOfferedJobs}
        offeredJobsLoading={this.props.offeredJobsLoading}
        onDragEnd={this.onDragEnd}
        getNextPage={this.getNextPage}
        checkLoaderVisibility={this.checkLoaderVisibility}
        sortStage={this.sortStage}
        draftJobsSortedBy={this.props.draftJobsSortedBy}
        hiredJobsSortedBy={this.props.hiredJobsSortedBy}
        interviewedJobsSortedBy={this.props.interviewedJobsSortedBy}
        presentedJobsSortedBy={this.props.presentedJobsSortedBy}
        offeredJobsSortedBy={this.props.offeredJobsSortedBy}
      />
    );
  }
}

CustomerDashboardContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  flushAllJobs: PropTypes.func,
  getHiredJobs: PropTypes.func,
  getInterviewedJobs: PropTypes.func,
  getPresentedJobs: PropTypes.func,
  getOfferedJobs: PropTypes.func,
  moveJobLocal: PropTypes.func,
  moveJob: PropTypes.func,
  setSortedState: PropTypes.func,
  hiredJobs: PropTypes.arrayOf(PropTypes.object),
  hiredJobsCurrentPage: PropTypes.number,
  totalHiredJobs: PropTypes.number,
  hiredJobsLoading: PropTypes.bool,
  interviewedJobs: PropTypes.arrayOf(PropTypes.object),
  interviewedJobsCurrentPage: PropTypes.number,
  totalInterviewedJobs: PropTypes.number,
  interviewedJobsLoading: PropTypes.bool,
  presentedJobs: PropTypes.arrayOf(PropTypes.object),
  presentedJobsCurrentPage: PropTypes.number,
  totalPresentedJobs: PropTypes.number,
  presentedJobsLoading: PropTypes.bool,
  offeredJobs: PropTypes.arrayOf(PropTypes.object),
  offeredJobsCurrentPage: PropTypes.number,
  totalOfferedJobs: PropTypes.number,
  offeredJobsLoading: PropTypes.bool,
  searchedEmployer: PropTypes.string,
  searchedJobTitle: PropTypes.string,
  isMoving: PropTypes.bool,
  history: PropTypes.object, // eslint-disable-line
  draftJobsSortedBy: PropTypes.string,
  hiredJobsSortedBy: PropTypes.string,
  interviewedJobsSortedBy: PropTypes.string,
  presentedJobsSortedBy: PropTypes.string,
  offeredJobsSortedBy: PropTypes.string,
};

CustomerDashboardContainer.defaultProps = {
  flushAllJobs: () => {},
  getHiredJobs: () => {},
  getInterviewedJobs: () => {},
  getPresentedJobs: () => {},
  getOfferedJobs: () => {},
  moveJobLocal: () => {},
  moveJob: () => {},
  setSortedState: () => {},
  hiredJobs: [],
  hiredJobsCurrentPage: 0,
  totalHiredJobs: 0,
  hiredJobsLoading: false,
  interviewedJobs: [],
  interviewedJobsCurrentPage: 0,
  totalInterviewedJobs: 0,
  interviewedJobsLoading: false,
  presentedJobs: [],
  presentedJobsCurrentPage: 0,
  totalPresentedJobs: 0,
  presentedJobsLoading: false,
  offeredJobs: [],
  offeredJobsCurrentPage: 0,
  totalOfferedJobs: 0,
  offeredJobsLoading: false,
  searchedEmployer: '',
  searchedJobTitle: '',
  isMoving: false,
  history: {},
  draftJobsSortedBy: 'none',
  hiredJobsSortedBy: 'none',
  interviewedJobsSortedBy: 'none',
  presentedJobsSortedBy: 'none',
  offeredJobsSortedBy: 'none',
};
const mapStateToProps = state => ({
  flushAllJobs: state.customerArea.flushAllJobs,
  hiredJobs: state.customerArea.hiredJobs,
  hiredJobsCurrentPage: state.customerArea.hiredJobsCurrentPage,
  totalHiredJobs: state.customerArea.totalHiredJobs,
  hiredJobsLoading: state.customerArea.hiredJobsLoading,
  interviewedJobs: state.customerArea.interviewedJobs,
  interviewedJobsCurrentPage: state.customerArea.interviewedJobsCurrentPage,
  totalInterviewedJobs: state.customerArea.totalInterviewedJobs,
  interviewedJobsLoading: state.customerArea.interviewedJobsLoading,
  presentedJobs: state.customerArea.presentedJobs,
  presentedJobsCurrentPage: state.customerArea.presentedJobsCurrentPage,
  totalPresentedJobs: state.customerArea.totalPresentedJobs,
  presentedJobsLoading: state.customerArea.presentedJobsLoading,
  offeredJobs: state.customerArea.offeredJobs,
  offeredJobsCurrentPage: state.customerArea.offeredJobsCurrentPage,
  totalOfferedJobs: state.customerArea.totalOfferedJobs,
  offeredJobsLoading: state.customerArea.offeredJobsLoading,
  searchedEmployer: state.customerArea.searchedEmployer,
  searchedJobTitle: state.customerArea.searchedJobTitle,
  uploadJobLoading: state.customerArea.uploadJobLoading,
  jobTemplates: state.customerArea.jobTemplates,
  noTemplatesData: state.customerArea.noTemplatesData,
  isMoving: state.customerArea.isMoving,
  draftJobsSortedBy: state.customerArea.draftJobsSortedBy,
  hiredJobsSortedBy: state.customerArea.hiredJobsSortedBy,
  interviewedJobsSortedBy: state.customerArea.interviewedJobsSortedBy,
  presentedJobsSortedBy: state.customerArea.presentedJobsSortedBy,
  offeredJobsSortedBy: state.customerArea.offeredJobsSortedBy,
});

const mapDispatchToProps = dispatch => ({
  flushAllJobs: () =>
    dispatch(flushAllJobs()),
  getHiredJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getHiredJobs(pageNo, sortBy, employer, key, perPage)),
  getInterviewedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getInterviewedJobs(pageNo, sortBy, employer, key, perPage)),
  getPresentedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getPresentedJobs(pageNo, sortBy, employer, key, perPage)),
  getOfferedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getOfferedJobs(pageNo, sortBy, employer, key, perPage)),
  uploadJob: data => dispatch(uploadJob(data)),
  getJobtemplate: key => dispatch(getJobtemplate(key)),
  moveJobLocal: (jobId, source, destination) => dispatch(moveJobLocal(jobId, source, destination)),
  moveJob: (jobId, source, destination) => dispatch(moveJob(jobId, source, destination)),
  setSortedState: (key, value) => dispatch(setSortedState(key, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(CustomerDashboardContainer)));// eslint-disable-line
