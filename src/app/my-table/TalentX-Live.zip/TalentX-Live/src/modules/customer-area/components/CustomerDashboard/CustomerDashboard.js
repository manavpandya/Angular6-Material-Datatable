import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import Select from 'material-ui/Select';
import PropTypes from 'prop-types';
import { MenuItem } from 'material-ui';
import Button from 'material-ui/Button';
import { withStyles } from 'material-ui/styles';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import DragScroll from 'react-dragscroll';
import JobSummary from '../../../jobs/components/JobSummary';
import InfiniteScroll from '../../../../shared/basic/InfiniteScroll';

const grid = 0.4;

const getItemStyle = (isDragging, draggableStyle) => ({
  // some basic styles to make the items look a bit nicer
  userSelect: 'none',
  padding: grid * 2,
  margin: `0 0 ${grid}px 0`,

  // change background colour if dragging
  background: isDragging ? 'lightgreen' : 'white',
  color: '#333',

  // styles we need to apply on draggables
  ...draggableStyle,
});

const getListStyle = isDraggingOver => ({
  background: isDraggingOver ? '#FFFFFF' : '#F9F9F9',
  padding: grid,
});

class CustomerDashboard extends Component {
  render() {
    const stages = [
      {
        key: 'presented',
        title: this.props.translate('presented'),
        className: 'stage-presented',
        jobs: this.props.presentedJobs,
        jobsLoading: this.props.presentedJobsLoading,
      },
      {
        key: 'interviewed',
        title: this.props.translate('interviewed'),
        className: 'stage-auto-interviewed',
        jobs: this.props.interviewedJobs,
        jobsLoading: this.props.interviewedJobsLoading,
      },
      {
        key: 'offered',
        title: this.props.translate('isOffered'),
        className: 'stage-open',
        jobs: this.props.offeredJobs,
        jobsLoading: this.props.offeredJobsLoading,
      },
      {
        key: 'hired',
        title: this.props.translate('Hired'),
        className: 'stage-hired',
        jobs: this.props.hiredJobs,
        jobsLoading: this.props.hiredJobsLoading,
      },
    ];
    return (
      <div className="page recruiter">
        <main>
          <div className="contain">
            <section className="board fixed">
              <DragScroll className="dragScroll">
                <section className="stages">
                  <DragDropContext onDragEnd={this.props.onDragEnd}>
                    {
                    stages.map(stage => (
                      <section className={`stage ${stage.className}`} key={stage.key}>
                        <header className="stage-header-wrapper">
                          <div className="stage-header">
                            <h3>{stage.title}</h3>
                            <Select
                              className="stage-sort"
                              value={this.props[`${stage.key}JobsSortedBy`] || 'none'}
                              onChange={event =>
                                this.props.sortStage(stage.key, event.target.value)}
                            >
                              <MenuItem value="none" className="stage-sort-option">
                                {this.props.translate('none')}
                              </MenuItem>
                              <MenuItem value="created_at" className="stage-sort-option">
                                {this.props.translate('byPostedDate')}
                              </MenuItem>
                            </Select>
                          </div>
                        </header>
                        <main>
                          <Droppable droppableId={stage.key}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}
                              >
                                <div className="jobs">
                                  {
                                    stage.jobs.length < 1 && stage.jobsLoading
                                    ? (
                                      <div className="spinner">
                                        {this.props.translate('pleaseWait')}
                                      </div>
                                    )
                                    : (
                                      <div>
                                        {
                                          stage.jobs.length < 1
                                          ? (
                                            <div className="no-jobs">
                                              {this.props.translate('nothingToDisplay')}
                                            </div>
                                            )
                                          : (
                                            <div>
                                              {
                                                stage.jobs.map((job, index) => (
                                                  <Draggable
                                                    key={job.id}
                                                    draggableId={job.id}
                                                    index={index}
                                                  >
                                                    {(innerProvided, innerSnapshot) => (
                                                      <div>
                                                        <div
                                                          ref={innerProvided.innerRef}
                                                          {...innerProvided.draggableProps}
                                                          {...innerProvided.dragHandleProps}
                                                          style={getItemStyle(
                                                            innerSnapshot.isDragging,
                                                            innerProvided.draggableProps.style,
                                                          )}
                                                          className="job-container-draggable-child"
                                                        >
                                                          <JobSummary
                                                            job={job}
                                                            stageKey={stage.key}
                                                            customerPage
                                                          />
                                                        </div>
                                                        {innerProvided.placeholder}
                                                      </div>
                                                    )}
                                                  </Draggable>
                                                ))
                                              }
                                              {
                                                stage.jobsLoading
                                                ? (
                                                  <div className="spinner">
                                                    {this.props.translate('pleaseWait')}...
                                                  </div>
                                                )
                                                : this.props.checkLoaderVisibility(stage.key) &&
                                                  <div className="btn-load-more-container">
                                                    <Button
                                                      className="btn-load-more"
                                                      onClick={() =>
                                                              this.props.getNextPage(stage.key)}
                                                    >
                                                      {this.props.translate('loadMore')}
                                                    </Button>
                                                  </div>
                                              }
                                            </div>
                                            )
                                        }
                                      </div>
                                    )
                                  }
                                  {
                                    this.props.checkLoaderVisibility(stage.key) &&
                                    <InfiniteScroll
                                      onReachedBottom={() => this.props.getNextPage(stage.key)}
                                    />
                                  }
                                </div>
                                {provided.placeholder}
                              </div>
                            )}
                          </Droppable>
                        </main>
                      </section>
                    ))
                  }
                  </DragDropContext>
                </section>
              </DragScroll>
            </section>
          </div>
        </main>
      </div>
    );
  }
}


CustomerDashboard.propTypes = {
  translate: PropTypes.func.isRequired,
  offeredJobs: PropTypes.arrayOf(PropTypes.object),
  offeredJobsLoading: PropTypes.bool,
  interviewedJobs: PropTypes.arrayOf(PropTypes.object),
  interviewedJobsLoading: PropTypes.bool,
  presentedJobs: PropTypes.arrayOf(PropTypes.object),
  presentedJobsLoading: PropTypes.bool,
  hiredJobs: PropTypes.arrayOf(PropTypes.object),
  hiredJobsLoading: PropTypes.bool,
  onDragEnd: PropTypes.func,
  checkLoaderVisibility: PropTypes.func,
  getNextPage: PropTypes.func.isRequired,
  sortStage: PropTypes.func,
  draftJobsSortedBy: PropTypes.string,
  offeredJobsSortedBy: PropTypes.string,
  interviewedJobsSortedBy: PropTypes.string,
  presentedJobsSortedBy: PropTypes.string,
  hiredJobsSortedBy: PropTypes.string,
};

CustomerDashboard.defaultProps = {
  offeredJobs: [],
  offeredJobsLoading: false,
  interviewedJobs: [],
  interviewedJobsLoading: false,
  presentedJobs: [],
  presentedJobsLoading: false,
  hiredJobs: [],
  hiredJobsLoading: false,
  onDragEnd: () => {},
  checkLoaderVisibility: () => true,
  sortStage: () => {},
  draftJobsSortedBy: 'none',
  offeredJobsSortedBy: 'none',
  interviewedJobsSortedBy: 'none',
  presentedJobsSortedBy: 'none',
  hiredJobsSortedBy: 'none',
};

export default withStyles()(withTranslate(CustomerDashboard));
