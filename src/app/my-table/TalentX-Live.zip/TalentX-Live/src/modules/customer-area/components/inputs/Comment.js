import React from 'react';
import Button from 'material-ui/Button';
import Avatar from '../../../../shared/basic/Avatar';

const Comment = prop => (
  <div className="input comment">
    <Avatar size={1} avatar={prop.avatar} alt="Avatar" />
    <textarea className="textarea-post input" rows={2} placeholder={prop.placeholder} />
    <Button color="primary">Post</Button>
  </div>
);

export default Comment;
