/*
  eslint-disable
*/
import React, { Fragment } from 'react';
import _ from 'lodash';
import { withTranslate } from 'react-redux-multilingual';
import { PropTypes } from 'prop-types';
import MomentTranslate from '../../../shared/basic/MomentTranslate';
import { sortAll } from '../../../utils/index';

const CustomerDescription = (props) => (
  <Fragment>
    <h2>{props.currentJob.job_description ? props.currentJob.job_description.job_title : ''}</h2>
    <div className="job-description">
      {props.currentJob.job_description && props.currentJob.job_description.description}
      {
        props.currentJob.job_description && props.currentJob.job_description.required_skills.length > 0 ?
        (
          <div>
            <h2 className="info-key">{props.translate('requiredSkills')}</h2>
            <span className="info-value">
              {
                sortAll(_.uniqBy(props.currentJob.job_description.required_skills, obj => obj.display_value.toLowerCase()), 'display_value').map(skill => skill.display_value).join(', ')
              }
            </span>
          </div>
        )
        : null
      }
      
      {
        props.currentJob.job_description && props.currentJob.job_description.desired_skills && props.currentJob.job_description.desired_skills.length > 0 &&
        <div>
          <h2 className="info-key">{props.translate('desiredSkills')}</h2>
          <span className="info-value">
            {
              _.uniqBy(props.currentJob.job_description.desired_skills, obj => obj.display_value.toLowerCase(), 'display_value').map(skill => skill.display_value).join(', ')
            }
          </span>
        </div>
      }
      {
        props.currentJob.job_description && props.currentJob.qualifications.degree.length > 0 &&
        <div>
          <h2 className="info-key">{props.translate('qualifications')}</h2>
          <span className="info-value">
            {
              props.currentJob.qualifications.degree.map(degree => degree).join(', ')
            }
          </span>
        </div>
      }
      {
        props.currentJob.job_description && props.currentJob.certification_license.certifications.length > 0 &&
        <div>
          <h2 className="info-key">{props.translate('candidateCertification')}</h2>
          <span className="info-value">
            {
              props.currentJob.certification_license.certifications.map(certification => certification).join(', ')
            }
          </span>
        </div>
      }
      {
        props.currentJob.job_description && props.currentJob.certification_license.licenses.length > 0 &&
        <div>
          <h2 className="info-key">{props.translate('candidateLicenses')}</h2>
          <span className="info-value">
            {
              props.currentJob.certification_license.licenses.map(license => license).join(', ')
            }
          </span>
        </div>
      }
    </div>

    <h3>{props.translate('createdBy')}: {props.currentJob ? props.currentJob.created_by &&
        props.currentJob.created_by.username : null}
    </h3>
    <h3>{props.translate('postedOn')}:
      <MomentTranslate
        fromNow={props.currentJob ? props.currentJob.created_at : null}
      />
    </h3>
  </Fragment>
);

CustomerDescription.propTypes = {
  currentJob: PropTypes.objectOf(PropTypes.any).isRequired,
  translate: PropTypes.func.isRequired,
};
export default withTranslate(CustomerDescription);
