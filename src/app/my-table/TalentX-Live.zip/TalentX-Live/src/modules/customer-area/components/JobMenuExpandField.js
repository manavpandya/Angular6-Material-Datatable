import React, { Component } from 'react';
import PropTypes from 'prop-types';
import ExpandIcon from 'material-ui-icons/Add';
import CollapseIcon from 'material-ui-icons/Remove';

class ExpandField extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: this.props.open || false,
      // summary: null,
    };
    // this.onChange = this.onChange.bind(this);
    this.toggle = this.toggle.bind(this);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.open !== this.state.open) {
      this.setState({
        open: nextProps.open,
      });
    }
  }

  toggle() {
    this.props.onChange();
    this.setState({ open: !this.state.open });
  }

  render() {
    return (
      <section className={this.state.open ? 'expand-field active' : 'expand-field'}>
        <header className="pointer" onClick={this.toggle} role="presentation" onKeyDown={() => {}}>
          <label htmlFor="nothing" >
            { this.state.open ? <CollapseIcon /> : <ExpandIcon /> }
            <h2>{ this.props.label }</h2>
          </label>
          <p className="summary">
            { this.props.summary || null }
          </p>
          {/* { this.props.summary && this.props.reset ?
            <ResetIcon onClick={this.props.reset} className="reset" /> : <span /> } */}
        </header>
        <main>
          { this.state.open && this.props.children }
        </main>
      </section>
    );
  }
}

ExpandField.propTypes = {
  label: PropTypes.string.isRequired,
  children: PropTypes.element.isRequired,
  // reset: PropTypes.func,
  open: PropTypes.bool.isRequired,
  summary: PropTypes.number,
  onChange: PropTypes.func,
};

ExpandField.defaultProps = {
  onChange: () => {},
  summary: 0,
};

export default ExpandField;
