import React from 'react';
import Comment from './inputs/Comment';

const avatar = 'http://i.pravatar.cc/150?img=59';
const recruiter = 'http://i.pravatar.cc/150?img=12';

const activityData = [
  {
    unread: true,
    when: '2d ago',
    title: 'More Info Requested for',
    candidates: ['Matthew Barton', 'Abby Towne', 'Stella Fisher'],
  },
  {
    unread: true,
    when: '3d ago',
    title: 'Interview scheduled for 5',
    candidates: ['Dr.Eva Hansen', 'Charli Feeney', 'Lara Hackett', 'Ms.Liam Jenkins', 'Claudia Wolf'],
  },
  {
    unread: false,
    when: '7d ago',
    title: 'Interview scheduled for 5',
    candidates: ['Charli Lowe', 'Mrs.Jake Gibson', 'Kayla Turcotte', 'Christopher Emard', 'Ms.Chase Armstrong'],
  },
  {
    unread: false,
    when: '10d ago',
    title: 'Follow up',
    candidates: ['Sarah O\'neill', 'Toby Khan', 'Sarah Grimes', 'Bella Little DVM', 'Lara Turcotte II'],
  },
  {
    unread: false,
    when: '12d ago',
    who: recruiter,
    message: 'Of course, I\'ll update it and redistribute.',
  },
  {
    unread: false,
    when: '12d ago',
    message: 'This job description doesn\'t include rate.Are we able to add that in?',
  },
];

const CustomerJobActivity = () => (
  <div className="job-activity">
    <Comment avatar={avatar} placeholder="Add Note ..." />
    <h2>Activity</h2>
    <main>
      <ul>
        { activityData.map(activity =>
          (
            <li className={activity.unread ? 'activity unread' : 'activity'} key={activity}>
              <img className="avatar" src={activity.who ? activity.who : avatar} alt="Avatar" />
              <div>
                <h6 className="when">{ activity.when }</h6>
                { activity.title &&
                  <h4 className="title">{ activity.title }</h4>
                }
                { activity.message &&
                  <p className="message">{ activity.message }</p>
                }
                <ul className="candidates">
                  { activity.candidates && activity.candidates.map(candidate =>
                    (
                      <li key={candidate}>
                        <a href="/customer">{ candidate }</a>
                      </li>
                    ))
                  }
                </ul>
              </div>
            </li>
        ))
        }
      </ul>
    </main>
  </div>
);

export default CustomerJobActivity;
