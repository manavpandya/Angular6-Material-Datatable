import _ from 'lodash';
import * as actionTypes from './actionTypes';
import { sortAll } from '../../../utils';

const initialState = {
  jobs: [],
  getJobsLoading: false,
  getJobsError: null,
  jobPosition: [],
  uploadJobLoading: false,
  uploadJobError: null,
  newJob: [],
  createNewJobLoading: false,
  createNewJobError: null,
  editJobLoading: false,
  editJobError: null,
  searchJobLoading: false,
  searchJobError: null,
  draftedJobs: [],
  draftedJobsCurrentPage: 0,
  totalDraftedJobs: 0,
  draftedJobsLoading: false,
  draftedJobsError: null,
  offeredJobs: [],
  offeredJobsCurrentPage: 0,
  totalPostedJobs: 0,
  offeredJobsLoading: false,
  offeredJobsError: null,
  interviewedJobs: [],
  interviewedJobsCurrentPage: 0,
  totalQualifiedJobs: 0,
  interviewedJobsLoading: false,
  interviewedJobsError: null,
  presentedJobs: [],
  presentedJobsCurrentPage: 0,
  totalPresentedJobs: 0,
  presentedJobsLoading: false,
  presentedJobsError: false,
  hiredJobs: [],
  hiredJobsCurrentPage: 0,
  totalClosedJobs: 0,
  hiredJobsLoading: false,
  hiredJobsError: null,
  searchedEmployer: '',
  searchedJobTitle: '',
  employers: [],
  employersLoading: false,
  employersError: null,
  jobTemplates: [],
  currentJob: {},
  currentJobLoading: false,
  currentJobError: null,
  searchJobTemplatesLoading: false,
  noTemplatesData: false,
  isMoving: false,
  notesLoading: false,
  notesError: null,
  jobApplicationList: {},
  matchedCandidates: {},
  jobApplicationCount: {},
  candidatesLoading: false,
  candidatesError: null,
  closeJobLoading: false,
  closeJobError: null,
  deleteJobLoading: false,
  deleteJobError: null,
  shortlistJobApplicationLoading: false,
  shortlistJobApplicationError: null,
  moveJobApplicationLoading: false,
  moveJobApplicationError: null,
  deleteJobApplicationLoading: false,
  deleteJobApplicationError: null,
  facets: null,
  filter: {
    query: '',
    facets: [],
  },
  facetFetchProfile: [],
  selectedCandidateProfile: {},
  draftJobsSortedBy: 'created_at',
  offeredJobsSortedBy: 'created_at',
  interviewedJobsSortedBy: 'created_at',
  presentedJobsSortedBy: 'created_at',
  hiredJobsSortedBy: 'created_at',
  offeredJobsForCandidatesLoading: false,
  offeredJobsForCandidatesError: null,
  offeredJobsForCandidates: [],
  totalPostedJobsForCandidates: 0,
  offeredJobsForCandidatesCurrentPage: 0,
  accountInfo: {},
  accountInfoError: null,
  recruiterBookmarking: false,
  candidateProfileLoading: false,
  accountInfoLoading: false,
  filterParam: '',
  clearFilters: true,
  intercomSearch: {},
  intercomSearchLoading: false,
  intercomSearchError: null,
  intercomCreate: {},
  intercomCreateLoading: false,
  intercomCreateError: null,
  shortlistBulkApplicationLoading: false,
  shortlistBulkApplicationError: null,
  moveBulkApplicationLoading: false,
  moveBulkApplicationError: null,
  hiredApplicants: [],
  rejectedApplicants: [],
  interviewedApplicants: [],
  offeredApplicants: [],
  inboxApplicants: [],
};

function setLoading(state, payload) {
  const obj = state;
  switch (payload) {
    case 'draft':
      obj.draftedJobsCurrentPage = 0;
      obj.draftedJobs = [];
      obj.draftedJobsLoading = true;
      break;
    case 'offered':
      obj.offeredJobsCurrentPage = 0;
      obj.offeredJobs = [];
      obj.offeredJobsLoading = true;
      break;
    case 'interviewed':
      obj.interviewedJobsCurrentPage = 0;
      obj.interviewedJobs = [];
      obj.interviewedJobsLoading = true;
      break;
    case 'presented':
      obj.presentedJobsCurrentPage = 0;
      obj.presentedJobs = [];
      obj.presentedJobsLoading = true;
      break;
    case 'hired':
      obj.hiredJobsCurrentPage = 0;
      obj.hiredJobs = [];
      obj.hiredJobsLoading = true;
      break;
    default:
      break;
  }
  return obj;
}

function initializeJobApplicationCounts(jobs = []) {
  return jobs.map(jobPosition => ({
    ...jobPosition,
    applications: [
      { doc_count: 0, key: 'offered', ...jobPosition.applications.find(application => application.key === 'offered') },
      { doc_count: 0, key: 'interviewed', ...jobPosition.applications.find(application => application.key === 'interviewed') },
      { doc_count: 0, key: 'presented', ...jobPosition.applications.find(application => application.key === 'presented') },
      { doc_count: 0, key: 'hired', ...jobPosition.applications.find(application => application.key === 'hired') },
    ],
  }));
}

export default function (state = initialState, action) {
  switch (action.type) {
    case `${actionTypes.FETCH_FACET}_SUCCESS`: {
      return {
        ...state,
        facets: action.payload.data.profile_facets,
        meta: action.payload.data.meta,
        filterParam: '',
        isNewSearch: true,
        checkedFilters: {},
        clearFilters: true,
        isRecentSearched: false,
        facetsLoading: false,
      };
    }

    case `${actionTypes.FETCH_PROFILE_FACET_MATCHED}_SUCCESS`: {
      return {
        ...state,
        matchedCandidates: action.payload.data,
        totalCandidates: action.payload.data.total,
        candidatesLoading: false,
        filterParam: action.payload.filterParam,
        isPageSetToZero: true,
      };
    }
    case `${actionTypes.FETCH_PROFILE_FACET_MATCHED}_LOADING`: {
      return {
        ...state,
        candidatesLoading: true,
      };
    }
    case actionTypes.RESET_FILTER_PARAM_MATCHED: {
      return {
        ...state,
        filter: {},
        clearFilters: true,
        checkedFilters: '',
        filterParam: '',
        searchedValue: '',
      };
    }
    case actionTypes.SET_CLEAR_FILTER_MATCHED: {
      return {
        ...state,
        clearFilters: false,
      };
    }

    case `${actionTypes.GET_PROFILE_INFO}_SUCCESS`:
      return {
        ...state,
        selectedCandidateProfile: action.payload.data.profile,
        candidateProfileLoading: false,
      };
    case `${actionTypes.GET_PROFILE_INFO}_LOADING`:
      return {
        ...state,
        candidateProfileLoading: true,
      };
    case actionTypes.FLUSH_SELECTED_CANDIDATE_PROFILE:
      return {
        ...state,
        selectedCandidateProfile: {},
      };
    case actionTypes.FLUSH_ALL_JOBS:
      return {
        ...state,
        draftedJobs: [],
        offeredJobs: [],
        interviewedJobs: [],
        presentedJobs: [],
        hiredJobs: [],
      };
    case `${actionTypes.FETCH_PROFILE_FACET_JOB}_SUCCESS`: {
      return {
        ...state,
        matchedCandidates: action.payload.data,
        totalCandidates: action.payload.data.total,
        candidatesLoading: false,
      };
    }
    case `${actionTypes.FETCH_PROFILE_FACET_JOB}_LOADING`: {
      return {
        ...state,
        candidatesLoading: true,
      };
    }

    case actionTypes.GET_JOBS_SUCCESS:
      return {
        ...state,
        jobs: action.payload.data.job_positions,
        getJobsLoading: false,
        getJobsError: null,
      };
    case actionTypes.GET_JOBS_ERROR:
      return {
        ...state,
        jobs: [],
        getJobsLoading: false,
        getJobsError: action.payload.data,
      };
    case actionTypes.GET_JOBS_LOADING:
      return {
        ...state,
        jobs: [],
        getJobsLoading: true,
        getJobsError: null,
      };
    case actionTypes.UPLOAD_JOB_SUCCESS:
      return {
        ...state,
        jobPosition: {
          ...action.payload.data.job_position,
          job_description: {
            ...action.payload.data.job_position.job_description,
            required_skills: _.uniqBy(
              action.payload.data.job_position.job_description.required_skills,
              obj => obj.display_value.toLowerCase(),
            ),
          },
        },
        uploadJobLoading: false,
        uploadJobError: null,
      };
    case actionTypes.UPLOAD_JOB_ERROR:
      return {
        ...state,
        jobPosition: [],
        uploadJobLoading: false,
        uploadJobError: action.payload.data,
      };
    case actionTypes.UPLOAD_JOB_LOADING:
      return {
        ...state,
        jobPosition: [],
        uploadJobLoading: true,
        uploadJobError: null,
      };
    case actionTypes.CREATE_NEWJOB_SUCCESS:
      return {
        ...state,
        newJob: action.payload,
        createNewJobLoading: false,
        createNewJobError: null,
      };
    case actionTypes.CREATE_NEWJOB_ERROR:
      return {
        ...state,
        newJob: [],
        createNewJobLoading: false,
        createNewJobError: action.payload,
      };
    case actionTypes.CREATE_NEWJOB_LOADING:
      return {
        ...state,
        newJob: [],
        createNewJobLoading: true,
        createNewJobError: null,
      };
    case actionTypes.UPDATE_JOB_SUCCESS:
      return {
        ...state,
        editJobLoading: false,
        editJobError: null,
      };
    case actionTypes.UPDATE_JOB_LOADING:
      return {
        ...state,
        editJobLoading: true,
        editJobError: null,
      };
    case actionTypes.UPDATE_JOB_ERROR:
      return {
        ...state,
        editJobLoading: false,
        editJobError: action.payload.data,
      };
    case actionTypes.SEARCH_SKILL_SUCCESS:
      return {
        ...state,
        jobs: action.payload.data,
        searchJobLoading: false,
        searchJobError: null,
      };
    case actionTypes.SEARCH_SKILL_ERROR:
      return {
        ...state,
        jobs: [],
        searchJobLoading: false,
        searchJobError: action.payload.data,
      };
    case actionTypes.SEARCH_SKILL_LOADING:
      return {
        ...state,
        jobs: [],
        searchJobLoading: true,
        searchJobError: null,
      };
    case actionTypes.GET_DRAFTED_JOBS_SUCCESS:
      return {
        ...state,
        draftedJobsLoading: false,
        draftedJobsError: null,
        draftedJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.draftedJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalDraftedJobs: action.payload.data.total,
        draftedJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_DRAFTED_JOBS_LOADING:
      return {
        ...state,
        draftedJobsLoading: true,
        draftedJobsError: null,
      };
    case actionTypes.GET_DRAFTED_JOBS_ERROR:
      return {
        ...state,
        draftedJobsLoading: false,
        draftedJobsError: action.payload.data,
        draftedJobs: [],
      };
    case actionTypes.GET_OFFERED_JOBS_SUCCESS:
      return {
        ...state,
        offeredJobsLoading: false,
        offeredJobsError: null,
        offeredJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.offeredJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalPostedJobs: action.payload.data.total,
        offeredJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_OFFERED_JOBS_LOADING:
      return {
        ...state,
        offeredJobsLoading: true,
        offeredJobsError: null,
      };
    case actionTypes.GET_OFFERED_JOBS_ERROR:
      return {
        ...state,
        offeredJobsLoading: false,
        offeredJobsError: action.payload.data,
        offeredJobs: [],
      };
    case actionTypes.GET_INTERVIEWED_JOBS_SUCCESS:
      return {
        ...state,
        interviewedJobsLoading: false,
        interviewedJobsError: null,
        interviewedJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.interviewedJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalQualifiedJobs: action.payload.data.total,
        interviewedJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_INTERVIEWED_JOBS_LOADING:
      return {
        ...state,
        interviewedJobsLoading: true,
        interviewedJobsError: null,
      };
    case actionTypes.GET_INTERVIEWED_JOBS_ERROR:
      return {
        ...state,
        interviewedJobsLoading: false,
        interviewedJobsError: action.payload.data,
        interviewedJobs: [],
      };
    case actionTypes.GET_PRESENTED_JOBS_SUCCESS:
      return {
        ...state,
        presentedJobsLoading: false,
        presentedJobsError: null,
        presentedJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.presentedJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalPresentedJobs: action.payload.data.total,
        presentedJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_PRESENTED_JOBS_LOADING:
      return {
        ...state,
        presentedJobsLoading: true,
        presentedJobsError: null,
      };
    case actionTypes.GET_PRESENTED_JOBS_ERROR:
      return {
        ...state,
        presentedJobsLoading: false,
        presentedJobsError: action.payload.data,
        presentedJobs: [],
      };
    case actionTypes.GET_HIRED_JOBS_SUCCESS:
      return {
        ...state,
        hiredJobsLoading: false,
        hiredJobsError: null,
        hiredJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.hiredJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalClosedJobs: action.payload.data.total,
        hiredJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_HIRED_JOBS_LOADING:
      return {
        ...state,
        hiredJobsLoading: true,
        hiredJobsError: null,
      };
    case actionTypes.GET_HIRED_JOBS_ERROR:
      return {
        ...state,
        hiredJobsLoading: false,
        hiredJobsError: action.payload.data,
        hiredJobs: [],
      };
    case actionTypes.SET_SEARCHED_EMPLOYER: {
      const obj = {
        ...state,
      };
      if (action.payload === '') {
        if (obj.searchedJobTitle === '') {
          obj.draftJobsSortedBy = 'created_at';
          obj.offeredJobsSortedBy = 'created_at';
          obj.interviewedJobsSortedBy = 'created_at';
          obj.presentedJobsSortedBy = 'created_at';
          obj.hiredJobsSortedBy = 'created_at';
        } else {
          obj.draftJobsSortedBy = 'none';
          obj.offeredJobsSortedBy = 'none';
          obj.interviewedJobsSortedBy = 'none';
          obj.presentedJobsSortedBy = 'none';
          obj.hiredJobsSortedBy = 'none';
        }
      } else {
        obj.draftJobsSortedBy = 'none';
        obj.offeredJobsSortedBy = 'none';
        obj.interviewedJobsSortedBy = 'none';
        obj.presentedJobsSortedBy = 'none';
        obj.hiredJobsSortedBy = 'none';
      }
      obj.searchedEmployer = action.payload;
      return obj;
    }
    case actionTypes.SET_SEARCHED_JOB_TITLE: {
      const obj = {
        ...state,
      };
      if (action.payload === '') {
        if (obj.searchedEmployer === '') {
          obj.draftJobsSortedBy = 'created_at';
          obj.offeredJobsSortedBy = 'created_at';
          obj.interviewedJobsSortedBy = 'created_at';
          obj.presentedJobsSortedBy = 'created_at';
          obj.hiredJobsSortedBy = 'created_at';
        } else {
          obj.draftJobsSortedBy = 'none';
          obj.offeredJobsSortedBy = 'none';
          obj.interviewedJobsSortedBy = 'none';
          obj.presentedJobsSortedBy = 'none';
          obj.hiredJobsSortedBy = 'none';
        }
      } else {
        obj.draftJobsSortedBy = 'none';
        obj.offeredJobsSortedBy = 'none';
        obj.interviewedJobsSortedBy = 'none';
        obj.presentedJobsSortedBy = 'none';
        obj.hiredJobsSortedBy = 'none';
      }
      obj.searchedJobTitle = action.payload;
      return obj;
    }
    case actionTypes.GET_EMPLOYERS_COUNT_SUCCESS:
      return {
        ...state,
        employers: action.payload.data.count,
        employersLoading: false,
        employersError: null,
      };
    case actionTypes.GET_EMPLOYERS_COUNT_LOADING:
      return {
        ...state,
        employers: [],
        employersLoading: true,
        employersError: null,
      };
    case actionTypes.GET_EMPLOYERS_COUNT_ERROR:
      return {
        ...state,
        employers: [],
        employersLoading: false,
        employersError: action.payload.data,
      };

    case actionTypes.SEARCH_TEMPLATE_ERROR:
      return {
        ...state,
        jobTemplates: [],
        searchJobTemplatesLoading: false,
        searchJobTemplatesError: action.payload.data,
      };
    case actionTypes.SEARCH_TEMPLATE_SUCCESS:
      return {
        ...state,
        jobTemplates: action.payload.data.job_templates,
        searchJobTemplatesLoading: true,
        searchJobTemplatesError: null,
        noTemplatesData: true,
      };
    case actionTypes.SEARCH_TEMPLATE_LOADING:
      return {
        ...state,
        jobTemplates: [],
        searchJobTemplatesLoading: true,
        searchJobTemplatesError: null,
        noTemplatesData: false,
      };
    case actionTypes.MOVE_JOB_LOCAL: {
      const obj = { ...state, isMoving: true };
      let movedJob = {};
      switch (action.payload.source) {
        case 'draft':
          movedJob = obj.draftedJobs.find(job => job.id === action.payload.jobId);
          obj.draftedJobs = [...obj.draftedJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        case 'offered':
          movedJob = obj.offeredJobs.find(job => job.id === action.payload.jobId);
          obj.offeredJobs = [...obj.offeredJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        case 'interviewed':
          movedJob = obj.interviewedJobs.find(job => job.id === action.payload.jobId);
          obj.interviewedJobs = [...obj.interviewedJobs.filter(job =>
            job.id !== action.payload.jobId)];
          break;
        case 'presented':
          movedJob = obj.presentedJobs.find(job => job.id === action.payload.jobId);
          obj.presentedJobs = [...obj.presentedJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        case 'hired':
          movedJob = obj.hiredJobs.find(job => job.id === action.payload.jobId);
          obj.hiredJobs = [...obj.hiredJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        default:
          break;
      }
      switch (action.payload.destination) {
        case 'draft':
          obj.draftedJobs = sortAll([movedJob, ...obj.draftedJobs], 'created_at', 'asc', 'date');
          break;
        case 'offered':
          obj.offeredJobs = sortAll([movedJob, ...obj.offeredJobs], 'created_at', 'asc', 'date');
          break;
        case 'interviewed':
          obj.interviewedJobs = sortAll([movedJob, ...obj.interviewedJobs], 'created_at', 'asc', 'date');
          break;
        case 'presented':
          obj.presentedJobs = sortAll([movedJob, ...obj.presentedJobs], 'created_at', 'asc', 'date');
          break;
        case 'hired':
          obj.hiredJobs = sortAll([movedJob, ...obj.hiredJobs], 'created_at', 'asc', 'date');
          break;
        default:
          break;
      }
      return obj;
    }
    case actionTypes.MOVE_JOB_SUCCESS: {
      let obj = { ...state };
      obj = setLoading(obj, action.payload.source);
      obj = setLoading(obj, action.payload.destination);
      return obj;
    }
    case actionTypes.GET_JOBDETAILS_BY_ID_SUCCESS:
      return {
        ...state,
        currentJob: {
          ...action.payload.data.job_position,
          job_description: {
            ...action.payload.data.job_position.job_description,
            required_skills: _.uniqBy(
              action.payload.data.job_position.job_description.required_skills,
              obj => obj.display_value.toLowerCase(),
            ),
          },
          notes: sortAll([...action.payload.data.job_position.notes || []], 'created_at', 'asc', 'date'),
        },
        currentJobLoading: false,
        currentJobError: null,
      };
    case actionTypes.GET_JOBDETAILS_BY_ID_LOADING:
      return {
        ...state,
        currentJob: {},
        currentJobLoading: true,
        currentJobError: null,
      };
    case actionTypes.GET_JOBDETAILS_BY_ID_ERROR:
      return {
        ...state,
        currentJob: {},
        currentJobLoading: false,
        currentJobError: action.payload.data,
      };
    case actionTypes.ADD_NOTE_SUCCESS:
      return {
        ...state,
        currentJob: {
          ...state.currentJob,
          notes: [action.payload.data, ...state.currentJob.notes],
        },
        notesLoading: false,
        notesError: null,
      };
    case actionTypes.ADD_NOTE_LOADING:
      return {
        ...state,
        notesLoading: true,
        notesError: null,
      };
    case actionTypes.ADD_NOTE_ERROR:
      return {
        ...state,
        notesLoading: false,
        notesError: action.payload.data,
      };
    case actionTypes.DELETE_NOTE_SUCCESS:
      return {
        ...state,
        currentJob: {
          ...state.currentJob,
          notes: [...state.currentJob.notes.filter(note => note.id !== action.payload.id)],
        },
        notesLoading: false,
        notesError: null,
      };
    case actionTypes.DELETE_NOTE_LOADING:
      return {
        ...state,
        notesLoading: true,
        notesError: null,
      };
    case actionTypes.DELETE_NOTE_ERROR:
      return {
        ...state,
        notesLoading: false,
        notesError: action.payload.data,
      };
    case actionTypes.GET_JOB_APPLICATION_LIST_CUSTOMER_SUCCESS: {
      const stateCopy = { ...state };
      switch (action.payload.status) {
        case 'presented':
          stateCopy.inboxApplicants = [...stateCopy.inboxApplicants,
            ...action.payload.data.applications];
          stateCopy.inboxApplicantsCurrentPage = action.payload.data.page;
          stateCopy.inboxApplicantsTotal = action.payload.data.total;
          stateCopy.inboxApplicantsLoading = false;
          break;
        case 'offered':
          stateCopy.offeredApplicants = [...stateCopy.offeredApplicants,
            ...action.payload.data.applications];
          stateCopy.offeredApplicantsCurrentPage = action.payload.data.page;
          stateCopy.offeredApplicantsTotal = action.payload.data.total;
          stateCopy.offeredApplicantsLoading = false;
          break;
        case 'interviewed':
          stateCopy.interviewedApplicants = [...stateCopy.interviewedApplicants,
            ...action.payload.data.applications];
          stateCopy.interviewedApplicantsCurrentPage = action.payload.data.page;
          stateCopy.interviewedApplicantsTotal = action.payload.data.total;
          stateCopy.interviewedApplicantsLoading = false;
          break;
        case 'rejected':
          stateCopy.rejectedApplicants = [...stateCopy.rejectedApplicants,
            ...action.payload.data.applications];
          stateCopy.rejectedApplicantsCurrentPage = action.payload.data.page;
          stateCopy.rejectedApplicantsTotal = action.payload.data.total;
          stateCopy.rejectedApplicantsLoading = false;
          break;
        case 'hired':
          stateCopy.hiredApplicants = [...stateCopy.hiredApplicants,
            ...action.payload.data.applications];
          stateCopy.hiredApplicantsCurrentPage = action.payload.data.page;
          stateCopy.hiredApplicantsTotal = action.payload.data.total;
          stateCopy.hiredApplicantsLoading = false;
          break;
        default:
          break;
      }
      return stateCopy;
    }
    case actionTypes.GET_JOB_APPLICATION_LIST_CUSTOMER_LOADING: {
      const stateCopy = { ...state };
      switch (action.meta.status) {
        case 'presented':
          stateCopy.inboxApplicantsLoading = true;
          break;
        case 'offered':
          stateCopy.offeredApplicantsLoading = true;
          break;
        case 'interviewed':
          stateCopy.interviewedApplicantsLoading = true;
          break;
        case 'rejected':
          stateCopy.rejectedApplicantsLoading = true;
          break;
        case 'hired':
          stateCopy.hiredApplicantsLoading = true;
          break;
        default:
          stateCopy.candidatesLoading = true;
          stateCopy.candidatesError = null;
          break;
      }
      return stateCopy;
    }
    case actionTypes.GET_JOB_APPLICATION_LIST_CUSTOMER_ERROR:
      return {
        ...state,
        jobApplicationList: {},
        candidatesLoading: false,
        candidatesError: action.payload.data,
      };
    case actionTypes.GET_JOB_APPLICATION_LIST_CUSTOMER_COUNTS_SUCCESS: {
      let jobs = [];
      let jobType = '';
      switch (state.currentJob.status) {
        case 'drafted':
          jobs = state.draftedJobs;
          jobType = 'draftedJobs';
          break;
        case 'offered':
          jobs = state.offeredJobs;
          jobType = 'offeredJobs';
          break;
        case 'interviewed':
          jobs = state.interviewedJobs;
          jobType = 'interviewedJobs';
          break;
        case 'presented':
          jobs = state.presentedJobs;
          jobType = 'presentedJobs';
          break;
        case 'hired':
          jobs = state.hiredJobs;
          jobType = 'hiredJobs';
          break;
        default:
          break;
      }

      const obj = {};
      obj[jobType] = [
        ...jobs.map((job) => {
          if (job.id === state.currentJob.id) {
            job.applications.map((application) => {
              const app = application;
              switch (app.key) {
                case 'offered':
                  app.doc_count = action.payload.data.Qualify.Shortlisted;
                  break;
                case 'interviewed':
                  app.doc_count = action.payload.data.Present.Qualified;
                  break;
                case 'presented':
                  app.doc_count = action.payload.data.Present.Presented;
                  break;
                case 'hired':
                  app.doc_count = action.payload.data.Qualify.Rejected;
                  break;
                default:
                  break;
              }
              return application;
            });
          }
          return job;
        }),
      ];
      return {
        ...state,
        ...obj,
        candidatesLoading: false,
        candidatesError: null,
        jobApplicationCount: action.payload.data,
      };
    }
    case actionTypes.GET_JOB_APPLICATION_LIST_CUSTOMER_COUNTS_LOADING:
      return {
        ...state,
        candidatesLoading: true,
        candidatesError: null,
        jobApplicationCount: {},
      };
    case actionTypes.GET_JOB_APPLICATION_LIST_CUSTOMER_COUNTS_ERROR:
      return {
        ...state,
        candidatesLoading: false,
        candidatesError: action.payload.err,
        jobApplicationCount: {},
      };
    case actionTypes.FLUSH_THE_COUNTS:
      return {
        ...state,
        jobApplicationCount: {},
      };
    case actionTypes.FLUSH_CURRENT_JOB:
      return {
        ...state,
        currentJob: {},
      };

    case actionTypes.FLUSH_CANDIDATES:
      return {
        ...state,
        hiredApplicants: [],
        rejectedApplicants: [],
        interviewedApplicants: [],
        offeredApplicants: [],
        inboxApplicants: [],
        matchedCandidates: {},
        jobApplicationList: {},
        candidatesLoading: false,
        candidatesError: null,
      };
    case actionTypes.CLOSE_JOB_LOADING:
      return {
        ...state,
        closeJobLoading: true,
        closeJobError: null,
      };
    case actionTypes.CLOSE_JOB_SUCCESS:
      return {
        ...state,
        closeJobLoading: false,
        closeJobError: null,
      };
    case actionTypes.CLOSE_JOB_ERROR:
      return {
        ...state,
        closeJobLoading: false,
        closeJobError: action.payload,
      };
    case actionTypes.DELETE_JOB_LOADING:
      return {
        ...state,
        deleteJobLoading: true,
        deleteJobError: null,
      };
    case actionTypes.DELETE_JOB_SUCCESS:
      return {
        ...state,
        deleteJobLoading: false,
        deleteJobError: null,
      };
    case actionTypes.DELETE_JOB_ERROR:
      return {
        ...state,
        deleteJobLoading: false,
        deleteJobError: action.payload,
      };
    case actionTypes.SHORTLIST_JOB_APPLICATION_SUCCESS:
      return {
        ...state,
        shortlistJobApplicationLoading: false,
        shortlistJobApplicationError: null,
      };
    case actionTypes.SHORTLIST_JOB_APPLICATION_LOADING:
      return {
        ...state,
        shortlistJobApplicationLoading: true,
        shortlistJobApplicationError: null,
      };
    case actionTypes.SHORTLIST_JOB_APPLICATION_ERROR:
      return {
        ...state,
        shortlistJobApplicationLoading: false,
        shortlistJobApplicationError: action.payload.data,
      };
    case actionTypes.SHORTLIST_BULK_APPLICATION_SUCCESS:
      return {
        ...state,
        shortlistBulkApplicationLoading: false,
        shortlistBulkApplicationError: null,
      };
    case actionTypes.SHORTLIST_BULK_APPLICATION_LOADING:
      return {
        ...state,
        shortlistBulkApplicationLoading: true,
        shortlistBulkApplicationError: null,
      };
    case actionTypes.SHORTLIST_BULK_APPLICATION_ERROR:
      return {
        ...state,
        shortlistBulkApplicationLoading: false,
        shortlistBulkApplicationError: action.payload.data,
      };
    case actionTypes.MOVE_BULK_APPLICATION_SUCCESS: {
      return {
        ...state,
        // jobs,
        moveBulkApplicationLoading: false,
        moveBulkApplicationError: null,
      };
    }
    case actionTypes.MOVE_BULK_APPLICATION_LOADING:
      return {
        ...state,
        moveBulkApplicationLoading: true,
        moveBulkApplicationError: null,
      };
    case actionTypes.MOVE_BULK_APPLICATION_ERROR:
      return {
        ...state,
        moveBulkApplicationLoading: false,
        moveBulkApplicationError: action.payload.data,
      };
    case actionTypes.MOVE_JOB_APPLICATION_SUCCESS: {
      return {
        ...state,
        // jobs,
        moveJobApplicationLoading: false,
        moveJobApplicationError: null,
      };
    }
    case actionTypes.MOVE_JOB_APPLICATION_LOADING:
      return {
        ...state,
        moveJobApplicationLoading: true,
        moveJobApplicationError: null,
      };
    case actionTypes.MOVE_JOB_APPLICATION_ERROR:
      return {
        ...state,
        moveJobApplicationLoading: false,
        moveJobApplicationError: action.payload.data,
      };
    case actionTypes.DELETE_JOB_APPLICATION_SUCCESS:
      return {
        ...state,
        deleteJobApplicationLoading: false,
        deleteJobApplicationError: null,
      };
    case actionTypes.DELETE_JOB_APPLICATION_LOADING:
      return {
        ...state,
        deleteJobApplicationLoading: true,
        deleteJobApplicationError: null,
      };
    case actionTypes.DELETE_JOB_APPLICATION_ERROR:
      return {
        ...state,
        deleteJobApplicationLoading: false,
        deleteJobApplicationError: action.payload.data,
      };
    case actionTypes.SET_SORTED_STATE:
      return {
        ...state,
        [`${action.payload.key}JobsSortedBy`]: action.payload.value,
      };
    case actionTypes.GET_OFFERED_JOBS_FOR_CANDIDATES_SUCCESS:
      return {
        ...state,
        offeredJobsForCandidatesLoading: false,
        offeredJobsForCandidatesError: null,
        offeredJobsForCandidates: action.payload.currentPageNo === 1
          ? action.payload.data.job_positions
          : [...state.offeredJobsForCandidates, ...action.payload.data.job_positions],
        totalPostedJobsForCandidates: action.payload.data.total,
        offeredJobsForCandidatesCurrentPage: action.payload.currentPageNo,
      };
    case actionTypes.GET_OFFERED_JOBS_FOR_CANDIDATES_LOADING:
      return {
        ...state,
        offeredJobsForCandidatesLoading: true,
        offeredJobsForCandidatesError: null,
      };
    case actionTypes.GET_OFFERED_JOBS_FOR_CANDIDATES_ERROR:
      return {
        ...state,
        offeredJobsForCandidatesLoading: false,
        offeredJobsForCandidatesError: action.payload.data,
        offeredJobsForCandidates: [],
      };
    case actionTypes.FLUSH_OFFERED_JOBS_FOR_CANDIDATES:
      return {
        ...state,
        offeredJobsForCandidates: [],
      };
    case actionTypes.GET_ACCOUNT_ME_SUCCESS:
      return {
        ...state,
        accountInfo: action.payload.data,
        accountInfoLoading: false,
        accountInfoError: null,
      };
    case actionTypes.GET_ACCOUNT_ME_LOADING:
      return {
        ...state,
        accountInfoLoading: true,
        accountInfoError: null,
      };
    case actionTypes.GET_ACCOUNT_ME_ERROR:
      return {
        ...state,
        accountInfo: {},
        accountInfoError: action.payload,
        accountInfoLoading: false,
      };
    case actionTypes.RECRUITER_JOB_BOOKMARK_TALENT_ERROR: {
      return {
        ...state,
        recruiterBookmarking: false,
      };
    }
    case actionTypes.RECRUITER_JOB_BOOKMARK_TALENT_LOADING: {
      return {
        ...state,
        recruiterBookmarking: true,
      };
    }
    case actionTypes.RECRUITER_JOB_BOOKMARK_TALENT_SUCCESS: {
      return {
        ...state,
        recruiterBookmarking: false,
        matchedCandidates: {
          page: state.matchedCandidates.page,
          profiles: state.matchedCandidates.profiles ?
            [...state.matchedCandidates.profiles.map((profile) => {
              if (profile.id === action.payload.candidateId) {
                const newProfile = profile;
                newProfile.is_bookmarked = true;
                return newProfile;
              }
              return profile;
            })] : null,
          total: state.matchedCandidates.total,
        },
        jobApplicationList: {
          applications: state.jobApplicationList.applications ?
            [...state.jobApplicationList.applications.map((application) => {
              let { profile } = application;
              if (profile.id === action.payload.candidateId) {
                profile = Object.assign({}, profile, {
                  is_bookmarked: true,
                });
                return Object.assign({}, application, {
                  profile,
                });
              }
              return application;
            })] : [],
          page: state.jobApplicationList.page,
          total: state.jobApplicationList.total,
        },
      };
    }
    case actionTypes.REMOVE_RECRUITER_JOB_BOOKMARK_TALENT_ERROR: {
      return {
        ...state,
        recruiterBookmarking: false,
      };
    }
    case actionTypes.REMOVE_RECRUITER_JOB_BOOKMARK_TALENT_LOADING: {
      return {
        ...state,
        recruiterBookmarking: true,
      };
    }
    case actionTypes.REMOVE_RECRUITER_JOB_BOOKMARK_TALENT_SUCCESS: {
      return {
        ...state,
        recruiterBookmarking: false,
        matchedCandidates: {
          page: state.matchedCandidates.page,
          profiles: state.matchedCandidates.profiles ?
            [...state.matchedCandidates.profiles.map((profile) => {
              if (profile.id === action.payload.candidateId) {
                const newProfile = profile;
                newProfile.is_bookmarked = false;
                return newProfile;
              }
              return profile;
            })] : null,
          total: state.matchedCandidates.total,
        },
        jobApplicationList: {
          applications: state.jobApplicationList.applications ?
            [...state.jobApplicationList.applications.map((application) => {
              let { profile } = application;
              if (profile.id === action.payload.candidateId) {
                profile = Object.assign({}, profile, {
                  is_bookmarked: false,
                });
                return Object.assign({}, application, {
                  profile,
                });
              }
              return application;
            })] : [],
          page: state.jobApplicationList.page,
          total: state.jobApplicationList.total,
        },
      };
    }
    case actionTypes.INTERCOM_SEARCH_SUCCESS: {
      return {
        ...state,
        intercomSearch: action.payload.data,
        intercomSearchLoading: false,
        intercomSearchError: null,
      };
    }
    case actionTypes.INTERCOM_SEARCH_LOADING: {
      return {
        ...state,
        intercomSearchLoading: true,
      };
    }
    case actionTypes.INTERCOM_SEARCH_ERROR: {
      return {
        ...state,
        intercomSearch: {},
        intercomSearchLoading: false,
        intercomSearchError: action.payload,
      };
    }
    case actionTypes.INTERCOM_CREATE_SUCCESS: {
      return {
        ...state,
        intercomCreate: action.payload.data,
        intercomCreateLoading: false,
        intercomCreateError: null,
      };
    }
    case actionTypes.INTERCOM_CREATE_LOADING: {
      return {
        ...state,
        intercomCreateLoading: true,
      };
    }
    case actionTypes.INTERCOM_CREATE_ERROR: {
      return {
        ...state,
        intercomCreate: {},
        intercomCreateLoading: false,
        intercomCreateError: action.payload,
      };
    }
    default:
      return state;
  }
}
