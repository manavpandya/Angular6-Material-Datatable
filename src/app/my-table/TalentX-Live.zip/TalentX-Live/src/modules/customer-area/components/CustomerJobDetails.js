import React, { Component } from 'react';
import { connect } from 'react-redux';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import ReduxBlockUi from 'react-block-ui';
// import PdfIcon from 'material-ui-icons/InsertDriveFile';
import { showNotification } from '../../../utils/Notifications';
import SuperCustomerHeader from './SuperCustomerHeader';
import JobMenu from './CustomerJobMenu';
import CustomerJobHeader from './CustomerJobHeader';
import JobDescription from './CustomerDescription';
import {
  getJobDetailsById,
  getJobApplicationListCustomer,
  flushCandidates,
} from './../redux/actions';
import CustomerJobActivity from './CustomerJobActivity';

const pageSize = 100;

class CustomerJobDetails extends Component { //eslint-disable-line
  constructor(props) {
    super(props);
    this.getData = this.getData.bind(this);
    this.getNextPageForApplicants = this.getNextPageForApplicants.bind(this);
    this.checkLoaderVisibilityForCandidates = this.checkLoaderVisibilityForCandidates.bind(this);
  }
  componentDidMount() {
    this.props.flushCandidates();
    this.init();
  }

  getData(isReset) {
    if (isReset) {
      this.props.flushCandidates();
    }
    const jobId = this.props.match.params.id;
    ['interviewed', 'presented', 'offered', 'hired', 'rejected'].forEach(status =>
      this.props.getJobApplicationListCustomer(jobId, status, 1, pageSize)
        .catch(() => {
          showNotification(this.props.translate('jobDetailNotFound'), 'error', 8000);
          // this.props.history.push('/customer');
        }));
  }

  getNextPageForApplicants(stageKey) {
    const jobId = this.props.match.params.id;
    const getJobApplicationListApi = this.props.getJobApplicationListCustomer;
    const {
      interviewedApplicantsCurrentPage,
      inboxApplicantsCurrentPage,
      offeredApplicantsCurrentPage,
      hiredApplicantsCurrentPage,
      rejectedApplicantsCurrentPage,
    } = this.props.customerArea;
    switch (stageKey) {
      case 'interviewed':
        getJobApplicationListApi(
          jobId,
          stageKey,
          interviewedApplicantsCurrentPage + 1,
          pageSize,
        );
        break;
      case 'presented':
        getJobApplicationListApi(
          jobId,
          stageKey,
          inboxApplicantsCurrentPage + 1,
          pageSize,
        );
        break;
      case 'offered':
        getJobApplicationListApi(
          jobId,
          stageKey,
          offeredApplicantsCurrentPage + 1,
          pageSize,
        );
        break;
      case 'hired':
        getJobApplicationListApi(
          jobId,
          stageKey,
          hiredApplicantsCurrentPage + 1,
          pageSize,
        );
        break;
      case 'rejected':
        getJobApplicationListApi(
          jobId,
          stageKey,
          rejectedApplicantsCurrentPage + 1,
          pageSize,
        );
        break;
      default:
        break;
    }
  }


  init() {
    const jobId = this.props.match.params.id;
    this.props.getJobDetailsById(jobId).catch(() => {
      showNotification(this.props.translate('jobDetailNotFound'), 'error', 8000);
      // this.props.history.push('/customer');
    });
    this.getData();
  }

  checkLoaderVisibilityForCandidates(stageKey) {
    const {
      interviewedApplicantsCurrentPage,
      interviewedApplicantsTotal,
      inboxApplicantsCurrentPage,
      inboxApplicantsTotal,
      offeredApplicantsCurrentPage,
      offeredApplicantsTotal,
      hiredApplicantsCurrentPage,
      hiredApplicantsTotal,
      rejectedApplicantsCurrentPage,
      rejectedApplicantsTotal,
    } = this.props.customerArea;
    switch (stageKey) {
      case 'interviewed':
        return interviewedApplicantsCurrentPage === 0
          ? true
          : (interviewedApplicantsTotal /
            (interviewedApplicantsCurrentPage * pageSize)) > 1;
      case 'presented':
        return inboxApplicantsCurrentPage === 0
          ? true
          : (inboxApplicantsTotal /
              (inboxApplicantsCurrentPage * pageSize)) > 1;
      case 'offered':
        return offeredApplicantsCurrentPage === 0
          ? true
          : (offeredApplicantsTotal /
              (offeredApplicantsCurrentPage * pageSize)) > 1;
      case 'hired':
        return hiredApplicantsCurrentPage === 0
          ? true
          : (hiredApplicantsTotal /
              (hiredApplicantsCurrentPage * pageSize)) > 1;
      case 'rejected':
        return rejectedApplicantsCurrentPage === 0
          ? true
          : (rejectedApplicantsTotal /
              (rejectedApplicantsCurrentPage * pageSize)) > 1;
      default:
        return true;
    }
  }

  render() {
    const {
      interviewedApplicantsTotal,
      inboxApplicantsTotal,
      offeredApplicantsTotal,
      hiredApplicantsTotal,
      rejectedApplicantsTotal,
      interviewedApplicantsLoading,
      inboxApplicantsLoading,
      offeredApplicantsLoading,
      hiredApplicantsLoading,
      rejectedApplicantsLoading,
    } = this.props.customerArea;

    return (
      <ReduxBlockUi
        tag="div"
        blocking={this.props.currentJobLoading}
        className="customerJob-details"
        renderChildren
      >
        <div className="page customer">
          <SuperCustomerHeader {...this.props} />
          <main className="job details">
            <CustomerJobHeader
              jobTitle={this.props.currentJob && this.props.currentJob.job_description
                ? this.props.currentJob.job_description.job_title : null}
            />
            <div className="contain">
              <aside className="job-menu">
                <JobMenu
                  getTotalCounts={{
                    interviewedApplicantsTotal,
                    inboxApplicantsTotal,
                    offeredApplicantsTotal,
                    hiredApplicantsTotal,
                    rejectedApplicantsTotal,
                  }}
                  getLoadingState={{
                    interviewedApplicantsLoading,
                    inboxApplicantsLoading,
                    offeredApplicantsLoading,
                    hiredApplicantsLoading,
                    rejectedApplicantsLoading,
                  }}
                  getNextPageForApplicants={this.getNextPageForApplicants}
                  checkLoaderVisibilityForCandidates={this.checkLoaderVisibilityForCandidates}
                  getData={this.getData}
                  inbox={this.props.customerArea.inboxApplicants}
                  interviewing={this.props.customerArea.interviewedApplicants}
                  offered={this.props.customerArea.offeredApplicants}
                  hired={this.props.customerArea.hiredApplicants}
                  rejected={this.props.customerArea.rejectedApplicants}
                />
              </aside>
              <main>
                <CustomerJobActivity />
              </main>
              <aside className="job-description">
                <h4>Job Description</h4>
                <JobDescription currentJob={this.props.currentJob} />
                {/* <h5 className="icon">
                  <PdfIcon style={{ color: 'crimson', marginRight: '0.5em' }} />
                  <span>UTC200-WorleyParson-ProjectManager.pdf</span>
                </h5> */}
              </aside>
            </div>
          </main>
        </div>
      </ReduxBlockUi>
    );
  }
}

CustomerJobDetails.propTypes = {
  customerArea: PropTypes.objectOf(PropTypes.any).isRequired,
  history: PropTypes.objectOf(PropTypes.any).isRequired,
  currentJob: PropTypes.objectOf(PropTypes.any).isRequired,
  match: PropTypes.objectOf(PropTypes.any).isRequired,
  getJobDetailsById: PropTypes.func.isRequired,
  translate: PropTypes.func.isRequired,
  getJobApplicationListCustomer: PropTypes.func.isRequired,
  flushCandidates: PropTypes.func.isRequired,
  currentJobLoading: PropTypes.bool.isRequired,
};

function mapStateToProps(state) {
  return {
    customerArea: state.customerArea,
    currentJob: state.customerArea.currentJob,
    currentJobLoading: state.customerArea.currentJobLoading,
  };
}

export default connect(
  mapStateToProps,
  {
    getJobDetailsById,
    getJobApplicationListCustomer,
    flushCandidates,
  },
)(withTranslate(CustomerJobDetails));
