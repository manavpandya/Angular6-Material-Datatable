import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import Tooltip from 'material-ui/Tooltip';
import NotificationIcon from 'material-ui-icons/ExitToApp';

const SuperCustomerHeader = props => (
  <div className="customer-page">
    <header>
      <h1>
        <span>{props.accountInfo.customer && props.accountInfo.customer.name}</span>
      </h1>
      <div className="profile">
        <div className="label-username flex-logout-button">
          {props.accountInfo && props.accountInfo.username}
          <Tooltip title="Logout" className="logout-link" placement="bottom">
            <Link to="/logout" >
              <NotificationIcon className="notification" />
            </Link>
          </Tooltip>
        </div>
      </div>
    </header>
  </div>
);

SuperCustomerHeader.propTypes = {
  accountInfo: PropTypes.objectOf(PropTypes.any).isRequired,
};

export default SuperCustomerHeader;
