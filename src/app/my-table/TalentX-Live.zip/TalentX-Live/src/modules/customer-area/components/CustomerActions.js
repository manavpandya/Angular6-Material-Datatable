import React from 'react';
import PropTypes from 'prop-types';
import MoreIcon from 'material-ui-icons/MoreVert';
import { MenuList, MenuItem } from 'material-ui/Menu';
import Menu from '../../../shared/compound/Menu';
import { showNotification } from './../../../utils/Notifications';

class CustomerActions extends React.Component { // eslint-disable-line
  render() {
    const menuItems = this.props.actionMenuItems || [];
    return (
      <div className="candidate-actions" style={{ display: menuItems.length === 0 ? 'none' : 'block' }}>
        <Menu
          label=""
          iconPrefix={<MoreIcon className="more-vert" style={{ color: this.props.isDisabled || menuItems.length === 0 ? 'rgb(200, 200, 200)' : '#333' }} />}
          isDisabled={
            this.props.isDisabled
            || menuItems.length === 0
          }
          popup={
            <MenuList role="menu">
              {
                menuItems.map((menuItem, index) => (
                  <MenuItem
                    key={menuItem.key}
                    className={index === menuItems.length - 1 ? '' : 'menu-item'}
                    onClick={() => {
                      this.props.moveJobApplication(this.props.appId, menuItem.key)
                      .then((res) => {
                        this.props.getData(true);
                        showNotification(res.action.payload.data.message, 'success');
                      })
                      .catch((res) => {
                        showNotification(res.message, 'error');
                      });
                  }}
                  >
                    {menuItem.label}
                  </MenuItem>
                ))
              }
            </MenuList>
          }
        />
      </div>
    );
  }
}

CustomerActions.propTypes = {
  actionMenuItems: PropTypes.arrayOf(PropTypes.object).isRequired,
  isDisabled: PropTypes.bool,
  moveJobApplication: PropTypes.func,
  getData: PropTypes.func,
  appId: PropTypes.string,
};

CustomerActions.defaultProps = {
  appId: '',
  isDisabled: false,
  moveJobApplication: () => {},
  getData: () => {},
};

export default CustomerActions;
