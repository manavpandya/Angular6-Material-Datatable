import React from 'react';
import Table, { TableBody, TableCell, TableHead, TableRow, TablePagination, TableFooter } from 'material-ui/Table';
import { MenuList, MenuItem } from 'material-ui/Menu';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import Paper from 'material-ui/Paper';
import { withStyles } from 'material-ui/styles';
import Tooltip from 'material-ui/Tooltip';
import MoreVertIcon from 'material-ui-icons/MoreVert';
import Checkbox from 'material-ui/Checkbox';
import Call from 'material-ui-icons/Call';
import Email from 'material-ui-icons/Email';
import Menu from '../../../shared/compound/Menu';
import LinkButton from '../../../shared/basic/LinkButton';
import Loader from '../../../shared/basic/Loader';

const stylePaper = {
  root: {
    marginTop: 25,
    maxHeight: '100%',
    overflow: 'auto',
    padding: 0,
    paddingBottom: 111,
  },
  popup: {
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 2000,
    padding: '0.5rem',
  },
};

const Users = props => (
  props.loading
    ? <Loader />
    : (
      <Paper classes={{ root: props.classes.root }} elevation={0} className="scroller">
        <Table className="overlay-table">
          <TableHead className="table-header">
            <TableRow>
              <TableCell padding="checkbox" className="users-checkbox">
                <Checkbox
                  indeterminate={
                    props.selectedUsers.length > 0 &&
                    props.selectedUsers.length < props.users.length
                  }
                  checked={props.selectedUsers.length === props.users.length}
                  onChange={(evt, checked) => props.selectAllRows(evt, checked, props.users)}
                />
              </TableCell>
              <TableCell className="users-name">{props.translate('username')}</TableCell>
              <TableCell className="users-name">{props.translate('fullName')}</TableCell>
              <TableCell className="users-title">{props.translate('userTitle')}</TableCell>
              <TableCell className="users-role">{props.translate('userRole')}</TableCell>
              <TableCell className="users-city">{props.translate('userLocation')}</TableCell>
              <TableCell className="users-timezone">{props.translate('userTimeZone')}</TableCell>
              <TableCell className="users-contact">{props.translate('userContact')}</TableCell>
              <TableCell className="users-menu" />
            </TableRow>
          </TableHead>
          <TableBody>
            {
              props.users.map(user => (
                <TableRow
                  key={user.id}
                  hover
                  role="checkbox"
                  tabIndex={-1}
                  aria-checked={props.selectedUsers.indexOf(user) !== -1}
                  selected={props.selectedUsers.indexOf(user) !== -1}
                >
                  <TableCell padding="checkbox" className="users-checkbox">
                    <Checkbox
                      checked={props.selectedUsers.indexOf(user) !== -1}
                      onClick={evt => props.selectRow(evt, user)}
                    />
                  </TableCell>
                  <TableCell className="users-name">
                    <LinkButton className="user-name" onClick={() => props.editUser(user)}>
                      {user.username}
                    </LinkButton>
                  </TableCell>
                  <TableCell className="users-full-name">{user.name}</TableCell>
                  <TableCell className="users-title">{user.title}</TableCell>
                  <TableCell className="users-role">{user.roles}</TableCell>
                  <TableCell>
                    {user.location && user.location.city} {user.location && user.location.country ? `- ${user.location.country}` : ''}
                  </TableCell>
                  <TableCell className="users-timezone">{user.timezone}</TableCell>
                  <TableCell className="users-contact">
                    <div className="contact-info">
                      {
                        user.phone
                          ?
                          (
                            <Tooltip
                              id="tooltip-phone"
                              className="multiline-tooltip"
                              title={user.phone}
                            >
                              <Call className="phone contact-icon" />
                            </Tooltip>
                          )
                          :
                          (
                            <Call className="phone contact-icon disabled" />
                          )
                      }
                      {
                        user.email
                          ?
                            <Tooltip
                              id="tooltip-phone"
                              className="multiline-tooltip"
                              title={user.email}
                            >
                              <Email className="email contact-icon" />
                            </Tooltip>
                          :
                          (
                            <Email className="email contact-icon disabled" />
                          )
                      }
                    </div>
                  </TableCell>
                  <TableCell className="text-right users-menu">
                    <Menu
                      menuStyle={stylePaper.popup}
                      iconSuffix={<MoreVertIcon style={{ color: '#000000', width: '17px', marginRight: '0.25rem' }} />}
                      popup={
                        <MenuList role="menu">
                          <MenuItem onClick={() => props.editUser(user)}>{props.translate('editRecord')}</MenuItem>
                          <MenuItem onClick={() => props.deleteUser(user)}>{props.translate('deleteRecord')}</MenuItem>
                        </MenuList>
                      }
                    />
                  </TableCell>
                </TableRow>
              ))
            }
          </TableBody>
          <TableFooter>
            <TableRow>
              <TablePagination
                labelRowsPerPage={props.translate('rowsPerPage')}
                colSpan={9}
                className="pagination"
                rowsPerPageOptions={[25, 50, 100]}
                count={props.total}
                rowsPerPage={props.resultsPerPage}
                page={props.page}
                backIconButtonProps={{
                  'aria-label': 'Previous Page',
                }}
                nextIconButtonProps={{
                  'aria-label': 'Next Page',
                }}
                onChangePage={
                  (event, page) => props.handlePagination(event, page)
                }
                onChangeRowsPerPage={props.handleChangeRowsPerPage}
              />
            </TableRow>
          </TableFooter>
        </Table>
      </Paper>
    )
);

Users.propTypes = {
  translate: PropTypes.func.isRequired,
  selectedUsers: PropTypes.arrayOf(PropTypes.object),
  selectAllRows: PropTypes.func.isRequired,
  handlePagination: PropTypes.func.isRequired,
  handleChangeRowsPerPage: PropTypes.func.isRequired,
  users: PropTypes.arrayOf(PropTypes.object),
  loading: PropTypes.bool,
  page: PropTypes.number.isRequired,
  resultsPerPage: PropTypes.number,
  total: PropTypes.number,
  classes: PropTypes.object.isRequired, // eslint-disable-line
};

Users.defaultProps = {
  total: 0,
  resultsPerPage: 100,
  selectedUsers: [],
  users: [],
  loading: false,
};

export default withStyles(stylePaper)(withTranslate(Users));
