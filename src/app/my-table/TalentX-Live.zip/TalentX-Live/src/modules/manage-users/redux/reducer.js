import * as actionTypes from './actionTypes';

const initialState = {
  users: [],
  selectedUsers: [],
  loading: false,
  error: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case actionTypes.GET_USERS_SUCCESS: {
      return {
        ...state,
        users: action.payload.data.accounts,
        totalUsers: action.payload.data.total,
        page: action.payload.data.page,
        loading: false,
        error: null,
      };
    }
    case actionTypes.GET_USERS_LOADING: {
      return {
        ...state,
        users: [],
        loading: true,
        error: null,
      };
    }
    case actionTypes.GET_USERS_ERROR: {
      return {
        ...state,
        users: [],
        loading: false,
        error: action.payload,
      };
    }
    case actionTypes.SAVE_USER_SUCCESS: {
      return {
        ...state,
        users: [...state.users, action.payload.data],
        loading: false,
        error: null,
      };
    }
    case actionTypes.SAVE_USER_LOADING: {
      return {
        ...state,
        loading: true,
        error: null,
      };
    }
    case actionTypes.SAVE_USER_ERROR: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    }
    case actionTypes.UPDATE_USER_SUCCESS: {
      return {
        ...state,
        users: [...state.users.map((user) => {
          if (user.id === action.payload.data.account.id) {
            return action.payload.data.account;
          }
          return user;
        })],
        loading: false,
        error: null,
      };
    }
    case actionTypes.UPDATE_USER_LOADING: {
      return {
        ...state,
        loading: true,
        error: null,
      };
    }
    case actionTypes.UPDATE_USER_ERROR: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    }
    case actionTypes.DELETE_USER_SUCCESS: {
      return {
        ...state,
        selectedUsers: [...state.selectedUsers.filter(user => user.id !== action.payload.id)],
        users: [...state.users.filter(user => user.id !== action.payload)],
        loading: false,
        error: null,
      };
    }
    case actionTypes.DELETE_USER_LOADING: {
      return {
        ...state,
        loading: true,
        error: null,
      };
    }
    case actionTypes.DELETE_USER_ERROR: {
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    }
    case actionTypes.SET_SELECTED_USERS: {
      return {
        ...state,
        selectedUsers: action.payload,
      };
    }
    case actionTypes.ADD_USER_TO_SELECTED_USERS: {
      return {
        ...state,
        selectedUsers: [...state.selectedUsers, action.payload],
      };
    }
    case actionTypes.REMOVE_USER_FROM_SELECTED_USERS: {
      return {
        ...state,
        selectedUsers: [...state.selectedUsers.filter(user => user.id !== action.payload.id)],
      };
    }
    default:
      return state;
  }
}
