import React from 'react';
import PropTypes from 'prop-types';
import Button from 'material-ui/Button';
import Message from 'material-ui-icons/Message';
import Call from 'material-ui-icons/Call';
import Email from 'material-ui-icons/Email';

const UserDetails = (props) => {
  const user = {
    id: props.id,
    username: props.username,
    title: props.title,
    location: props.location,
    timezone: props.timezone,
    phone: props.phone,
    email: props.email,
    lastUpdated: props.lastUpdated,
  };

  return (
    <div className="user">
      <p className="username">{props.username}</p>
      { props.title && <p className="title">{props.title}</p> }
      {
        (props.location || (props.timezone && props.timezone !== 'NA')) &&
        <p>{`${props.location && props.location.city ? props.location.city : ''}${props.location && props.location.city ? ', ' : ''}${props.location && props.location.country ? props.location.country : ''}${props.timezone && props.timezone !== 'NA' ? props.timezone : ''}`}</p>
      }
      <br />
      <p><span className="last-updated">Last Updated:</span> {props.lastUpdated ? props.lastUpdated : 'Never'}</p>
      <div className="contact-info bottom-left">
        <Message className="chat contact-icon" />
        {
          user.phone
            ?
            (
              <a href={`call:${user.phone}`}>
                <Call className="phone contact-icon" />
              </a>
            )
            :
            (
              <Call className="phone contact-icon disabled" />
            )
        }
        {
          user.email
            ?
            (
              <a href={`mailto:${user.email}`}>
                <Email className="email contact-icon" />
              </a>
            )
            :
            (
              <Email className="email contact-icon disabled" />
            )
        }
      </div>
      <div className="bottom-right">
        <Button default onClick={props.disableUser}>DISABLE</Button>
        <Button default onClick={() => props.deleteUser(user)}>DELETE</Button>
        <Button default onClick={() => props.editUser(user)}>EDIT</Button>
      </div>
    </div>
  );
};

UserDetails.propTypes = {
  id: PropTypes.string,
  username: PropTypes.string,
  title: PropTypes.string,
  location: PropTypes.shape({
    city: PropTypes.string,
    country: PropTypes.string,
  }),
  timezone: PropTypes.string,
  lastUpdated: PropTypes.string,
  phone: PropTypes.string,
  email: PropTypes.string,
  disableUser: PropTypes.func,
  deleteUser: PropTypes.func,
  editUser: PropTypes.func,
};

UserDetails.defaultProps = {
  id: null,
  username: null,
  title: null,
  location: null,
  timezone: null,
  lastUpdated: null,
  phone: null,
  email: null,
  disableUser: () => {},
  deleteUser: () => {},
  editUser: () => {},
};

export default UserDetails;
