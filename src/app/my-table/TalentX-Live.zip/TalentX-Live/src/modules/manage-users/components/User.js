import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { Form, Field, reduxForm } from 'redux-form';
import { TextField, Select as RenderSelect, Checkbox } from 'redux-form-material-ui';
import { MenuItem } from 'material-ui/Menu';
import Input, { InputLabel } from 'material-ui/Input';
import { withStyles } from 'material-ui/styles';
import { FormControl, FormControlLabel } from 'material-ui/Form';
import PropTypes from 'prop-types';
import Typography from 'material-ui/Typography';
import ArrowDropDownIcon from 'material-ui-icons/ArrowDropDown';
import ArrowDropUpIcon from 'material-ui-icons/ArrowDropUp';
import ClearIcon from 'material-ui-icons/Clear';
import Select from 'react-select';
import MultiSelect from '../../../shared/basic/MultiSelect';
import { required, matchRegEx, email, phone, specialCharactersRegex } from '../../../utils/validators';
import timezone from '../../../assets/timezone.json';
import userRoles from '../../../assets/userRoles.json';
import cities from '../../../assets/cities.json';
import Option from '../../../shared/basic/Option';
import { LONG, MEDIUM } from '../../../constants/stringLengths';

const ITEM_HEIGHT = 48;

const styles = theme => ({
  root: {
    flexGrow: 1,
    height: 250,
    width: 200,
  },
  chip: {
    margin: theme.spacing.unit / 4,
  },
  // We had to use a lot of global selectors in order to style react-select.
  // We are waiting on https://github.com/JedWatson/react-select/issues/1679
  // to provide a better implementation.
  // Also, we had to reset the default style injected by the library.
  '@global': {
    '.Select-control': {
      display: 'flex',
      alignItems: 'center',
      border: 0,
      height: 'auto',
      background: 'transparent',
      '&:hover': {
        boxShadow: 'none',
      },
    },
    '.Select-multi-value-wrapper': {
      flexGrow: 1,
      display: 'flex',
      flexWrap: 'wrap',
    },
    '.Select--multi .Select-input': {
      margin: 0,
    },
    '.Select.has-value.is-clearable.Select--single > .Select-control .Select-value': {
      padding: 0,
    },
    '.Select-noresults': {
      padding: theme.spacing.unit * 2,
    },
    '.Select-input': {
      display: 'inline-flex !important',
      padding: 0,
      height: 'auto',
    },
    '.Select-input input': {
      background: 'transparent',
      border: 0,
      padding: 0,
      cursor: 'default',
      display: 'inline-block',
      fontFamily: 'inherit',
      fontSize: 'inherit',
      margin: 0,
      outline: 0,
    },
    '.Select-placeholder, .Select--single .Select-value': {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      display: 'flex',
      alignItems: 'center',
      fontFamily: theme.typography.fontFamily,
      fontSize: theme.typography.pxToRem(16),
      padding: 0,
    },
    '.Select-placeholder': {
      opacity: 0.42,
      color: theme.palette.common.black,
    },
    '.Select-menu-outer': {
      backgroundColor: theme.palette.background.paper,
      boxShadow: theme.shadows[2],
      position: 'absolute',
      left: 0,
      top: `calc(100% + ${theme.spacing.unit}px)`,
      width: '100%',
      zIndex: 2,
      maxHeight: ITEM_HEIGHT * 4.5,
    },
    '.Select.is-focused:not(.is-open) > .Select-control': {
      boxShadow: 'none',
    },
    '.Select-menu': {
      maxHeight: ITEM_HEIGHT * 4.5,
      overflowY: 'auto',
    },
    '.Select-menu div': {
      boxSizing: 'content-box',
    },
    '.Select-arrow-zone, .Select-clear-zone': {
      color: theme.palette.action.active,
      cursor: 'pointer',
      height: 21,
      width: 21,
      zIndex: 1,
    },
    // Only for screen readers. We can't use display none.
    '.Select-aria-only': {
      position: 'absolute',
      overflow: 'hidden',
      clip: 'rect(0 0 0 0)',
      height: 1,
      width: 1,
      margin: -1,
    },
  },
});


const suggestions = timezone.map(suggestion => ({
  value: suggestion,
  label: suggestion,
}));

function SelectWrapped(props) {
  const { ...other } = props;
  return (
    <Select
      onCloseResetsInput
      onBlurResetsInput
      optionComponent={Option}
      noResultsText={<Typography>No results found</Typography>}
      arrowRenderer={arrowProps =>
        (arrowProps.isOpen ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />)}
      clearRenderer={() => <ClearIcon />}
      valueComponent={(valueProps) => {
        const { children } = valueProps;
        return <div className="Select-value">{children}</div>;
      }}
      {...other}
    />
  );
}

const User = props => (
  <Form onSubmit={props.handleSubmit(values =>
    props.saveOrUpdateUser(values, props.initialValues))}
  >
    <div className="user-form">
      <div className="part-left">
        <Field
          fullWidth
          id="username"
          name="username"
          label={props.translate('usersName')}
          // disabled={props.isEditing}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: MEDIUM,
          }}
        />
        <Field
          fullWidth
          id="password"
          name="password"
          label={props.translate('userPassword')}
          type="password"
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: LONG,
          }}
        />

        <Field
          fullWidth
          id="confirm_password"
          name="confirm_password"
          label={props.translate('userPasswordConfirm')}
          type="password"
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: LONG,
          }}
        />
        <FormControl className="user-form-field">
          <InputLabel htmlFor="title">{props.translate('userTitle')}</InputLabel>
          <Field
            fullWidth
            label={props.translate('userTitle')}
            name="title"
            component={RenderSelect}
            placeholder="Title"
          >
            <MenuItem value="">Please select ...</MenuItem>
            <MenuItem value="Recruiter">Recruiter</MenuItem>
            <MenuItem value="Sr. Recruiter">Sr. Recruiter</MenuItem>
            <MenuItem value="Recruiting Manager">Recruiting Manager</MenuItem>
          </Field>
        </FormControl>
        <FormControl className="user-form-field">
          <InputLabel htmlFor="userRoles">{props.translate('userRole')}</InputLabel>
          <Field
            fullWidth
            label={props.translate('userRole')}
            name="roles"
            component={RenderSelect}
            onChange={(event, val) => {
              if (val === 'CUSTOMER') {
                props.setCustomerField(true);
              } else {
                props.setCustomerField(false);
              }
              }
            }
            placeholder="User roles"
          >
            <MenuItem value="">Please select ...</MenuItem>
            {
              userRoles.map(data =>
                (
                  <MenuItem
                    key={data.key}
                    value={data.key}
                  >
                    {data.value}
                  </MenuItem>
                ))
            }
          </Field>
        </FormControl>
        {props.showCustomerField === true ?
          <FormControl className="user-form-field">
            <label htmlFor="customer_id" className="selectLabelFix">
              Customer
            </label>
            <Field
              options={props.customerSuggestions}
              valueKey="id"
              labelKey="name"
              component={MultiSelect}
              multi={false}
              id="customer_id"
              name="customer_id"
            />
          </FormControl>
        : null}
        <Field
          id="phone"
          name="phone"
          label={props.translate('userPhone')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: MEDIUM,
          }}
        />
      </div>
      <div className="part-right">
        <Field
          fullWidth
          id="name"
          name="name"
          label={props.translate('fullName')}
          // disabled={props.isEditing}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: LONG,
          }}
        />
        <Field
          fullWidth
          id="email"
          name="email"
          label={props.translate('userEmail')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: LONG,
          }}
        />
        <FormControl className="user-form-field">
          <InputLabel htmlFor="city">{props.translate('userCity')}</InputLabel>
          <Field
            fullWidth
            label={props.translate('userCity')}
            name="city"
            component={RenderSelect}
            onChange={(event, val) => {
              cities.map((f) => {
                if (f.city === val) {
                  props.change('country', f.country);
                  return f.country;
                }
                return true;
              });
              }
            }
            placeholder="City"
          >
            <MenuItem value="">Please select ...</MenuItem>
            {
              cities.map(data =>
                (
                  <MenuItem
                    key={data.city}
                    value={data.city}
                  >
                    {data.city}
                  </MenuItem>
                ))
            }
          </Field>
        </FormControl>
        <Field
          fullWidth
          id="country"
          name="country"
          label={props.translate('userCountry')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: MEDIUM,
          }}
        />
        <FormControl className="user-form-field">
          <label htmlFor="timezone" className="selectLabelFix">{props.translate('userTimeZone')}</label>
          <Field
            inputComponent={SelectWrapped}
            type="text"
            // defaultValue={props.isEditing ? props.initialValues : props.single}
            inputProps={{
              classes: props.classes,
              value: props.single,
              onChange: props.handleChangeSingle,
              placeholder: 'Select Timezone',
              instanceId: 'timezone-select-single',
              id: 'timezone-select-single',
              name: 'timezone-select-single',
              simpleValue: true,
              options: suggestions,
            }}
            id="timezone"
            name="timezone"
            className="select-dropdown--timezone"
            component={Input}
          />
        </FormControl>
        {
          props.isEditing &&
          <div className="locked-checkbox">
            <FormControlLabel
              control={<Field name="is_locked" component={Checkbox} />}
              label="Locked"
            />
          </div>
        }
      </div>
    </div>
  </Form>
);

User.propTypes = {
  translate: PropTypes.func.isRequired,
  // isEditing: PropTypes.bool.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  change: PropTypes.func.isRequired,
  handleChangeSingle: PropTypes.func.isRequired,
  setCustomerField: PropTypes.func.isRequired,
  saveOrUpdateUser: PropTypes.func,
  getCustomerSuggestions: PropTypes.func.isRequired, // eslint-disable-line
  classes: PropTypes.object.isRequired, // eslint-disable-line
  initialValues: PropTypes.object.isRequired, // eslint-disable-line
  single: PropTypes.string,
  customerSuggestions: PropTypes.arrayOf(PropTypes.object),
  showCustomerField: PropTypes.bool,
  isEditing: PropTypes.bool,
};

User.defaultProps = {
  single: '',
  name: '',
  customerSuggestions: [],
  userRole: null,
  loading: false,
  showCustomerField: false,
  saveOrUpdateUser: () => {},
  getCustomerSuggestions: () => {},
  isEditing: false,
};

const validate = (values, props) => {
  const errors = {};
  if (values.password !== values.confirm_password) {
    errors.confirm_password = 'Password & Confirm Password not matching';
  }
  if (props.isEditing === false) {
    errors.username = required(values.username);
    errors.password = required(values.password);
  }
  if (values.username) errors.username = !matchRegEx(values.username, specialCharactersRegex) && 'Invalid Name';
  if (values.username && values.username.trim().length === 0) errors.username = 'Invalid Name';

  // country
  if (values.country) errors.country = !matchRegEx(values.country, specialCharactersRegex) && 'Invalid Country';
  if (values.country && values.country.trim().length === 0) errors.country = 'Invalid Country';

  errors.customer_id = required(values.customer_id);
  errors.email = required(values.email);
  if (!errors.email) errors.email = !matchRegEx(values.email, email) && 'Invalid email';
  errors.phone = required(values.phone);
  if (!errors.phone) errors.phone = !matchRegEx(values.phone, phone) && 'Invalid number';
  return errors;
};

export default reduxForm({
  form: 'UserForm', validate, enableReinitialize: true, keepDirtyOnReinitialize: true,
})(withStyles(styles)(withTranslate(User)));

