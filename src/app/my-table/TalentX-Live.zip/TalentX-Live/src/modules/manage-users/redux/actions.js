import api from '../../../shared/api';
import * as constants from './actionTypes';

export function getUsersFunction(params) {
  const { page = 1, perPage = 100 } = params || {};
  return {
    type: constants.GET_USERS,
    payload: api.get(`accounts?page=${page <= 0 ? 1 : page}&per_page=${perPage}`),
  };
}

export function saveUserFunction(user) {
  return {
    type: constants.SAVE_USER,
    payload: api.post('accounts', user),
  };
}

export function updateUserFunction(user) {
  return {
    type: constants.UPDATE_USER,
    payload: api.put(`accounts/${user.id}`, user),
  };
}

export function deleteUserFunction(userId) {
  return {
    type: constants.DELETE_USER,
    payload: api.delete(`accounts/${userId}`).then(() => userId),
  };
}

export function setSelectedUsersFunction(users) {
  return {
    type: constants.SET_SELECTED_USERS,
    payload: users,
  };
}

export function addUserToSelectedUsersFunction(user) {
  return {
    type: constants.ADD_USER_TO_SELECTED_USERS,
    payload: user,
  };
}

export function removeUserFromSelectedUsersFunction(user) {
  return {
    type: constants.REMOVE_USER_FROM_SELECTED_USERS,
    payload: user,
  };
}
