import React, { Component } from 'react';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withTranslate } from 'react-redux-multilingual';
import Dialog, { DialogTitle, DialogContent, DialogContentText, DialogActions } from 'material-ui/Dialog';
import Button from 'material-ui/Button';
import CloseIcon from 'material-ui-icons/Close';
import AddIcon from 'material-ui-icons/Add';
import DeleteIcon from 'material-ui-icons/Delete';
import { submit, change, formValueSelector } from 'redux-form';
import { withStyles } from 'material-ui/styles';
import Users from './components/Users';
import UserDetails from './components/UserDetails';
import User from './components/User';
import { logoutFunction } from '../auth/redux/actions';
import {
  getUsersFunction,
  saveUserFunction,
  updateUserFunction,
  deleteUserFunction,
  setSelectedUsersFunction,
  addUserToSelectedUsersFunction,
  removeUserFromSelectedUsersFunction,
} from './redux/actions';
import {
  getCustomers,
} from '../manage-customers/redux/actions';
import Loader from '../../shared/basic/Loader';
import { showNotification } from './../../utils/Notifications';
import BoardHeader from '../../shared/compound/board/BoardHeader';
import AppBarContent from '../../shared/compound/AppBarContent';
import AppBarButtons from '../../shared/compound/AppBarButtons';

let initialValues = {};

const styles = {
  paper: {
    overflow: 'visible',
  },
};


class UsersContainer extends Component {
  constructor(props) {
    super(props);
    this.selectAllRows = this.selectAllRows.bind(this);
    this.selectRow = this.selectRow.bind(this);
    this.openUserDetails = this.openUserDetails.bind(this);
    this.closeUserDetails = this.closeUserDetails.bind(this);
    this.selectUser = this.selectUser.bind(this);
    this.confirmedDeleteUser = this.confirmedDeleteUser.bind(this);
    this.deleteUser = this.deleteUser.bind(this);
    this.confirmedDeleteSelectedUsers = this.confirmedDeleteSelectedUsers.bind(this);
    this.deleteSelectedUsers = this.deleteSelectedUsers.bind(this);
    this.editUser = this.editUser.bind(this);
    this.addUser = this.addUser.bind(this);
    this.closeAddOrEditUser = this.closeAddOrEditUser.bind(this);
    this.closeConfirmDelete = this.closeConfirmDelete.bind(this);
    this.closeConfirmDeleteSelectedUsers = this.closeConfirmDeleteSelectedUsers.bind(this);
    this.saveOrUpdateUser = this.saveOrUpdateUser.bind(this);
    this.saveOrUpdateUserHelper = this.saveOrUpdateUserHelper.bind(this);
    this.handleChangeSingle = this.handleChangeSingle.bind(this);
    this.renderAddButton = this.renderAddButton.bind(this);
    this.renderDeleteButton = this.renderDeleteButton.bind(this);
    this.setCustomerField = this.setCustomerField.bind(this);
    this.handlePagination = this.handlePagination.bind(this);
    this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this);

    this.state = {
      selectedUser: {},
      addOrEditUser: false,
      confirmDelete: false,
      confirmDeleteSelectedUsers: false,
      isEditing: false,
      openUserDetails: false,
      single: '',
      page: 0,
      resultsPerPage: 100,
    };
  }

  componentDidMount() {
    this.props.getUsers({ page: 1, perPage: 100 });
    this.props.getCustomers();
  }

  setCustomerField(isCustomerSelected) {
    this.setState({
      showCustomerField: isCustomerSelected,
    });
  }

  handleChangeSingle(single) {
    this.props.dispatch(change('UserForm', 'timezone-select-single', single));
    this.setState({
      single,
    });
  }

  selectAllRows(event, checked, users) {
    if (checked) {
      this.props.setSelectedUsers(users);
    } else {
      this.props.setSelectedUsers([]);
    }
  }

  selectRow(event, user) {
    if (!this.props.selectedUsers.includes(user)) {
      this.props.addUserToSelectedUsers(user);
    } else {
      this.props.removeUserFromSelectedUsers(user);
    }
  }

  openUserDetails() {
    this.setState({
      openUserDetails: true,
    });
  }

  closeUserDetails() {
    this.setState({
      openUserDetails: false,
      single: '',
    });
  }

  selectUser(user) {
    this.setState({
      selectedUser: user,
      openUserDetails: true,
    });
  }

  confirmedDeleteUser() {
    const { id } = this.state.selectedUser;
    this.props.deleteUser(this.state.selectedUser.id).then(() => {
      showNotification(this.props.translate('userDeleted'), 'success', 8000);
      this.setState({
        selectedUser: {},
        openUserDetails: false,
        confirmDelete: false,
      });
      this.props.setSelectedUsers([...this.props.selectedUsers.filter(user => user.id !== id)]);
    }).catch((err) => {
      showNotification(err.message, 'error', 8000);
    });
  }

  deleteUser(user) {
    this.setState({
      selectedUser: user,
      confirmDelete: true,
    });
  }

  confirmedDeleteSelectedUsers() {
    Promise.all(this.props.selectedUsers.map(user => this.props.deleteUser(user.id))).then(() => {
      showNotification(this.props.translate('selectedUserDeleted'), 'success', 8000);
      this.setState({
        confirmDeleteSelectedUsers: false,
      });
      this.props.setSelectedUsers([]);
    }).catch((err) => {
      showNotification(err.message, 'error', 8000);
    });
  }

  deleteSelectedUsers() {
    this.setState({
      confirmDeleteSelectedUsers: true,
    });
  }

  editUser(user) {
    const tempUser = user.location
      ?
      {
        ...user,
        city: user.location.city,
        country: user.location.country,
        roles: user.roles,
      }
      : user;
    initialValues = tempUser;
    this.setState({
      selectedUser: user,
      openUserDetails: false,
      addOrEditUser: true,
      isEditing: true,
      single: user.timezone,
      showCustomerField: tempUser.roles === 'CUSTOMER',
    });
  }

  addUser() {
    initialValues = {};
    this.setState({
      selectedUser: {},
      addOrEditUser: true,
      isEditing: false,
      showCustomerField: false,
      single: '',
    });
  }

  closeAddOrEditUser() {
    this.setState({
      selectedUser: {},
      addOrEditUser: false,
      isEditing: false,
    });
    initialValues = {};
  }

  closeConfirmDelete() {
    this.setState({
      confirmDelete: false,
    });
  }

  closeConfirmDeleteSelectedUsers() {
    this.setState({
      confirmDeleteSelectedUsers: false,
    });
  }

  saveOrUpdateUser(values, initValues) {
    let timezoneNew; // eslint-disable-line
    if (values['timezone-select-single']) {
      timezoneNew = values['timezone-select-single'];
    } else if (typeof values['timezone-select-single'] === typeof null) {
      timezoneNew = '';
    } else {
      timezoneNew = values.timezone ? values.timezone : '';
    }

    const user = {
      name: values.name,
      title: values.title,
      timezone: timezoneNew,
      email: values.email,
      phone: values.phone,
    };
    if (values.roles !== initValues.roles) {
      user.roles = values.roles;
    }
    if (values.customer_id !== initValues.customer_id) {
      user.customer_id = this.state.showCustomerField ? values.customer_id.id : '';
    }
    if (values.city || values.country) {
      user.location = {
        city: values.city,
        country: values.country,
      };
    }

    if (this.state.isEditing) {
      if (values.password !== '') {
        user.password = values.password;
        user.confirm_password = values.confirm_password;
      }
      if (values.username !== initValues.username) {
        user.username = values.username;
      }
      if (values.is_locked !== initValues.is_locked) {
        user.is_locked = values.is_locked;
      }
      user.id = this.state.selectedUser.id;
      this.saveOrUpdateUserHelper(this.props.updateUser(user));
    } else {
      user.username = values.username;
      user.password = values.password;
      user.confirm_password = values.confirm_password;
      this.saveOrUpdateUserHelper(this.props.saveUser(user));
    }
  }

  saveOrUpdateUserHelper(saveOrUpdateFunc) {
    saveOrUpdateFunc
      .then(() => {
        showNotification(`${this.props.translate('userData')} ${this.state.isEditing ? this.props.translate('statusUpdated') : this.props.translate('statusSaved')} ${this.props.translate('successfully')}`, 'success', 8000);
        this.closeAddOrEditUser();
      }).catch((err) => {
        const message = (err && err.response) &&
        (err.response.data.message || err.response.data.account.message);
        if (typeof message === 'object') {
          Object.keys(message).forEach((key) => {
            const obj = message[key];
            showNotification(`${obj}`, 'error', 8000);
          });
        }
        if (typeof message === 'string') {
          showNotification(`${message}`, 'error', 8000);
        }
      });
  }

  handleChangeRowsPerPage(event) {
    let query = {};
    this.setState({ resultsPerPage: event.target.value, page: 0 }, () => {
      query = {
        page: 0,
        perPage: event.target.value,
      };
      this.props.getUsers(query);
    });
  }

  handlePagination(event, page) {
    if (page > this.state.page) {
      // hit api for next page data
      this.setState({
        page: this.state.page + 1,
      });
      const query = {
        page: page + 1,
        perPage: this.state.resultsPerPage,
      };
      this.props.getUsers(query);
    } else {
      // hit api for previous page data
      this.setState({
        page: this.state.page - 1,
      });
      const query = {
        page: this.state.page < 0 ? 0 : this.state.page,
        perPage: this.state.resultsPerPage,
      };
      this.props.getUsers(query);
    }
  }

  renderAddButton() {
    return (
      <Button
        variant="raised"
        color="primary"
        className={`${this.props.classes.button} add-user`}
        onClick={this.props.addUser}
      >
        <AddIcon className={this.props.classes.leftIcon} />
        Add
      </Button>
    );
  }

  renderDeleteButton() {
    return (
      <Button
        variant="raised"
        color="secondary"
        className={`${this.props.classes.button} add-user`}
        onClick={this.props.deleteSelectedUsers}
        disabled={this.props.selectedUsers.length <= 0}
      >
        <DeleteIcon className={this.props.classes.leftIcon} />
            Delete
      </Button>
    );
  }


  render() {
    return (
      <div className="page">
        <BoardHeader logoutFunction={this.props.logout} />
        <section className="users">
          <div className="container">
            <div className="user-header">
              <AppBarContent
                header={this.props.translate('userManagement')}
                appBarButtons={
                  <AppBarButtons
                    addUser={this.addUser}
                    deleteSelectedUsers={this.deleteSelectedUsers}
                    disabled={this.props.selectedUsers.length <= 0}
                  />
              }
              />
            </div>
            <Users
              selectAllRows={this.selectAllRows}
              selectRow={this.selectRow}
              selectedUsers={this.props.selectedUsers}
              users={this.props.users}
              selectUser={this.selectUser}
              loading={this.props.loading}
              editUser={this.editUser}
              deleteUser={this.deleteUser}
              handleChangeRowsPerPage={this.handleChangeRowsPerPage}
              handlePagination={this.handlePagination}
              page={this.state.page}
              total={this.props.total}
              resultsPerPage={this.state.resultsPerPage}
            />
            <Dialog
              open={this.state.openUserDetails}
              onClose={this.closeUserDetails}
              autoFocus
            >
              <div className="user-details-wrapper">
                <div className="user-details">
                  <main>
                    <UserDetails
                      {...this.state.selectedUser}
                      loading={this.props.loading}
                      disableUser={this.disableUser}
                      deleteUser={this.deleteUser}
                      editUser={this.editUser}
                    />
                  </main>
                </div>
              </div>
            </Dialog>
            <Dialog
              className="OF-visible-for-Modal"
              open={this.state.addOrEditUser}
              onClose={this.closeAddOrEditUser}
              autoFocus
              maxWidth="md"
            >
              {
                this.props.loading && <Loader />
              }
              <div className="add-edit-user">
                <header className="dialog-header">
                  <h1>{this.state.isEditing ? this.props.translate('userEdit') : this.props.translate('userCreate') }</h1>
                  <Button onClick={this.closeAddOrEditUser}>
                    <CloseIcon />
                  </Button>
                </header>
                <div>
                  <main>
                    <User
                      handleChangeSingle={this.handleChangeSingle}
                      handleChangeCustomerId={this.handleChangeCustomerId}
                      single={this.state.single}
                      customerName={this.state.customerName}
                      customer_id={this.props.customer_id}
                      setCustomerField={this.setCustomerField}
                      showCustomerField={this.state.showCustomerField}
                      multi={this.state.multi}
                      {...this.state.selectedUser}
                      loading={this.props.loading}
                      isEditing={this.state.isEditing}
                      initialValues={initialValues}
                      saveOrUpdateUser={this.saveOrUpdateUser}
                      users={this.props.users}
                      customerSuggestions={this.props.customers || []}
                      getCustomerSuggestions={this.getCustomerSuggestions}
                    />
                  </main>
                </div>
              </div>
              <DialogActions>
                <Button
                  default
                  onClick={this.closeAddOrEditUser}
                >
                  {this.props.translate('cancel')}
                </Button>
                <Button
                  color="primary"
                  variant="raised"
                  onClick={() => this.props.dispatch(submit('UserForm'))}
                >
                  {this.state.isEditing ? this.props.translate('updateRecord') : this.props.translate('saveRecord')}
                </Button>
              </DialogActions>
            </Dialog>
            <Dialog
              onClose={this.closeConfirmDelete}
              open={this.state.confirmDelete}
            >
              {
                this.props.loading && <Loader />
              }
              <DialogTitle>
                {this.props.translate('deleteRecord')}
              </DialogTitle>
              <DialogContent>
                <DialogContentText>
                  {this.props.translate('userDeleteMessage')}
                  <strong> {this.state.selectedUser.username} </strong>?
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button
                  default
                  onClick={this.closeConfirmDelete}
                >
                  {this.props.translate('cancel')}
                </Button>
                <Button
                  color="primary"
                  variant="raised"
                  onClick={this.confirmedDeleteUser}
                >
                  {this.props.translate('deleteRecord')}
                </Button>
              </DialogActions>
            </Dialog>
            <Dialog
              onClose={this.closeConfirmDeleteSelectedUsers}
              open={this.state.confirmDeleteSelectedUsers}
            >
              {
                this.props.loading && <Loader />
              }
              <DialogTitle>
                {this.props.translate('deleteRecord')}
              </DialogTitle>
              <DialogContent>
                <DialogContentText>
                  {this.props.translate('areYouSureWantTo')} {this.props.translate('deleteRecord')} {this.props.translate('all')} <strong>{this.props.translate('selected')}</strong> {this.props.translate('users')}
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button
                  default
                  onClick={this.closeConfirmDeleteSelectedUsers}
                >
                  {this.props.translate('cancel')}
                </Button>
                <Button
                  color="secondary"
                  variant="raised"
                  onClick={this.confirmedDeleteSelectedUsers}
                >
                  {this.props.translate('deleteRecord')}
                </Button>
              </DialogActions>
            </Dialog>
          </div>
        </section>
      </div>
    );
  }
}

UsersContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  customer_id: PropTypes.string,
  logout: PropTypes.func,
  getUsers: PropTypes.func.isRequired,
  getCustomers: PropTypes.func.isRequired,
  saveUser: PropTypes.func,
  updateUser: PropTypes.func,
  deleteUser: PropTypes.func,
  setSelectedUsers: PropTypes.func,
  addUserToSelectedUsers: PropTypes.func,
  removeUserFromSelectedUsers: PropTypes.func,
  users: PropTypes.arrayOf(PropTypes.object),
  selectedUsers: PropTypes.arrayOf(PropTypes.object),
  customers: PropTypes.arrayOf(PropTypes.object),
  loading: PropTypes.bool,
  dispatch: PropTypes.func.isRequired,
  addUser: PropTypes.func,
  deleteSelectedUsers: PropTypes.func,
  classes: PropTypes.object.isRequired, //eslint-disable-line
  total: PropTypes.number, //eslint-disable-line
  page: PropTypes.number, //eslint-disable-line
};

UsersContainer.defaultProps = {
  logout: () => {},
  saveUser: () => {},
  updateUser: () => {},
  deleteUser: () => {},
  setSelectedUsers: () => {},
  addUserToSelectedUsers: () => {},
  removeUserFromSelectedUsers: () => {},
  users: [],
  customers: [],
  selectedUsers: [],
  deleteSelectedUsers: () => {},
  loading: false,
  addUser: () => {},
  customer_id: '',
  total: 0,
  page: 1,
};

const selector = formValueSelector('UserForm');

const mapStateToProps = state => ({
  customer_id: selector(state, 'customer_id'),
  users: state.users.users,
  total: state.users.totalUsers,
  page: state.users.page,
  customers: state.customers.customers,
  selectedUsers: state.users.selectedUsers,
  loading: state.users.loading,
  error: state.users.error,
});

const mapDispatchToProps = dispatch => ({
  logout: () => dispatch(logoutFunction()),
  getUsers: params => dispatch(getUsersFunction(params)),
  getCustomers: () => dispatch(getCustomers()),
  saveUser: values => dispatch(saveUserFunction(values)),
  updateUser: values => dispatch(updateUserFunction(values)),
  deleteUser: values => dispatch(deleteUserFunction(values)),
  setSelectedUsers: users => dispatch(setSelectedUsersFunction(users)),
  addUserToSelectedUsers: user => dispatch(addUserToSelectedUsersFunction(user)),
  removeUserFromSelectedUsers: user => dispatch(removeUserFromSelectedUsersFunction(user)),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(withTranslate(UsersContainer)));//eslint-disable-line
