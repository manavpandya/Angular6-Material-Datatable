import React from 'react';
import BoardHeader from '../../../shared/compound/board/BoardHeader';

const ProfileAppbar = () => (
  <div className="page">
    <BoardHeader />
  </div>
);

export default ProfileAppbar;
