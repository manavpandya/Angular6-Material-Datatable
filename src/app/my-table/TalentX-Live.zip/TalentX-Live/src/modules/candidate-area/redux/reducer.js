import * as actionTypes from './actionTypes';

const initialState = {
  register: {},
  registerLoading: false,
  registerSuccess: false,
  registerError: null,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case actionTypes.REGISTER_CANDIDATE_SUCCESS:
      return {
        ...state,
        register: action.payload,
        registerLoading: false,
        registerSuccess: true,
        registerError: null,
      };
    case actionTypes.REGISTER_CANDIDATE_LOADING:
      return {
        ...state,
        register: null,
        registerLoading: true,
        registerSuccess: false,
        registerError: null,
      };
    case actionTypes.REGISTER_CANDIDATE_ERROR:
      return {
        ...state,
        register: null,
        registerLoading: false,
        registerSuccess: false,
        registerError: action.payload,
      };
    default:
      return state;
  }
}
