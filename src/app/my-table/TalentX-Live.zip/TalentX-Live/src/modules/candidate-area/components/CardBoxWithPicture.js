import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import Card, { CardContent, CardMedia } from 'material-ui/Card';
import Typography from 'material-ui/Typography';

const styles = {
  media: {
    height: '172px',
    width: 'auto',
  },
  card: {
    minWidth: 275,
  },
  bullet: {
    display: 'inline-block',
    margin: '0 2px',
    transform: 'scale(0.8)',
  },
  title: {
    float: 'right',
    color: 'white',
    width: 'auto',
    height: '45px',
    padding: '3px 7px',
    display: 'flex',
    fontSize: '17px',
    background: 'rgba(0, 0, 0, 0.38)',
    textAlign: 'center',
    marginRight: '5px',
    marginTop: '4px',
    alignItems: 'center',
    borderRadius: '50px',
    justifyContent: 'center',
    textShadow: '0px 1px 0px grey',
  },
  pos: {
    marginBottom: 12,
  },
  paper: {
    padding: '0px',
  },
};

const ProfileMatchingCard = props => (
  <Card style={{
width: '255px', height: '303px', padding: 0, margin: '1%',
}}
  >
    <CardMedia
      className={props.classes.media}
      image={props.imageSrc}
      title="Contemplative Reptile"
    >
      <Typography component="div" className={props.classes.title} color="textSecondary">
        {`${props.value}`}
      </Typography>
    </CardMedia>
    <CardContent className="cardBoxWithPicture-card-content">
      <Typography variant="headline" component="h2" >
        {props.title}
      </Typography>
      <Typography component="div" className="cardBoxWithPicture-typography">
        {props.description}

      </Typography>
    </CardContent>
  </Card>
);


ProfileMatchingCard.propTypes = {
  classes: PropTypes.object.isRequired, //eslint-disable-line
  title: PropTypes.string,
  value: PropTypes.string,
  description: PropTypes.string,
  imageSrc: PropTypes.string,
};

ProfileMatchingCard.defaultProps = {
  title: 'JOB ABC',
  value: '000',
  description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor. ',
  imageSrc: 'http://via.placeholder.com/350x150',
};


export default withStyles(styles)(ProfileMatchingCard);
