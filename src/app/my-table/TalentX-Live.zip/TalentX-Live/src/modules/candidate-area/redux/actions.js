import api from '../../../shared/api';
import * as ActionTypes from './actionTypes';

export default function registerCandidate(values) {
  return {
    type: ActionTypes.REGISTER_CANDIDATE,
    payload: api.post('/accounts/register', values),
  };
}
