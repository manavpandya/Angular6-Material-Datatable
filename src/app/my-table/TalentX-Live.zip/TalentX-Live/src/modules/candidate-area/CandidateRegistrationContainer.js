import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import Paper from 'material-ui/Paper';
import Button from 'material-ui/Button';
import RegistrationForm from './components/registrationForm';
import registerCandidate from './redux/actions';
import Loader from '../../shared/basic/Loader';
import { showNotification } from '../../utils/Notifications';
import Confirmation from '../auth/components/Confirmation';
import { required, matchRegEx, specialCharactersRegex, email, phone } from '../../utils/validators';

const validate = (values) => {
  const errors = {};
  errors.username = required(values.username);
  if (values.username) errors.username = !matchRegEx(values.username, specialCharactersRegex) && this.props.translate('invalidName');
  if (values.username && values.username.trim().length === 0) errors.username = this.props.translate('invalidName');
  errors.email = required(values.email);
  if (!errors.email) errors.email = !matchRegEx(values.email, email) && this.props.translate('invalidEmail');
  errors.password = required(values.password);
  if (values.phone) {
    errors.phone = !matchRegEx(values.phone, phone) && this.props.translate('invalidNumber');
  }
  return errors;
};

class CandidateRegistrationContainer extends Component {
  constructor(props) {
    super(props);
    this.moreUserInformation = this.moreUserInformation.bind(this);
  }

  moreUserInformation(values) {
    this.props.registerCandidate(values).catch(error => showNotification(error, 'error', 5000));
  }

  render() {
    return (
      <div>
        {
          this.props.registerSuccess ?
            <div>
              <Confirmation
                header={this.props.translate('emailAccontVerification')}
              />
            </div>
          :
            <Paper className="registration widget">
              <h1 style={{ textAlign: 'center', color: 'black' }}>
                {this.props.translate('createAccount')}
              </h1>
              <div className="register-parent">
                <div className="linkedInBtn">
                  <Button>{this.props.translate('signupWithLinkedin')}</Button>
                </div>
                <div className="horizontal-line" />
                <RegistrationForm
                  moreUserInformation={this.moreUserInformation}
                  validate={validate}
                />
              </div>
            </Paper>
        }
        {
          this.props.registerLoading
          ?
            <Loader />
          :
            ''
        }
      </div>
    );
  }
}

CandidateRegistrationContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  history: PropTypes.object.isRequired, // eslint-disable-line
  registerCandidate: PropTypes.func,
  registerLoading: PropTypes.bool,
  registerSuccess: PropTypes.bool,
};

CandidateRegistrationContainer.defaultProps = {
  registerCandidate: () => {},
  registerLoading: false,
  registerSuccess: false,
};

const mapStateToProps = state => ({
  registerLoading: state.registerCandidate.registerLoading,
  registerSuccess: state.registerCandidate.registerSuccess,
});

const mapDispatchToProps = dispatch => ({
  dispatch,
  registerCandidate: values => dispatch(registerCandidate(values)),
});

export default
connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(CandidateRegistrationContainer)));// eslint-disable-line

