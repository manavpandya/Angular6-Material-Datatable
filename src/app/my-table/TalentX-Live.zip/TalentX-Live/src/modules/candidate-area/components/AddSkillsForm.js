import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import Typography from 'material-ui/Typography';
import GridList, { GridListTile } from 'material-ui/GridList';

import Paper from 'material-ui/Paper';
import { Form, Field, reduxForm } from 'redux-form';
import Button from 'material-ui/Button';
import { FormControl } from 'material-ui/Form';
import { required } from '../../../utils/validators';
import ReactSelectMulti from '../../../shared/compound/ReactSelectMulti';


const suggestions = [
  { label: 'React' },
  { label: 'Angular' },
  { label: 'PHP' },
  { label: 'NodeJs' },
].map(suggestion => ({
  value: suggestion.label,
  label: suggestion.label,
}));

const styles = theme => ({
  root: theme.mixins.gutters({
    paddingTop: 16,
    paddingBottom: 16,
    marginTop: theme.spacing.unit * 3,
  }),
});

const AddSkillsForm = props => (
  <div style={{ width: '100%' }}>
    <GridList className="add-skills" cols={2}>
      <GridListTile className="add-skills-gridtile">
        <h1>Boost your profile</h1>
        <Typography component="div" color="textSecondary">
          What would you say your greatest skills are?
        </Typography>
        <Paper elevation={1} className={props.classes.root}>
          <div className="paper-form-field">
            <br />
            <Form onSubmit={props.handleSubmit(props.saveSkills)} >
              <FormControl className="form-field-multiSkills">
                <Field
                  suggestions={suggestions}
                  fullWidth
                  id="multiSkills"
                  name="multiSkills"
                  className="select-dropdown--multiSkills"
                  component={ReactSelectMulti}
                />
              </FormControl>
              <br />
              <br />
              <Button
                color="primary"
                onClick={() => props.submit('AddSkillsForm')}
              >
                Submit
              </Button>
            </Form>
          </div>
        </Paper>
      </GridListTile>
      <GridListTile>
        <div className="highest-possible-match-container">
          <Typography component="p">
          Highest match possible
          </Typography>
          <Typography className="highest-possible-match">
          72.3%
          </Typography>
        </div>
      </GridListTile>
    </GridList>

  </div>
);


AddSkillsForm.propTypes = {
  classes: PropTypes.object.isRequired, //eslint-disable-line
  handleSubmit: PropTypes.func.isRequired,
  saveSkills: PropTypes.func.isRequired,
  submit: PropTypes.func.isRequired,
  multiSkillsValue: PropTypes.arrayOf(), //eslint-disable-line
};

AddSkillsForm.defaultProps = {
  multiSkillsValue: null,
};

const validate = (values) => {
  const errors = {};
  errors.multiSkills = required(values.multiSkills);
  return errors;
};

export default reduxForm({ form: 'AddSkillsForm', validate, enableReinitialize: true })(withStyles(styles)(AddSkillsForm));
