import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Input, { InputLabel, InputAdornment } from 'material-ui/Input';
import { FormControl } from 'material-ui/Form';
import IconButton from 'material-ui/IconButton';
import Visibility from 'material-ui-icons/Visibility';
import VisibilityOff from 'material-ui-icons/VisibilityOff';

const getColor = (touched, error, isFocused) => {
  if (touched && error) {
    return '#f44336';
  }
  return isFocused ? '#17375C' : '#a4a4a4';
};

class InputPassword extends Component {
  constructor(props) {
    super(props);

    this.state = {
      showPassword: false,
      selectFocused: false,
    };

    this.setSelectFocused = this.setSelectFocused.bind(this);
    this.handleClickShowPasssword = this.handleClickShowPasssword.bind(this);
    this.handleMouseDownPassword = this.handleMouseDownPassword.bind(this);
  }

  setSelectFocused(isFocused) {
    this.setState({
      selectFocused: isFocused,
    });
  }

  handleMouseDownPassword(event) { // eslint-disable-line
    event.preventDefault();
  }

  handleClickShowPasssword() {
    this.setState({ showPassword: !this.state.showPassword });
  }

  render() {
    const { meta } = this.props;
    const { touched, error } = meta;
    return (
      <FormControl>
        <InputLabel
          htmlFor="adornment-password"
          style={{
            color: getColor(touched, error, this.state.selectFocused),
          }}
        >
          Password
        </InputLabel>
        <Input
          {...this.props.input}
          id="adornment-password"
          type={this.state.showPassword ? 'text' : 'password'}
          error={touched && error}
          onFocus={() => {
            this.props.input.onFocus();
            this.setSelectFocused(true);
          }}
          onBlur={() => {
            this.props.input.onBlur();
            this.setSelectFocused(false);
          }}
          endAdornment={
            <InputAdornment position="end" >
              <IconButton
                className="iconButton"
                aria-label="Toggle password visibility"
                onClick={this.handleClickShowPasssword}
                onMouseDown={this.handleMouseDownPassword}
              >
                {this.state.showPassword ? <Visibility /> : <VisibilityOff /> }
              </IconButton>
            </InputAdornment>
          }
        />
        {
          touched && error &&
          <p className="error">
            {error}
          </p>
        }
      </FormControl>
    );
  }
}

InputPassword.propTypes = {
  meta: PropTypes.object.isRequired, // eslint-disable-line
  input: PropTypes.object.isRequired // eslint-disable-line
};

export default InputPassword;
