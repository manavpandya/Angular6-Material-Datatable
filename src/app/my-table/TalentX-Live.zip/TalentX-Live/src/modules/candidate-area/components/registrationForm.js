import React from 'react';
import PropTypes from 'prop-types';
import { reduxForm, Form, Field } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import Button from 'material-ui/Button';
import InputPassword from './inputPassword';

const RegistrationForm = props => (
  <div className="register-form">
    <Form onSubmit={props.handleSubmit(props.moreUserInformation)}>
      <div className="register-fields">
        <div>
          <Field
            name="username"
            component={TextField}
            type="text"
            label="Username"
            fullWidth
          />
        </div>
        <div>
          <Field
            name="email"
            component={TextField}
            label="Email"
          />
        </div>
        <div>
          <Field
            name="password"
            component={InputPassword}
            label="Password"
          />
        </div>
        <div>
          <Field
            name="phone"
            component={TextField}
            label="Phone"
          />
        </div>
      </div>
      <div className="register">
        <Button
          variant="raised"
          color="primary"
          type="submit"
        >
          Register
        </Button>
      </div>
    </Form>
  </div>
);

RegistrationForm.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  moreUserInformation: PropTypes.func,
};

RegistrationForm.defaultProps = {
  moreUserInformation: () => {},
};

export default reduxForm({ form: 'Registration' })(RegistrationForm);
