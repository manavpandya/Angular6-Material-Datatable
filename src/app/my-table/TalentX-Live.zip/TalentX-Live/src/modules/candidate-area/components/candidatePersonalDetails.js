import React from 'react';
import GridList, { GridListTile } from 'material-ui/GridList';
import ModeEdit from 'material-ui-icons/ModeEdit';
import candidateProfileImage from '../../../assets/images/candidate-profile.png';

const CandidatePersonalDetails = () => (
  <GridList className="profile-details" cols={2} cellHeight="auto">
    <GridListTile className="profile-details-component">
      <div className="personal-edit-info">
        <h1>Personal Details</h1>
        <div className="edit-button"><ModeEdit /></div>
      </div>
      <div className="personal-br">
        <div>
          <div>Name</div>
          <div className="profile-h2">Joe Citizen</div>
        </div>
        <div>
          <div>Location</div>
          <div className="profile-h2">Melbourne, Austradiva</div>
        </div>
        <div>
          <div>Lorem Ipsum</div>
          <div className="profile-h2">Lorem Ipsum</div>
        </div>
        <div>
          <div>Lorem Ipsum</div>
          <div className="profile-h2">Lorem Ipsum</div>
        </div>
      </div>
    </GridListTile>
    <GridListTile className="profile-image">
      <img
        src={candidateProfileImage}
        alt="candidate-profile"
      />
    </GridListTile>
  </GridList>
);

export default CandidatePersonalDetails;
