import React from 'react';
import PropTypes from 'prop-types';
// import Dropzone from 'react-dropzone';
import Grid from 'material-ui/Grid';
import GridList, { GridListTile } from 'material-ui/GridList';
import Button from 'material-ui/Button';

let upload;

const CandidateUploadCV = props => (
  <Grid item xs={12}>
    <GridList className="upload-cv" cols={2} cellHeight="auto">
      <GridListTile style={{ margin: 'auto' }}>
        <div className="cv-text">
          <h1>Pre-fill from your CV or LinkedIn</h1>
          <p>We will extract as much as we can.</p>
        </div>
      </GridListTile>
      <GridListTile rows={2} className="button-cv">
        <input
          type="file"
          ref={(ref) => { upload = ref; }}
          style={{ display: 'none' }}
          onChange={props.fileUpload}
        />
        <Button variant="raised" onClick={() => upload.click()}>
          UPLOAD CV
        </Button>
        <Button variant="raised">
            LINKEDIN
        </Button>
      </GridListTile>
    </GridList>
  </Grid>
);

CandidateUploadCV.propTypes = {
  fileUpload: PropTypes.func,
};

CandidateUploadCV.defaultProps = {
  fileUpload: () => {},
};

export default CandidateUploadCV;
