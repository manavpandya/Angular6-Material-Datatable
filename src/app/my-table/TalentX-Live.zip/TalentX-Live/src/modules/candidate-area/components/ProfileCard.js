import React from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import { withStyles } from 'material-ui/styles';
import Card, { CardContent, CardMedia } from 'material-ui/Card';
import Button from 'material-ui/Button';

const styles = {
  media: {
    width: '219px',
    borderRadius: '262px',
    height: '219px',
    margin: 'auto',
  },
  card: {
    minWidth: 275,
  },
  bullet: {
    display: 'inline-block',
    margin: '0 2px',
    transform: 'scale(0.8)',
  },
  title: {
    float: 'right',
    color: 'white',
    width: 'auto',
    height: '45px',
    padding: '3px 7px',
    display: 'flex',
    fontSize: '17px',
    background: 'rgba(0, 0, 0, 0.38)',
    textAlign: 'center',
    marginRight: '5px',
    marginTop: '4px',
    alignItems: 'center',
    borderRadius: '50px',
    justifyContent: 'center',
    textShadow: '0px 1px 0px grey',
  },
  pos: {
    marginBottom: 12,
  },
  paper: {
    padding: '0px',
  },
};

const ProfileCard = props => (
  <Card
    elevation={0}
    raised={false}
    style={{
  width: '255px', height: '303px', padding: 0, margin: '1%', background: 'transparent',

  }}
  >
    <CardMedia
      className={props.classes.media}
      image={props.ImageSrc}
      title="Contemplative Reptile"
    />
    <CardContent style={{ textAlign: 'center' }}>
      <Button size="medium" color="primary" onClick={() => props.history.push('/candidate/profile')}>
        VIEW PROFILE
      </Button>
    </CardContent>
  </Card>
);


ProfileCard.propTypes = {
  classes: PropTypes.object.isRequired, //eslint-disable-line
  history: PropTypes.object.isRequired, //eslint-disable-line
  ImageSrc: PropTypes.string,
};

ProfileCard.defaultProps = {
  ImageSrc: 'http://i.pravatar.cc/355',
};


export default withRouter(withStyles(styles)(ProfileCard));
