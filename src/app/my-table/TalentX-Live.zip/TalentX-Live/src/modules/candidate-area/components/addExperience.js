import React from 'react';
import GridList, { GridListTile } from 'material-ui/GridList';
import AddIcon from 'material-ui-icons/Add';
import ModeEdit from 'material-ui-icons/ModeEdit';
import Button from 'material-ui/Button';

const AddExperience = () => (
  <div className="add-experience">
    <GridList cols={1} cellHeight="auto">
      <GridListTile>
        <div className="work-history">
          <h1>Work History</h1>
          <div className="edit-button"><ModeEdit /></div>
        </div>
        <GridList cols={3} style={{ paddingRight: '10%' }} cellHeight="auto">
          <GridListTile>
            <p>Lorem Ipsum</p>
            <h1>Lorem Ipsum</h1>
          </GridListTile>
          <GridListTile>
            <p>Lorem Ipsum</p>
            <h1>Lorem Ipsum</h1>
          </GridListTile>
          <GridListTile>
            <p>Lorem Ipsum</p>
            <h1>Lorem Ipsum</h1>
          </GridListTile>
        </GridList>
        <h3>Lorem Ipsum</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          Aenean euismod bibendum laoreet. Proin gravida dolor sit
          amet lacus accumsan et viverra justo commodo.
          Proin sodales pulvinar sic tempor.
          Sociis natoque penatibus et magnis dis parturient montes,
          nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate,
          felis tellus mollis orci,
          sed rhoncus pronin sapien nunc accuan eget.
        </p>
      </GridListTile>
    </GridList>
    <Button variant="raised">
      <AddIcon />
      Add Experience
    </Button>
  </div>
);

export default AddExperience;
