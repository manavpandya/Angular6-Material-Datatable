import React, { Component } from 'react';
import ProfileAppbar from './components/profileAppbar';
import CandidatePersonalDetails from './components/candidatePersonalDetails';
import CandidateUploadCV from './components/candidateUploadCV';
import AddSkillsForm from './components/AddSkillsForm';
import AddExperience from './components/addExperience';

class CandidateProfileContainer extends Component {
  constructor(props) {
    super(props);

    this.fileUpload = this.fileUpload.bind(this);
    this.saveSkills = this.saveSkills.bind(this);
  }

  fileUpload(event) { // eslint-disable-line
    event.stopPropagation();
    event.preventDefault();
    // const file = event.target.files[0];
    // console.log(file); // TODO
  }

  saveSkills() { //eslint-disable-line
  }

  render() {
    return (
      <div>
        <ProfileAppbar />
        <CandidatePersonalDetails />
        <CandidateUploadCV
          fileUpload={this.fileUpload}
        />
        <AddSkillsForm saveSkills={this.saveSkills} />
        <AddExperience />
      </div>
    );
  }
}

export default CandidateProfileContainer;
