import api from '../../../shared/api';
import * as constants from './actionTypes';

export function getCustomers(pageNo = 1, pageSize = 100) {
  return {
    type: constants.GET_CUSTOMERS,
    payload: api.get(`customers?page=${pageNo}&per_page=${pageSize}`).then(res => ({ ...res.data, pageSize })),
  };
}

export function saveCustomers(user) {
  return {
    type: constants.SAVE_CUSTOMERS,
    payload: api.post('customers', user),
  };
}

export function updateCustomers(user) {
  return {
    type: constants.UPDATE_CUSTOMERS,
    payload: api.put(`customers/${user.id}`, user),
  };
}

export function deleteCustomers(userId) {
  return {
    type: constants.DELETE_CUSTOMERS,
    payload: api.delete(`customers/${userId}`).then(() => userId),
  };
}

export function setSelectedCustomers(users) {
  return {
    type: constants.SET_SELECTED_CUSTOMERS,
    payload: users,
  };
}

export function addCustomerToSelectedCustomers(user) {
  return {
    type: constants.ADD_CUSTOMER_TO_SELECTED_CUSTOMERS,
    payload: user,
  };
}

export function removeCustomerFromSelectedCustomers(user) {
  return {
    type: constants.REMOVE_CUSTOMER_FROM_SELECTED_CUSTOMERS,
    payload: user,
  };
}

export function searchCustomers(searchItem, pageNo = 1, pageSize = 100) {
  return {
    type: constants.SEARCH_CUSTOMERS,
    payload: api.get(`customers/search?q=${searchItem}&page=${pageNo}&per_page=${pageSize}`)
      .then(res => ({ ...res, searchItem, pageSize })),
  };
}

export function setSearchItem() {
  return {
    type: constants.SET_SEARCH_ITEM,
  };
}

