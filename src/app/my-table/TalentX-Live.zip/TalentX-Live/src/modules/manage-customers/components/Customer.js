import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { Form, Field, reduxForm } from 'redux-form';
import { TextField, Select } from 'redux-form-material-ui';
import { MenuItem } from 'material-ui/Menu';
import { InputLabel } from 'material-ui/Input';
import { withStyles } from 'material-ui/styles';
import { FormControl } from 'material-ui/Form';
import PropTypes from 'prop-types';
import { required, matchRegEx, email, phone, website, specialCharactersRegex } from '../../../utils/validators';
import cities from '../../../assets/cities.json';
import { LONG, MEDIUM, SHORT } from '../../../constants/stringLengths';


const styles = theme => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing.unit * 2,
  },
  visiblility:
  {
    display: 'none',
  },
});

const Customer = props => (
  <Form onSubmit={props.handleSubmit(props.saveOrUpdateUser)}>
    <div className="user-form" >
      <div className="part-left">
        <Field
          fullWidth
          id="name"
          name="name"
          label={props.translate('customerName')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: LONG,
          }}
        />
        <Field
          fullWidth
          id="company_name_for_invoicing"
          name="company_name_for_invoicing"
          label={props.translate('customerCompanyNameForInvoice')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: LONG,
          }}
        />
        <Field
          fullWidth
          id="client_type"
          name="client_type"
          label={props.translate('customerType')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: SHORT,
          }}
        />
        <Field
          fullWidth
          id="website"
          name="website"
          label={props.translate('customerWebsite')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: MEDIUM,
          }}
        />
      </div>
      <div className="part-right">
        <Field
          fullWidth
          id="industry"
          name="industry"
          label={props.translate('customerIndustry')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: MEDIUM,
          }}
        />
        <Field
          fullWidth
          id="industry_sector"
          name="industry_sector"
          label={props.translate('customerIndustrySector')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: MEDIUM,
          }}
        />
        <Field
          id="phone"
          name="phone"
          label={props.translate('customerPhoneNo')}
          className="user-form-field"
          component={TextField}
          inputProps={{
            maxLength: MEDIUM,
          }}
        />
      </div>
    </div>
    <div >
      <div className="dialog-header" style={{ marginLeft: '15px' }}>
        <h1>Address Information</h1>
      </div>
      <div className="user-form">

        <div className="part-left">
          <Field
            fullWidth
            id="street"
            name="street"
            label={props.translate('customerStreet')}
            className="user-form-field"
            component={TextField}
            inputProps={{
              maxLength: MEDIUM,
            }}
          />
          <FormControl className="user-form-field">
            <InputLabel htmlFor="city">{props.translate('customerCity')}</InputLabel>
            <Field
              fullWidth
              label={props.translate('customerCity')}
              name="city"
              component={Select}
              onChange={(event, val) => {
              cities.map((f) => {
                if (f.city === val) {
                  props.change('country', f.country);
                  return f.country;
                }
                return true;
              });
              }
            }
              placeholder="City"
            >
              <MenuItem value="">{props.translate('pleaseSelect')}</MenuItem>
              {
              cities.map(data =>
                (
                  <MenuItem
                    key={data.city}
                    value={data.city}
                  >
                    {data.city}
                  </MenuItem>
                ))
            }
            </Field>
          </FormControl>
          <Field
            fullWidth
            id="postalCode"
            name="postalCode"
            label={props.translate('customerZipCode')}
            className="user-form-field"
            component={TextField}
            inputProps={{
              maxLength: SHORT,
            }}
          />

        </div>
        <div className="part-right">
          <Field
            fullWidth
            id="state"
            name="state"
            label={props.translate('customerState')}
            className="user-form-field"
            component={TextField}
            inputProps={{
              maxLength: MEDIUM,
            }}
          />
          <Field
            fullWidth
            id="country"
            name="country"
            label={props.translate('customerCountry')}
            className="user-form-field"
            component={TextField}
            inputProps={{
              maxLength: MEDIUM,
            }}
          />
        </div>
      </div>
    </div>
  </Form>
);

Customer.propTypes = {
  translate: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  change: PropTypes.func.isRequired,
  saveOrUpdateUser: PropTypes.func,
  classes: PropTypes.object.isRequired, // eslint-disable-line
};

Customer.defaultProps = {
  saveOrUpdateUser: () => {},
};

const errors = {};

const validate = (values, props) => {
  if (!props.isEditing) {
    errors.phone = required(values.phone);
    if (!errors.phone) errors.phone = !matchRegEx(values.phone, phone) && 'Invalid number';
    errors.name = required(values.name);
    if (values.name) errors.name = !matchRegEx(values.name, specialCharactersRegex) && 'Invalid Name';
    if (values.name && values.name.trim().length === 0) errors.name = 'Invalid Name';
    errors.website = required(values.website);
    if (!errors.website) errors.website = !matchRegEx(values.website, website) && 'Invalid website name';
    errors.industry = required(values.industry);
    if (values.industry) errors.industry = !matchRegEx(values.industry, specialCharactersRegex) && 'Invalid Country';
    // country
    if (values.country) errors.country = !matchRegEx(values.country, specialCharactersRegex) && 'Invalid Country';
    if (values.country && values.country.trim().length === 0) errors.country = 'Invalid Country';
  }
  // country
  if (values.country) errors.country = !matchRegEx(values.country, specialCharactersRegex) && 'Invalid Country';
  if (values.country && values.country.trim().length === 0) errors.country = 'Invalid Country';

  errors.email = required(values.email);
  if (!errors.email) errors.email = !matchRegEx(values.email, email) && 'Invalid email';
  errors.phone = required(values.phone);
  if (!errors.phone) errors.phone = !matchRegEx(values.phone, phone) && 'Invalid number';
  errors.website = required(values.website);
  if (!errors.website) errors.website = !matchRegEx(values.website, website) && 'Invalid website name';
  errors.industry = required(values.industry);
  if (values.industry) errors.industry = !matchRegEx(values.industry, specialCharactersRegex) && 'Invalid Name of Industry';
  return errors;
};

export default reduxForm({ form: 'UserForm', validate, enableReinitialize: true })(withStyles(styles)(withTranslate(Customer)));
