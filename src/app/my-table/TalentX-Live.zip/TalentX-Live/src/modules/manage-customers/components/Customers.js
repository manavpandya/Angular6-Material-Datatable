import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import Table, { TableBody, TableCell, TableHead, TableRow, TableFooter, TablePagination } from 'material-ui/Table';
import { MenuList, MenuItem } from 'material-ui/Menu';
import PropTypes from 'prop-types';
import Paper from 'material-ui/Paper';
import { withStyles } from 'material-ui/styles';
import MoreVertIcon from 'material-ui-icons/MoreVert';
import Checkbox from 'material-ui/Checkbox';
import Message from 'material-ui-icons/Message';
import Call from 'material-ui-icons/Call';
import Email from 'material-ui-icons/Email';
import Menu from '../../../shared/compound/Menu';
import LinkButton from '../../../shared/basic/LinkButton';
import CustomTablePaginationActions from '../../../shared/compound/CustomTablePaginationActions';

const stylePaper = {
  root: {
    marginTop: 25,
    maxHeight: '100%',
    overflow: 'auto',
    padding: 0,
    paddingBottom: 111,
  },
  popup: {
    position: 'absolute',
    top: 0,
    right: 0,
    zIndex: 2000,
    padding: '0.5rem',
  },
};

const Customers = props => (
  <Paper classes={{ root: props.classes.root }} elevation={0}>
    <Table className="overlay-table">
      <TableHead className="table-header">
        <TableRow>
          <TableCell padding="checkbox" className="users-checkbox">
            <Checkbox
              indeterminate={
                props.selectedUsers.length > 0 &&
                props.selectedUsers.length < props.customers.length
              }
              checked={props.selectedUsers.length === props.customers.length}
              onChange={(evt, checked) => props.selectAllRows(evt, checked, props.customers)}
            />
          </TableCell>
          <TableCell className="users-name">{props.translate('customerName')}</TableCell>
          <TableCell className="users-phone">{props.translate('customerPhone')}</TableCell>
          <TableCell className="users-timezone">{props.translate('customerLocation')}</TableCell>
          <TableCell className="users-industry">{props.translate('customerIndustry')}</TableCell>
          <TableCell className="users-contact">{props.translate('customerContact')}</TableCell>
          <TableCell className="users-menu" />
        </TableRow>
      </TableHead>
      <TableBody>
        {
          props.customers.map(user => (
            <TableRow
              key={user.id}
              hover
              role="checkbox"
              tabIndex={-1}
              aria-checked={props.selectedUsers.indexOf(user) !== -1}
              selected={props.selectedUsers.indexOf(user) !== -1}
            >
              <TableCell padding="checkbox" className="users-checkbox">
                <Checkbox
                  checked={props.selectedUsers.indexOf(user) !== -1}
                  onClick={evt => props.selectRow(evt, user)}
                />
              </TableCell>
              <TableCell className="users-name">
                <LinkButton className="user-name" onClick={() => props.editUser(user)}>
                  {user.name}
                </LinkButton>
              </TableCell>
              <TableCell className="users-phone">{user.phone}</TableCell>
              <TableCell>
                {user.address && user.address.city} {user.address && user.address.country ? `- ${user.address.country}` : ''}
              </TableCell>
              <TableCell className="users-industry">{user.industry}</TableCell>
              <TableCell className="users-contact">
                <div className="contact-info">
                  <Message className="chat contact-icon" />
                  {
                    user.phone
                      ?
                      (
                        <a href={`call:${user.phone}`}>
                          <Call className="phone contact-icon" />
                        </a>
                      )
                      :
                      (
                        <Call className="phone contact-icon disabled" />
                      )
                  }
                  {
                    user.email
                      ?
                        <a href={`mailto:${user.email}`}>
                          <Email className="email contact-icon" />
                        </a>
                      :
                      (
                        <Email className="email contact-icon disabled" />
                      )
                  }
                </div>
              </TableCell>
              <TableCell className="text-right users-menu">
                <Menu
                  menuStyle={stylePaper.popup}
                  iconSuffix={<MoreVertIcon style={{ color: '#000000', width: '17px', marginRight: '0.25rem' }} />}
                  popup={
                    <MenuList role="menu">
                      <MenuItem onClick={() => props.editUser(user)}>{props.translate('editRecord')}</MenuItem>
                      <MenuItem onClick={() => props.deleteUser(user)}>{props.translate('deleteRecord')}</MenuItem>
                    </MenuList>
                  }
                />
              </TableCell>
            </TableRow>
          ))
        }
      </TableBody>
      <TableFooter>
        <TableRow>
          <TablePagination
            labelRowsPerPage={props.translate('rowsPerPage')}
            colSpan={6}
            className="pagination"
            rowsPerPageOptions={[25, 50, 100]}
            count={props.totalCustomers}
            rowsPerPage={props.currentPageSize}
            // - 1 is done to remove the difference between API and table indexing.
            // API indexing is 1 and table indexing is 0
            page={props.currentPageNo - 1}
            onChangePage={
              props.searchItem
              ? (event, page) => props.handleSearchPagination(event, page)
              : (event, page) => props.handleChangePage(event, page)
            }
            onChangeRowsPerPage={props.handleChangeRowsPerPage}
            backIconButtonProps={{
              'aria-label': 'Previous Page',
            }}
            nextIconButtonProps={{
              'aria-label': 'Next Page',
            }}
            Actions={CustomTablePaginationActions}
          />
        </TableRow>
      </TableFooter>
    </Table>
  </Paper>
);

Customers.propTypes = {
  translate: PropTypes.func.isRequired,
  selectedUsers: PropTypes.arrayOf(PropTypes.object),
  selectAllRows: PropTypes.func.isRequired,
  customers: PropTypes.arrayOf(PropTypes.object),
  classes: PropTypes.object.isRequired, // eslint-disable-line
  currentPageNo: PropTypes.number,
  currentPageSize: PropTypes.number,
  totalCustomers: PropTypes.number,
  handleChangePage: PropTypes.func,
  handleChangeRowsPerPage: PropTypes.func,
  handleSearchPagination: PropTypes.func,
  searchItem: PropTypes.string,
};

Customers.defaultProps = {
  selectedUsers: [],
  customers: [],
  currentPageNo: 1,
  currentPageSize: 100,
  totalCustomers: 0,
  handleChangePage: () => {},
  handleSearchPagination: () => {},
  handleChangeRowsPerPage: () => {},
  searchItem: '',
};
export default withStyles(stylePaper)(withTranslate(Customers));
