import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import Dialog, { DialogTitle, DialogContent, DialogContentText, DialogActions } from 'material-ui/Dialog';
import Button from 'material-ui/Button';
import CloseIcon from 'material-ui-icons/Close';
import { submit } from 'redux-form';
import BlockUI from 'react-block-ui';
import Customer from './components/Customer';
import Customers from './components/Customers';
import CustomerDetails from './components/CustomerDetails';
import { logoutFunction } from '../auth/redux/actions';
import {
  getCustomers,
  saveCustomers,
  updateCustomers,
  deleteCustomers,
  setSelectedCustomers,
  addCustomerToSelectedCustomers,
  removeCustomerFromSelectedCustomers,
  searchCustomers,
  setSearchItem,
} from './redux/actions';
import { showNotification } from './../../utils/Notifications';
import BoardHeader from '../../shared/compound/board/BoardHeader';
import AppBarContent from '../../shared/compound/AppBarContent';
import AppBarButtons from '../../shared/compound/AppBarButtons';
import Loader from '../../shared/basic/Loader';

let initialValues = {};

class CustomersContainer extends Component {
  constructor(props) {
    super(props);
    this.selectAllRows = this.selectAllRows.bind(this);
    this.selectRow = this.selectRow.bind(this);
    this.openUserDetails = this.openUserDetails.bind(this);
    this.closeUserDetails = this.closeUserDetails.bind(this);
    this.selectUser = this.selectUser.bind(this);
    this.confirmedDeleteUser = this.confirmedDeleteUser.bind(this);
    this.deleteUser = this.deleteUser.bind(this);
    this.confirmedDeleteSelectedUsers = this.confirmedDeleteSelectedUsers.bind(this);
    this.deleteSelectedUsers = this.deleteSelectedUsers.bind(this);
    this.editUser = this.editUser.bind(this);
    this.addUser = this.addUser.bind(this);
    this.closeAddOrEditUser = this.closeAddOrEditUser.bind(this);
    this.closeConfirmDelete = this.closeConfirmDelete.bind(this);
    this.closeConfirmDeleteSelectedUsers = this.closeConfirmDeleteSelectedUsers.bind(this);
    this.saveOrUpdateUser = this.saveOrUpdateUser.bind(this);
    this.saveOrUpdateUserHelper = this.saveOrUpdateUserHelper.bind(this);
    this.handleChangePage = this.handleChangePage.bind(this);
    this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this);
    this.handleSearchPagination = this.handleSearchPagination.bind(this);

    this.state = {
      selectedUser: {},
      addOrEditUser: false,
      confirmDelete: false,
      confirmDeleteSelectedUsers: false,
      isEditing: false,
      openUserDetails: false,
    };
  }

  componentDidMount() {
    this.props.getCustomers(1);
  }

  componentWillUnmount() {
    if (this.props.searchItem) {
      this.props.setSearchItem();
    }
  }

  selectAllRows(event, checked, customers) {
    if (checked) {
      this.props.setSelectedUsers(customers);
    } else {
      this.props.setSelectedUsers([]);
    }
  }

  selectRow(event, user) {
    if (!this.props.selectedUsers.includes(user)) {
      this.props.addUserToSelectedUsers(user);
    } else {
      this.props.removeUserFromSelectedUsers(user);
    }
  }

  openUserDetails() {
    this.setState({
      openUserDetails: true,
    });
  }

  closeUserDetails() {
    this.setState({
      openUserDetails: false,
    });
  }

  selectUser(user) {
    this.setState({
      selectedUser: user,
      openUserDetails: true,
    });
  }

  confirmedDeleteUser() {
    const { id } = this.state.selectedUser;
    this.props.deleteUser(this.state.selectedUser.id).then(() => {
      showNotification(this.props.translate('customerDeleted'), 'success', 8000);
      this.setState({
        selectedUser: {},
        openUserDetails: false,
        confirmDelete: false,
      });
      this.props.setSelectedUsers([...this.props.selectedUsers.filter(user => user.id !== id)]);
    }).catch((err) => {
      showNotification(err.message, 'error', 8000);
    });
  }

  deleteUser(user) {
    this.setState({
      selectedUser: user,
      confirmDelete: true,
    });
  }

  confirmedDeleteSelectedUsers() {
    Promise.all(this.props.selectedUsers.map(user => this.props.deleteUser(user.id))).then(() => {
      showNotification(this.props.translate('selectedCustomerDeleted'), 'success', 8000);
      this.setState({
        confirmDeleteSelectedUsers: false,
      });
      this.props.setSelectedUsers([]);
    }).catch((err) => {
      showNotification(err.message, 'error', 8000);
    });
  }

  deleteSelectedUsers() {
    this.setState({
      confirmDeleteSelectedUsers: true,
    });
  }

  editUser(user) {
    const tempUser = user.address
      ?
      {
        // ...user,
        name: user.name,
        company_name_for_invoicing: user.company_name_for_invoicing,
        client_type: user.client_type,
        status: user.status,
        website: user.website,
        industry: user.industry,
        industry_sector: user.industry_sector,
        phone: user.phone,
        city: user.address.city,
        country: user.address.country,
        postalCode: user.address.postalCode,
        state: user.address.state,
        street: user.address.street,
      }
      : user;
    initialValues = tempUser;
    this.setState({
      selectedUser: user,
      openUserDetails: false,
      addOrEditUser: true,
      isEditing: true,
    });
  }

  addUser() {
    initialValues = {};
    this.setState({
      selectedUser: {},
      addOrEditUser: true,
      isEditing: false,
    });
  }

  closeAddOrEditUser() {
    this.setState({
      selectedUser: {},
      addOrEditUser: false,
      isEditing: false,
    });
    initialValues = {};
  }

  closeConfirmDelete() {
    this.setState({
      confirmDelete: false,
    });
  }

  closeConfirmDeleteSelectedUsers() {
    this.setState({
      confirmDeleteSelectedUsers: false,
    });
  }

  saveOrUpdateUser(values) {
    const user = {
      address: {
        city: values.city,
        country: values.country,
        postalCode: values.postalCode,
        state: values.state,
        street: values.street,
      },
      name: values.name,
      company_name_for_invoicing: values.company_name_for_invoicing,
      client_type: values.client_type,
      phone: values.phone,
      status: values.status,
      website: values.website,
      industry: values.industry,
      industry_sector: values.industry_sector,
    };
    if (this.state.isEditing) {
      user.id = this.state.selectedUser.id;
      this.saveOrUpdateUserHelper(this.props.updateCustomer(user));
    } else {
      user.name = values.name;
      this.saveOrUpdateUserHelper(this.props.saveCustomer(user));
    }
  }

  saveOrUpdateUserHelper(saveOrUpdateFunc) {
    saveOrUpdateFunc
      .then(() => {
        showNotification(`Customer data ${this.state.isEditing ? this.props.translate('statusUpdated') : this.props.translate('statusSaved')} `, 'success', 8000);
        this.closeAddOrEditUser();
      }).catch((err) => {
        showNotification(err.message, 'error', 8000);
      });
  }

  handleChangePage(event, nextPageNo) {
    // here we are getting nextPageNo but still we have to do + 1 because
    // our table pagination is 0 indexed while our API is 1 indexed.
    this.props.getCustomers(nextPageNo + 1, this.props.currentPageSize);
  }

  handleChangeRowsPerPage(event) {
    if (this.props.searchItem) {
      this.props.searchCustomers(this.props.searchItem, 1, event.target.value);
    } else {
      this.props.getCustomers(1, event.target.value);
    }
  }

  handleSearchPagination(event, nextPageNo) {
    this.props.searchCustomers(this.props.searchItem, nextPageNo + 1, this.props.currentPageSize);
  }

  render() {
    const customerObject = {
      ...this.state.selectedUser,
      city: this.state.selectedUser.address ? this.state.selectedUser.address.city : '',
      country: this.state.selectedUser.address ? this.state.selectedUser.address.country : '',
    };
    return (
      <div className="page">
        <BoardHeader
          headerName="3002🚀"
          clientPage
          logoutFunction={this.props.logout}
        />
        <section className="users">
          <div className="container">
            <div className="user-header">
              <AppBarContent
                header={this.props.translate('customerManagement')}
                appBarButtons={
                  <AppBarButtons
                    addUser={this.addUser}
                    deleteSelectedUsers={this.deleteSelectedUsers}
                    disabled={this.props.selectedUsers.length <= 0}
                  />
                }
              />
            </div>
            <BlockUI tag="div" className="scroller" blocking={this.props.loading}>
              <Customers
                selectAllRows={this.selectAllRows}
                selectRow={this.selectRow}
                selectedUsers={this.props.selectedUsers}
                customers={this.props.customers}
                selectUser={this.selectUser}
                editUser={this.editUser}
                deleteUser={this.deleteUser}
                handleChangePage={this.handleChangePage}
                handleChangeRowsPerPage={this.handleChangeRowsPerPage}
                currentPageNo={this.props.currentPageNo}
                currentPageSize={this.props.currentPageSize}
                totalCustomers={this.props.totalCustomers}
                searchItem={this.props.searchItem}
                handleSearchPagination={this.handleSearchPagination}
              />
            </BlockUI>
            <Dialog
              open={this.state.openUserDetails}
              onClose={this.closeUserDetails}
              autoFocus
            >
              <div className="user-details-wrapper">
                <div className="user-details">
                  <main>
                    <CustomerDetails
                      {...this.state.selectedUser}
                      loading={this.props.loading}
                      disableUser={this.disableUser}
                      deleteUser={this.deleteUser}
                      editUser={this.editUser}
                    />
                  </main>
                </div>
              </div>
            </Dialog>
            <Dialog
              open={this.state.addOrEditUser}
              onClose={this.closeAddOrEditUser}
              autoFocus
              maxWidth="md"
            >
              {
                this.props.loading && <Loader />
              }
              <div className="add-edit-user">
                <header className="dialog-header">
                  <h1>{this.state.isEditing ? this.props.translate('customerEdit') : this.props.translate('customerCreate')} </h1>
                  <Button onClick={this.closeAddOrEditUser}>
                    <CloseIcon />
                  </Button>
                </header>
                <div>
                  <main>
                    <Customer
                      {...customerObject}
                      loading={this.props.loading}
                      isEditing={this.state.isEditing}
                      initialValues={initialValues}
                      saveOrUpdateUser={this.saveOrUpdateUser}
                    />
                  </main>
                </div>
              </div>
              <DialogActions>
                <Button
                  default
                  onClick={this.closeAddOrEditUser}
                >
                  {this.props.translate('cancel')}
                </Button>
                <Button
                  color="primary"
                  variant="raised"
                  onClick={() => this.props.dispatch(submit('UserForm'))}
                >
                  {this.state.isEditing ? this.props.translate('updateRecord') : this.props.translate('saveRecord')}
                </Button>
              </DialogActions>
            </Dialog>
            <Dialog
              onClose={this.closeConfirmDelete}
              open={this.state.confirmDelete}
            >
              {
                this.props.loading && <Loader />
              }
              <DialogTitle>
                {this.props.translate('deleteRecord')}
              </DialogTitle>
              <DialogContent>
                <DialogContentText>
                  {this.props.translate('customerDeleteMessage')}
                  <strong> {this.state.selectedUser.name}  </strong>?
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button
                  default
                  onClick={this.closeConfirmDelete}
                >
                  {this.props.translate('cancel')}
                </Button>
                <Button
                  color="primary"
                  variant="raised"
                  onClick={this.confirmedDeleteUser}
                >
                  {this.props.translate('deleteRecord')}
                </Button>
              </DialogActions>
            </Dialog>
            <Dialog
              onClose={this.closeConfirmDeleteSelectedUsers}
              open={this.state.confirmDeleteSelectedUsers}
            >
              {
                this.props.loading && <Loader />
              }
              <DialogTitle>
                {this.props.translate('deleteRecord')}
              </DialogTitle>
              <DialogContent>
                <DialogContentText>
                  {this.props.translate('areYouSureWantTo')} {this.props.translate('deleteRecord')} {this.props.translate('all')} <strong>{this.props.translate('selected')}</strong> {this.props.translate('customers')}
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button
                  default
                  onClick={this.closeConfirmDeleteSelectedUsers}
                >
                  {this.props.translate('cancel')}
                </Button>
                <Button
                  color="secondary"
                  variant="raised"
                  onClick={this.confirmedDeleteSelectedUsers}
                >
                  {this.props.translate('deleteRecord')}
                </Button>
              </DialogActions>
            </Dialog>
          </div>
        </section>
      </div>
    );
  }
}

CustomersContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  logout: PropTypes.func,
  getCustomers: PropTypes.func.isRequired,
  saveCustomer: PropTypes.func,
  updateCustomer: PropTypes.func,
  deleteUser: PropTypes.func,
  setSelectedUsers: PropTypes.func,
  addUserToSelectedUsers: PropTypes.func,
  removeUserFromSelectedUsers: PropTypes.func,
  customers: PropTypes.arrayOf(PropTypes.object),
  selectedUsers: PropTypes.arrayOf(PropTypes.object),
  loading: PropTypes.bool,
  error: PropTypes.func,
  dispatch: PropTypes.func.isRequired,
  classes: PropTypes.object.isRequired, //eslint-disable-line
  currentPageNo: PropTypes.number,
  currentPageSize: PropTypes.number,
  totalCustomers: PropTypes.number,
  searchItem: PropTypes.string,
  searchCustomers: PropTypes.func,
  setSearchItem: PropTypes.func,
};

CustomersContainer.defaultProps = {
  logout: () => {},
  saveCustomer: () => {},
  updateCustomer: () => {},
  deleteUser: () => {},
  setSelectedUsers: () => {},
  addUserToSelectedUsers: () => {},
  removeUserFromSelectedUsers: () => {},
  customers: [],
  selectedUsers: [],
  loading: false,
  error: () => {},
  currentPageNo: 1,
  currentPageSize: 100,
  totalCustomers: 0,
  searchItem: '',
  searchCustomers: () => {},
  setSearchItem: () => {},
};

const mapStateToProps = state => ({
  customers: state.customers.customers,
  searchItem: state.customers.searchItem,
  currentPageNo: state.customers.currentPageNo,
  currentPageSize: state.customers.currentPageSize,
  totalCustomers: state.customers.totalCustomers,
  selectedUsers: state.customers.selectedUsers,
  loading: state.customers.loading,
  error: state.customers.error,
});

const mapDispatchToProps = dispatch => ({
  logout: () => dispatch(logoutFunction()),
  getCustomers: (pageNo, pageSize) => dispatch(getCustomers(pageNo, pageSize)),
  saveCustomer: values => dispatch(saveCustomers(values)),
  updateCustomer: values => dispatch(updateCustomers(values)),
  deleteUser: values => dispatch(deleteCustomers(values)),
  setSelectedUsers: customers => dispatch(setSelectedCustomers(customers)),
  addUserToSelectedUsers: user => dispatch(addCustomerToSelectedCustomers(user)),
  searchCustomers: (searchItem, pageNo, pageSize) =>
    dispatch(searchCustomers(searchItem, pageNo, pageSize)),
  setSearchItem: () => dispatch(setSearchItem()),
  removeUserFromSelectedUsers: user => dispatch(removeCustomerFromSelectedCustomers(user)),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(CustomersContainer));//eslint-disable-line
