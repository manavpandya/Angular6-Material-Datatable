import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { updateToken } from '../redux/actions';
import { getAccountMe } from '../../jobs/redux/actions';
import { showNotification } from '../../../utils/Notifications';
import permissions from '../../../assets/permissions.json';

export default function (ComposedComponent) {
  class Authentication extends Component {
    constructor(props) {
      super(props);
      this.state = {
        pageAccessible: false,
      };

      this.checkPagePermissions = this.checkPagePermissions.bind(this);
    }

    componentWillMount() {
      const token = localStorage.getItem('user_info');
      if (token) {
        if (Object.keys(this.props.accountInfo).length === 0) {
          this.props.getAccountMe()
            .then(() => {
              this.checkPagePermissions();
              this.setState({ pageAccessible: true });
            })
            .catch(() => {
              localStorage.removeItem('user_info');
              localStorage.removeItem('tenant');
              this.props.history.push('/login');
            });
        } else {
          this.checkPagePermissions();
          this.setState({ pageAccessible: true });
        }
        const script = document.createElement('script');
        script.text = '(function() {var walkme = document.createElement(\'script\'); walkme.type = \'text/javascript\'; walkme.async = true; walkme.src = \'https://cdn.walkme.com/users/a3e1b682f89542b3af804d521fdbd09d/test/walkme_a3e1b682f89542b3af804d521fdbd09d_https.js\'; var s = document.getElementsByTagName(\'script\')[0]; s.parentNode.insertBefore(walkme, s); window._walkmeConfig = {smartLoad:true}; })();';
        document.body.appendChild(script);
      } else {
        this.props.history.push('/login');
      }
    }
    //  =================================
    //      Do not delete below code
    //      This is for future reference
    //  =================================

    // componentWillReceiveProps(nextProps) {
    //   if ((this.props.error !== nextProps.error) ||
    //   (this.props.fetchTreeError !== nextProps.fetchTreeError)) {
    //     const { error, fetchTreeError } = nextProps;
    //     if ((error && error.response && error.response.status === 403) ||
    //     (fetchTreeError && fetchTreeError.response && fetchTreeError.response.status === 403)
    //     ) {
    //       showNotification((error && error.response.data.msg) ||
    // (fetchTreeError && fetchTreeError.response.data.msg), 'error', 8000);
    //       this.props.history.push('/recruiter');
    //     }
    //   }
    // }

    checkPagePermissions() {
      permissions.pages.forEach((page) => {
        if (this.props.match.path === page.path) {
          if (!page.roles.some(role => this.props.accountInfo.roles.includes(role))) {
            showNotification('Unauthorised', 'error', 8000);
            if (this.props.accountInfo.roles.includes('CUSTOMER')) {
              this.props.history.push('/customer');
            } else if (this.props.accountInfo.roles.includes('CANDIDATE')) {
              this.props.history.push('/access-denied');
            } else {
              this.props.history.push('/recruiter');
            }
          }
        }
      });
    }

    render() {
      return this.state.pageAccessible ? <ComposedComponent {...this.props} /> : <div />;
    }
  }

  Authentication.propTypes = {
    match: PropTypes.object.isRequired, // eslint-disable-line
    history: PropTypes.object.isRequired, // eslint-disable-line
    updateToken: PropTypes.func,
    getAccountMe: PropTypes.func,
    accountInfo: PropTypes.objectOf(PropTypes.any),
    token: PropTypes.string,
    error: PropTypes.objectOf(PropTypes.any),
    fetchTreeError: PropTypes.objectOf(PropTypes.any),
  };

  Authentication.defaultProps = {
    updateToken: () => {},
    getAccountMe: () => {},
    accountInfo: {},
    token: '',
    error: {},
    fetchTreeError: {},
  };

  const mapStateToProps = state => ({
    accountInfo: state.recruiter.accountInfo,
    token: state.login.token,
    error: state.users.error,
    fetchTreeError: state.taxonomy.fetchTreeError,
    fetchTermError: state.taxonomy.fetchTermError,
  });

  const mapDispatchToProps = dispatch => ({
    updateToken: token => dispatch(updateToken(token)),
    getAccountMe: () => dispatch(getAccountMe()),
  });

  return connect(mapStateToProps, mapDispatchToProps)(withRouter(Authentication));
}
