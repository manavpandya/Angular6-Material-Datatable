import * as actionTypes from './actionTypes';

const initialState = {
  token: '',
  isLoggedIn: false,
  loginLoading: false,
  loginError: null,
  tokenResponse: '',
  verifyingToken: false,
  verifiedToken: false,
  errorVerifyingToken: null,
  emailResponse: '',
  isSubmitting: false,
  isSubmitted: false,
  submitError: null,
  passwordResponse: '',
  settingPassword: false,
  passwordSet: false,
  errorSettingPassword: null,
  candidateDetails: {},
  candidateDetailsLoading: false,
  candidateDetailsError: null,
  firstLoginFlag: false,
};

export default function (state = initialState, action) {
  switch (action.type) {
    case actionTypes.USER_LOGIN_LOADING: {
      return {
        ...state,
        token: null,
        isLoggedIn: false,
        loginLoading: true,
        loginError: null,
      };
    }
    case actionTypes.USER_LOGIN_SUCCESS: {
      return {
        ...state,
        token: action.payload,
        isLoggedIn: true,
        loginLoading: false,
        loginError: null,
      };
    }
    case actionTypes.USER_LOGIN_ERROR: {
      return {
        ...state,
        token: null,
        isLoggedIn: false,
        loginLoading: false,
        loginError: JSON.parse(JSON.stringify(action.payload)).response.data.description,
      };
    }
    case actionTypes.LOGOUT: {
      return {
        ...state,
        isLoggedIn: false,
        token: null,
      };
    }
    case actionTypes.UPDATE_TOKEN: {
      return {
        ...state,
        token: action.payload,
        isLoggedIn: true,
        loginLoading: false,
        loginError: null,
      };
    }
    case actionTypes.CHANGE_PASSWORD: {
      return {
        ...state,
        loginLoading: false,
      };
    }
    case actionTypes.SUBMIT_EMAIL_LOADING: {
      return {
        ...state,
        emailResponse: null,
        isSubmitting: true,
        isSubmitted: false,
        submitError: null,
      };
    }
    case actionTypes.SUBMIT_EMAIL_SUCCESS: {
      return {
        ...state,
        emailResponse: action.payload.data.message.toLowerCase(),
        isSubmitting: false,
        isSubmitted: true,
        submitError: null,
      };
    }
    case actionTypes.SUBMIT_EMAIL_ERROR: {
      return {
        ...state,
        emailResponse: 'error',
        isSubmitting: false,
        isSubmitted: false,
        submitError: 'error',
      };
    }
    case actionTypes.VERIFY_TOKEN_LOADING: {
      return {
        ...state,
        tokenResponse: '',
        verifyingToken: true,
        verifiedToken: false,
        errorVerifyingToken: null,
      };
    }
    case actionTypes.VERIFY_TOKEN_SUCCESS: {
      return {
        ...state,
        tokenResponse: action.payload.data.message,
        verifyingToken: false,
        verifiedToken: true,
        errorVerifyingToken: null,
      };
    }
    case actionTypes.VERIFY_TOKEN_ERROR: {
      return {
        ...state,
        tokenResponse: 'error',
        verifyingToken: false,
        verifiedToken: false,
        errorVerifyingToken: 'error',
      };
    }
    case actionTypes.RESET_PASSWORD_LOADING: {
      return {
        ...state,
        passwordResponse: null,
        settingPassword: true,
        passwordSet: false,
        errorSettingPassword: null,
      };
    }
    case actionTypes.RESET_PASSWORD_SUCCESS: {
      return {
        ...state,
        passwordResponse: action.payload.data.message,
        settingPassword: false,
        passwordSet: true,
        errorSettingPassword: null,
      };
    }
    case actionTypes.RESET_PASSWORD_ERROR: {
      return {
        ...state,
        passwordResponse: null,
        settingPassword: false,
        passwordSet: false,
        errorSettingPassword: 'error',
      };
    }
    case actionTypes.GO_TO_INDEX_PAGE: {
      return {
        isSubmitted: false,
        passwordSet: false,
      };
    }
    case actionTypes.MORE_CANDIDATE_DETAILS_SUCCESS:
      return {
        ...state,
        candidateDetails: action.payload,
        candidateDetailsLoading: false,
        candidateDetailsError: null,
      };
    case actionTypes.MORE_CANDIDATE_DETAILS_LOADING:
      return {
        ...state,
        candidateDetails: null,
        candidateDetailsLoading: true,
        candidateDetailsError: null,
      };
    case actionTypes.MORE_CANDIDATE_DETAILS_ERROR:
      return {
        ...state,
        candidateDetails: null,
        candidateDetailsLoading: false,
        candidateDetailsError: action.payload,
      };
    case actionTypes.FIRST_LOGIN:
      return {
        ...state,
        firstLoginFlag: action.payload,
      };
    default:
      return state;
  }
}
