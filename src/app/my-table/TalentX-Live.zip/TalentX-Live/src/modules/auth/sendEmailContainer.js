import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import Button from 'material-ui/Button';
import { submitEmail, gotToIndexPage } from './redux/actions';
import Loader from '../../shared/basic/Loader';
import Confirmation from './components/Confirmation';
import SendEmail from './components/sendEmail';
import { required, email as emailPattern, matchRegEx } from '../../utils/validators';
import { showNotification } from '../../utils/Notifications';

const errors = {};

const validate = (values) => {
  errors.email = required(values.email);
  if (values.email) errors.email = !matchRegEx(values.email, emailPattern) && 'Invalid email';

  return errors;
};

const showError = (emailResponse, prop) => {
  if (emailResponse) {
    showNotification(prop.translate('errorProcessiongRequest'), 'error', 8000);
  }
};

class SendEmailContainer extends Component {
  constructor(props) {
    super(props);
    this.sendUserEmail = this.sendUserEmail.bind(this);
  }

  sendUserEmail(values) {
    this.props.submitEmail(values.email)
      .catch(error => showNotification(error, 'error', 5000));
  }

  render() {
    return (
      <div>
        <SendEmail
          sendUserEmail={this.sendUserEmail}
          validate={validate}
          gotToIndexPage={this.props.gotToIndexPage}
        />
        {
          this.props.isSubmitting ?
            <Loader />
            :
            <div />
        }
        {
          this.props.emailResponse === 'success' ?
            <Confirmation
              header={this.props.translate('emailSentConfirmation')}
              button={
                <div>
                  <Link to="/login">
                    <Button
                      onClick={this.props.gotToIndexPage}
                    >
                      {this.props.translate('goToLoginPage')}
                    </Button>
                  </Link>
                </div>
              }
            />
            :
            showError(this.props.emailResponse, this.props)
        }
      </div>
    );
  }
}

SendEmailContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  submitEmail: PropTypes.func,
  gotToIndexPage: PropTypes.func,
  isSubmitting: PropTypes.bool,
  emailResponse: PropTypes.string,
};

SendEmailContainer.defaultProps = {
  submitEmail: () => {},
  gotToIndexPage: () => {},
  emailResponse: '',
  isSubmitting: false,
};

const mapStateToProps = state => ({
  emailResponse: state.login.emailResponse,
  isSubmitting: state.login.isSubmitting,
  isSubmitted: state.login.isSubmitted,
  submitError: state.login.submitError,
});

const mapDispatchToProps = dispatch => ({
  submitEmail: email => dispatch(submitEmail(email)),
  gotToIndexPage: () => dispatch(gotToIndexPage()),
});

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(SendEmailContainer));
