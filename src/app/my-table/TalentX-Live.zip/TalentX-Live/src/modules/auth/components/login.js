import React, { Component } from 'react';
import { withRouter } from 'react-router';
import { Field, reduxForm, formValueSelector, submit } from 'redux-form';
import { withTranslate } from 'react-redux-multilingual';

import Paper from 'material-ui/Paper';
import { TextField } from 'redux-form-material-ui';
import Button from 'material-ui/Button';
import Dialog, {
  DialogActions,
  DialogContent,
  DialogTitle,
} from 'material-ui/Dialog';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { loginFunction, updateToken, moreCandidateDetails, firstLogin } from '../redux/actions';
import { getAccountMe } from '../../jobs/redux/actions';
import { showNotification } from '../../../utils/Notifications';
import RegistrationDialog from './registrationDialog';
import Loader from '../../../shared/basic/Loader';
import { USER_LOGIN_SUCCESS } from '../redux/actionTypes';
import LanguageOptions from '../../../shared/compound/LanguageOptions';
import languages from '../../../i18n/languages';

const errors = {};
const required = value => (value == null ? 'required' : undefined);

const validate = (values) => {
  errors.username = required(values.username);
  errors.password = required(values.password);
  return errors;
};

const loginFailure = (res) => {
  const response = JSON.parse(JSON.stringify(res));
  if (response.response) {
    const message = response.response ? response.response.data.description : this.props.translate('networkError');
    showNotification(message, 'error', 8000);
  }
};

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };

    this.handleClickOpen = this.handleClickOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.workPreference = this.workPreference.bind(this);
    this.login = this.login.bind(this);
  }
  componentWillMount() {
    this.initAuthCheck();
  }

  initAuthCheck() {
    const token = localStorage.getItem('user_info');
    const userRoles = this.props.accountInfo
      && this.props.accountInfo.roles ? this.props.accountInfo.roles : [];
    if (token) {
      if (userRoles.includes('CUSTOMER')) {
        this.props.history.push('/customer');
      } else {
        this.props.history.push('/recruiter');
      }
    }
  }

  handleClickOpen() {
    this.setState({ open: true });
  }

  handleClose() {
    this.setState({ open: false });
  }

  workPreference(values) {
    this.props.moreCandidateDetails(values).then(() => {
      this.props.firstLogin(false);
      this.handleClose();
      this.props.history.push('/recruiter');
    });
  }

  login() {
    const { username, password } = this.props;
    const credentials = {
      username,
      password,
    };
    if (!username && !password) return false;
    this.props.loginFunction(credentials, this.props.Intl.locale).then(({ action }) => {
      if (action.type === USER_LOGIN_SUCCESS) {
        const token = localStorage.getItem('user_info');
        if (token) {
          this
            .props
            .updateToken(token);
        }
        this.props.getAccountMe()
          .then((success) => {
            if (Array.isArray(success.value.data.tenants)) {
              const tenantsName = success.value.data.tenants[0].name;
              localStorage.setItem('tenant', tenantsName);
              if (this.props.firstLoginFlag) {
                this.handleClickOpen();
              } else if (this.props.accountInfo.roles.includes('CUSTOMER')) {
                this.props.history.push('/customer');
              } else {
                this.props.history.push('/recruiter');
              }
            }
          });
      }
    }).catch(err => loginFailure(err));
    return true;
  }

  render() {
    const {
      anyTouched,
      valid,
      loginLoading,
      accountInfoLoading,
      handleSubmit,
    } = this.props;
    return (
      <div className="authentication page">
        {loginLoading || accountInfoLoading ? <Loader />
      :
        <Paper className="authentication widget">
          <div className="authentication-header">
            <h1>{this.props.translate('login')}</h1>
            <LanguageOptions
              dispatch={this.props.dispatch}
              languages={languages}
            />
          </div>
          <form onSubmit={handleSubmit(this.login)}>
            <div>
              <Field
                name="username"
                component={TextField}
                autoComplete="username"
                label={this.props.translate('username')}
                validate={required}
              />
            </div>
            <br />
            <div>
              <Field
                name="password"
                component={TextField}
                label={this.props.translate('password')}
                type="password"
                autoComplete="current-password"
                validate={required}
              />
            </div>
            <br />
            <div>
              <Button
                type="submit"
                className="login-buttons"
                disabled={!valid && anyTouched}
                primary="true"
                onClick={this.login}
              >
                {this.props.translate('login')}
              </Button>
              <Button
                className="login-buttons"
                type="button"
                onClick={() => this.props.history.push('/reset_password')}
              >
                {this.props.translate('forgotPassword')}
              </Button>
            </div>
          </form>
        </Paper>
        }
        <Dialog
          disableBackdropClick
          disableEscapeKeyDown
          open={this.state.open}
          aria-labelledby="form-dialog-title"
        >
          { this.props.candidateDetailsLoading && <Loader /> }
          <DialogTitle id="form-dialog-title">{this.props.translate('dialogInfo')}</DialogTitle>
          <DialogContent>
            <RegistrationDialog
              workPreference={this.workPreference}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => this.props.dispatch(submit('registrationDialog'))}>
              {this.props.translate('loadingFinish')}
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

Login.propTypes = {
  dispatch: PropTypes.func.isRequired,
  translate: PropTypes.func.isRequired,
  match: PropTypes.object, // eslint-disable-line
  accountInfo: PropTypes.objectOf(PropTypes.any).isRequired, // eslint-disable-line
  username: PropTypes.string,
  password: PropTypes.string,
  valid: PropTypes.bool.isRequired,
  loginFunction: PropTypes.func,
  updateToken: PropTypes.func,
  firstLogin: PropTypes.func,
  loginLoading: PropTypes.bool,
  firstLoginFlag: PropTypes.bool,
  candidateDetailsLoading: PropTypes.bool,
  moreCandidateDetails: PropTypes.func,
  anyTouched: PropTypes.bool,
  history: PropTypes.oneOfType([
    PropTypes.number,
    PropTypes.string,
    PropTypes.object,
  ]),
  handleSubmit: PropTypes.func.isRequired,
  Intl: PropTypes.object, // eslint-disable-line
  // accountInfo: PropTypes.objectOf(PropTypes.any),
  getAccountMe: PropTypes.func,
  accountInfoLoading: PropTypes.bool,
};

Login.defaultProps = {
  match: {},
  username: '',
  password: '',
  loginFunction: () => {},
  moreCandidateDetails: () => {},
  firstLogin: () => {},
  updateToken: {},
  loginLoading: false,
  firstLoginFlag: false,
  candidateDetailsLoading: false,
  history: {},
  anyTouched: false,
  Intl: {},
  // accountInfo: {},
  accountInfoLoading: false,
  getAccountMe: () => {},
};

const selector = formValueSelector('Login');

const LoginForm = reduxForm({
  form: 'Login', // a unique identifier for this form
  validate,
})(Login);

const mapDispatchToProps = dispatch => ({
  loginFunction: (credentials, locale) => dispatch(loginFunction(credentials, locale)),
  dispatch,
  updateToken: token => dispatch(updateToken(token)),
  firstLogin: flag => dispatch(firstLogin(flag)),
  moreCandidateDetails: values => dispatch(moreCandidateDetails(values)),
  getAccountMe: () => dispatch(getAccountMe()),
});

export default connect((state => ({
  username: selector(state, 'username'),
  password: selector(state, 'password'),
  accessToken: state.login.token || null,
  accountInfo: state.recruiter.accountInfo,
  accountInfoLoading: state.recruiter.accountInfoLoading,
  loginLoading: state.login.loginLoading || false,
  candidateDetailsLoading: state.login.candidateDetailsLoading,
  firstLoginFlag: state.login.firstLoginFlag,
  loginError: state.login.loginError || null,
  Intl: state.Intl,
})), mapDispatchToProps)(withRouter(withTranslate(LoginForm)));
