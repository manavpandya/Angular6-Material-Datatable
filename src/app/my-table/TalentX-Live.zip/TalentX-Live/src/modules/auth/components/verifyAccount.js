import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import Button from 'material-ui/Button';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import { verifyToken, gotToIndexPage, firstLogin } from '../redux/actions';
import Loader from '../../../shared/basic/Loader';
import { showNotification } from '../../../utils/Notifications';
import Confirmation from './Confirmation';

class verifyAccount extends Component {
  constructor(props) {
    super(props);

    this.showError = this.showError.bind(this);
  }
  componentDidMount() {
    if (this.props.match.params.token) {
      this.props.verifyToken(this.props.match.params.token)
        .catch(error => showNotification(error, 'error', 5000));
    }
  }

  showError(tokenResponse) {
    if (tokenResponse === 'error') {
      setTimeout(() => this.props.history.push('/login'), 5000);
    }
  }

  render() {
    const { verifyingToken } = this.props;
    return (
      <div>
        {
          verifyingToken
          ?
            <Loader />
          :
            (
              <div>
                {
                  this.props.tokenResponse === 'Valid Token'
                  ?
                    <Confirmation
                      header={this.props.translate('accountVerified')}
                      button={
                        <div>
                          <Button
                            type="button"
                            onClick={() => {
                              this.props.gotToIndexPage();
                              this.props.firstLogin(true);
                              this.props.history.push('/login');
                            }}
                          >
                            {this.props.translate('goToLoginPage')}
                          </Button>
                        </div>
                      }
                    />
                  :
                    <div>
                      {
                        this.props.match.params.token
                        ?
                          <div>
                            <Confirmation
                              header={this.props.translate('loginTransferMessage')}
                              responseLogo={false}
                            />
                            {this.showError(this.props.tokenResponse)}
                          </div>
                        :
                          <div />
                      }
                    </div>
                }
              </div>
            )
        }
      </div>
    );
  }
}

verifyAccount.propTypes = {
  translate: PropTypes.func,
  match: PropTypes.object, // eslint-disable-line
  history: PropTypes.object, // eslint-disable-line
  verifyToken: PropTypes.func,
  gotToIndexPage: PropTypes.func,
  firstLogin: PropTypes.func,
  verifyingToken: PropTypes.bool,
  tokenResponse: PropTypes.string,
};

verifyAccount.defaultProps = {
  translate: () => {},
  match: {},
  history: {},
  verifyToken: () => {},
  gotToIndexPage: () => {},
  firstLogin: () => {},
  verifyingToken: false,
  tokenResponse: '',
};

const mapStateToProps = state => ({
  verifyingToken: state.login.verifyingToken,
  tokenResponse: state.login.tokenResponse,
});

const mapDispatchToProps = dispatch => ({
  verifyToken: token => dispatch(verifyToken(token)),
  gotToIndexPage: () => dispatch(gotToIndexPage()),
  firstLogin: flag => dispatch(firstLogin(flag)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(verifyAccount)));// eslint-disable-line
