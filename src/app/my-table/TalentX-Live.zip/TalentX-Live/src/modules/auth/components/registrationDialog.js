import React from 'react';
import PropTypes from 'prop-types';
import { reduxForm, Form, Field } from 'redux-form';
import { TextField, Select, RadioGroup, Checkbox } from 'redux-form-material-ui';
import Radio from 'material-ui/Radio';
import { MenuItem } from 'material-ui/Menu';
import {
  DialogContent,
  DialogContentText,
} from 'material-ui/Dialog';
import { FormControl, FormControlLabel } from 'material-ui/Form';

const RegistrationDialog = props => (
  <div>
    <Form onSubmit={props.handleSubmit(props.workPreference)}>
      <DialogContent>
        <DialogContentText>
          Where do you live?
        </DialogContentText>
        <Field
          fullWidth
          id="city"
          name="city"
          component={TextField}
        />
      </DialogContent>
      <DialogContent>
        <DialogContentText>
          What type of work are you looking for?
        </DialogContentText>
        <FormControl>
          <Field
            fullWidth
            label="Work Type"
            name="workType"
            component={Select}
          >
            <MenuItem value="">Please select ...</MenuItem>
            <MenuItem value="Full Time">Full Time</MenuItem>
            <MenuItem value="Part Time">Part Time</MenuItem>
          </Field>
        </FormControl>
      </DialogContent>
      <DialogContent>
        <DialogContentText>
          Which field are you looking to work in?
        </DialogContentText>
        <Field
          fullWidth
          id="workField"
          name="workField"
          component={TextField}
        />
      </DialogContent>
      <DialogContent>
        <DialogContentText>
          Where are you in your search?
        </DialogContentText>
        <FormControl>
          <Field
            fullWidth
            label="Search Type"
            name="searchType"
            component={Select}
          >
            <MenuItem value="">Please select ...</MenuItem>
            <MenuItem value="Actively Looking">Actively Looking</MenuItem>
            <MenuItem value="Passively Looking">Passively Looking</MenuItem>
          </Field>
        </FormControl>
      </DialogContent>
      <DialogContent>
        <DialogContentText>
          Are you authorised to work in Australia?
        </DialogContentText>
        <Field name="authorisedToWork" component={RadioGroup}>
          <FormControlLabel
            value="yes"
            control={<Radio />}
            label="Yes"
          />
          <FormControlLabel
            value="no"
            control={<Radio />}
            label="No"
          />
        </Field>
      </DialogContent>
      <DialogContent>
        <FormControlLabel
          control={<Field name="agreeToTerms" component={Checkbox} />}
          label="Agree to terms?"
        />
      </DialogContent>
    </Form>
  </div>
);

RegistrationDialog.propTypes = {
  handleSubmit: PropTypes.func.isRequired,
  workPreference: PropTypes.func,
};

RegistrationDialog.defaultProps = {
  workPreference: () => {},
};

export default reduxForm({ form: 'registrationDialog' })(RegistrationDialog);
