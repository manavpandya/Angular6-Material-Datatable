import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import permissions from '../../../assets/permissions.json';

class ActionControl extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isUserAllowed: null,
    };

    this.checkActionPermissions = this.checkActionPermissions.bind(this);
  }

  componentWillMount() {
    this.checkActionPermissions();
  }

  checkActionPermissions() {
    const permissionsActions = permissions.actions
      .find(action => action.action_type === this.props.actionName);
    this.setState({
      isUserAllowed:
        (this.props.actionName && permissionsActions)
          ? permissionsActions.roles.some(role => this.props.accountInfo.roles.includes(role))
          : true,
    });
  }

  render() {
    return (
      <Fragment>
        {
          this.state.isUserAllowed
            ? this.props.children
            : ''
        }
      </Fragment>
    );
  }
}

ActionControl.propTypes = {
  children: PropTypes.element,
  accountInfo: PropTypes.objectOf(PropTypes.any),
  actionName: PropTypes.string,
};

ActionControl.defaultProps = {
  children: <div />,
  accountInfo: {},
  actionName: '',
};

const mapStateToProps = state => ({
  accountInfo: state.recruiter.accountInfo,
});

export default connect(mapStateToProps)(ActionControl);
