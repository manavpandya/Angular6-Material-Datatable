import React from 'react';
import PropTypes from 'prop-types';
import Loader from '../../../shared/basic/Loader';
import Confirmation from '../components/Confirmation';
import SendEmailContainer from '../sendEmailContainer';
import ResetPasswordPageContainer from '../resetPasswordPageContainer';

const RenderResetPage = props => (
  <div>
    {
      props.verifyingToken ?
        <Loader />
        : (
          <div>
            {
              props.tokenResponse === 'Valid Token'
                ?
                  <ResetPasswordPageContainer resetToken={props.resetToken} />
                :
                  <div>
                    {
                      props.paramsToken
                      ? (
                        <div>
                          <Confirmation
                            header="The page you are trying to access is invalid.
                                    You will be redirected to Login Page."
                            responseLogo={false}
                          />
                          {props.showError(props.tokenResponse)}
                        </div>
                      )
                      : (
                        <SendEmailContainer />
                      )
                    }
                  </div>
            }
          </div>
        )
      }
  </div>
);

RenderResetPage.propTypes = {
  match: PropTypes.object, // eslint-disable-line
  resetToken: PropTypes.string,
  verifyingToken: PropTypes.bool,
  history: PropTypes.object, // eslint-disable-line
  tokenResponse: PropTypes.string,
  showError: PropTypes.func,
  paramsToken: PropTypes.string,
};

RenderResetPage.defaultProps = {
  match: {},
  history: {},
  resetToken: '',
  tokenResponse: '',
  paramsToken: '',
  verifyingToken: false,
  showError: () => {},
};

export default RenderResetPage;
