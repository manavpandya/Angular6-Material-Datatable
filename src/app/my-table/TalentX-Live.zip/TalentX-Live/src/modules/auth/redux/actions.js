import api from '../../../shared/api';
import { LOGOUT, USER_LOGIN, UPDATE_TOKEN, CHANGE_PASSWORD, SUBMIT_EMAIL, VERIFY_TOKEN, RESET_PASSWORD, GO_TO_INDEX_PAGE, MORE_CANDIDATE_DETAILS, FIRST_LOGIN } from './actionTypes';

export function logoutFunction() {
  // localStorage.removeItem('tenant');
  // window.location.reload();
  return {
    type: LOGOUT,
    payload: api.post('/logout'),
  };
}

export function loginFunction(credentials, locale) {
  return {
    type: USER_LOGIN,
    payload: api.post(`auth?locale=${locale}`, credentials)
      .then((data) => {
        localStorage.setItem('user_info', JSON.stringify(data.data.access_token));
        // window.location.reload();
      }),
  };
}

export const updateToken = token => ({ type: UPDATE_TOKEN, payload: token });

export function changePasswordFunction(passwords) {
  return {
    type: CHANGE_PASSWORD,
    payload: api.put('accounts/change_password', passwords),
  };
}

export function submitEmail(email) {
  return {
    type: SUBMIT_EMAIL,
    payload: api.get(`reset_password/${email}`),
  };
}

export function verifyToken(token) {
  return {
    type: VERIFY_TOKEN,
    payload: api.post(`verify/${token}`),
  };
}

export function resetPasswordFunction(token, passwords) {
  return {
    type: RESET_PASSWORD,
    payload: api.post(`change_password/${token}`, passwords),
  };
}

export function gotToIndexPage() {
  return {
    type: GO_TO_INDEX_PAGE,
    payload: null,
  };
}

export function moreCandidateDetails(values) {
  return {
    type: MORE_CANDIDATE_DETAILS,
    payload: api.post('https://jsonplaceholder.typicode.com/posts', values),
  };
}

export function firstLogin(flag) {
  return {
    type: FIRST_LOGIN,
    payload: flag,
  };
}
