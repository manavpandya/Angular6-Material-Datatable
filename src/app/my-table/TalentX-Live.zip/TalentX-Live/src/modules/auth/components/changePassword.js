import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { Form, Field, reduxForm, formValueSelector } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { changePasswordFunction } from '../redux/actions';
import { showNotification } from '../../../utils/Notifications';
import Loader from '../../../shared/basic/Loader';

const errors = {};
const required = value => (value == null ? this.props.translate('requiredField') : undefined);
const match = (value, comparisonValue) => (value === comparisonValue ? undefined : this.props.translate('passwordNotMatched'));

const validate = (values) => {
  errors.oldPassword = required(values.oldPassword);
  errors.newPassword = required(values.newPassword);
  errors.newPassword = match(values.newPassword, values.confirmNewPassword);
  errors.confirmNewPassword = required(values.confirmNewPassword);
  errors.confirmNewPassword = match(values.confirmNewPassword, values.newPassword);
  return errors;
};

class ChangePassword extends Component {
  constructor(props) {
    super(props);
    this.onSubmit = this.onSubmit.bind(this);
  }

  onSubmit() {
    const { oldPassword, newPassword, confirmNewPassword } = this.props;
    const passwords = {
      current_password: oldPassword,
      new_password: newPassword,
      confirm_password: confirmNewPassword,
    };
    this.props.changePasswordFunction(passwords).then(response =>
      this.changePasswordSuccess(response))
      .catch(err => this.changePasswordFailure(err));
  }

  changePasswordSuccess() {
    showNotification(this.props.translate('passwordChanged'), 'success', 8000);
    this.props.closeChangePassword();
  }


  changePasswordFailure(err) {
    this.showNotification(err.message, 'error', 8000);
  }

  render() {
    const { changePasswordLoading } = this.props;

    return (
      <div>
        {
          changePasswordLoading
            ? <Loader />
            : (
              <Form onSubmit={this.props.handleSubmit(this.onSubmit)}>
                <div>
                  <Field
                    name="oldPassword"
                    type="password"
                    component={TextField}
                    floatingLabelText={this.props.translate('currentPassword')}
                    validate={required}
                  />
                </div>
                <div>
                  <Field
                    name="newPassword"
                    floatingLabelText={this.props.translate('newPassword')}
                    type="password"
                    validate={required}
                    component={TextField}
                  />
                </div>
                <div>
                  <Field
                    name="confirmNewPassword"
                    floatingLabelText={this.props.translate('confirmPassword')}
                    type="password"
                    validate={required}
                    component={TextField}
                  />
                </div>
              </Form>
            )
        }
      </div>
    );
  }
}

ChangePassword.propTypes = {
  translate: PropTypes.func.isRequired,
  oldPassword: PropTypes.string,
  newPassword: PropTypes.string,
  confirmNewPassword: PropTypes.string,
  changePasswordFunction: PropTypes.func,
  closeChangePassword: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func.isRequired,
  changePasswordLoading: PropTypes.bool.isRequired,
};

ChangePassword.defaultProps = {
  oldPassword: '',
  newPassword: '',
  confirmNewPassword: '',
  changePasswordFunction,
};

const selector = formValueSelector('ChangePassword');

const ChangePasswordForm = reduxForm({
  form: 'ChangePassword', // a unique identifier for this form
  validate,
})(ChangePassword);

export default connect((state => ({
  oldPassword: selector(state, 'oldPassword'),
  newPassword: selector(state, 'newPassword'),
  confirmNewPassword: selector(state, 'confirmNewPassword'),
  isLoggedIn: state.login.isLoggedIn,
  changePasswordLoading: state.login.loginLoading,
})), {
  changePasswordFunction,
})(withTranslate(ChangePasswordForm));
