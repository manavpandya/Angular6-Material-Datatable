import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import Paper from 'material-ui/Paper';
import { withRouter } from 'react-router';
import Button from 'material-ui/Button';
import { TextField } from 'redux-form-material-ui';
import { reduxForm, Form, Field } from 'redux-form';

const SendEmail = props => (
  <div>
    <Paper className="authentication widget">
      <div className="send-email-component">
        <h1>{props.translate('resetPassword')}</h1>
        <Form onSubmit={props.handleSubmit(props.sendUserEmail)}>
          <div className="send-email-field">
            <Field
              name="email"
              component={TextField}
              label={props.translate('resetEmail')}
            />
          </div>
          <div className="send-email-buttons">
            <Button type="submit">
              {props.translate('submitButton')}
            </Button>
            <Button
              type="button"
              onClick={() => props.history.push('/login')}
            >
              {props.translate('cancelButton')}
            </Button>
          </div>
        </Form>
      </div>
    </Paper>
  </div>
);

SendEmail.propTypes = {
  translate: PropTypes.func.isRequired,
  handleSubmit: PropTypes.func,
  sendUserEmail: PropTypes.func,
  history: PropTypes.object.isRequired, // eslint-disable-line
};

SendEmail.defaultProps = {
  handleSubmit: () => {},
  sendUserEmail: () => {},
};

export default reduxForm({ form: 'sendEmail' })(withRouter(withTranslate(SendEmail)));
