import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import moment from 'moment';
import { change, formValueSelector } from 'redux-form';
import NewJob from './NewJob';
import {
  createNewJob,
  updateJob,
  getDraftedJobs,
  getPostedJobs,
  getQualifiedJobs,
  getPresentedJobs,
  getClosedJobs,
  getJobById,
  getCountries,
  getStatesByCountry,
  getCitiesByState,
  flushLocationFieldsData,
} from '../../redux/actions';
import { getCustomers } from '../../../manage-customers/redux/actions';
import { showNotification } from '../../../../utils/Notifications';
import Loader from '../../../../shared/basic/Loader';

let initialValues = {};

const initializeForm = () => {
  initialValues = {
    job_title: '',
    no_of_positions: '',
    job_release_date: moment(new Date()).format('YYYY-MM-DD'),
    job_due_date: moment(new Date()).format('YYYY-MM-DD'),
    job_application_close_date: moment(new Date()).format('YYYY-MM-DD'),
    required_skills: [],
    desired_skills: [],
    qualifications: [],
    min_experience: '',
    max_experience: '',
    certifications: [],
    licenses: [],
    read: [],
    write: [],
    speak: [],
    country: '',
    postal_code: '',
    region: '',
    job_type: '',
    employment_length: '',
    visa_required: '',
    type_of_travel: '',
    job_start_date: moment(new Date()).format('YYYY-MM-DD'),
    job_end_date: moment(new Date()).format('YYYY-MM-DD'),
    ultimate_client_id: '',
    description: '',
  };
};

const mapBooleanToYesNo = (boolean) => {
  if (boolean) return 'yes';
  return 'no';
};

const displayValueBiConverterSkills = (prop) => {
  let newProp = prop;
  if (prop.value && !newProp.display_value) {
    newProp.display_value = prop.value;
  }
  if (prop.preferred_term) {
    newProp.value = prop.preferred_term;
    newProp.preferred_term = prop.preferred_term;
  }
  if (!(prop.display_value && prop.value)) {
    newProp = {};
    newProp.display_value = prop;
    newProp.value = prop;
  }
  return newProp;
};

const displayValueBiConverter = (prop) => {
  let newProp = prop;
  if (prop.value) {
    newProp.display_value = prop.value;
  }
  if (prop.display_value) {
    newProp.value = prop.display_value;
  }
  if (!(prop.display_value && prop.value)) {
    newProp = {};
    newProp.display_value = prop;
    newProp.value = prop;
  }
  return newProp;
};

const setDefaultValues = values => ({
  job_title: values.job_description && values.job_description.job_title
    ? values.job_description.job_title
    : '',
  no_of_positions: values.no_of_positions || '',
  job_release_date: values.job_description &&
    values.job_description.job_release_date
    ? values.job_description.job_release_date
    : moment(new Date()).format('YYYY-MM-DD'),
  job_due_date: values.job_description &&
    values.job_description.job_due_date
    ? values.job_description.job_due_date
    : moment(new Date()).format('YYYY-MM-DD'),
  job_application_close_date: values.job_description &&
    values.job_description.job_application_close_date
    ? values.job_description.job_application_close_date
    : moment(new Date()).format('YYYY-MM-DD'),
  status: values.status || '',
  required_skills: values.job_description && values.job_description.required_skills
    ? values.job_description.required_skills.map(displayValueBiConverterSkills)
    : [],
  desired_skills: values.job_description && values.job_description.desired_skills
    ? values.job_description.desired_skills.map(displayValueBiConverterSkills)
    : [],
  qualifications: values.qualifications && values.qualifications.degree
    ? values.qualifications.degree.map(displayValueBiConverter)
    : [],
  min_experience: values.industry_experience && values.industry_experience.min_experience
    ? values.industry_experience.min_experience
    : '',
  max_experience: values.industry_experience && values.industry_experience.max_experience
    ? values.industry_experience.max_experience
    : '',
  certifications: values.certification_license && values.certification_license.certifications
    ? values.certification_license.certifications.map(displayValueBiConverter)
    : [],
  licenses: values.certification_license && values.certification_license.licenses
    ? values.certification_license.licenses.map(displayValueBiConverter)
    : [],
  read: values.language_proficiency && values.language_proficiency.read
    ? values.language_proficiency.read
    : [],
  write: values.language_proficiency && values.language_proficiency.write
    ? values.language_proficiency.write
    : [],
  speak: values.language_proficiency && values.language_proficiency.speak
    ? values.language_proficiency.speak
    : [],
  country: values.location && values.location.country ? values.location.country : '',
  postal_code: values.location && values.location.postal_code
    ? values.location.postal_code
    : '',
  region: values.location && values.location.region ? values.location.region : '',
  job_type: values.employment_type && values.employment_type.type
    ? values.employment_type.type
    : '',
  employment_length: values.employment_type && values.employment_type.length
    ? values.employment_type.length
    : '',
  visa_required: values.employment_type && values.employment_type.visa_required
    ? mapBooleanToYesNo(values.employment_type.visa_required)
    : '',
  type_of_travel: values.employment_type && values.employment_type.type_of_travel
    ? values.employment_type.type_of_travel
    : '',
  job_end_date: values.job_description && values.job_description.job_end_date
    ? values.job_description.job_end_date
    : moment(new Date()).format('YYYY-MM-DD'),
  job_start_date: values.job_description && values.job_description.job_start_date
    ? values.job_description.job_start_date
    : moment(new Date()).format('YYYY-MM-DD'),
  ultimate_client: values.customer && values.customer.name
    ? values.customer.name
    : '',
  ultimate_client_id: values.customer && values.customer.id
    ? values.customer
    : '',
  description: values.job_description && values.job_description.description
    ? values.job_description.description
    : '',
  country_id: values.jp_location && values.jp_location.country_id
    ? values.jp_location.country_id
    : '',
  region_id: values.jp_location && values.jp_location.region_id
    ? values.jp_location.region_id
    : '',
  city_id: values.jp_location && values.jp_location.city_id
    ? values.jp_location.city_id
    : '',
});

class NewJobContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      jobType: '',
      client: '',
    };
    this.setJobType = this.setJobType.bind(this);
    this.submitNewJob = this.submitNewJob.bind(this);
    this.handleChangeClient = this.handleChangeClient.bind(this);
    initializeForm();
  }

  componentDidMount() {
    if (this.props.match.params.id) {
      this.props.getJobById(this.props.match.params.id);
    }
    this.props.getCustomers(1);
    this.props.getCountries()
      .then(() => {
        if (this.props.currentJob.jp_location && this.props.currentJob.jp_location.country_id) {
          this.props.getStatesByCountry(this.props.currentJob.jp_location.country_id)
            .then(() => {
              if (this.props.currentJob.jp_location &&
                  this.props.currentJob.jp_location.region_id) {
                this.props.getCitiesByState(this.props.currentJob.jp_location.region_id);
              }
            })
            .catch(() => {
              showNotification('Something went wrong, Please reload the page', 'error');
            });
        }
      })
      .catch(() => {
        showNotification('Something went wrong, Please reload the page', 'error');
      });
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.currentJob !== nextProps.currentJob) {
      if (Object.keys(nextProps.currentJob).length > 0) {
        initialValues = setDefaultValues(nextProps.currentJob);
        this.setState({
          client: nextProps.currentJob.job_description.employer,
        });
      }
    }
  }

  setJobType(value) {
    this.setState({
      jobType: value,
    });
  }

  submitNewJob(values) {
    const job = {
      certification_license: {
        certifications: values.certifications
          && values.certifications.filter(certification => certification !== null)
            .map(certification => certification.display_value),
        licenses: values.licenses
          && values.licenses.filter(license => license !== null)
            .map(license => license.display_value),
      },
      employer: {
        employer: [
          'NA',
        ],
        main_employer: 'NA',
      },
      industry_experience: {
        min_experience: values.min_experience === '' ? 0 : Number(values.min_experience),
        max_experience: values.max_experience === '' ? 0 : Number(values.max_experience),
      },
      employment_type: {
        type: values.job_type,
        length: values.employment_length,
        visa_required: values.visa_required,
        type_of_travel: values.type_of_travel,
      },
      customer_id: values.ultimate_client_id.id,
      job_description: {
        job_title: values.job_title,
        job_release_date: values.job_release_date,
        job_due_date: values.job_due_date,
        job_application_close_date: values.job_application_close_date,
        required_skills: values.required_skills
          && values.required_skills.filter(skill => skill !== null)
            .map(skill => skill.preferred_term || skill.value),
        mgmt_score: 0,
        desired_skills: values.desired_skills
          && values.desired_skills.filter(skill => skill !== null)
            .map(skill => skill.preferred_term || skill.value),
        alternate_job_titles: [],
        // employer: values.ultimate_client.name,
        executive_type: 'NONE',
        is_management_job: false,
        job_end_date: values.job_end_date,
        job_start_date: values.job_start_date,
        description: values.description,
      },
      language_proficiency: {
        read: values.read
          && values.read.filter(language => language !== null)
            .map(language => language.value || language),
        write: values.write
          && values.write.filter(language => language !== null)
            .map(language => language.value || language),
        speak: values.speak
          && values.speak.filter(language => language !== null)
            .map(language => language.value || language),
      },
      location: {
        country: values.country,
        postal_code: values.postal_code,
        region: values.region,
      },
      payment: {
        currency: 'NA',
        payrate: 'NA',
      },
      qualifications: {
        degree: values.qualifications
          && values.qualifications.filter(skill => skill !== null)
            .map(skill => skill.display_value),
      },
      status: this.props.match.params.id ? values.status : this.state.jobType,
      no_of_positions: values.no_of_positions,
      jp_location: {
        country_id: values.country_id.id,
        region_id: values.region_id.id,
        city_id: values.city_id.id,
      },
    };

    // if (this.props.match.params.id && values.status !== 'posted') {
    if (this.props.match.params.id) {
      this.props.updateJob(this.props.match.params.id, job).then(() => {
        showNotification(this.props.translate('jobUpdated'), 'success', 8000);
        switch (job.status) {
          case 'draft':
            this.props.getDraftedJobs(1, this.props.draftJobsSortedBy);
            break;
          case 'posted':
            this.props.getPostedJobs(1, this.props.postedJobsSortedBy);
            break;
          case 'qualified':
            this.props.getQualifiedJobs(1, this.props.qualifiedJobsSortedBy);
            break;
          case 'presented':
            this.props.getPresentedJobs(1, this.props.presentedJobsSortedBy);
            break;
          case 'closed':
            this.props.getClosedJobs(1, this.props.closedJobsSortedBy);
            break;
          default:
            break;
        }
        this.props.history.push('/recruiter');
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      });
    } else {
      this.props.createNewJob(job).then(() => {
        showNotification(this.props.translate('jobPosted'), 'success', 8000);
        if (this.state.jobType === 'draft') {
          this.props.getDraftedJobs(1, this.props.draftJobsSortedBy);
        } else {
          this.props.getPostedJobs(1, this.props.postedJobsSortedBy);
        }
        this.props.history.push('/recruiter');
      }).catch((err) => {
        showNotification(err, 'error', 8000);
      });
    }
  }

  handleChangeClient(client) {
    this.props.dispatch(change('NewJobForm', 'ultimate_client_id', client));
    this.setState({
      client,
    });
  }

  render() {
    return (
      <div>
        <NewJob
          initialValues={
            Object.keys(this.props.initialValues).length > 0
              ? setDefaultValues(this.props.initialValues)
              : initialValues
          }
          handleExpandClick={this.props.handleExpandClick}
          expanded={this.props.expanded}
          addToExpanded={this.props.addToExpanded}
          getOptions={this.getOptions}
          submitNewJob={this.submitNewJob}
          setJobType={this.setJobType}
          id={this.props.match.params ? this.props.match.params.id : ''}
          ultimateClientSuggestions={this.ultimateClientSuggestions}
          customers={this.props.customers}
          countries={this.props.countries}
          states={this.props.states}
          cities={this.props.cities}
          getStatesByCountry={this.props.getStatesByCountry}
          getCitiesByState={this.props.getCitiesByState}
          client={this.state.client}
          handleChangeClient={this.handleChangeClient}
          flushLocationFieldsData={this.props.flushLocationFieldsData}
          release_date={this.props.release_date}
          due_date={this.props.due_date}
        />
        {
          (this.props.currentJobLoading
          || this.props.createNewJobLoading
          || this.props.editJobLoading
          || this.props.loading)
          && <Loader />
        }
      </div>
    );
  }
}

NewJobContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  handleExpandClick: PropTypes.func,
  expanded: PropTypes.arrayOf(PropTypes.string),
  addToExpanded: PropTypes.func,
  initialValues: PropTypes.object, // eslint-disable-line
  createNewJob: PropTypes.func,
  updateJob: PropTypes.func,
  getDraftedJobs: PropTypes.func,
  getPostedJobs: PropTypes.func,
  getQualifiedJobs: PropTypes.func,
  getPresentedJobs: PropTypes.func,
  getClosedJobs: PropTypes.func,
  getCustomers: PropTypes.func,
  getCountries: PropTypes.func,
  getStatesByCountry: PropTypes.func,
  getCitiesByState: PropTypes.func,
  history: PropTypes.object, // eslint-disable-line
  match: PropTypes.object, // eslint-disable-line
  getJobById: PropTypes.func,
  currentJob: PropTypes.object, // eslint-disable-line
  currentJobLoading: PropTypes.bool,
  currentJobError: PropTypes.object, // eslint-disable-line
  createNewJobLoading: PropTypes.bool,
  createNewJobError: PropTypes.object, // eslint-disable-line
  editJobLoading: PropTypes.bool,
  loading: PropTypes.bool.isRequired,
  editJobError: PropTypes.object, // eslint-disable-line
  draftJobsSortedBy: PropTypes.string,
  postedJobsSortedBy: PropTypes.string,
  qualifiedJobsSortedBy: PropTypes.string,
  presentedJobsSortedBy: PropTypes.string,
  closedJobsSortedBy: PropTypes.string,
  customers: PropTypes.arrayOf(PropTypes.any),
  countries: PropTypes.arrayOf(PropTypes.any),
  states: PropTypes.arrayOf(PropTypes.any),
  cities: PropTypes.arrayOf(PropTypes.any),
  flushLocationFieldsData: PropTypes.func,
  dispatch: PropTypes.func,
  release_date: PropTypes.string,
  due_date: PropTypes.string,
};

NewJobContainer.defaultProps = {
  flushLocationFieldsData: () => { },
  handleExpandClick: () => { },
  expanded: [],
  addToExpanded: () => { },
  initialValues: {},
  createNewJob: () => { },
  updateJob: () => { },
  getDraftedJobs: () => { },
  getPostedJobs: () => { },
  getQualifiedJobs: () => {},
  getPresentedJobs: () => {},
  getClosedJobs: () => {},
  dispatch: () => {},
  customers: [],
  countries: [],
  states: [],
  cities: [],
  history: {},
  match: {},
  getJobById: () => { },
  getCustomers: () => {},
  getCountries: () => {},
  getStatesByCountry: () => {},
  getCitiesByState: () => {},
  currentJob: {},
  currentJobLoading: false,
  currentJobError: {},
  createNewJobLoading: false,
  createNewJobError: {},
  editJobLoading: false,
  editJobError: {},
  draftJobsSortedBy: 'none',
  postedJobsSortedBy: 'none',
  qualifiedJobsSortedBy: 'none',
  presentedJobsSortedBy: 'none',
  closedJobsSortedBy: 'none',
  release_date: '',
  due_date: '',
};

const selector = formValueSelector('NewJobForm');

const mapStateToProps = state => ({
  loading: state.recruiter.loading,
  cities: state.recruiter.cities,
  states: state.recruiter.states,
  countries: state.recruiter.countries,
  currentJob: state.recruiter.currentJob,
  currentJobLoading: state.recruiter.currentJobLoading,
  currentJobError: state.recruiter.currentJobError,
  createNewJobLoading: state.recruiter.createNewJobLoading,
  createNewJobError: state.recruiter.createNewJobError,
  editJobLoading: state.recruiter.editJobLoading,
  editJobError: state.recruiter.editJobError,
  draftJobsSortedBy: state.recruiter.draftJobsSortedBy,
  postedJobsSortedBy: state.recruiter.postedJobsSortedBy,
  qualifiedJobsSortedBy: state.recruiter.qualifiedJobsSortedBy,
  presentedJobsSortedBy: state.recruiter.presentedJobsSortedBy,
  closedJobsSortedBy: state.recruiter.closedJobsSortedBy,
  customers: state.customers.customers,
  release_date: selector(state, 'job_release_date'),
  due_date: selector(state, 'job_due_date'),
});

const mapDispatchToProps = dispatch => ({
  createNewJob: job => dispatch(createNewJob(job)),
  updateJob: (id, job) => dispatch(updateJob(id, job)),
  getDraftedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getDraftedJobs(pageNo, sortBy, employer, key, perPage)),
  getPostedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getPostedJobs(pageNo, sortBy, employer, key, perPage)),
  getQualifiedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getQualifiedJobs(pageNo, sortBy, employer, key, perPage)),
  getPresentedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getPresentedJobs(pageNo, sortBy, employer, key, perPage)),
  getClosedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getClosedJobs(pageNo, sortBy, employer, key, perPage)),
  getJobById: jobId => dispatch(getJobById(jobId)),
  getCustomers: pageNo => dispatch(getCustomers(pageNo)),
  getCountries: (pageNo, pageSize) => dispatch(getCountries(pageNo, pageSize)),
  getStatesByCountry: (value, pageNo, pageSize) =>
    dispatch(getStatesByCountry(value, pageNo, pageSize)),
  getCitiesByState: (value, pageNo, pageSize) =>
    dispatch(getCitiesByState(value, pageNo, pageSize)),
  flushLocationFieldsData: () =>
    dispatch(flushLocationFieldsData()),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(NewJobContainer)));// eslint-disable-line
