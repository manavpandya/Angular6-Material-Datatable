import React from 'react';
import Button from 'material-ui/Button';
import Paper from 'material-ui/Paper';
import Dialog from 'material-ui/Dialog';
import LibraryIcon from 'material-ui-icons/LibraryBooks';
import Badge from 'material-ui/Badge';

const faker = require('faker');

class JobLibraryMatches extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      open: false,
    };
    this.handleClickOpen = this.handleClickOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }

  handleClickOpen() {
    this.setState({ open: true });
  }

  handleClose() {
    this.setState({ open: false });
  }

  render() {
    const actions = [
      <Button
        label="Cancel"
        primary
        onClick={this.handleClickOpen}
      />,
      <Button
        label="Submit"
        primary
        keyboardFocused
        onClick={this.handleClose}
      />,
    ];

    return (
      <div>
        <Button className="btn-white">
          <Badge badgeContent={4} className="match">
            <LibraryIcon onClick={this.handleClickOpen} className="color-grey" />
          </Badge>

        </Button>
        <Dialog
          actions={actions}
          modal={false}
          open={this.state.open}
          onRequestClose={this.handleClose}
          maxWidth="md"
          autoFocus
        >
          <h2>4 Matches found</h2>
          <div>
            <div className="templates job-library-templates">
              {[1, 2, 3, 4].map(i => (
                <Paper
                  key={i}
                  elevation={1}
                  className="template-paper"

                >
                  <h2 className="color-grey">Template {i}</h2>
                  <h2>{faker.random.number({ min: 70, max: 98 })}% match</h2>
                </Paper>))}
            </div>
          </div>
        </Dialog>
      </div>
    );
  }
}


export default JobLibraryMatches;
