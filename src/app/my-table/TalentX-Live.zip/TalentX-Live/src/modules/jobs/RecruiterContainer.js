import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import BoardHeader from '../../shared/compound/board/BoardHeader/index';
import JobDashboardContainer from './components/JobDashboard/JobDashboardContainer';
import { intercomSearch, intercomCreate } from './redux/actions';

class RecruiterContainer extends React.Component {
  componentDidMount() {
    this.props.intercomSearch('search');
    this.props.intercomCreate('create');
  }
  render() {
    return (
      <div className="page">
        <BoardHeader headerName="3000🚀" />
        <JobDashboardContainer />
      </div>
    );
  }
}

RecruiterContainer.propTypes = {
  intercomSearch: PropTypes.func,
  intercomCreate: PropTypes.func,
};

RecruiterContainer.defaultProps = {
  intercomSearch: () => {},
  intercomCreate: () => {},
};

const mapDispatchToProps = dispatch => ({
  intercomSearch: searchKey => dispatch(intercomSearch(searchKey)),
  intercomCreate: searchKey => dispatch(intercomCreate(searchKey)),
});

export default connect(null, mapDispatchToProps)(RecruiterContainer);

