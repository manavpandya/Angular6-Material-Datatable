import React from 'react';

import JobDetailsContainer from '../jobs/components/JobDetails/JobDetailsContainer';

const JobDetails = () => (
  <JobDetailsContainer />
);

export default JobDetails;
