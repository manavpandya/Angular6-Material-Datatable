import React from 'react';
import NewJobXonged from './components/NewJobXonged';

const RecruiterNewJobMatches = () =>
  (
    <div className="page jobs">
      <main>
        <div className="container">
          <h1>New Job Posting</h1>
          <div className="widget job">
            <aside className="job library">
              <h5>Matched Templates</h5>
            </aside>
            <main>
              <NewJobXonged />
            </main>
          </div>
        </div>
      </main>
    </div>
  );

export default RecruiterNewJobMatches;
