import React from 'react';
import AddIcon from 'material-ui-icons/Add';
import ShareIcon from 'material-ui-icons/Share';
import _ from 'lodash';

const stakeholders = [
  {
    name: 'Christina Ross',
    avatar: 'https://cdn1.iconfinder.com/data/icons/user-pictures/100/female1-512.png',
    type: 'clients',
    primary: true,
  },
  {
    name: 'Alice Boyle',
    avatar: 'http://www.designshock.com/wp-content/uploads/2016/04/man-4-400.jpg',
    type: 'teams',
  },
  {
    name: 'Henry Morrison',
    avatar: 'http://i.pravatar.cc/150?img=59',
    type: 'teams',
  },
  {
    name: 'Vincent Cooper',
    avatar: 'http://i.pravatar.cc/150?img=12',
    type: 'owners',
  },
  {
    name: 'Harry Beahan',
    avatar: 'https://cdn0.iconfinder.com/data/icons/user-pictures/100/matureman1-512.png',
    type: 'clients',
  },
];

const groups = _.groupBy(stakeholders, 'type');

const JobStakeholders = () => (
  <div className="stakeholders">
    <h3>Client <AddIcon /></h3>
    <ul>
      {
        groups.clients.map(client => (
          <li key={client.name}>
            <img className="avatar" alt="" src={client.avatar} />
            <span className="name">{client.name}</span>
            {client.primary ? <span className="primary-contact">primary</span> : ''}
          </li>
        ))
      }
    </ul>
    <h3>Team <ShareIcon /></h3>
    <ul>
      {
        groups.teams.map(team => (
          <li key={team.name}>
            <img className="avatar" alt="" src={team.avatar} />
            <span className="name">{team.name}</span>
          </li>
        ))
      }
    </ul>
    <h3>Owner</h3>
    <ul>
      {
        groups.owners.map(owner => (
          <li key={owner.name}>
            <img className="avatar" alt="" src={owner.avatar} />
            <span className="name">{owner.name}</span>
          </li>
        ))
      }
    </ul>
  </div>
);

export default JobStakeholders;
