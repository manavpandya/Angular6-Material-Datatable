import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { withRouter } from 'react-router';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import update from 'immutability-helper';
import { showNotification } from '../../../../../utils/Notifications';
import BASE_URL from '../../../../../constants';
import RecruiterJob from './RecruiterJob';
import AddToJobDialog from '../../../../../shared/compound/AddToJobDialog';
import { fetchFacetMatched, resetFilterParamsMatched, flushTheCounts, getMatchedCandidates, getJobApplicationList, getJobApplicationListCounts, flushCandidates, shortlistJobApplication, shortlistBulkApplication, moveJobApplication, moveBulkApplication, deleteJobApplication, deleteJobApplicationBulk } from '../../../redux/actions';
import { getTempToken, selectAllCandidates } from '../../../../candidates/redux/actions';


class RecruiterJobContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      // currentCandidate: {},
      currentTabKey: '',
      currentSubTabKey: '',
      currentTabCountKey: '',
      currentSubTabCountKey: '',
      currentSubTabKeys: [],
      addtoJobCandidates: {},
      isAddToJobDialogOpen: false,
      pagination: {
        shortlist: {
          'shortlist-matched': {
            pageNo: 0,
            pageSize: 100,
          },
          // 'shortlist-interested': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
          // 'shortlist-reviewLater': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
          // 'shortlist-skipped': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
        },
        qualify: {
          'qualify-shortlisted': {
            pageNo: 0,
            pageSize: 100,
          },
          'qualify-rejected': {
            pageNo: 0,
            pageSize: 100,
          },
          // 'qualify-contacted': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
          // 'qualify-consented': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
          // 'qualify-skipped': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
        },
        present: {
          'present-qualified': {
            pageNo: 0,
            pageSize: 100,
          },
          'present-presented': {
            pageNo: 0,
            pageSize: 100,
          },
          // 'present-skipped': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
        },
        accepted: {
          'shortlist-matched': {
            pageNo: 0,
            pageSize: 100,
          },
          'qualify-rejected': {
            pageNo: 0,
            pageSize: 100,
          },
          // 'present-skipped': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
        },
        offer: {
          'qualify-interviewed': {
            pageNo: 0,
            pageSize: 100,
          },
          'qualify-rejected': {
            pageNo: 0,
            pageSize: 100,
          },
          // 'present-skipped': {
          //   pageNo: 0,
          //   pageSize: 100,
          // },
        },
        interview: {
          'shortlist-matched': {
            pageNo: 0,
            pageSize: 100,
          },
          'qualify-rejected': {
            pageNo: 0,
            pageSize: 100,
          },
        },
        // hiring: {
        //   'hiring-viewed': {
        //     pageNo: 0,
        //     pageSize: 100,
        //   },
        //   'hiring-interviewed': {
        //     pageNo: 0,
        //     pageSize: 100,
        //   },
        //   'hiring-offered': {
        //     pageNo: 0,
        //     pageSize: 100,
        //   },
        //   'hiring-rejected': {
        //     pageNo: 0,
        //     pageSize: 100,
        //   },
        //   'hiring-hired': {
        //     pageNo: 0,
        //     pageSize: 100,
        //   },
        // },
      },
    };
    this.getMatchedCandidates = this.getMatchedCandidates.bind(this);
    this.getCandidates = this.getCandidates.bind(this);
    // this.setCurrentCandidate = this.setCurrentCandidate.bind(this);
    this.setCurrentTabKey = this.setCurrentTabKey.bind(this);
    this.setCurrentSubTabKey = this.setCurrentSubTabKey.bind(this);
    this.setCurrentSubTabKeys = this.setCurrentSubTabKeys.bind(this);
    this.setPagination = this.setPagination.bind(this);
    this.shortlistJobApplication = this.shortlistJobApplication.bind(this);
    this.moveJobApplication = this.moveJobApplication.bind(this);
    this.deleteJobApplication = this.deleteJobApplication.bind(this);
    this.deleteJobApplicationBulk = this.deleteJobApplicationBulk.bind(this);
    this.downloadFile = this.downloadFile.bind(this);
    this.openAddToJobDialog = this.openAddToJobDialog.bind(this);
    this.closeAddToJobDialog = this.closeAddToJobDialog.bind(this);
    this.shortlistBulkApplication = this.shortlistBulkApplication.bind(this);
    this.moveBulkApplication = this.moveBulkApplication.bind(this);
  }

  componentDidMount() {
    this.props.flushTheCounts();
    if (Object.keys(this.props.job).length > 0 && this.props.job.id) {
      this.props.getJobApplicationListCounts(this.props.job.id);
    }
  }

  getCandidatesHelper(callback) {
    if (this.props.job) {
      const { pagination, currentTabKey, currentSubTabKey } = this.state;
      if (this.state.currentTabKey && this.state.currentSubTabKey) {
        const currentSubTab = pagination[currentTabKey][currentSubTabKey];
        const { pageNo, pageSize } = currentSubTab;
        callback(pageNo, pageSize);
      } else {
        callback();
      }
    }
  }

  getMatchedCandidates() {
    this.getCandidatesHelper((pageNo, pageSize) => {
      this.props.getMatchedCandidates(this.props.job.id, 1, pageSize || 100);
    });
  }

  getCandidates(status) {
    this.getCandidatesHelper((pageNo, pageSize) => {
      this.props.getJobApplicationList(this.props.job.id, status, pageNo + 1 || 1, pageSize || 100);
    });
  }

  setCurrentTabKey(key, countKey, callback) {
    this.setState({
      currentTabKey: key,
      currentTabCountKey: countKey,
    }, () => {
      if (callback) callback();
    });
  }

  setCurrentSubTabKey(key, countKey, callback) {
    this.setState({
      currentSubTabKey: key,
      currentSubTabCountKey: countKey,
    }, () => {
      if (callback) callback();
    });
  }

  setCurrentSubTabKeys(keys) {
    this.setState({
      currentSubTabKeys: keys,
    });
  }

  setPagination(options, callback) {
    const newState = update(this.state, {
      pagination: {
        [this.state.currentTabKey]: {
          [this.state.currentSubTabKey]: {
            ...options,
          },
        },
      },
    });
    this.setState(newState, () => {
      if (callback) callback();
    });
  }

  shortlistJobApplication(jobId, applicationId, status) {
    return new Promise((resolve) => {
      resolve(this.props.shortlistJobApplication(jobId, applicationId, status).then(() => {
        this.props.getJobApplicationListCounts(jobId);
      }));
    });
  }

  shortlistBulkApplication(jobId, applicationIds, status) {
    return new Promise((resolve) => {
      resolve(this.props.shortlistBulkApplication(jobId, applicationIds, status).then(() => {
        this.props.selectAllCandidates([]);
        this.props.getJobApplicationListCounts(jobId);
      }));
    });
  }

  moveBulkApplication(jobId, applicationIds, action) {
    return new Promise((resolve) => {
      resolve(this.props.moveBulkApplication(jobId, applicationIds, action).then(() => {
        this.props.selectAllCandidates([]);
        this.props.getJobApplicationListCounts(jobId);
      }));
    });
  }

  moveJobApplication(jobId, applicationId, action) {
    return new Promise((resolve) => {
      resolve(this.props.moveJobApplication(applicationId, action).then(() => {
        this.props.getJobApplicationListCounts(jobId);
      }));
    });
  }

  deleteJobApplication(jobId, applicationId) {
    return new Promise((resolve) => {
      resolve(this.props.deleteJobApplication(applicationId).then(() => {
        this.props.getJobApplicationListCounts(jobId);
      }));
    });
  }

  deleteJobApplicationBulk(jobId, applicationId) {
    return new Promise((resolve) => {
      resolve(this.props.deleteJobApplicationBulk(jobId, applicationId).then(() => {
        this.props.getJobApplicationListCounts(jobId);
      }));
    });
  }

  downloadFile(jobId) {
    this.props.getTempToken(jobId).then(() => {
      window.open(`${BASE_URL}job_position/download/${jobId}?token=${this.props.tempToken}`);
    }).catch(err => showNotification(err, 'error', 8000));
  }

  openAddToJobDialog(candidateInfo, multipleCandidates) {
    this.setState({
      addtoJobCandidates: candidateInfo
        || multipleCandidates,
      isAddToJobDialogOpen: true,
    });
  }

  closeAddToJobDialog() {
    this.setState({ isAddToJobDialogOpen: false, addtoJobCandidates: {} });
  }

  render() {
    return (
      <div className="page">
        <RecruiterJob
          filterParamMatched={this.props.filterParamMatched}
          fetchFacetMatched={this.props.fetchFacetMatched}
          resetFilterParamsMatched={this.props.resetFilterParamsMatched}
          totalMatchedCandidates={this.props.totalMatchedCandidates}
          locale={this.props.locale}
          chatType={this.props.chatType}
          handleSubmitMessage={this.props.handleSubmitMessage}
          showMessageDialog={this.props.showMessageDialog}
          handlerShowMessageDialog={this.props.handlerShowMessageDialog}
          job={this.props.job}
          addNote={this.props.addNote}
          deleteNote={this.props.deleteNote}
          newNoteDescription={this.props.newNoteDescription}
          changeNewNoteDescription={this.props.changeNewNoteDescription}
          getMatchedCandidates={this.getMatchedCandidates}
          getCandidates={this.getCandidates}
          matchedCandidates={this.props.matchedCandidates}
          matchedCandidatesCounts={this.props.matchedCandidatesCounts}
          jobApplicationList={this.props.jobApplicationList}
          flushCandidates={this.props.flushCandidates}
          shortlistJobApplication={this.shortlistJobApplication}
          moveJobApplication={this.moveJobApplication}
          deleteJobApplication={this.deleteJobApplication}
          deleteJobApplicationBulk={this.deleteJobApplicationBulk}
          pagination={this.state.pagination}
          setPagination={this.setPagination}
          currentTabKey={this.state.currentTabKey}
          currentSubTabKey={this.state.currentSubTabKey}
          currentTabCountKey={this.state.currentTabCountKey}
          currentSubTabCountKey={this.state.currentSubTabCountKey}
          setCurrentTabKey={this.setCurrentTabKey}
          setCurrentSubTabKey={this.setCurrentSubTabKey}
          currentSubTabKeys={this.state.currentSubTabKeys}
          setCurrentSubTabKeys={this.setCurrentSubTabKeys}
          jobApplicationCount={this.props.jobApplicationCount}
          openAddToJobDialog={this.openAddToJobDialog}
          downloadFile={this.downloadFile}
          candidatesLoading={this.props.candidatesLoading}
          selectedCandidates={this.props.selectedCandidates}
          shortlistBulkApplication={this.shortlistBulkApplication}
          moveBulkApplication={this.moveBulkApplication}
          selectAllCandidates={this.props.selectAllCandidates}
          customerPage={this.props.match.path === '/customer/jobs/job/:id'}
        />
        <AddToJobDialog
          addtoJobCandidates={this.state.addtoJobCandidates.length
            ? this.state.addtoJobCandidates[0] : this.state.addtoJobCandidates}
          addtoJobCandidatesMultiple={this.state.addtoJobCandidates.length
            ? this.state.addtoJobCandidates : []}
          isAddToJobDialogOpen={this.state.isAddToJobDialogOpen}
          closeAddToJobDialog={this.closeAddToJobDialog}
        />
      </div>
    );
  }
}

RecruiterJobContainer.propTypes = {
  match: PropTypes.objectOf(PropTypes.any),
  locale: PropTypes.string,
  job: PropTypes.instanceOf(Object).isRequired,
  addNote: PropTypes.func,
  deleteNote: PropTypes.func,
  newNoteDescription: PropTypes.string,
  changeNewNoteDescription: PropTypes.func,
  getMatchedCandidates: PropTypes.func,
  matchedCandidates: PropTypes.instanceOf(Object),
  getJobApplicationList: PropTypes.func,
  jobApplicationList: PropTypes.instanceOf(Object),
  flushCandidates: PropTypes.func,
  chatType: PropTypes.instanceOf(Object),
  showMessageDialog: PropTypes.bool,
  handlerShowMessageDialog: PropTypes.func,
  handleSubmitMessage: PropTypes.func,
  shortlistJobApplication: PropTypes.func,
  moveJobApplication: PropTypes.func,
  deleteJobApplication: PropTypes.func,
  deleteJobApplicationBulk: PropTypes.func,
  matchedCandidatesCounts: PropTypes.string,
  getJobApplicationListCounts: PropTypes.func,
  flushTheCounts: PropTypes.func,
  jobApplicationCount: PropTypes.instanceOf(Object),
  getTempToken: PropTypes.func,
  tempToken: PropTypes.string,
  totalMatchedCandidates: PropTypes.number,
  resetFilterParamsMatched: PropTypes.func,
  fetchFacetMatched: PropTypes.func,
  filterParamMatched: PropTypes.string,
  candidatesLoading: PropTypes.bool,
  selectedCandidates: PropTypes.arrayOf(PropTypes.any),
  shortlistBulkApplication: PropTypes.func,
  moveBulkApplication: PropTypes.func,
  selectAllCandidates: PropTypes.func,
};

RecruiterJobContainer.defaultProps = {
  totalMatchedCandidates: 0,
  match: {},
  locale: '',
  addNote: () => { },
  deleteNote: () => { },
  newNoteDescription: '',
  changeNewNoteDescription: () => {},
  getMatchedCandidates: () => {},
  matchedCandidates: {},
  getJobApplicationList: () => {},
  jobApplicationList: {},
  flushCandidates: () => {},
  chatType: {},
  handlerShowMessageDialog: () => {},
  handleSubmitMessage: () => {},
  showMessageDialog: false,
  shortlistJobApplication: () => {},
  moveJobApplication: () => {},
  deleteJobApplication: () => { },
  deleteJobApplicationBulk: () => {},
  matchedCandidatesCounts: '-',
  flushTheCounts: () => {},
  getJobApplicationListCounts: () => {},
  jobApplicationCount: {},
  getTempToken: () => {},
  tempToken: '',
  resetFilterParamsMatched: () => {},
  fetchFacetMatched: () => {},
  filterParamMatched: '',
  candidatesLoading: false,
  selectedCandidates: [],
  shortlistBulkApplication: () => {},
  moveBulkApplication: () => {},
  selectAllCandidates: () => {},
};

const mapStateToProps = state => ({
  locale: state.Intl.locale,
  facets: state.profiles.filter,
  filterParamMatched: state.recruiter.filterParam,
  matchedCandidates: state.recruiter.matchedCandidates,
  totalMatchedCandidates: state.recruiter.totalCandidates,
  matchedCandidatesCounts: state.recruiter.matchedCandidatesCounts,
  jobApplicationList: state.recruiter.jobApplicationList,
  jobApplicationCount: state.recruiter.jobApplicationCount,
  candidatesLoading: state.recruiter.candidatesLoading,
  tempToken: state.profiles.tempToken,
  selectedCandidates: state.profiles.selectedCandidates,
});

const mapDispatchToProps = dispatch => ({
  fetchFacetMatched: (keyword, jobId) => dispatch(fetchFacetMatched(keyword, jobId)),
  resetFilterParamsMatched: () => dispatch(resetFilterParamsMatched()),
  getMatchedCandidates: (jobId, pageNo, pageSize) =>
    dispatch(getMatchedCandidates(jobId, pageNo, pageSize)),
  getJobApplicationList: (jobId, status, pageNo, pageSize) =>
    dispatch(getJobApplicationList(jobId, status, pageNo, pageSize)),
  getJobApplicationListCounts: jobId => dispatch(getJobApplicationListCounts(jobId)),
  flushCandidates: () => dispatch(flushCandidates()),
  shortlistJobApplication: (jobId, applicationId, status) =>
    dispatch(shortlistJobApplication(jobId, applicationId, status)),
  shortlistBulkApplication: (jobId, applicationIds, status) =>
    dispatch(shortlistBulkApplication(jobId, applicationIds, status)),
  moveBulkApplication: (jobId, applicationIds, action) =>
    dispatch(moveBulkApplication(jobId, applicationIds, action)),
  moveJobApplication: (applicationId, action) =>
    dispatch(moveJobApplication(applicationId, action)),
  deleteJobApplication: applicationId => dispatch(deleteJobApplication(applicationId)),
  deleteJobApplicationBulk: (jobId, applicationId) =>
    dispatch(deleteJobApplicationBulk(jobId, applicationId)),
  flushTheCounts: () => dispatch(flushTheCounts()),
  selectAllCandidates: candidates => dispatch(selectAllCandidates(candidates)),
  getTempToken: jobId => dispatch(getTempToken(jobId)),
});

export default
connect(mapStateToProps, mapDispatchToProps)(withTranslate(withRouter(RecruiterJobContainer)));
