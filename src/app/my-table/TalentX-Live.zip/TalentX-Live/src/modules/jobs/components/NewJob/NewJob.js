import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { Form, Field, reduxForm } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import { withStyles } from 'material-ui/styles';
import GridList, { GridListTile } from 'material-ui/GridList';
import { FormControl } from 'material-ui/Form';
import Typography from 'material-ui/Typography';
import { MenuItem } from 'material-ui/Menu';
import Button from 'material-ui/Button';
import Expander from '../../../../shared/compound/Expander';
import MultiSelect from '../../../../shared/basic/MultiSelect';
import RegularSelect from '../../../../shared/basic/RegularSelect';
// import { required, hasChildren, compare, numeric, matchRegEx }
// from '../../../../utils/validators';
import { required, hasChildren, compareDate } from '../../../../utils/validators';
import languages from '../../../../constants/Languages';
import CustomDatePicker from '../../../../shared/compound/CustomDatePicker';
import { sortAll, getOptions } from '../../../../utils';
import { MEDIUM, LONG, SHORT } from '../../../../constants/stringLengths';

const styles = theme => ({
  expand: {
    transform: 'rotate(0deg)',
    transition: theme.transitions.create('transform', {
      duration: theme.transitions.duration.shortest,
    }),
    marginLeft: 'auto',
  },
  expandOpen: {
    transform: 'rotate(180deg)',
  },
  container: {
    height: 0,
    overflow: 'visible',
    transition: theme.transitions.create('height'),
  },
  root: {
    overflow: 'visible',
  },
  liRoot: {
    height: '100% !important',
  },
  tile: {
    overflow: 'visible',
  },
});

const expandersDictionary = {
  job_title: ['job_title', 'no_of_positions'],
  job_application_close_date: ['job_application_close_date'],
  required_skills: ['required_skills'],
  desired_skills: ['desired_skills'],
  qualifications: ['qualifications'],
  industry_experience: ['min_experience', 'max_experience'],
  certifications: ['certifications', 'licenses'],
  language_proficiency: ['read', 'write', 'speak'],
  location: ['country_id', 'postal_code', 'region'],
  employment_type: ['job_type', 'employment_length', 'visa_required', 'type_of_travel'],
  duration: ['job_end_date', 'job_start_date'],
  ultimate_client: ['ultimate_client_id'],
};

const errors = {};

const validate = (values) => {
  errors.job_title = required(values.job_title);
  errors.no_of_positions = required(values.no_of_positions);
  errors.required_skills = hasChildren(values.required_skills);
  errors.job_due_date = compareDate(values.job_due_date, values.job_release_date) ? '' : 'Invalid Due Date';
  errors.job_application_close_date = compareDate(values.job_application_close_date, values.job_release_date) ? '' : 'Invalid Application Close Date';
  errors.country_id = required(values.country_id);
  // // todo: errors.desired_skills = hasChildren(values.desired_skills);
  // errors.qualifications = hasChildren(values.qualifications);
  // errors.min_experience = required(values.min_experience);
  // errors.max_experience = required(values.max_experience);
  // if (values.min_experience) {
  //   errors.min_experience = matchRegEx(values.min_experience, numeric)
  // ? undefined : 'Should be a number between 0 and 99';
  // }
  // if (values.max_experience) {
  //   errors.max_experience = matchRegEx(values.max_experience, numeric)
  // ? undefined : 'Should be a number between 0 and 99';
  // }
  // if (values.min_experience && matchRegEx(values.min_experience, numeric)
  //   && values.max_experience && matchRegEx(values.max_experience, numeric)) {
  //   errors.min_experience = compare(Number(values.min_experience), Number(values.max_experience))
  // ? undefined : 'Min Experience greater than Max Experience';
  //   errors.max_experience = compare(Number(values.min_experience), Number(values.max_experience))
  //  ? undefined : 'Min Experience greater than Max Experience';
  // }
  // // todo:
  // // errors.certifications = hasChildren(values.certifications);
  // // errors.licenses = hasChildren(values.licenses);
  // // errors.languages = hasChildren(values.languages);
  // errors.country = required(values.country);
  // errors.postal_code = required(values.postal_code);
  // errors.region = required(values.region);
  // errors.job_type = required(values.job_type);
  // errors.employment_length = required(values.employment_length);
  // errors.visa_required = required(values.visa_required);
  // errors.type_of_travel = required(values.type_of_travel);
  // errors.job_start_date = required(values.job_start_date);
  // errors.job_end_date = required(values.job_end_date);
  // if (values.job_end_date && values.job_start_date) {
  //   errors.job_start_date = compare(values.job_start_date, values.job_end_date)
  //     ? undefined : 'End date after Start date';
  //   errors.job_end_date = compare(values.job_start_date, values.job_end_date)
  //     ? undefined : 'End date after Start date';
  // }
  errors.ultimate_client_id = required(values.ultimate_client_id);
  return errors;
};

const ExpandExpandersWithError = (props) => {
  const expandersToBeExpanded = [];
  Object.keys(expandersDictionary).map(expanderKey =>
    expandersDictionary[expanderKey].map(fieldName =>
      errors[fieldName]
      && !expandersToBeExpanded.includes(expanderKey)
      && expandersToBeExpanded.push(expanderKey)));
  props.addToExpanded(expandersToBeExpanded);
  const el = document.getElementById(expandersToBeExpanded[0]);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
};

const getPreviewContent = (props, fieldName) => {
  let content = '';
  const { initialValues } = props;
  const tmpContent = [];
  switch (fieldName) {
    case 'job_title':
      if (initialValues.job_title !== null && initialValues.job_title !== '') {
        tmpContent.push(`${props.translate('newJobTitle')}:  ${initialValues.job_title}`);
      }
      if (initialValues.no_of_positions !== null && initialValues.no_of_positions !== '') {
        tmpContent.push(`${props.translate('jobPositionOpen')}: ${initialValues.no_of_positions}`);
      }
      content = tmpContent.join(', ');
      break;
    case 'job_application_close_date':
      if (initialValues.job_application_close_date !== '') {
        content = `${props.translate('applicationCloseDate')}: ${initialValues.job_application_close_date}`;
      }
      break;
    case 'required_skills':
      content = initialValues.required_skills.map(skill => skill.value);
      content = content.join(', ');
      break;
    case 'desired_skills':
      content = initialValues.desired_skills.map(skill => skill.value);
      content = content.join(', ');
      break;
    case 'qualifications':
      content = initialValues.qualifications.map(qualification => qualification.value);
      content = content.join(', ');
      break;
    case 'industry_experience':
      if (initialValues.max_experience !== '') {
        tmpContent.push(`${props.translate('maxExperience')}: ${initialValues.max_experience}`);
      }
      if (initialValues.min_experience !== '') {
        tmpContent.push(`${props.translate('minExperience')}: ${initialValues.min_experience}`);
      }
      content = tmpContent.join(', ');
      break;
    case 'certifications':
      if (initialValues.certifications.length > 0) {
        content += `${props.translate('jobCertification')}: ${initialValues.certifications.map(certification => certification.value).join(', ')}`;
      }
      if (initialValues.licenses.length > 0) {
        content += `${props.translate('jobLicenses')}: ${initialValues.licenses.map(license => license.value)}`;
      }
      break;
    case 'language_proficiency':
      content = '';
      if (initialValues.write.length > 0) {
        tmpContent.push(`${props.translate('canWrite')}: ${initialValues.write.join(', ')}`);
      }
      if (initialValues.read.length > 0) {
        tmpContent.push(`${props.translate('canRead')}: ${initialValues.read.join(', ')}`);
      }
      if (initialValues.speak.length > 0) {
        tmpContent.push(`${props.translate('canSpeak')}: ${initialValues.speak.join(', ')}`);
      }
      content = tmpContent.join(' ');
      break;
    case 'location':
      if (initialValues.country !== '') {
        tmpContent.push(`${props.translate('jobCountry')}: ${initialValues.country}`);
      }
      if (initialValues.postal_code !== '') {
        tmpContent.push(`${props.translate('jobPostalCode')}: ${initialValues.postal_code}`);
      }
      if (initialValues.region) {
        tmpContent.push(`${props.translate('jobCity')}: ${initialValues.region}`);
      }
      content = tmpContent.join(', ');
      break;
    case 'employment_type':
      if (initialValues.job_type !== '') {
        tmpContent.push(`${props.translate('jobType')}: ${initialValues.job_type}`);
      }
      if (initialValues.employment_length !== '') {
        tmpContent.push(`${props.translate('jobEmploymentLength')}: ${initialValues.employment_length}`);
      }
      if (initialValues.visa_required !== '') {
        tmpContent.push(`${props.translate('jobVisaRequired')}: ${initialValues.visa_required}`);
      }
      if (initialValues.type_of_travel !== '') {
        tmpContent.push(`${props.translate('jobTypeOfTravel')}: ${initialValues.type_of_travel}`);
      }
      content = tmpContent.join(', ');
      break;
    case 'duration':
      if (initialValues.job_start_date !== '') {
        tmpContent.push(`${props.translate('durationFrom')}: ${initialValues.job_start_date}`);
      }
      if (initialValues.job_end_date !== '') {
        tmpContent.push(`${props.translate('durationTo')}: ${initialValues.job_end_date}`);
      }
      content = tmpContent.join(', ');
      break;
    case 'ultimate_client':
      content = initialValues.ultimate_client;
      break;
    case 'ultimate_client_id':
      content = initialValues.ultimate_client_id;
      break;
    case 'job_description':
      content = initialValues.description;
      break;
    default:
      content = '';
  }

  return content;
};

const NewJob = (props) => {
  sortAll(props.initialValues.required_skills, 'display_value');
  return (
    <Form onSubmit={props.handleSubmit(props.submitNewJob)}>
      <div className="release-due-date">
        <Field
          label={props.translate('jobReleaseDate')}
          name="job_release_date"
          component={CustomDatePicker}
        />
        <Field
          label={props.translate('jobDueDate')}
          name="job_due_date"
          minDate={props.release_date}
          minDateMessage=""
          disablePast
          component={CustomDatePicker}
        />
      </div>
      <div id="job_title">
        <Expander
          name="job_title"
          className="cardHeader"
          heading={props.translate('newJobTitle')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'job_title')}
          expanded={props.expanded}
        >
          <GridList padding={1} cols={2} cellHeight={90}>
            <GridListTile classes={{ tile: props.classes.tile }} >
              <Field
                label={props.translate('newJobTitle')}
                name="job_title"
                component={TextField}
                inputProps={{
                  maxLength: LONG,
                }}
                fullWidth
              />
            </GridListTile>
            <GridListTile>
              <Field
                fullWidth
                label={props.translate('jobPositionOpen')}
                name="no_of_positions"
                component={TextField}
                inputProps={{
                  maxLength: SHORT,
                }}
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="job_description">
        <Expander
          name="job_description"
          className="cardHeader"
          heading={props.translate('jobDescription')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'job_description')}
          expanded={props.expanded}
        >
          <GridList padding={1} cols={1} cellHeight={90}>
            <GridListTile>
              <Field
                label={props.translate('jobDescription')}
                name="description"
                component={TextField}
                inputProps={{
                  maxLength: LONG,
                }}
                multiline
                rows={3}
                fullWidth
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="job_application_close_date">
        <Expander
          name="job_application_close_date"
          className="cardHeader"
          heading={props.translate('applicationCloseDate')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'job_application_close_date')}
          expanded={props.expanded}
        >
          <GridList padding={1} cols={1} cellHeight={90}>
            <GridListTile>
              <Field
                label={props.translate('applicationCloseDate')}
                name="job_application_close_date"
                component={CustomDatePicker}
                disablePast
                minDate={props.release_date}
                rows={3}
                fullWidth
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="required_skills">
        <Expander
          name="required_skills"
          className="cardHeader"
          heading={props.translate('jobRequiredSkill')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'required_skills')}
          expanded={props.expanded}
        >
          <GridList
            classes={{ root: props.classes.root }}
            padding={1}
            cols={1}
            cellHeight={120}
          >
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }}>
              <Typography align="left" gutterBottom>
                {props.translate('jobRequiredSkill')}
              </Typography>
              <Field
                getOptions={getOptions}
                valueKey="preferred_term"
                labelKey="display_value"
                type="Async"
                apiUrl="/terms/search?&search_type=leaf_only&skill="
                // apiParams="search_type=leaf_only"
                name="required_skills"
                component={MultiSelect}
                searchKey="terms"
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="desired_skills">
        <Expander
          name="desired_skills"
          className="cardHeader"
          heading={props.translate('jobDesiredSkill')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'desired_skills')}
          expanded={props.expanded}
        >
          <GridList
            classes={{ root: props.classes.root }}
            padding={1}
            cols={1}
            cellHeight={120}
          >
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }} >
              <Typography align="left" gutterBottom>
                {props.translate('jobDesiredSkill')}
              </Typography>
              <Field
                getOptions={getOptions}
                valueKey="preferred_term"
                labelKey="display_value"
                type="Async"
                apiUrl="/terms/search?&search_type=leaf_only&skill="
                name="desired_skills"
                component={MultiSelect}
                searchKey="terms"
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="qualifications">
        <Expander
          name="qualifications"
          className="cardHeader"
          heading={props.translate('jobQualifications')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'qualifications')}
          expanded={props.expanded}
        >
          <GridList
            classes={{ root: props.classes.root }}
            padding={1}
            cols={1}
            cellHeight={120}
          >
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }} >
              <Typography align="left" gutterBottom>
                {props.translate('jobQualifications')}
              </Typography>
              <Field
                getOptions={getOptions}
                valueKey="display_value"
                labelKey="display_value"
                type="AsyncCreatable"
                apiUrl="/terms/search?&search_type=leaf_only&skill="
                name="qualifications"
                component={MultiSelect}
                searchKey="terms"
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="industry_experience">
        <Expander
          name="industry_experience"
          className="cardHeader"
          heading={props.translate('jobIndustryExperience')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'industry_experience')}
          expanded={props.expanded}
        >
          <GridList
            classes={{ root: props.classes.root }}
            padding={1}
            cols={2}
            cellHeight={90}
          >
            <GridListTile classes={{ tile: props.classes.tile }} >
              <Field
                label={props.translate('minExperienc')}
                type="number"
                name="min_experience"
                component={TextField}
              />
            </GridListTile>
            <GridListTile classes={{ tile: props.classes.tile }} >
              <Field
                label={props.translate('maxExperienc')}
                type="number"
                name="max_experience"
                component={TextField}
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="certifications">
        <Expander
          name="certifications"
          className="cardHeader"
          heading={props.translate('jobCertification')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'certifications')}
          expanded={props.expanded}
        >
          <GridList
            classes={{ root: props.classes.root }}
            padding={1}
            cols={2}
            cellHeight={90}
          >
            <GridListTile
              classes={{ root: props.classes.liRoot, tile: props.classes.tile }}
            >
              <Typography align="left" gutterBottom>
                {props.translate('jobCertification')}
              </Typography>
              <Field
                type="Creatable"
                valueKey="display_value"
                labelKey="display_value"
                label={props.translate('jobCertification')}
                name="certifications"
                component={MultiSelect}
              />
            </GridListTile>
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }} >
              <Typography align="left" gutterBottom>
                {props.translate('jobLicenses')}
              </Typography>
              <Field
                type="Creatable"
                valueKey="display_value"
                labelKey="display_value"
                label={props.translate('jobLicenses')}
                name="licenses"
                component={MultiSelect}
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="language_proficiency">
        <Expander
          name="language_proficiency"
          className="cardHeader"
          heading={props.translate('jobLanguageProficiency')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'language_proficiency')}
          expanded={props.expanded}
        >
          <GridList
            classes={{ root: props.classes.root }}
            padding={1}
            cols={3}
            cellHeight={90}
          >
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }} >
              <Typography align="left" gutterBottom>
                {props.translate('canRead')}
              </Typography>
              <Field
                options={languages}
                name="read"
                component={MultiSelect}
              />
            </GridListTile>
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }} >
              <Typography align="left" gutterBottom>
                {props.translate('canWrite')}
              </Typography>
              <Field
                options={languages}
                name="write"
                component={MultiSelect}
              />
            </GridListTile>
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }} >
              <Typography align="left" gutterBottom>
                {props.translate('canSpeak')}
              </Typography>
              <Field
                options={languages}
                name="speak"
                component={MultiSelect}
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="location">
        <Expander
          name="location"
          className="cardHeader"
          heading={props.translate('jobLocation')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          // preview={getPreviewContent(props, 'location')}
          expanded={props.expanded}
        >
          <GridList
            classes={{ root: props.classes.root }}
            padding={1}
            cols={2}
            cellHeight={90}
          >
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }}>
              <Field
                options={props.countries}
                valueKey="id"
                labelKey="name"
                placeholder={props.translate('jobCountry')}
                inputProps={{
                  autoComplete: 'nope',
                }}
                onChange={(value) => {
                  props.flushLocationFieldsData();
                  props.change('region_id', '');
                  props.change('city_id', '');
                  props.getStatesByCountry(value.id)
                    .catch(() => {
                      props.change('country_id', '');
                    });
                }
                }
                component={MultiSelect}
                multi={false}
                id="country_id"
                name="country_id"
              />
            </GridListTile>
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }}>
              <Field
                options={props.states}
                valueKey="id"
                labelKey="name"
                inputProps={{
                  autoComplete: 'nope',
                }}
                onChange={(value) => {
                  props.change('city_id', '');
                  if (value) {
                    props.getCitiesByState(value.id)
                      .catch(() => {
                        props.change('region_id', '');
                      });
                  }
                  }
                }
                placeholder={props.translate('jobState')}
                component={MultiSelect}
                multi={false}
                id="region_id"
                name="region_id"
              />
            </GridListTile>
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }}>
              <Field
                options={props.cities}
                valueKey="id"
                labelKey="name"
                placeholder={props.translate('jobCity')}
                component={MultiSelect}
                multi={false}
                id="city_id"
                name="city_id"
                inputProps={{
                  autoComplete: 'nope',
                }}
              />
            </GridListTile>
            {/* <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }}>
              <Field
                label={props.translate('jobPostalCode')}
                name="postal_code"
                component={TextField}
              />
            </GridListTile> */}
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="employment_type">
        <Expander
          name="employment_type"
          className="cardHeader"
          heading={props.translate('jobEmploymentType')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'employment_type')}
          expanded={props.expanded}
        >
          <div>
            <GridList
              classes={{ root: props.classes.root }}
              padding={1}
              cols={2}
              cellHeight={90}
            >
              <GridListTile>
                <Field
                  id="jobType"
                  name="job_type"
                  label={props.translate('jobType')}
                  component={RegularSelect}
                >
                  <MenuItem value="Part Time">Part Time </MenuItem>
                  <MenuItem value="Full Time">Full Time </MenuItem>
                </Field>
              </GridListTile>

              <GridListTile>
                <Field
                  name="employment_length"
                  label={props.translate('jobEmploymentLength')}
                  component={TextField}
                  inputProps={{
                    maxLength: MEDIUM,
                  }}
                />
              </GridListTile>
            </GridList>
            <GridList padding={1} cols={2} cellHeight={90}>
              <GridListTile>
                <Field
                  id="visaRequired"
                  name="visa_required"
                  label={props.translate('jobVisaRequired')}
                  component={RegularSelect}
                >
                  <MenuItem value="yes"> Yes </MenuItem>
                  <MenuItem value="no"> No </MenuItem>
                </Field>
              </GridListTile>

              <GridListTile>
                <Field
                  id="typeOfTravel"
                  name="type_of_travel"
                  label={props.translate('jobTypeOfTravel')}
                  component={RegularSelect}
                >
                  <MenuItem value="Air"> Air </MenuItem>
                  <MenuItem value="Road">Road </MenuItem>
                </Field>
              </GridListTile>
            </GridList>
          </div>
        </Expander>
      </div>

      <br />

      <div id="duration">
        <Expander
          name="duration"
          className="cardHeader"
          heading={props.translate('jobDuration')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'duration')}
          expanded={props.expanded}
        >
          <GridList padding={1} cols={2} cellHeight={90}>
            <GridListTile>
              <Field
                label={props.translate('durationFrom')}
                name="job_start_date"
                component={CustomDatePicker}
              />
            </GridListTile>
            <GridListTile>
              <Field
                label={props.translate('durationTo')}
                name="job_end_date"
                component={CustomDatePicker}
              />
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />

      <div id="ultimate_client">
        <Expander
          name="ultimate_client"
          className="cardHeader"
          heading={props.translate('jobUltimateClient')}
          classes={props.classes}
          handleExpandClick={props.handleExpandClick}
          preview={getPreviewContent(props, 'ultimate_client')}
          expanded={props.expanded}
        >
          <GridList padding={1} cols={1} cellHeight={90} classes={{ root: props.classes.root }}>
            <GridListTile classes={{ root: props.classes.liRoot, tile: props.classes.tile }} >
              <FormControl>
                <Field
                  getOptions={getOptions}
                  valueKey="id"
                  labelKey="name"
                  searchKey="customers"
                  placeholder={props.translate('jobUltimateClient')}
                  type="Async"
                  apiUrl="/customers/search?q="
                  component={MultiSelect}
                  multi={false}
                  id="ultimate_client_id"
                  name="ultimate_client_id"
                />
              </FormControl>
            </GridListTile>
          </GridList>
        </Expander>
      </div>

      <br />
      {
        props.id && props.id !== ''
          ? (
            <Button
              type="submit"
              color="primary"
              onClick={() => {
                ExpandExpandersWithError(props);
                if (props.initialValues.status === 'posted') props.setJobType('posted');
              }}
            >
              {/* {props.initialValues.status === 'posted' ? props.translate('postJob') :
            props.translate('updateRecord')} */}
              {props.translate('updateRecord')}
            </Button>
          )
          : (
            <div>
              <Button
                type="submit"
                color="primary"
                onClick={() => { ExpandExpandersWithError(props); props.setJobType('draft'); }}
              >
                {props.translate('saveJob')}
              </Button>
              <Button
                type="submit"
                color="primary"
                onClick={() => { ExpandExpandersWithError(props); props.setJobType('posted'); }}
              >
                {props.translate('postJob')}
              </Button>
            </div>
          )
      }

    </Form>
  );
};

NewJob.propTypes = {
  translate: PropTypes.func.isRequired,
  classes: PropTypes.object.isRequired, // eslint-disable-line
  handleExpandClick: PropTypes.func,
  expanded: PropTypes.arrayOf(PropTypes.string),
  handleSubmit: PropTypes.func.isRequired,
  submitNewJob: PropTypes.func,
  setJobType: PropTypes.func,
  id: PropTypes.string,
  initialValues: PropTypes.object, // eslint-disable-line
  // customers: PropTypes.arrayOf(PropTypes.any),
  countries: PropTypes.arrayOf(PropTypes.any),
  states: PropTypes.arrayOf(PropTypes.any),
  cities: PropTypes.arrayOf(PropTypes.any),
  getStatesByCountry: PropTypes.func,
  getCitiesByState: PropTypes.func,
  flushLocationFieldsData: PropTypes.func,
  change: PropTypes.func.isRequired,
  release_date: PropTypes.string,
};

NewJob.defaultProps = {
  flushLocationFieldsData: () => { },
  handleExpandClick: () => { },
  expanded: [],
  submitNewJob: () => { },
  setJobType: () => { },
  id: '',
  initialValues: {},
  // customers: [],
  countries: [],
  states: [],
  cities: [],
  getStatesByCountry: () => { },
  getCitiesByState: () => { },
  release_date: '',
};

export default reduxForm({
  form: 'NewJobForm',
  enableReinitialize: true,
  keepDirtyOnReinitialize: true,
  validate,
})(withStyles(styles)(withTranslate(NewJob)));
