import _ from 'lodash';
import * as actionTypes from './actionTypes';
import { sortAll } from '../../../utils';

const initialState = {
  jobs: [],
  getJobsLoading: false,
  getJobsError: null,
  jobPosition: [],
  uploadJobLoading: false,
  uploadJobError: null,
  newJob: [],
  createNewJobLoading: false,
  createNewJobError: null,
  editJobLoading: false,
  editJobError: null,
  searchJobLoading: false,
  searchJobError: null,
  draftedJobs: [],
  draftedJobsCurrentPage: 0,
  totalDraftedJobs: 0,
  draftedJobsLoading: false,
  draftedJobsError: null,
  postedJobs: [],
  postedJobsCurrentPage: 0,
  totalPostedJobs: 0,
  postedJobsLoading: false,
  postedJobsError: null,
  qualifiedJobs: [],
  qualifiedJobsCurrentPage: 0,
  totalQualifiedJobs: 0,
  qualifiedJobsLoading: false,
  qualifiedJobsError: null,
  presentedJobs: [],
  presentedJobsCurrentPage: 0,
  totalPresentedJobs: 0,
  presentedJobsLoading: false,
  presentedJobsError: false,
  closedJobs: [],
  closedJobsCurrentPage: 0,
  totalClosedJobs: 0,
  closedJobsLoading: false,
  closedJobsError: null,
  searchedEmployer: '',
  searchedLocation: '',
  searchedJobTitle: '',
  employers: [],
  employersLoading: false,
  employersError: null,
  jobTemplates: [],
  currentJob: {},
  currentJobLoading: false,
  currentJobError: null,
  searchJobTemplatesLoading: false,
  noTemplatesData: false,
  isMoving: false,
  notesLoading: false,
  notesError: null,
  jobApplicationList: {},
  matchedCandidates: {},
  jobApplicationCount: {},
  candidatesLoading: false,
  candidatesError: null,
  closeJobLoading: false,
  closeJobError: null,
  deleteJobLoading: false,
  deleteJobError: null,
  shortlistJobApplicationLoading: false,
  shortlistJobApplicationError: null,
  moveJobApplicationLoading: false,
  moveJobApplicationError: null,
  deleteJobApplicationLoading: false,
  deleteJobApplicationError: null,
  facets: null,
  filter: {
    query: '',
    facets: [],
  },
  facetFetchProfile: [],
  selectedCandidateProfile: {},
  draftJobsSortedBy: 'created_at',
  postedJobsSortedBy: 'created_at',
  qualifiedJobsSortedBy: 'created_at',
  presentedJobsSortedBy: 'created_at',
  closedJobsSortedBy: 'created_at',
  postedJobsForCandidatesLoading: false,
  postedJobsForCandidatesError: null,
  postedJobsForCandidates: [],
  totalPostedJobsForCandidates: 0,
  postedJobsForCandidatesCurrentPage: 0,
  accountInfo: {},
  accountInfoError: null,
  recruiterBookmarking: false,
  candidateProfileLoading: false,
  accountInfoLoading: false,
  filterParam: '',
  clearFilters: true,
  intercomSearch: {},
  intercomSearchLoading: false,
  intercomSearchError: null,
  intercomCreate: {},
  intercomCreateLoading: false,
  intercomCreateError: null,
  shortlistBulkApplicationLoading: false,
  shortlistBulkApplicationError: null,
  moveBulkApplicationLoading: false,
  moveBulkApplicationError: null,
};

function setLoading(state, payload) {
  const obj = state;
  switch (payload) {
    case 'draft':
      obj.draftedJobsCurrentPage = 0;
      obj.draftedJobs = [];
      obj.draftedJobsLoading = true;
      break;
    case 'posted':
      obj.postedJobsCurrentPage = 0;
      obj.postedJobs = [];
      obj.postedJobsLoading = true;
      break;
    case 'qualified':
      obj.qualifiedJobsCurrentPage = 0;
      obj.qualifiedJobs = [];
      obj.qualifiedJobsLoading = true;
      break;
    case 'presented':
      obj.presentedJobsCurrentPage = 0;
      obj.presentedJobs = [];
      obj.presentedJobsLoading = true;
      break;
    case 'closed':
      obj.closedJobsCurrentPage = 0;
      obj.closedJobs = [];
      obj.closedJobsLoading = true;
      break;
    default:
      break;
  }
  return obj;
}

function initializeJobApplicationCounts(jobs = []) {
  return jobs.map(jobPosition => ({
    ...jobPosition,
    applications: [
      { doc_count: 0, key: 'matched', ...jobPosition.applications.find(application => application.key === 'matched') },
      { doc_count: 0, key: 'shortlisted', ...jobPosition.applications.find(application => application.key === 'shortlisted') },
      { doc_count: 0, key: 'qualified', ...jobPosition.applications.find(application => application.key === 'qualified') },
      { doc_count: 0, key: 'presented', ...jobPosition.applications.find(application => application.key === 'presented') },
      { doc_count: 0, key: 'rejected', ...jobPosition.applications.find(application => application.key === 'rejected') },
    ],
  }));
}

export default function (state = initialState, action) {
  switch (action.type) {
    case `${actionTypes.FLUSH_LOCATION_FIELDS_DATA}`: {
      return {
        ...state,
        cities: [],
        states: [],
      };
    }
    case `${actionTypes.GET_CITIES_BY_STATE}_SUCCESS`: {
      return {
        ...state,
        cities: action.payload.locations,
        totalCities: action.payload.total,
        currentPageNo: action.payload.page,
        currentPageSize: action.payload.pageSize,
        loading: false,
        error: null,
      };
    }
    case `${actionTypes.GET_CITIES_BY_STATE}_LOADING`: {
      return {
        ...state,
        loading: true,
        error: null,
      };
    }
    case `${actionTypes.GET_CITIES_BY_STATE}_ERROR`: {
      return {
        ...state,
        cities: [],
        loading: false,
        error: action.payload,
      };
    }
    case `${actionTypes.GET_STATES_BY_COUNTRY}_SUCCESS`: {
      return {
        ...state,
        states: action.payload.locations,
        totalStates: action.payload.total,
        currentPageNo: action.payload.page,
        currentPageSize: action.payload.pageSize,
        loading: false,
        error: null,
      };
    }
    case `${actionTypes.GET_STATES_BY_COUNTRY}_LOADING`: {
      return {
        ...state,
        loading: true,
        error: null,
      };
    }
    case `${actionTypes.GET_STATES_BY_COUNTRY}_ERROR`: {
      return {
        ...state,
        states: [],
        loading: false,
        error: action.payload,
      };
    }
    case `${actionTypes.GET_COUNTRIES}_SUCCESS`: {
      return {
        ...state,
        countries: action.payload.locations,
        totalCountries: action.payload.total,
        currentPageNo: action.payload.page,
        currentPageSize: action.payload.pageSize,
        loading: false,
        error: null,
      };
    }
    case `${actionTypes.GET_COUNTRIES}_LOADING`: {
      return {
        ...state,
        loading: true,
        error: null,
      };
    }
    case `${actionTypes.GET_COUNTRIES}_ERROR`: {
      return {
        ...state,
        countries: [],
        loading: false,
        error: action.payload,
      };
    }
    case `${actionTypes.FETCH_FACET}_SUCCESS`: {
      return {
        ...state,
        facets: action.payload.data.profile_facets,
        meta: action.payload.data.meta,
        filterParam: '',
        isNewSearch: true,
        checkedFilters: {},
        clearFilters: true,
        isRecentSearched: false,
        facetsLoading: false,
      };
    }

    case `${actionTypes.FETCH_PROFILE_FACET_MATCHED}_SUCCESS`: {
      return {
        ...state,
        matchedCandidates: action.payload.data,
        totalCandidates: action.payload.data.total,
        candidatesLoading: false,
        filterParam: action.payload.filterParam,
        isPageSetToZero: true,
      };
    }
    case `${actionTypes.FETCH_PROFILE_FACET_MATCHED}_LOADING`: {
      return {
        ...state,
        candidatesLoading: true,
      };
    }
    case actionTypes.RESET_FILTER_PARAM_MATCHED: {
      return {
        ...state,
        filter: {},
        clearFilters: true,
        checkedFilters: '',
        filterParam: '',
        searchedValue: '',
      };
    }
    case actionTypes.SET_CLEAR_FILTER_MATCHED: {
      return {
        ...state,
        clearFilters: false,
      };
    }

    case `${actionTypes.GET_PROFILE_INFO}_SUCCESS`:
      return {
        ...state,
        selectedCandidateProfile: action.payload.data.profile,
        candidateProfileLoading: false,
      };
    case `${actionTypes.GET_PROFILE_INFO}_LOADING`:
      return {
        ...state,
        candidateProfileLoading: true,
      };
    case actionTypes.FLUSH_SELECTED_CANDIDATE_PROFILE:
      return {
        ...state,
        selectedCandidateProfile: {},
      };
    case actionTypes.FLUSH_ALL_JOBS:
      return {
        ...state,
        draftedJobs: [],
        postedJobs: [],
        qualifiedJobs: [],
        presentedJobs: [],
        closedJobs: [],
      };
    case `${actionTypes.FETCH_PROFILE_FACET_JOB}_SUCCESS`: {
      return {
        ...state,
        matchedCandidates: action.payload.data,
        totalCandidates: action.payload.data.total,
        candidatesLoading: false,
      };
    }
    case `${actionTypes.FETCH_PROFILE_FACET_JOB}_LOADING`: {
      return {
        ...state,
        candidatesLoading: true,
      };
    }

    case actionTypes.GET_JOBS_SUCCESS:
      return {
        ...state,
        jobs: action.payload.data.job_positions,
        getJobsLoading: false,
        getJobsError: null,
      };
    case actionTypes.GET_JOBS_ERROR:
      return {
        ...state,
        jobs: [],
        getJobsLoading: false,
        getJobsError: action.payload.data,
      };
    case actionTypes.GET_JOBS_LOADING:
      return {
        ...state,
        jobs: [],
        getJobsLoading: true,
        getJobsError: null,
      };
    case actionTypes.UPLOAD_JOB_SUCCESS:
      return {
        ...state,
        jobPosition: {
          ...action.payload.data.job_position,
          job_description: {
            ...action.payload.data.job_position.job_description,
            required_skills: _.uniqBy(
              action.payload.data.job_position.job_description.required_skills,
              obj => obj.display_value.toLowerCase(),
            ),
          },
        },
        uploadJobLoading: false,
        uploadJobError: null,
      };
    case actionTypes.UPLOAD_JOB_ERROR:
      return {
        ...state,
        jobPosition: [],
        uploadJobLoading: false,
        uploadJobError: action.payload.data,
      };
    case actionTypes.UPLOAD_JOB_LOADING:
      return {
        ...state,
        jobPosition: [],
        uploadJobLoading: true,
        uploadJobError: null,
      };
    case actionTypes.CREATE_NEWJOB_SUCCESS:
      return {
        ...state,
        newJob: action.payload,
        createNewJobLoading: false,
        createNewJobError: null,
      };
    case actionTypes.CREATE_NEWJOB_ERROR:
      return {
        ...state,
        newJob: [],
        createNewJobLoading: false,
        createNewJobError: action.payload,
      };
    case actionTypes.CREATE_NEWJOB_LOADING:
      return {
        ...state,
        newJob: [],
        createNewJobLoading: true,
        createNewJobError: null,
      };
    case actionTypes.UPDATE_JOB_SUCCESS:
      return {
        ...state,
        editJobLoading: false,
        editJobError: null,
      };
    case actionTypes.UPDATE_JOB_LOADING:
      return {
        ...state,
        editJobLoading: true,
        editJobError: null,
      };
    case actionTypes.UPDATE_JOB_ERROR:
      return {
        ...state,
        editJobLoading: false,
        editJobError: action.payload.data,
      };
    case actionTypes.SEARCH_SKILL_SUCCESS:
      return {
        ...state,
        jobs: action.payload.data,
        searchJobLoading: false,
        searchJobError: null,
      };
    case actionTypes.SEARCH_SKILL_ERROR:
      return {
        ...state,
        jobs: [],
        searchJobLoading: false,
        searchJobError: action.payload.data,
      };
    case actionTypes.SEARCH_SKILL_LOADING:
      return {
        ...state,
        jobs: [],
        searchJobLoading: true,
        searchJobError: null,
      };
    case actionTypes.GET_DRAFTED_JOBS_SUCCESS:
      return {
        ...state,
        draftedJobsLoading: false,
        draftedJobsError: null,
        draftedJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.draftedJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalDraftedJobs: action.payload.data.total,
        draftedJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_DRAFTED_JOBS_LOADING:
      return {
        ...state,
        draftedJobsLoading: true,
        draftedJobsError: null,
      };
    case actionTypes.GET_DRAFTED_JOBS_ERROR:
      return {
        ...state,
        draftedJobsLoading: false,
        draftedJobsError: action.payload.data,
        draftedJobs: [],
      };
    case actionTypes.GET_POSTED_JOBS_SUCCESS:
      return {
        ...state,
        postedJobsLoading: false,
        postedJobsError: null,
        postedJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.postedJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalPostedJobs: action.payload.data.total,
        postedJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_POSTED_JOBS_LOADING:
      return {
        ...state,
        postedJobsLoading: true,
        postedJobsError: null,
      };
    case actionTypes.GET_POSTED_JOBS_ERROR:
      return {
        ...state,
        postedJobsLoading: false,
        postedJobsError: action.payload.data,
        postedJobs: [],
      };
    case actionTypes.GET_QUALIFIED_JOBS_SUCCESS:
      return {
        ...state,
        qualifiedJobsLoading: false,
        qualifiedJobsError: null,
        qualifiedJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.qualifiedJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalQualifiedJobs: action.payload.data.total,
        qualifiedJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_QUALIFIED_JOBS_LOADING:
      return {
        ...state,
        qualifiedJobsLoading: true,
        qualifiedJobsError: null,
      };
    case actionTypes.GET_QUALIFIED_JOBS_ERROR:
      return {
        ...state,
        qualifiedJobsLoading: false,
        qualifiedJobsError: action.payload.data,
        qualifiedJobs: [],
      };
    case actionTypes.GET_PRESENTED_JOBS_SUCCESS:
      return {
        ...state,
        presentedJobsLoading: false,
        presentedJobsError: null,
        presentedJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.presentedJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalPresentedJobs: action.payload.data.total,
        presentedJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_PRESENTED_JOBS_LOADING:
      return {
        ...state,
        presentedJobsLoading: true,
        presentedJobsError: null,
      };
    case actionTypes.GET_PRESENTED_JOBS_ERROR:
      return {
        ...state,
        presentedJobsLoading: false,
        presentedJobsError: action.payload.data,
        presentedJobs: [],
      };
    case actionTypes.GET_CLOSED_JOBS_SUCCESS:
      return {
        ...state,
        closedJobsLoading: false,
        closedJobsError: null,
        closedJobs: action.payload.currentPageNo === 1
          ? initializeJobApplicationCounts(action.payload.data.job_positions)
          : [
            ...state.closedJobs,
            ...initializeJobApplicationCounts(action.payload.data.job_positions),
          ],
        totalClosedJobs: action.payload.data.total,
        closedJobsCurrentPage: action.payload.currentPageNo,
        isMoving: false,
      };
    case actionTypes.GET_CLOSED_JOBS_LOADING:
      return {
        ...state,
        closedJobsLoading: true,
        closedJobsError: null,
      };
    case actionTypes.GET_CLOSED_JOBS_ERROR:
      return {
        ...state,
        closedJobsLoading: false,
        closedJobsError: action.payload.data,
        closedJobs: [],
      };
    case actionTypes.SET_SEARCHED_EMPLOYER: {
      const obj = {
        ...state,
      };
      if (action.payload === '') {
        if (obj.searchedJobTitle === '') {
          obj.draftJobsSortedBy = 'created_at';
          obj.postedJobsSortedBy = 'created_at';
          obj.qualifiedJobsSortedBy = 'created_at';
          obj.presentedJobsSortedBy = 'created_at';
          obj.closedJobsSortedBy = 'created_at';
        } else {
          obj.draftJobsSortedBy = 'none';
          obj.postedJobsSortedBy = 'none';
          obj.qualifiedJobsSortedBy = 'none';
          obj.presentedJobsSortedBy = 'none';
          obj.closedJobsSortedBy = 'none';
        }
      } else {
        obj.draftJobsSortedBy = 'none';
        obj.postedJobsSortedBy = 'none';
        obj.qualifiedJobsSortedBy = 'none';
        obj.presentedJobsSortedBy = 'none';
        obj.closedJobsSortedBy = 'none';
      }
      obj.searchedEmployer = action.payload;
      return obj;
    }
    case actionTypes.SET_SEARCHED_LOCATION: {
      const obj = {
        ...state,
      };
      if (action.payload === '') {
        if (obj.searchedJobTitle === '') {
          obj.draftJobsSortedBy = 'created_at';
          obj.postedJobsSortedBy = 'created_at';
          obj.qualifiedJobsSortedBy = 'created_at';
          obj.presentedJobsSortedBy = 'created_at';
          obj.closedJobsSortedBy = 'created_at';
        } else {
          obj.draftJobsSortedBy = 'none';
          obj.postedJobsSortedBy = 'none';
          obj.qualifiedJobsSortedBy = 'none';
          obj.presentedJobsSortedBy = 'none';
          obj.closedJobsSortedBy = 'none';
        }
      } else {
        obj.draftJobsSortedBy = 'none';
        obj.postedJobsSortedBy = 'none';
        obj.qualifiedJobsSortedBy = 'none';
        obj.presentedJobsSortedBy = 'none';
        obj.closedJobsSortedBy = 'none';
      }
      obj.searchedLocation = action.payload;
      return obj;
    }
    case actionTypes.SET_SEARCHED_JOB_TITLE: {
      const obj = {
        ...state,
      };
      if (action.payload === '') {
        if (obj.searchedEmployer === '') {
          obj.draftJobsSortedBy = 'created_at';
          obj.postedJobsSortedBy = 'created_at';
          obj.qualifiedJobsSortedBy = 'created_at';
          obj.presentedJobsSortedBy = 'created_at';
          obj.closedJobsSortedBy = 'created_at';
        } else {
          obj.draftJobsSortedBy = 'none';
          obj.postedJobsSortedBy = 'none';
          obj.qualifiedJobsSortedBy = 'none';
          obj.presentedJobsSortedBy = 'none';
          obj.closedJobsSortedBy = 'none';
        }
      } else {
        obj.draftJobsSortedBy = 'none';
        obj.postedJobsSortedBy = 'none';
        obj.qualifiedJobsSortedBy = 'none';
        obj.presentedJobsSortedBy = 'none';
        obj.closedJobsSortedBy = 'none';
      }
      obj.searchedJobTitle = action.payload;
      return obj;
    }
    case actionTypes.GET_EMPLOYERS_COUNT_SUCCESS:
      return {
        ...state,
        employers: action.payload.data.count,
        employersLoading: false,
        employersError: null,
      };
    case actionTypes.GET_EMPLOYERS_COUNT_LOADING:
      return {
        ...state,
        employers: [],
        employersLoading: true,
        employersError: null,
      };
    case actionTypes.GET_EMPLOYERS_COUNT_ERROR:
      return {
        ...state,
        employers: [],
        employersLoading: false,
        employersError: action.payload.data,
      };
    case actionTypes.GET_LOCATIONS_COUNT_SUCCESS:
      return {
        ...state,
        locations: action.payload.data.count,
        locationsLoading: false,
        locationsError: null,
      };
    case actionTypes.GET_LOCATIONS_COUNT_LOADING:
      return {
        ...state,
        locations: [],
        locationsLoading: true,
        locationsError: null,
      };
    case actionTypes.GET_LOCATIONS_COUNT_ERROR:
      return {
        ...state,
        locations: [],
        locationsLoading: false,
        locationsError: action.payload.data,
      };

    case actionTypes.SEARCH_TEMPLATE_ERROR:
      return {
        ...state,
        jobTemplates: [],
        searchJobTemplatesLoading: false,
        searchJobTemplatesError: action.payload.data,
      };
    case actionTypes.SEARCH_TEMPLATE_SUCCESS:
      return {
        ...state,
        jobTemplates: action.payload.data.job_templates,
        searchJobTemplatesLoading: true,
        searchJobTemplatesError: null,
        noTemplatesData: true,
      };
    case actionTypes.SEARCH_TEMPLATE_LOADING:
      return {
        ...state,
        jobTemplates: [],
        searchJobTemplatesLoading: true,
        searchJobTemplatesError: null,
        noTemplatesData: false,
      };
    case actionTypes.MOVE_JOB_LOCAL: {
      const obj = { ...state, isMoving: true };
      let movedJob = {};
      switch (action.payload.source) {
        case 'draft':
          movedJob = obj.draftedJobs.find(job => job.id === action.payload.jobId);
          obj.draftedJobs = [...obj.draftedJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        case 'posted':
          movedJob = obj.postedJobs.find(job => job.id === action.payload.jobId);
          obj.postedJobs = [...obj.postedJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        case 'qualified':
          movedJob = obj.qualifiedJobs.find(job => job.id === action.payload.jobId);
          obj.qualifiedJobs = [...obj.qualifiedJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        case 'presented':
          movedJob = obj.presentedJobs.find(job => job.id === action.payload.jobId);
          obj.presentedJobs = [...obj.presentedJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        case 'closed':
          movedJob = obj.closedJobs.find(job => job.id === action.payload.jobId);
          obj.closedJobs = [...obj.closedJobs.filter(job => job.id !== action.payload.jobId)];
          break;
        default:
          break;
      }
      switch (action.payload.destination) {
        case 'draft':
          obj.draftedJobs = sortAll([movedJob, ...obj.draftedJobs], 'created_at', 'asc', 'date');
          break;
        case 'posted':
          obj.postedJobs = sortAll([movedJob, ...obj.postedJobs], 'created_at', 'asc', 'date');
          break;
        case 'qualified':
          obj.qualifiedJobs = sortAll([movedJob, ...obj.qualifiedJobs], 'created_at', 'asc', 'date');
          break;
        case 'presented':
          obj.presentedJobs = sortAll([movedJob, ...obj.presentedJobs], 'created_at', 'asc', 'date');
          break;
        case 'closed':
          obj.closedJobs = sortAll([movedJob, ...obj.closedJobs], 'created_at', 'asc', 'date');
          break;
        default:
          break;
      }
      return obj;
    }
    case actionTypes.MOVE_JOB_SUCCESS: {
      let obj = { ...state };
      obj = setLoading(obj, action.payload.source);
      obj = setLoading(obj, action.payload.destination);
      return obj;
    }
    case actionTypes.GET_JOB_BY_ID_SUCCESS:
      return {
        ...state,
        currentJob: {
          ...action.payload.data.job_position,
          job_description: {
            ...action.payload.data.job_position.job_description,
            required_skills: _.uniqBy(
              action.payload.data.job_position.job_description.required_skills,
              obj => obj.display_value.toLowerCase(),
            ),
          },
          notes: sortAll([...action.payload.data.job_position.notes || []], 'created_at', 'asc', 'date'),
        },
        currentJobLoading: false,
        currentJobError: null,
      };
    case actionTypes.GET_JOB_BY_ID_LOADING:
      return {
        ...state,
        currentJob: {},
        currentJobLoading: true,
        currentJobError: null,
      };
    case actionTypes.GET_JOB_BY_ID_ERROR:
      return {
        ...state,
        currentJob: {},
        currentJobLoading: false,
        currentJobError: action.payload.data,
      };
    case actionTypes.ADD_NOTE_SUCCESS:
      return {
        ...state,
        currentJob: {
          ...state.currentJob,
          notes: [action.payload.data, ...state.currentJob.notes],
        },
        notesLoading: false,
        notesError: null,
      };
    case actionTypes.ADD_NOTE_LOADING:
      return {
        ...state,
        notesLoading: true,
        notesError: null,
      };
    case actionTypes.ADD_NOTE_ERROR:
      return {
        ...state,
        notesLoading: false,
        notesError: action.payload.data,
      };
    case actionTypes.DELETE_NOTE_SUCCESS:
      return {
        ...state,
        currentJob: {
          ...state.currentJob,
          notes: [...state.currentJob.notes.filter(note => note.id !== action.payload.id)],
        },
        notesLoading: false,
        notesError: null,
      };
    case actionTypes.DELETE_NOTE_LOADING:
      return {
        ...state,
        notesLoading: true,
        notesError: null,
      };
    case actionTypes.DELETE_NOTE_ERROR:
      return {
        ...state,
        notesLoading: false,
        notesError: action.payload.data,
      };
    case actionTypes.GET_JOB_APPLICATION_LIST_SUCCESS:
      return {
        ...state,
        jobApplicationList: action.payload.data,
        candidatesLoading: false,
        candidatesError: null,
      };
    case actionTypes.GET_JOB_APPLICATION_LIST_LOADING:
      return {
        ...state,
        // jobApplicationList: {},
        candidatesLoading: true,
        candidatesError: null,
      };
    case actionTypes.GET_JOB_APPLICATION_LIST_ERROR:
      return {
        ...state,
        jobApplicationList: {},
        candidatesLoading: false,
        candidatesError: action.payload.data,
      };
    case actionTypes.GET_JOB_APPLICATION_LIST_COUNTS_SUCCESS: {
      let jobs = [];
      let jobType = '';
      switch (state.currentJob.status) {
        case 'drafted':
          jobs = state.draftedJobs;
          jobType = 'draftedJobs';
          break;
        case 'posted':
          jobs = state.postedJobs;
          jobType = 'postedJobs';
          break;
        case 'qualified':
          jobs = state.qualifiedJobs;
          jobType = 'qualifiedJobs';
          break;
        case 'presented':
          jobs = state.presentedJobs;
          jobType = 'presentedJobs';
          break;
        case 'closed':
          jobs = state.closedJobs;
          jobType = 'closedJobs';
          break;
        default:
          break;
      }

      const obj = {};
      obj[jobType] = [
        ...jobs.map((job) => {
          if (job.id === state.currentJob.id) {
            job.applications.map((application) => {
              const app = application;
              switch (app.key) {
                case 'matched':
                  app.doc_count = action.payload.data.Shortlist.Matched;
                  break;
                case 'shortlisted':
                  app.doc_count = action.payload.data.Qualify.Shortlisted;
                  break;
                case 'qualified':
                  app.doc_count = action.payload.data.Present.Qualified;
                  break;
                case 'presented':
                  app.doc_count = action.payload.data.Present.Presented;
                  break;
                case 'rejected':
                  app.doc_count = action.payload.data.Qualify.Rejected;
                  break;
                default:
                  break;
              }
              return application;
            });
          }
          return job;
        }),
      ];
      return {
        ...state,
        ...obj,
        candidatesLoading: false,
        candidatesError: null,
        jobApplicationCount: action.payload.data,
      };
    }
    case actionTypes.GET_JOB_APPLICATION_LIST_COUNTS_LOADING:
      return {
        ...state,
        candidatesLoading: true,
        candidatesError: null,
        jobApplicationCount: {},
      };
    case actionTypes.GET_JOB_APPLICATION_LIST_COUNTS_ERROR:
      return {
        ...state,
        candidatesLoading: false,
        candidatesError: action.payload.err,
        jobApplicationCount: {},
      };
    case actionTypes.FLUSH_THE_COUNTS:
      return {
        ...state,
        jobApplicationCount: {},
      };
    case actionTypes.FLUSH_CURRENT_JOB:
      return {
        ...state,
        currentJob: {},
      };
    case actionTypes.GET_MATCHED_CANDIDATES_SUCCESS:
      return {
        ...state,
        matchedCandidates: action.payload.data,
        totalCandidates: action.payload.data.total,
        candidatesLoading: false,
        candidatesError: null,
      };
    case actionTypes.GET_MATCHED_CANDIDATES_LOADING:
      return {
        ...state,
        // matchedCandidates: {},
        candidatesLoading: true,
        candidatesError: null,
      };
    case actionTypes.GET_MATCHED_CANDIDATES_ERROR:
      return {
        ...state,
        matchedCandidates: {},
        candidatesLoading: false,
        candidatesError: action.payload.data,
      };
    case actionTypes.GET_MATCHED_CANDIDATES_COUNTS_SUCCESS:
      return {
        ...state,
        matchedCandidatesCounts: (action.payload.data && action.payload.data.total > 0)
          ? action.payload.data.total.toString() : '0',
        candidatesLoading: false,
        candidatesError: null,
      };
    case actionTypes.GET_MATCHED_CANDIDATES_COUNTS_LOADING:
      return {
        ...state,
        matchedCandidatesCounts: '-',
        candidatesLoading: true,
        candidatesError: null,
      };
    case actionTypes.GET_MATCHED_CANDIDATES_COUNTS_ERROR:
      return {
        ...state,
        matchedCandidatesCounts: '0',
        candidatesLoading: false,
        candidatesError: action.payload.data,
      };
    case actionTypes.FLUSH_CANDIDATES:
      return {
        ...state,
        matchedCandidates: {},
        jobApplicationList: {},
        candidatesLoading: false,
        candidatesError: null,
      };
    case actionTypes.CLOSE_JOB_LOADING:
      return {
        ...state,
        closeJobLoading: true,
        closeJobError: null,
      };
    case actionTypes.CLOSE_JOB_SUCCESS:
      return {
        ...state,
        closeJobLoading: false,
        closeJobError: null,
      };
    case actionTypes.CLOSE_JOB_ERROR:
      return {
        ...state,
        closeJobLoading: false,
        closeJobError: action.payload,
      };
    case actionTypes.DELETE_JOB_LOADING:
      return {
        ...state,
        deleteJobLoading: true,
        deleteJobError: null,
      };
    case actionTypes.DELETE_JOB_SUCCESS:
      return {
        ...state,
        deleteJobLoading: false,
        deleteJobError: null,
      };
    case actionTypes.DELETE_JOB_ERROR:
      return {
        ...state,
        deleteJobLoading: false,
        deleteJobError: action.payload,
      };
    case actionTypes.SHORTLIST_JOB_APPLICATION_SUCCESS:
      return {
        ...state,
        shortlistJobApplicationLoading: false,
        shortlistJobApplicationError: null,
      };
    case actionTypes.SHORTLIST_JOB_APPLICATION_LOADING:
      return {
        ...state,
        shortlistJobApplicationLoading: true,
        shortlistJobApplicationError: null,
      };
    case actionTypes.SHORTLIST_JOB_APPLICATION_ERROR:
      return {
        ...state,
        shortlistJobApplicationLoading: false,
        shortlistJobApplicationError: action.payload.data,
      };
    case actionTypes.SHORTLIST_BULK_APPLICATION_SUCCESS:
      return {
        ...state,
        shortlistBulkApplicationLoading: false,
        shortlistBulkApplicationError: null,
      };
    case actionTypes.SHORTLIST_BULK_APPLICATION_LOADING:
      return {
        ...state,
        shortlistBulkApplicationLoading: true,
        shortlistBulkApplicationError: null,
      };
    case actionTypes.SHORTLIST_BULK_APPLICATION_ERROR:
      return {
        ...state,
        shortlistBulkApplicationLoading: false,
        shortlistBulkApplicationError: action.payload.data,
      };
    case actionTypes.MOVE_BULK_APPLICATION_SUCCESS: {
      return {
        ...state,
        // jobs,
        moveBulkApplicationLoading: false,
        moveBulkApplicationError: null,
      };
    }
    case actionTypes.MOVE_BULK_APPLICATION_LOADING:
      return {
        ...state,
        moveBulkApplicationLoading: true,
        moveBulkApplicationError: null,
      };
    case actionTypes.MOVE_BULK_APPLICATION_ERROR:
      return {
        ...state,
        moveBulkApplicationLoading: false,
        moveBulkApplicationError: action.payload.data,
      };
    case actionTypes.MOVE_JOB_APPLICATION_SUCCESS: {
      return {
        ...state,
        // jobs,
        moveJobApplicationLoading: false,
        moveJobApplicationError: null,
      };
    }
    case actionTypes.MOVE_JOB_APPLICATION_LOADING:
      return {
        ...state,
        moveJobApplicationLoading: true,
        moveJobApplicationError: null,
      };
    case actionTypes.MOVE_JOB_APPLICATION_ERROR:
      return {
        ...state,
        moveJobApplicationLoading: false,
        moveJobApplicationError: action.payload.data,
      };
    case actionTypes.DELETE_JOB_APPLICATION_SUCCESS:
      return {
        ...state,
        deleteJobApplicationLoading: false,
        deleteJobApplicationError: null,
      };
    case actionTypes.DELETE_JOB_APPLICATION_LOADING:
      return {
        ...state,
        deleteJobApplicationLoading: true,
        deleteJobApplicationError: null,
      };
    case actionTypes.DELETE_JOB_APPLICATION_ERROR:
      return {
        ...state,
        deleteJobApplicationLoading: false,
        deleteJobApplicationError: action.payload.data,
      };
    case actionTypes.SET_SORTED_STATE:
      return {
        ...state,
        [`${action.payload.key}JobsSortedBy`]: action.payload.value,
      };
    case actionTypes.GET_POSTED_JOBS_FOR_CANDIDATES_SUCCESS:
      return {
        ...state,
        postedJobsForCandidatesLoading: false,
        postedJobsForCandidatesError: null,
        postedJobsForCandidates: action.payload.currentPageNo === 1
          ? action.payload.data.job_positions
          : [...state.postedJobsForCandidates, ...action.payload.data.job_positions],
        totalPostedJobsForCandidates: action.payload.data.total,
        postedJobsForCandidatesCurrentPage: action.payload.currentPageNo,
      };
    case actionTypes.GET_POSTED_JOBS_FOR_CANDIDATES_LOADING:
      return {
        ...state,
        postedJobsForCandidatesLoading: true,
        postedJobsForCandidatesError: null,
      };
    case actionTypes.GET_POSTED_JOBS_FOR_CANDIDATES_ERROR:
      return {
        ...state,
        postedJobsForCandidatesLoading: false,
        postedJobsForCandidatesError: action.payload.data,
        postedJobsForCandidates: [],
      };
    case actionTypes.FLUSH_POSTED_JOBS_FOR_CANDIDATES:
      return {
        ...state,
        postedJobsForCandidates: [],
      };
    case actionTypes.GET_ACCOUNT_ME_SUCCESS:
      return {
        ...state,
        accountInfo: action.payload.data,
        accountInfoLoading: false,
        accountInfoError: null,
      };
    case actionTypes.GET_ACCOUNT_ME_LOADING:
      return {
        ...state,
        accountInfoLoading: true,
        accountInfoError: null,
      };
    case actionTypes.GET_ACCOUNT_ME_ERROR:
      return {
        ...state,
        accountInfo: {},
        accountInfoError: action.payload,
        accountInfoLoading: false,
      };
    case actionTypes.RECRUITER_JOB_BOOKMARK_TALENT_ERROR: {
      return {
        ...state,
        recruiterBookmarking: false,
      };
    }
    case actionTypes.RECRUITER_JOB_BOOKMARK_TALENT_LOADING: {
      return {
        ...state,
        recruiterBookmarking: true,
      };
    }
    case actionTypes.RECRUITER_JOB_BOOKMARK_TALENT_SUCCESS: {
      return {
        ...state,
        recruiterBookmarking: false,
        matchedCandidates: {
          page: state.matchedCandidates.page,
          profiles: state.matchedCandidates.profiles ?
            [...state.matchedCandidates.profiles.map((profile) => {
              if (profile.id === action.payload.candidateId) {
                const newProfile = profile;
                newProfile.is_bookmarked = true;
                return newProfile;
              }
              return profile;
            })] : null,
          total: state.matchedCandidates.total,
        },
        jobApplicationList: {
          applications: state.jobApplicationList.applications ?
            [...state.jobApplicationList.applications.map((application) => {
              let { profile } = application;
              if (profile.id === action.payload.candidateId) {
                profile = Object.assign({}, profile, {
                  is_bookmarked: true,
                });
                return Object.assign({}, application, {
                  profile,
                });
              }
              return application;
            })] : [],
          page: state.jobApplicationList.page,
          total: state.jobApplicationList.total,
        },
      };
    }
    case actionTypes.REMOVE_RECRUITER_JOB_BOOKMARK_TALENT_ERROR: {
      return {
        ...state,
        recruiterBookmarking: false,
      };
    }
    case actionTypes.REMOVE_RECRUITER_JOB_BOOKMARK_TALENT_LOADING: {
      return {
        ...state,
        recruiterBookmarking: true,
      };
    }
    case actionTypes.REMOVE_RECRUITER_JOB_BOOKMARK_TALENT_SUCCESS: {
      return {
        ...state,
        recruiterBookmarking: false,
        matchedCandidates: {
          page: state.matchedCandidates.page,
          profiles: state.matchedCandidates.profiles ?
            [...state.matchedCandidates.profiles.map((profile) => {
              if (profile.id === action.payload.candidateId) {
                const newProfile = profile;
                newProfile.is_bookmarked = false;
                return newProfile;
              }
              return profile;
            })] : null,
          total: state.matchedCandidates.total,
        },
        jobApplicationList: {
          applications: state.jobApplicationList.applications ?
            [...state.jobApplicationList.applications.map((application) => {
              let { profile } = application;
              if (profile.id === action.payload.candidateId) {
                profile = Object.assign({}, profile, {
                  is_bookmarked: false,
                });
                return Object.assign({}, application, {
                  profile,
                });
              }
              return application;
            })] : [],
          page: state.jobApplicationList.page,
          total: state.jobApplicationList.total,
        },
      };
    }
    case actionTypes.INTERCOM_SEARCH_SUCCESS: {
      return {
        ...state,
        intercomSearch: action.payload.data,
        intercomSearchLoading: false,
        intercomSearchError: null,
      };
    }
    case actionTypes.INTERCOM_SEARCH_LOADING: {
      return {
        ...state,
        intercomSearchLoading: true,
      };
    }
    case actionTypes.INTERCOM_SEARCH_ERROR: {
      return {
        ...state,
        intercomSearch: {},
        intercomSearchLoading: false,
        intercomSearchError: action.payload,
      };
    }
    case actionTypes.INTERCOM_CREATE_SUCCESS: {
      return {
        ...state,
        intercomCreate: action.payload.data,
        intercomCreateLoading: false,
        intercomCreateError: null,
      };
    }
    case actionTypes.INTERCOM_CREATE_LOADING: {
      return {
        ...state,
        intercomCreateLoading: true,
      };
    }
    case actionTypes.INTERCOM_CREATE_ERROR: {
      return {
        ...state,
        intercomCreate: {},
        intercomCreateLoading: false,
        intercomCreateError: action.payload,
      };
    }
    default:
      return state;
  }
}
