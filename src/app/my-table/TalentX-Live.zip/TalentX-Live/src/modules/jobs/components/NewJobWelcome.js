import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { Link, withRouter } from 'react-router-dom';
import PropTypes from 'prop-types';
import Dropzone from 'react-dropzone';
import { Field, reduxForm } from 'redux-form';
import Paper from 'material-ui/Paper';
import { TextField } from 'redux-form-material-ui';
import Dialog from 'material-ui/Dialog';
import { Tabs, Tab } from 'material-ui/Tabs';
import Divider from 'material-ui/Divider';
import IconButton from 'material-ui/IconButton';
import Button from 'material-ui/Button';
import CloseIcon from 'material-ui-icons/Close';
import AddIcon from 'material-ui-icons/Add';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { getJobPositions, uploadJob } from '../redux/actions';


const styles = {
  appBar: {
    position: 'relative',
  },
  flex: {
    flex: 1,
  },
  btn: {
    background: '#FFF',
    border: '1px solid #CCC',
    marginBottom: '1rem',
  },
};

const errors = {};

const required = value => (value == null ? 'Required' : undefined);
const minValue = min => value => (value && value < min ? `Must be at least ${min}` : undefined);
const validate = (values) => {
  errors.jobInput = required(values.jobInput);
  if (values.jobInput) {
    errors.jobInput = minValue(values.jobInput, 100);
  }
  return errors;
};

class NewJobWelcome extends React.Component {
  constructor(props) {
    super(props);
    this.openPostJob = this.openPostJob.bind(this);
    this.onDrop = this.onDrop.bind(this);
    this.textInputJob = this.textInputJob.bind(this);
    this.closePostJob = this.closePostJob.bind(this);
    this.uploadJob = this.uploadJob.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.state = {
      open: false,
      files: [],
      value: 'a',
    };
  }

  onDrop(files) {
    this.setState({
      files,
    });
  }
  handleChange(value) {
    this.setState({ value });
  }

  openPostJob() {
    this.props.initialize({ jobInput: null });
    this.setState({
      open: true,
      files: [],
    });
  }

  textInputJob() {
    const formData = new FormData();
    formData.append('txt', this.props.jobInput);
    this.props.uploadJob(formData).then(() =>
      this.closePostJob()).then(() =>
      this.props.history.push({
        pathname: '/recruiter/jobs/new',
        state: { existingJobUpload: true },
      }));
  }

  uploadJob() {
    const formData = new FormData();
    formData.append('file', this.state.files[0]);
    this.props.uploadJob(formData).then(() =>
      this.closePostJob()).then(() => this.props.history.push({
      pathname: '/recruiter/jobs/new',
      state: { existingJobUpload: true },
    }));
  }

  closePostJob() {
    this.setState({
      open: false,
    });
  }

  render() {
    const actions = [
      <Button
        variant="raised"
        label="Cancel"
        primary
        onClick={this.openPostJob}
      />,
      <Button
        variant="raised"
        label="Submit"
        primary
        keyboardFocused
        onClick={this.closePostJob}
      />,
    ];

    return (
      <div>
        <Button variant="flat" onClick={this.openPostJob}>
          <AddIcon style={{ color: '#FFFFFF', width: '1rem', height: '1rem' }} >
            <h3 style={{ color: '#FFFFFF' }}>New</h3>
          </AddIcon>
        </Button>

        <Dialog
          actions={actions}
          modal={false}
          open={this.state.open}
          onRequestClose={this.closePostJob}
          autoFocus
        >
          <header style={{ display: 'flex', justifyContent: 'space-between' }}>
            <h1>{this.props.translate('createNewJob')}</h1>
            <IconButton onClick={this.handleClose}>
              <CloseIcon />
            </IconButton>
          </header>
          <div className="new-job-welcome">
            <main>
              <header className="templates-header">
                <h2>Templates</h2>
                <div className="search">
                  <TextField name="searchTemplate" type="text" label="Search ..." />
                </div>
              </header>
              <div className="templates">
                {
                 [1, 2, 3, 4, 5, 6, 7].map(i =>
                  (
                    <Paper key={i} elevation={1} style={{ width: '100%', height: '5rem', marginBottom: '0.5rem' }}>
                      <h2 style={{ color: '#333' }}>Template {i}</h2>
                    </Paper>
                   ))
                }
              </div>
            </main>
            <aside>
              <div className="upload">
                <h2>Upload</h2>
                <Divider />
                <Tabs
                  value={this.state.value}
                  onChange={this.handleChange}
                >
                  <Tab label="Upload File" value="a">
                    <Dropzone multiple={false} onDrop={this.onDrop}>
                      <p>Try dropping some files here, or click to select files to upload.</p>
                    </Dropzone>

                    <div>Dropped files</div>
                    <span>
                      {
                       this.state.files.map(f => <li key={f.name}>{f.name} - {f.size} bytes</li>)
                      }
                    </span>

                    <Button
                      variant="raised"
                      style={styles.btn}
                      color="primary"
                      disabled={!(this.state.files.length > 0)}
                      onClick={this.uploadJob}
                    >
                      Upload Job
                    </Button>
                  </Tab>
                  <Tab label="Text Input" value="b">
                    <Field
                      name="jobInput"
                      hintText="Job Input"
                      floatingLabelText="Job Input"
                      validate={[required]}
                      component={TextField}
                      id="jobInput"
                      multiline="true"
                      rows={5}
                      label="Job"
                      margin="normal"
                    />
                    <div>
                      <Button
                        variant="raised"
                        color="primary"
                        disabled={!this.props.valid}
                        onClick={this.textInputJob}
                      >Upload
                      </Button>
                    </div>
                  </Tab>
                </Tabs>
              </div>
            </aside>
            <div className="blank">
              <Link onClick={this.closePostJob} className="btn" to={{ pathname: '/recruiter/jobs/new', state: { existingJobUpload: false } }} style={styles.btn}>Start Fresh ...</Link>
            </div>
          </div>
        </Dialog>
      </div>
    );
  }
}

NewJobWelcome.propTypes = {
  translate: PropTypes.func.isRequired,
  initialize: PropTypes.func,
  jobInput: PropTypes.objectOf(PropTypes.string),
  uploadJob: PropTypes.func,
  history: PropTypes.object, // eslint-disable-line react/forbid-prop-types
  valid: PropTypes.bool,
};


NewJobWelcome.defaultProps = {
  initialize: {},
  jobInput: {},
  uploadJob: {},
  history: {},
  valid: '',
};


function mapStateToProps(state) {
  return {
    state,
  };
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({ getJobPositions, uploadJob }, dispatch);
}

let PostJobForm = reduxForm({
  form: 'PostJob', // a unique identifier for this form
  validate,
})(NewJobWelcome);

PostJobForm = withRouter(PostJobForm);

export default connect(mapStateToProps, mapDispatchToProps)(withTranslate(PostJobForm));
