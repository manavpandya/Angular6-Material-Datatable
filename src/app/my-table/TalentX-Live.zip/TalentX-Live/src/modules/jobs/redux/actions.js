import api from '../../../shared/api';
import * as ActionTypes from './actionTypes';

const FOR_PAGE = {
  per_page: 100,
  page: 1,
};

export function flushLocationFieldsData() {
  return {
    type: ActionTypes.FLUSH_LOCATION_FIELDS_DATA,
    payload: null,
  };
}
export function getCountries(pageNo = 1, pageSize = 300) {
  return {
    type: ActionTypes.GET_COUNTRIES,
    // payload: api.get(`customers?page=${pageNo}&per_page=${pageSize}`)
    // .then(res => ({ ...res.data, pageSize })),
    payload: api.get(`locations?kind=COUNTRY&page=${pageNo}&per_page=${pageSize}`).then(res => ({ ...res.data, pageSize })),
  };
}
export function getStatesByCountry(countryId, pageNo = 1, pageSize = 300) {
  return {
    type: ActionTypes.GET_STATES_BY_COUNTRY,
    payload: api.get(`locations?kind=STATE&parent_id=${countryId}&page=${pageNo}&per_page=${pageSize}`).then(res => ({ ...res.data, pageSize })),
  };
}
export function getCitiesByState(stateId, pageNo = 1, pageSize = 300) {
  return {
    type: ActionTypes.GET_CITIES_BY_STATE,
    payload: api.get(`locations?kind=CITY&parent_id=${stateId}&page=${pageNo}&per_page=${pageSize}`).then(res => ({ ...res.data, pageSize })),
  };
}

export function unsetClearFilterMatched() {
  return {
    type: ActionTypes.SET_CLEAR_FILTER_MATCHED,
  };
}


export function resetFilterMatched(id) {
  return {
    type: ActionTypes.RESET_FILTER,
    payload: id,
  };
}

export function resetFilterParamsMatched() {
  return {
    type: ActionTypes.RESET_FILTER_PARAM_MATCHED,
    payload: '',
  };
}

export function fetchLocalFilterSearchMatched(searchValue, filterType, mainSearchedValue) {
  return {
    type: ActionTypes.FETCH_LOCAL_FILTER,
    payload: searchValue && api.get(`/profile/search_facets?key=${mainSearchedValue}&search_type=query_filter&autocomplete=${filterType}=${encodeURIComponent(searchValue)}`),
  };
}

export function setCheckedFiltersMatched(key, value) {
  return {
    type: ActionTypes.CHECKED_FILTERS,
    payload: {
      key,
      value,
    },
  };
}

export function fetchFacetMatched(searchedValue, jobId) {
  return {
    type: ActionTypes.FETCH_FACET,
    // payload: api.get(`/profile/facets?key=${searchedValue || ''}&search_type=query_filter`),
    payload: api.get(`/job_position/${jobId}/match_facets`),
  };
}

export function profileSearchMatched(query, boardSearch, jobId) {
  FOR_PAGE.page = 1;
  let finalQuery = '';

  if (query) {
    Object.values(query).map((key) => { // loop over query for filters
      const values = [];
      if (key.items) { // check if there are selected options
        finalQuery = `${finalQuery}&fields[]=${key.filter}`;
        Object.keys(key.items).forEach((value) => {
          const val = values.length > 0 ? `||${encodeURIComponent(value)}` : `=${encodeURIComponent(value)}`;
          finalQuery = `${finalQuery}${val}`;
          values.push(values.length > 0 ? `||${encodeURIComponent(value)}` : `=${encodeURIComponent(value)}`);
        });
      }
      return true;
    });
  }
  return (dispatch) => {
    const action1 = {
      type: ActionTypes.FETCH_PROFILE_FACET_MATCHED,
      payload: api.get(`job_position/${jobId}/matches?${finalQuery}&page=1&per_page=${FOR_PAGE.per_page}`)
        .then(res => ({
          data: res.data,
          filterParam: finalQuery,
          searchedValue: boardSearch,
        })),
    };
    dispatch(action1);
  };
}

export function getProfileInfo(jobId, profileId) {
  return {
    type: ActionTypes.GET_PROFILE_INFO,
    payload: api.get(jobId ? `job_position/${jobId}/profile/${profileId}` : `profile/${profileId}`),
  };
}

export function flushSelectedCandidateProfile() {
  return {
    type: ActionTypes.FLUSH_SELECTED_CANDIDATE_PROFILE,
  };
}

export function flushAllJobs() {
  return {
    type: ActionTypes.FLUSH_ALL_JOBS,
    payload: [],
  };
}

export function flushCurrentJob() {
  return {
    type: ActionTypes.FLUSH_CURRENT_JOB,
  };
}

export function flushTheCounts() {
  return {
    type: ActionTypes.FLUSH_THE_COUNTS,
  };
}

export function getJobPositions() {
  return {
    type: ActionTypes.GET_JOBS,
    payload: api.get('job_positions'),
  };
}

function createJobFilterRequest(status, type, employer = '', key = '', pageNo = 1, perPage = 10, sortBy = 'none', location) {
  let employerParam = employer !== '' ? `&fields[]=${employer !== '' ? `job_description.employer.raw=${employer}` : ''}` : '';
  if (location) {
    employerParam += `&fields[]=location.country.raw=${location}`;
  }
  const searchParam = key !== '' ? `&key=${key}` : '';
  const searchType = key !== '' ? 'query_filter' : 'filter';
  const sortByParam = sortBy && sortBy !== 'none' ? `&sort_by=${sortBy}` : '';

  return {
    type,
    payload: api.get(`job_position/search?search_type=${searchType}${searchParam}${employerParam}&fields[]=status=${status}&page=${pageNo}&per_page=${perPage}${sortByParam}`)
      .then(res => ({
        data: res.data,
        currentPageNo: pageNo,
        recordsPerPage: perPage,
      })),
  };
}

export function getDraftedJobs(pageNo = 1, sortBy = 'none', employer = '', key = '', perPage = 10, location = '') {
  return createJobFilterRequest('draft', ActionTypes.GET_DRAFTED_JOBS, employer, key, pageNo, perPage, sortBy, location);
}

export function getPostedJobs(pageNo = 1, sortBy = 'none', employer = '', key = '', perPage = 10, location = '') {
  return createJobFilterRequest('posted', ActionTypes.GET_POSTED_JOBS, employer, key, pageNo, perPage, sortBy, location);
}

export function getQualifiedJobs(pageNo = 1, sortBy = 'none', employer = '', key = '', perPage = 10, location = '') {
  return createJobFilterRequest('qualified', ActionTypes.GET_QUALIFIED_JOBS, employer, key, pageNo, perPage, sortBy, location);
}

export function getPresentedJobs(pageNo = 1, sortBy = 'none', employer = '', key = '', perPage = 10, location = '') {
  return createJobFilterRequest('presented', ActionTypes.GET_PRESENTED_JOBS, employer, key, pageNo, perPage, sortBy, location);
}

export function getClosedJobs(pageNo = 1, sortBy = 'none', employer = '', key = '', perPage = 10, location = '') {
  return createJobFilterRequest('closed', ActionTypes.GET_CLOSED_JOBS, employer, key, pageNo, perPage, sortBy, location);
}

export function getPostedJobsForCandidates(pageNo = 1, sortBy = 'none', employer = '', key = '', perPage = 10) {
  return createJobFilterRequest('posted', ActionTypes.GET_POSTED_JOBS_FOR_CANDIDATES, employer, key, pageNo, perPage, sortBy);
}

export function flushPostedJobsForCandidates() {
  return {
    type: ActionTypes.FLUSH_POSTED_JOBS_FOR_CANDIDATES,
    payload: null,
  };
}

export function moveJobLocal(jobId, source, destination) {
  return {
    type: ActionTypes.MOVE_JOB_LOCAL,
    payload: {
      jobId,
      source,
      destination,
    },
  };
}

export function moveJob(jobId, source, destination) {
  return {
    type: ActionTypes.MOVE_JOB,
    payload: api.put(`job_position/status/${jobId}`, { status: destination }).then(() => ({
      source,
      destination,
    })),
  };
}

export function getEmployersCount() {
  return {
    type: ActionTypes.GET_EMPLOYERS_COUNT,
    payload: api.get('job_position/count?get_count_for=job_description.employer.raw'),
  };
}

export function getLocationsCount() {
  return {
    type: ActionTypes.GET_LOCATIONS_COUNT,
    payload: api.get('job_position/count?get_count_for=location.country.raw'),
  };
}

export function getJobById(jobId) {
  return {
    type: ActionTypes.GET_JOB_BY_ID,
    payload: api.get(`/job_position/${jobId}`),
  };
}

export function uploadJob(uploadJobData) {
  return {
    type: ActionTypes.UPLOAD_JOB,
    payload: api.post('job_position/upload', uploadJobData),
  };
}

export function createNewJob(data) {
  return {
    type: ActionTypes.CREATE_NEWJOB,
    payload: api.post('job_position/create', data),
  };
}

export function updateJob(id, data) {
  return {
    type: ActionTypes.UPDATE_JOB,
    payload: api.put(`job_position/${id}`, data),
  };
}

export function searchSkills(option) {
  return {
    type: ActionTypes.SEARCH_SKILL,
    payload: api.get(`terms/search?skill=${option}`),
  };
}

export function setSearchedEmployer(employer) {
  return {
    type: ActionTypes.SET_SEARCHED_EMPLOYER,
    payload: employer,
  };
}

export function setSearchedLocation(location) {
  return {
    type: ActionTypes.SET_SEARCHED_LOCATION,
    payload: location,
  };
}

export function setSearchedJobTitle(jobTitle) {
  return {
    type: ActionTypes.SET_SEARCHED_JOB_TITLE,
    payload: jobTitle,
  };
}

export function getJobtemplate(option) {
  return {
    type: ActionTypes.SEARCH_TEMPLATE,
    payload: api.get(`job_templates/search?key=${option}&search_type=key&page=1`),
  };
}

export function addNote(jobId, noteDescription) {
  return {
    type: ActionTypes.ADD_NOTE,
    payload: api.post(`job_position/${jobId}/notes`, { description: noteDescription }),
  };
}

export function getJobApplicationList(jobId, status, pageNo = 1, pageSize = 100) {
  return {
    type: ActionTypes.GET_JOB_APPLICATION_LIST,
    payload: api.get(`job_position/${jobId}/applications/${status}?page=${pageNo}&per_page=${pageSize}`),
  };
}

export function getJobApplicationListCounts(jobId) {
  return {
    type: ActionTypes.GET_JOB_APPLICATION_LIST_COUNTS,
    payload: api.get(`job_position/${jobId}/applications/count`),
  };
}

export function getMatchedCandidates(jobId, pageNo = 1, pageSize = 100, filterParam) {
  return {
    type: ActionTypes.GET_MATCHED_CANDIDATES,
    payload: api.get(`job_position/${jobId}/matches?${filterParam || ''}&page=${pageNo}&per_page=${pageSize}`),
  };
}

export function getMatchedCandidatesCounts(jobId, pageNo = 1, pageSize = 1) {
  return {
    type: ActionTypes.GET_MATCHED_CANDIDATES_COUNTS,
    payload: api.get(`job_position/${jobId}/matches?page=${pageNo}&per_page=${pageSize}`),
  };
}

export function flushCandidates() {
  return {
    type: ActionTypes.FLUSH_CANDIDATES,
    payload: null,
  };
}

export function deleteNote(jobId, noteId) {
  return {
    type: ActionTypes.DELETE_NOTE,
    payload: api.delete(`job_position/${jobId}/note/${noteId}`).then(res => ({
      data: res.data,
      id: noteId,
    })),
  };
}

export function closeJob(jobId) {
  return {
    type: ActionTypes.CLOSE_JOB,
    payload: api.put(`job_position/status/${jobId}`, { status: 'closed' }).then(() => ({
      jobId,
    })),
  };
}

export function deleteJob(jobId) {
  return {
    type: ActionTypes.DELETE_JOB,
    payload: api.delete(`job_position/${jobId}`).then(() => ({
      jobId,
    })),
  };
}

export function shortlistJobApplication(jobId, applicationId, status) {
  return {
    type: ActionTypes.SHORTLIST_JOB_APPLICATION,
    payload: api.post(`job_positions/${jobId}/applications`, { profile_id: applicationId, status }),
  };
}

export function shortlistBulkApplication(jobId, applicationIds, status) {
  return {
    type: ActionTypes.SHORTLIST_BULK_APPLICATION,
    payload: api.post(`job_position/${jobId}/applications`, { job_position_id: jobId, profile_ids: applicationIds, status }),
  };
}

export function moveBulkApplication(jobId, applicationIds, action) {
  return {
    type: ActionTypes.MOVE_BULK_APPLICATION,
    payload: api.put(`/job_position/${jobId}/applications/${action}`, { appplication_ids: applicationIds }),
  };
}

export function moveJobApplication(applicationId, action) {
  return {
    type: ActionTypes.MOVE_JOB_APPLICATION,
    payload: api.post(`application/${applicationId}/${action}`),
  };
}

export function deleteJobApplication(applicationId) {
  return {
    type: ActionTypes.DELETE_JOB_APPLICATION,
    payload: api.delete(`application/${applicationId}`),
  };
}

export function deleteJobApplicationBulk(jobId, applicationIds) {
  return {
    type: ActionTypes.DELETE_JOB_APPLICATION,
    payload: api.delete(`/job_position/${jobId}/applications`, { data: { application_ids: applicationIds } }),
  };
}

export function setSortedState(key, value) {
  return {
    type: ActionTypes.SET_SORTED_STATE,
    payload: { key, value },
  };
}

export function getAccountMe() {
  return {
    type: ActionTypes.GET_ACCOUNT_ME,
    payload: api.get('/accounts/me'),
  };
}

export function intercomSearch(key) {
  return {
    type: ActionTypes.INTERCOM_SEARCH,
    payload: api.get(`/logs/search?key=${key}`),
  };
}

export function intercomCreate(key) {
  return {
    type: ActionTypes.INTERCOM_CREATE,
    payload: api.get(`/logs/search?key=${key}`),
  };
}

