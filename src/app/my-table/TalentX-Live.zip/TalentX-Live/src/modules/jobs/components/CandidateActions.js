import React from 'react';
import PropTypes from 'prop-types';
import MoreIcon from 'material-ui-icons/MoreVert';
import Divider from 'material-ui/Divider';
import { MenuList, MenuItem } from 'material-ui/Menu';
import Menu from '../../../shared/compound/Menu';


class CandidateActions extends React.Component { // eslint-disable-line
  render() {
    return (
      <div className="candidate-actions">
        <Menu
          label=""
          iconPrefix={<MoreIcon className="more-vert" style={{ color: this.props.isDisabled || this.props.menuItems.length === 0 ? 'rgb(200, 200, 200)' : '#333' }} />}
          isDisabled={
            this.props.isDisabled
            || this.props.menuItems.length === 0
          }
          popup={
            <MenuList role="menu">
              {
                this.props.menuItems.map((menuItem, index) => // eslint-disable-line
                  menuItem.label === '-'
                  ? <Divider key={menuItem.key} />
                  : (
                    <MenuItem
                      key={menuItem.key}
                      className={index === this.props.menuItems.length - 1 ? '' : 'menu-item'}
                      onClick={() => {
                        if (this.props.bulkAction) {
                          menuItem.onHeaderClick(this.props.selectedCandidates
                            .map(selctedCandidate => selctedCandidate));
                        } else {
                          menuItem.onClick(this.props.candidate);
                        }
                      }
                    }
                    >
                      {menuItem.label}
                    </MenuItem>
                  ))
              }
            </MenuList>
          }
        />
      </div>
    );
  }
}

CandidateActions.propTypes = {
  menuItems: PropTypes.arrayOf(PropTypes.object),
  isDisabled: PropTypes.bool,
  candidate: PropTypes.objectOf(PropTypes.any),
  bulkAction: PropTypes.bool,
  selectedCandidates: PropTypes.arrayOf(PropTypes.object),
};

CandidateActions.defaultProps = {
  menuItems: [],
  isDisabled: false,
  candidate: {},
  bulkAction: false,
  selectedCandidates: [],
};

export default CandidateActions;
