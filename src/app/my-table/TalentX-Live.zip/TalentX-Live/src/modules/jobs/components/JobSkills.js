import React from 'react';
import List, {
  ListItem,
} from 'material-ui/List';
import MoreVertIcon from 'material-ui-icons/MoreVert';
import Divider from 'material-ui/Divider';

function generate(element) {
  return [0, 1, 2].map(value =>
    React.cloneElement(element, {
      key: value,
    }));
}

const JobSkills = () => (
  <div>
    <List>
      {
        generate( //eslint-disable-line
          <div>
            <ListItem style={{ paddingLeft: 0 }}>
              <MoreVertIcon />
              Project Management
            </ListItem>
            <Divider />
          </div>)
      }
    </List>
  </div>
);

export default JobSkills;
