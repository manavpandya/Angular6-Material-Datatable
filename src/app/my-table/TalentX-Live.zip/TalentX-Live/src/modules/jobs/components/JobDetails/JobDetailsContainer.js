import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import { reset } from 'redux-form';
import JobDetails from './JobDetails';
import { getJobById, getJobApplicationList, addNote, deleteNote, flushCurrentJob } from '../../redux/actions';
import { showNotification } from '../../../../utils/Notifications';
import Loader from '../../../../shared/basic/Loader';

class JobDetailsContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      newNoteDescription: '',
      chatType: {},
    };
    this.changeNewNoteDescription = this.changeNewNoteDescription.bind(this);
    this.addNote = this.addNote.bind(this);
    this.getJobApplicationList = this.getJobApplicationList.bind(this);
    this.handlerShowMessageDialog = this.handlerShowMessageDialog.bind(this);
    this.handleSubmitMessage = this.handleSubmitMessage.bind(this);
    this.deleteNote = this.deleteNote.bind(this);
  }

  componentDidMount() {
    const jobId = this.props.match.params.id;
    this.props.getJobById(jobId).catch(() => {
      showNotification(this.props.translate('jobDetailNotFound'), 'error', 8000);
      this.props.history.push('/recruiter');
    });
  }

  componentWillUnmount() {
    this.props.flushCurrentJob();
  }

  getJobApplicationList(status, pageNo, pageSize) {
    this.props.getJobApplicationList(this.props.currentJob.id, status, pageNo, pageSize);
  }

  handlerShowMessageDialog(chatType, messageFrom, emailTo, event) {
    this.setState({ chatType: { messageFrom, emailTo, type: chatType }, showMessageDialog: event });
  }

  handleSubmitMessage(event) {
    if (event.subject) {
      showNotification(this.props.translate('emailSent'), 'success', 8000);
    } else {
      showNotification(this.props.translate('emailSent'), 'success', 8000);
    }
    this.props.dispatch(reset('MessageForm'));
    this.setState({ showMessageDialog: false });
  }

  changeNewNoteDescription(event) {
    this.setState({
      newNoteDescription: event.target.value,
    });
  }

  addNote(event, fakeDivRef) {
    if (event.key === 'Enter') {
      this.props.addNote(this.props.match.params.id, event.target.value).then(() => {
        fakeDivRef.scrollIntoView({ behavior: 'smooth' });
        this.setState({
          newNoteDescription: '',
        });
      });
    }
  }

  deleteNote(noteId) {
    this.props.deleteNote(this.props.match.params.id, noteId).then(() => {
      showNotification(this.props.translate('noteDeleted'), 'success', 8000);
    }).catch((err) => {
      showNotification(err.message, 'error', 8000);
    });
  }

  render() {
    const { currentJobLoading } = this.props;
    if (currentJobLoading) {
      return (
        <Loader />
      );
    } return (
      <JobDetails
        chatType={this.state.chatType}
        showMessageDialog={this.state.showMessageDialog}
        handlerShowMessageDialog={this.handlerShowMessageDialog}
        handleSubmitMessage={this.handleSubmitMessage}
        job={this.props.currentJob}
        addNote={this.addNote}
        deleteNote={this.deleteNote}
        newNoteDescription={this.state.newNoteDescription}
        changeNewNoteDescription={this.changeNewNoteDescription}
      />
    );
  }
}

JobDetailsContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  history: PropTypes.object.isRequired, // eslint-disable-line
  getJobApplicationList: PropTypes.func.isRequired,
  chatType: PropTypes.object, // eslint-disable-line
  match: PropTypes.object.isRequired, // eslint-disable-line
  getJobById: PropTypes.func,
  currentJob: PropTypes.object, // eslint-disable-line
  currentJobLoading: PropTypes.bool,
  addNote: PropTypes.func,
  dispatch: PropTypes.func,
  deleteNote: PropTypes.func,
  flushCurrentJob: PropTypes.func,
};

JobDetailsContainer.defaultProps = {
  chatType: {},
  getJobById: () => {},
  currentJob: {},
  currentJobLoading: false,
  addNote: () => {},
  dispatch: () => {},
  deleteNote: () => { },
  flushCurrentJob: () => {},
};

const mapStateToProps = state => ({
  currentJob: state.recruiter.currentJob,
  currentJobLoading: state.recruiter.currentJobLoading,
});

const mapDispatchToProps = dispatch => ({
  getJobById: jobId => dispatch(getJobById(jobId)),
  addNote: (jobId, noteDescription) => dispatch(addNote(jobId, noteDescription)),
  getJobApplicationList: (jobId, status, pageNo, pageSize) =>
    dispatch(getJobApplicationList(jobId, status, pageNo, pageSize)),
  deleteNote: (jobId, noteId) => dispatch(deleteNote(jobId, noteId)),
  flushCurrentJob: () => dispatch(flushCurrentJob()),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(JobDetailsContainer)));// eslint-disable-line
