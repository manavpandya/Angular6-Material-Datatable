import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
import TextField from 'redux-form-material-ui';
import NoteIcon from 'material-ui-icons/Note';
import ExpandField from '../../../shared/compound/ExpandField';
import MomentTranslate from '../../../shared/basic/MomentTranslate';

class JobDashboard extends Component {
  render() {
    const j = this.props.job;
    return (
      <div className="job-dashboard">
        <main>
          <h2>{this.props.translate('jobHistory')}</h2>
          <div className="job-history">
            <div className="noneBorder">

              <span className="date"><NoteIcon /></span>
              <div className="main">
                <TextField defaultValue="Add Notes ..." />
              </div>
            </div>
            {this.props.notifications.map(n =>
              (
                <div className={n.read ? '' : 'unread'} key={n.date}>
                  <span className="date">{n.date}</span>
                  <div className="main">
                    {n.title && <h3 className="title">{n.title}</h3>}
                    {n.message && <span className="message">{n.message}</span>}
                  </div>
                </div>
              ))}
          </div>
        </main>
        <aside>
          <ExpandField label="Job Description">
            {this.esc(j.description)}
            <h3>{this.props.translate('postedBy')}: {j.postedBy}</h3>
            <h3>{this.props.translate('postedOn')}:
              <MomentTranslate
                fromNow={j.posted}
              />
            </h3>
            <div className="insert-drive-file-div">
              <InsertDriveFile className="insert-dive-file-file" />
              <h2 className="drive-file-head">UTC200-{j.client}-{j.title}.pdf</h2>
            </div>
          </ExpandField>
          <ExpandField label={`${j.project.name} jobs`} />
          <ExpandField label={`${j.client} jobs`} />
        </aside>
      </div>
    );
  }
}

JobDashboard.propTypes = {
  translate: PropTypes.func.isRequired,
  job: PropTypes.object, // eslint-disable-line
  notifications: PropTypes.array, // eslint-disable-line
};

JobDashboard.defaultProps = {
  job: {},
  notifications: [],
};

export default withTranslate(JobDashboard);
