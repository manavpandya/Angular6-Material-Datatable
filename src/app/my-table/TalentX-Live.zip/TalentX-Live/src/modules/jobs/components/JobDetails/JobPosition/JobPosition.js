import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router';
import IconButton from 'material-ui/IconButton';
import Menu, { MenuItem } from 'material-ui/Menu';
import MoreVertIcon from 'material-ui-icons/MoreVert';
import Button from 'material-ui/Button';
import Dialog, {
  DialogActions,
  DialogTitle,
  DialogContent,
} from 'material-ui/Dialog';
import Loader from '../../../../../shared/basic/Loader';

const ITEM_HEIGHT = 48;

const JobPosition = props => (
  <div className={props.jobStatus === 'closed' ? 'disabled-image' : ''}>
    <IconButton
      aria-label="More"
      aria-owns={props.anchorEl ? 'long-menu' : null}
      aria-haspopup="true"
      onClick={props.handleClick}
    >
      <MoreVertIcon />
    </IconButton>
    <Menu
      id="long-menu"
      anchorEl={props.anchorEl}
      open={Boolean(props.anchorEl)}
      onClose={props.handleClose}
      PaperProps={{
        style: {
          maxHeight: ITEM_HEIGHT * 4.5,
          width: 200,
        },
      }}
    >
      {
        (props.jobStatus === 'draft' || props.jobStatus === 'posted') &&
        <MenuItem
          onClick={() =>
            props.history.push({
              pathname: `/recruiter/jobs/edit/${props.jobId}`,
              state: {
                job_status: props.jobStatus,
                job_title: props.jobTitle,
                sector: props.job.sector ? props.job.sector.primary : '',
              },
            })}
        >
          {props.translate('editJob')}
        </MenuItem>
      }
      {
        <MenuItem
          onClick={() => {
              props.handleClose();
              props.handleCloseJob(true);
          }}
        >
          {props.translate('closeJob')}
        </MenuItem>
      }
      {
        props.jobStatus === 'draft' && <MenuItem onClick={() => { props.handleClose(); props.handleDeleteJob(true); }}>{props.translate('deleteJob')}</MenuItem>
      }
      {props.options.map(option => (
        <MenuItem key={option.key} selected={option === 'Pyxis'} onClick={props.handleClose}>
          {option.value}
        </MenuItem>
      ))}
    </Menu>
    <Dialog
      open={props.openCloseJobDialog}
      onClose={() => props.handleCloseJob(false)}
    >
      <DialogTitle>{props.translate('closeWindow')}</DialogTitle>
      <DialogContent>
        <p>{props.translate('closeJobMessage')}</p>
        {
          props.closeJobLoading && <Loader />
        }
      </DialogContent>
      <DialogActions>
        <Button
          onClick={() => props.handleCloseJob(false)}
          color="primary"
        >
          {props.translate('btnNo')}
        </Button>
        <Button
          color="primary"
          autoFocus
          onClick={props.confirmJobClose}
        >
          {props.translate('btnYes')}
        </Button>
      </DialogActions>
    </Dialog>
    <Dialog
      open={props.openDeleteJobDialog}
      onClose={() => props.handleDeleteJob(false)}
    >
      <DialogTitle>{props.translate('deleteRecord')}</DialogTitle>
      <DialogContent>
        <p>{props.translate('deleteJobMessage')}</p>
        {
          props.deleteJobLoading && <Loader />
        }
      </DialogContent>
      <DialogActions>
        <Button
          onClick={() => props.handleDeleteJob(false)}
          color="primary"
        >
          {props.translate('btnNo')}
        </Button>
        <Button
          color="primary"
          autoFocus
          onClick={props.confirmDeleteJob}
        >
          {props.translate('btnYes')}
        </Button>
      </DialogActions>
    </Dialog>
  </div>
);

JobPosition.propTypes = {
  translate: PropTypes.func.isRequired,
  anchorEl: PropTypes.object, // eslint-disable-line
  options: PropTypes.array, //eslint-disable-line
  jobId: PropTypes.string,
  jobStatus: PropTypes.string,
  jobTitle: PropTypes.string,
  job: PropTypes.object, //eslint-disable-line
  history: PropTypes.object, //eslint-disable-line
  handleClick: PropTypes.func,
  handleClose: PropTypes.func,
  handleCloseJob: PropTypes.func,
  handleDeleteJob: PropTypes.func,
  confirmJobClose: PropTypes.func,
  confirmDeleteJob: PropTypes.func,
  openCloseJobDialog: PropTypes.bool,
  openDeleteJobDialog: PropTypes.bool,
  closeJobLoading: PropTypes.bool.isRequired,
  deleteJobLoading: PropTypes.bool.isRequired,
};

JobPosition.defaultProps = {
  anchorEl: {},
  options: [],
  jobId: '',
  jobStatus: '',
  jobTitle: '',
  job: {},
  history: {},
  handleClick: () => {},
  handleClose: () => {},
  handleCloseJob: () => {},
  handleDeleteJob: () => {},
  confirmJobClose: () => {},
  confirmDeleteJob: () => {},
  openCloseJobDialog: false,
  openDeleteJobDialog: false,
};

export default withRouter(withTranslate(JobPosition));
