import _ from 'lodash';
import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { withRouter } from 'react-router';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import BackIcon from 'material-ui-icons/ArrowBack';
// import LocationIcon from 'material-ui-icons/LocationOn';
import JobPositionContainer from '../JobDetails/JobPosition/JobPositionContainer';
import MomentTranslate from '../../../../shared/basic/MomentTranslate';


const JobHeader = props => (
  Object.keys(props.job).length > 0
    ?
      <header className="job-header">
        <div className="job-header-content">

          <Link disabled={props.candidatesLoading} to={`${props.customerPage ? '/customer' : '/recruiter'}`}>
            <BackIcon className="back-button" />
          </Link>
          <div>
            <h3>
              <strong className="status">
                {_.startCase(props.job.status)},  {props.translate('lastUpdated')} : <MomentTranslate
                  fromNow={props.job.updated_at}
                />
              </strong>
            </h3>
            <h1>{props.job.job_description.job_title} [{props.job.no_of_positions}] </h1>
            <div className="client-location">
              <h2 className="client">
                {/* <img
                    className="logo"
                    alt={props.job.job_description.employer}
                    src="/logos/shell.svg"
                  /> */}
                {(props.job && props.job.customer && props.job.customer.name) ||
                  props.job.job_description.employer}{/* , {props.job.project_name} */}
              </h2>
              {/* <h2 className="location">
                  <LocationIcon className="icon" />
                  {props.job.location.region}
                </h2> */}
            </div>
          </div>
          <div><JobPositionContainer job={props.job} /></div>
        </div>
      </header>
    : <div />
);

JobHeader.propTypes = {
  translate: PropTypes.func.isRequired,
  job: PropTypes.instanceOf(Object),
  candidatesLoading: PropTypes.bool,
  customerPage: PropTypes.bool,
};

JobHeader.defaultProps = {
  job: {},
  candidatesLoading: false,
  customerPage: false,
};

export default withRouter(withTranslate(JobHeader));
