import { showNotification } from '../../../../../utils/Notifications';

const ResolvePromise = (promise, successMessage, errorMessage, getData) => {
  setTimeout(() => promise().then(() => {
    showNotification(successMessage, 'success', 5000);
    getData();
  }).catch((err) => {
    if (err.response) showNotification(err.response.data.message, 'error', 5000);
  }), 1);
};

const allMenuItems = props => ([
  {
    key: 'Shortlist-Shortlist',
    label: props.translate('shortlist'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.shortlistBulkApplication(props.currentJobId, candidates.map(candidate => candidate.id), 'shortlisted'),
        `${candidates.length} Candidates ${props.translate('shortlisted')}`,
        `${props.translate('failedToShortlist')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: (candidate) => {
      ResolvePromise(
        () => props.shortlistApplication(props.currentJobId, candidate.id, 'shortlisted'),
        `${candidate.name} ${props.translate('shortlisted')}`,
        `${props.translate('failedToShortlist')} ${candidate.name}`,
        props.getData,
      );
    },
  },
  {
    key: 'Shortlist-Present',
    label: props.translate('present'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.shortlistBulkApplication(props.currentJobId, candidates.map(candidate => candidate.id), 'presented'),
        `${candidates.length} Candidates ${props.translate('presented')}`,
        `${props.translate('failedToPresent')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: (candidate) => {
      ResolvePromise(
        () => props.shortlistApplication(props.currentJobId, candidate.id, 'presented'),
        `${candidate.name} ${props.translate('presented')}`,
        `${props.translate('failedToPresent')} ${candidate.name}`,
        props.getData,
      );
    },
  },
  {
    key: 'Shortlist-ReviewLater',
    label: props.translate('reviewLater'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'reviewLater', 'reviewLater'),
        `${candidates.length} Candidates ${props.translate('movedToReviewLater')}`,
        `${props.translate('failedToMove')} Selected Candidates ${props.translate('toReviewLater')}`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'reviewLater', 'reviewLater'),
      `${candidate.name} ${props.translate('movedToReviewLater')}`,
      `${props.translate('failedToMove')} ${candidate.name} ${props.translate('toReviewLater')}`,
      props.getData,
    ),
  },
  {
    key: 'Shortlist-Reject',
    label: props.translate('reject'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'reject', 'rejected'),
        `${candidates.length} Candidates ${props.translate('rejected')}`,
        `${props.translate('failedToReject')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'reject', 'rejected'),
      `${candidate.name} ${props.translate('rejected')}`,
      `${props.translate('failedToReject')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Qualify-Qualify',
    label: props.translate('qualify'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'qualify', 'qualified'),
        `${candidates.length} Candidates ${props.translate('qualified')}`,
        `${props.translate('failedToQualify')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: (candidate) => {
      ResolvePromise(
        () => props.moveApplication(props.currentJobId, candidate.parentId, 'qualify', 'qualified'),
        `${candidate.name} ${props.translate('qualified')}`,
        `${props.translate('failedToQualify')} ${candidate.name}`,
        props.getData,
      );
    },
  },
  {
    key: 'Qualify-Present',
    label: props.translate('present'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'present', 'presented'),
        `${candidates.length} Candidates ${props.translate('presented')}`,
        `${props.translate('failedToPresent')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'present', 'presented'),
      `${candidate.name} ${props.translate('presented')}`,
      `${props.translate('failedToPresent')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Qualify-Reject',
    label: props.translate('reject'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'reject', 'rejected'),
        `${candidates.length} Candidates ${props.translate('rejected')}`,
        `${props.translate('failedToReject')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'reject', 'rejected'),
      `${candidate.name} ${props.translate('rejected')}`,
      `${props.translate('failedToReject')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Qualify-MoveBack',
    label: props.translate('moveBack'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.deleteJobApplicationBulk(props.currentJobId, candidates
          .map(candidate => candidate.parentId)),
        `${candidates.length} Candidates ${props.translate('movedBackTo')} ${props.translate('matched')} candidates`,
        `${props.translate('failedToMoveBack')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.deleteApplication(props.currentJobId, candidate.parentId),
      `${candidate.name} ${props.translate('movedBackTo')} ${props.translate('matched')} candidates`,
      `${props.translate('failedToMoveBack')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Reject-MoveBack',
    label: props.translate('moveBack'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'shortlist', 'rejected'),
        `${candidates.length} Candidates ${props.translate('movedBackTo')} ${props.translate('shortlisted')}`,
        `${props.translate('failedToMoveBack')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'shortlist', 'rejected'),
      `${candidate.name} ${props.translate('movedBackTo')} ${props.translate('shortlisted')}`,
      `${props.translate('failedToMoveBack')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Present-Present',
    label: props.translate('present'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'present', 'presented'),
        `${candidates.length} Candidates ${props.translate('presented')}`,
        `${props.translate('failedToPresent')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'present', 'presented'),
      `${candidate.name} ${props.translate('presented')}`,
      `${props.translate('failedToPresent')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Present-Reject',
    label: props.translate('reject'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'reject', 'rejected'),
        `${candidates.length} Candidates ${props.translate('rejected')}`,
        `${props.translate('failedToReject')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'reject', 'rejected'),
      `${candidate.name} ${props.translate('rejected')}`,
      `${props.translate('failedToReject')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Present-MoveBack',
    label: props.translate('moveBack'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'shortlist', 'qualified'),
        `${candidates.length} Candidates ${props.translate('movedBackTo')} ${props.translate('shortlisted')}`,
        `${props.translate('failedToMoveBack')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'shortlist', 'qualified'),
      `${candidate.name} ${props.translate('movedBackTo')} ${props.translate('shortlisted')}`,
      `${props.translate('failedToMoveBack')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Presented-MoveBack',
    label: props.translate('moveBack'),
    onHeaderClick: (candidates) => {
      ResolvePromise(
        () => props.moveBulkApplication(props.currentJobId, candidates.map(candidate => candidate.parentId), 'qualify', 'presented'),
        `${candidates.length} Candidates ${props.translate('movedBackTo')} ${props.translate('qualified')}`,
        `${props.translate('failedToMoveBack')} Selected Candidates`,
        props.getData,
      );
    },
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'qualify', 'presented'),
      `${candidate.name} ${props.translate('movedBackTo')} ${props.translate('qualified')}`,
      `${props.translate('failedToMoveBack')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Hiring-Interview',
    label: props.translate('interview'),
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'interview', 'interviewed'),
      `${candidate.name} ${props.translate('movedToInterview')}`,
      `${props.translate('failedToMove')} ${candidate.name} ${props.translate('toInterview')}`,
      props.getData,
    ),
  },
  {
    key: 'Hiring-Offer',
    label: props.translate('offer'),
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'offer', 'offered'),
      `${candidate.name} ${props.translate('offered')}`,
      `${props.translate('failedToOffer')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Hiring-Hire',
    label: props.translate('hire'),
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'hire', 'hired'),
      `${candidate.name} ${props.translate('hired')}`,
      `${props.translate('failedToHire')} ${candidate.name}`,
      props.getData,
    ),
  },
  {
    key: 'Hiring-Reject',
    label: props.translate('reject'),
    onClick: candidate => ResolvePromise(
      () => props.moveApplication(props.currentJobId, candidate.parentId, 'reject', 'rejected'),
      `${candidate.name} ${props.translate('rejected')}`,
      `${props.translate('failedToReject')} ${candidate.name}`,
      props.getData,
    ),
  },
  { key: 'common-1', label: '-', onClick: () => { } },
  {
    key: 'common-AddToJob',
    label: props.translate('addtoJob'),
    onHeaderClick: (candidates) => {
      props.openAddToJobDialog(null, candidates);
    },
    onClick: candidate => props.openAddToJobDialog(candidate),
  },
  { key: 'common-MoveToJob', label: props.translate('moveToJob'), onClick: () => { } },
  { key: 'common-2', label: '-', onClick: () => { } },
  { key: 'common-Share', label: props.translate('share'), onClick: () => { } },
]);

export const getMenuItems = (props, keys) => {
  const menuItems = [];
  keys.forEach((key) => {
    const currentMenuItem = allMenuItems(props).find(menuItem => menuItem.key === key);
    menuItems.push(currentMenuItem);
  });
  return menuItems;
};

export const ShortlistMatchedMenuItems = props =>
  getMenuItems(props, ['Shortlist-Shortlist', 'Shortlist-Present', 'common-AddToJob']);

export const ShortlistMatchedBulkMenuItems = props =>
  getMenuItems(props, ['Shortlist-Shortlist', 'Shortlist-Present', 'common-AddToJob']);

export const QualifyShortlistedMenuItems = props =>
  getMenuItems(props, ['Qualify-Qualify', 'Qualify-Present', 'Qualify-Reject', 'Qualify-MoveBack']);

export const QualifyShortlistedBulkMenuItems = props =>
  getMenuItems(props, ['Qualify-Qualify', 'Qualify-Present', 'Qualify-Reject', 'Qualify-MoveBack']);

export const QualifyRejectedMenuItems = props =>
  getMenuItems(props, ['Reject-MoveBack']);

export const QualifyRejectedBulkMenuItems = props =>
  getMenuItems(props, ['Reject-MoveBack']);

export const PresentQualifiedMenuItems = props =>
  getMenuItems(props, ['Present-Present', 'Present-MoveBack']);

export const PresentQualifiedBulkMenuItems = props =>
  getMenuItems(props, ['Present-Present', 'Present-MoveBack']);

export const PresentPresentedMenuItems = props =>
  getMenuItems(props, ['Presented-MoveBack']);

export const PresentPresentedBulkMenuItems = props =>
  getMenuItems(props, ['Presented-MoveBack']);
