import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { showNotification } from '../../../../utils/Notifications';

import CreateNewJob from './CreateNewJob';
import { getJobtemplate, uploadJob } from '../../redux/actions';

class CreateNewJobContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      files: [],
      activeTab: 'a',
      jobUploaded: false,
    };
    this.onDropFiles = this.onDropFiles.bind(this);
    this.searchTemplate = this.searchTemplate.bind(this);
    this.changeActiveTab = this.changeActiveTab.bind(this);
    this.uploadJob = this.uploadJob.bind(this);
    this.uploadFailure = this.uploadFailure.bind(this);
    this.textInputJob = this.textInputJob.bind(this);
    this.closePostJob = this.closePostJob.bind(this);
    this.openTemplate = this.openTemplate.bind(this);
  }

  componentDidMount() {
    this.props.getJobtemplate('');
  }

  componentWillReceiveProps(nextProps) {
    if (this.state.jobUploaded && this.props.jobPosition !== nextProps.jobPosition) {
      this.props.history.push({
        pathname: '/recruiter/jobs/new',
        state: { initialValues: nextProps.jobPosition },
      });
      this.closePostJob();
    }
  }

  onDropFiles(files) {
    this.setState({
      files,
    });
  }

  searchTemplate(event) {
    if (event.target.value.length > 2) {
      this.props.getJobtemplate(event.target.value);
    }
  }

  changeActiveTab(tab) {
    this.setState({ activeTab: tab });
  }

  uploadJob() {
    const formData = new FormData();
    formData.append('file', this.state.files[0]);
    this.setState({
      jobUploaded: true,
    });
    this.props.uploadJob(formData).catch(res => this.uploadFailure(res));
  }

  uploadFailure(res) {
    this.props.setShowCreateNewJob(true);
    const message = JSON.parse(JSON.stringify(res)).response.data.message; //eslint-disable-line
    showNotification(message, 'error', 8000);
  }

  textInputJob(values) {
    const formData = new FormData();
    formData.append('txt', values.jobInput);
    this.setState({
      jobUploaded: true,
    });
    this.props.uploadJob(formData).catch(res => this.uploadFailure(res));
  }

  closePostJob() {
    this.props.setShowCreateNewJob(false);
  }

  openTemplate(values) {
    this.closePostJob();
    this.props.history.push({
      pathname: '/recruiter/jobs/new',
      state: {
        initialValues: {
          job_description: {
            job_title: values.job_title,
            mgmt_score: values.mgmt_score,
            alternate_job_titles: values.alternate_job_titles,
            employer: values.employer,
            executive_type: values.executive_type,
            is_management_job: values.is_management_job,
            job_end_date: values.job_end_date,
            job_start_date: values.job_start_date,
          },
        },
      },
    });
  }

  render() {
    return (
      <CreateNewJob
        noTemplatesData={this.props.noTemplatesData}
        jobTemplates={this.props.jobTemplates}
        searchTemplate={this.searchTemplate}
        activeTab={this.state.activeTab}
        changeActiveTab={this.changeActiveTab}
        onDropFiles={this.onDropFiles}
        files={this.state.files}
        uploadJob={this.uploadJob}
        closePostJob={this.closePostJob}
        textInputJob={this.textInputJob}
        openTemplate={this.openTemplate}
        dispatch={this.props.dispatch}
        uploadJobLoading={this.props.uploadJobLoading}
      />
    );
  }
}

CreateNewJobContainer.propTypes = {
  noTemplatesData: PropTypes.bool,
  jobTemplates: PropTypes.array, // eslint-disable-line
  getJobtemplate: PropTypes.func,
  uploadJob: PropTypes.func,
  history: PropTypes.object.isRequired, // eslint-disable-line
  setShowCreateNewJob: PropTypes.func,
  dispatch: PropTypes.func,
  uploadJobLoading: PropTypes.bool,
  jobPosition: PropTypes.object, // eslint-disable-line
};

CreateNewJobContainer.defaultProps = {
  noTemplatesData: false,
  jobTemplates: [],
  getJobtemplate: () => {},
  uploadJob: () => {},
  setShowCreateNewJob: () => {},
  dispatch: () => {},
  uploadJobLoading: false,
  jobPosition: {},
};

const mapStateToProps = state => ({
  noTemplatesData: state.recruiter.noTemplatesData,
  jobTemplates: state.recruiter.jobTemplates,
  uploadJobLoading: state.recruiter.uploadJobLoading,
  jobPosition: state.recruiter.jobPosition,
});

const mapDispatchToProps = dispatch => ({
  getJobtemplate: option => dispatch(getJobtemplate(option)),
  uploadJob: formData => dispatch(uploadJob(formData)),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(CreateNewJobContainer)));// eslint-disable-line
