import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import ReduxBlockUI from 'react-block-ui/redux';
// import Button from 'material-ui/Button';
// import AdvancedSearchPanel from '../../../../shared/compound/AdvancedSearchPanel';

const styles = {
  appBar: {
    position: 'relative',
  },
  flex: {
    flex: 1,
  },
};

class JobPipeline extends Component {
  constructor(props) {
    super(props);
    this.state = {
      active_tab: this.props.tabs[0].originalKey,
    };
    this.handleTabClick = this.handleTabClick.bind(this);
  }

  handleTabClick(tab) {
    this.setState({ active_tab: tab }, () => this.props.selectAllCandidates([]));
    // if (tab === 'shortlist') {
    //   setTimeout(() => {
    //     this.props.fetchFacetMatched('', this.props.jobData.id)
    //       .then(() => {
    //         this.props.resetFilterParamsMatched();
    //       });
    //   }, 1);
    // }
  }

  render() {
    return (
      <div className="tabs pipeline">
        <header>
          {this.props.summary}
          {
              this.props.jobData.sector &&
              <div className="sector-rectangle right">
                {this.props.jobData.sector.primary}
              </div>
          }
          <ReduxBlockUI
            tag="div"
            className="inline-block"
            keepInView={false}
            loader={<span />}
            blocking={this.props.candidatesLoading}
          >
            <ul className="tab-header">
              {
                this.props.tabs.map(tab => (
                  <li key={tab.originalKey} className={this.state.active_tab === tab.originalKey ? 'active' : ''}>
                    <div
                      role="presentation"
                      className="main-tabs"
                      onKeyDown={() => {}}
                      onClick={() => this.handleTabClick(tab.originalKey)}
                    >
                      {this.props.header[tab.originalKey]}
                    </div>
                  </li>
                ))
              }
            </ul>
          </ReduxBlockUI>
        </header>
        <div className="tab-content">
          {
            this.props.tabs.map(tab => (
              <div key={tab.originalKey} className={this.state.active_tab === tab.originalKey ? 'active' : ''}>
                {/* {(tab.originalKey) === 'shortlist' ?
                  <AdvancedSearchPanel
                    isMatched
                    jobId={this.props.jobData.id}
                    showFacets={[
                      { key: 'current_location', type: 'checkbox', component: 'location' },
                      { key: 'preferred_location', type: 'checkbox', component: 'location' },
                    ]}
                  />
                  : null
                } */}
                {this.props.content[tab.originalKey]}
              </div>
            ))
          }
        </div>
      </div>
    );
  }
}

JobPipeline.propTypes = {
  classes: PropTypes.object.isRequired, // eslint-disable-line
  tabs: PropTypes.array.isRequired, // eslint-disable-line
  summary: PropTypes.element,
  header: PropTypes.object.isRequired, // eslint-disable-line
  content: PropTypes.object, // eslint-disable-line
  jobData: PropTypes.object, // eslint-disable-line
  selectAllCandidates: PropTypes.func,
  candidatesLoading: PropTypes.bool,
  // resetFilterParamsMatched: PropTypes.func,
  // fetchFacetMatched: PropTypes.func,

};

JobPipeline.defaultProps = {
  summary: <div />,
  content: {},
  jobData: {},
  selectAllCandidates: () => { },
  candidatesLoading: false,
  // resetFilterParamsMatched: () => {},
  // fetchFacetMatched: () => {},
};

export default withStyles(styles)(JobPipeline);
