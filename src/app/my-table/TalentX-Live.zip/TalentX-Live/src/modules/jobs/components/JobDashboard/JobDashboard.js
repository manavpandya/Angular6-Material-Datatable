import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import Select from 'material-ui/Select';
import PropTypes from 'prop-types';
import { MenuItem } from 'material-ui';
import Button from 'material-ui/Button';
import { withStyles } from 'material-ui/styles';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';
import DragScroll from 'react-dragscroll';
import JobSummary from '../JobSummary';
import InfiniteScroll from '../../../../shared/basic/InfiniteScroll';

const grid = 0.4;

const getItemStyle = (isDragging, draggableStyle) => ({
  // some basic styles to make the items look a bit nicer
  userSelect: 'none',
  padding: grid * 2,
  margin: `0 0 ${grid}px 0`,

  // change background colour if dragging
  background: isDragging ? 'lightgreen' : 'white',
  color: '#333',

  // styles we need to apply on draggables
  ...draggableStyle,
});

const getListStyle = isDraggingOver => ({
  background: isDraggingOver ? '#FFFFFF' : '#F9F9F9',
  padding: grid,
});

class JobDashboard extends Component {
  render() {
    const stages = [
      {
        key: 'draft',
        title: this.props.translate('draftJobs'),
        className: 'stage-draft',
        jobs: this.props.draftedJobs,
        jobsLoading: this.props.draftedJobsLoading,
        showNew: true,
      },
      {
        key: 'posted',
        title: this.props.translate('posted'),
        className: 'stage-open',
        jobs: this.props.postedJobs,
        jobsLoading: this.props.postedJobsLoading,
      },
      {
        key: 'qualified',
        title: `${this.props.translate('qualified')}...`,
        className: 'stage-auto-qualified',
        jobs: this.props.qualifiedJobs,
        jobsLoading: this.props.qualifiedJobsLoading,
      },
      {
        key: 'presented',
        title: this.props.translate('presented'),
        className: 'stage-presented',
        jobs: this.props.presentedJobs,
        jobsLoading: this.props.presentedJobsLoading,
      },
      {
        key: 'closed',
        title: this.props.translate('closed'),
        className: 'stage-closed',
        jobs: this.props.closedJobs,
        jobsLoading: this.props.closedJobsLoading,
      },
    ];
    return (
      <div className="page recruiter">
        <main>
          <div className="contain">
            <section className="board fixed">
              <DragScroll className="dragScroll">
                <section className="stages">
                  <DragDropContext onDragEnd={this.props.onDragEnd}>
                    {
                    stages.map(stage => (
                      <section className={`stage ${stage.className}`} key={stage.key}>
                        <header className="stage-header-wrapper">
                          <div className="stage-header">
                            <h3>{stage.title}</h3>
                            <Select
                              className="stage-sort"
                              value={this.props[`${stage.key}JobsSortedBy`] || 'none'}
                              onChange={event =>
                                this.props.sortStage(stage.key, event.target.value)}
                            >
                              <MenuItem value="none" className="stage-sort-option">
                                {this.props.translate('none')}
                              </MenuItem>
                              <MenuItem value="created_at" className="stage-sort-option">
                                {this.props.translate('byPostedDate')}
                              </MenuItem>
                              <MenuItem
                                value="job_description.job_due_date"
                                className="stage-sort-option"
                              >
                                {this.props.translate('byJobDueDate')}
                              </MenuItem>

                            </Select>
                          </div>
                        </header>
                        <main>
                          <Droppable droppableId={stage.key}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                style={getListStyle(snapshot.isDraggingOver)}
                              >
                                <div className="jobs">
                                  {
                                    stage.jobs.length < 1 && stage.jobsLoading
                                    ? (
                                      <div className="spinner">
                                        {this.props.translate('pleaseWait')}
                                      </div>
                                    )
                                    : (
                                      <div>
                                        {
                                          stage.jobs.length < 1
                                          ? (
                                            <div className="no-jobs">
                                              {this.props.translate('nothingToDisplay')}
                                            </div>
                                            )
                                          : (
                                            <div>
                                              {
                                                stage.jobs.map((job, index) => (
                                                  <Draggable
                                                    key={job.id}
                                                    draggableId={job.id}
                                                    index={index}
                                                  >
                                                    {(innerProvided, innerSnapshot) => (
                                                      <div>
                                                        <div
                                                          ref={innerProvided.innerRef}
                                                          {...innerProvided.draggableProps}
                                                          {...innerProvided.dragHandleProps}
                                                          style={getItemStyle(
                                                            innerSnapshot.isDragging,
                                                            innerProvided.draggableProps.style,
                                                          )}
                                                          className="job-container-draggable-child"
                                                        >
                                                          <JobSummary
                                                            job={job}
                                                            stageKey={stage.key}
                                                          />
                                                        </div>
                                                        {innerProvided.placeholder}
                                                      </div>
                                                    )}
                                                  </Draggable>
                                                ))
                                              }
                                              {
                                                stage.jobsLoading
                                                ? (
                                                  <div className="spinner">
                                                    {this.props.translate('pleaseWait')}...
                                                  </div>
                                                )
                                                : this.props.checkLoaderVisibility(stage.key) &&
                                                  <div className="btn-load-more-container">
                                                    <Button
                                                      className="btn-load-more"
                                                      onClick={() =>
                                                              this.props.getNextPage(stage.key)}
                                                    >
                                                      {this.props.translate('loadMore')}
                                                    </Button>
                                                  </div>
                                              }
                                            </div>
                                            )
                                        }
                                      </div>
                                    )
                                  }
                                  {
                                    this.props.checkLoaderVisibility(stage.key) &&
                                    <InfiniteScroll
                                      onReachedBottom={() => this.props.getNextPage(stage.key)}
                                    />
                                  }
                                </div>
                                {provided.placeholder}
                              </div>
                            )}
                          </Droppable>
                        </main>
                      </section>
                    ))
                  }
                  </DragDropContext>
                </section>
              </DragScroll>
            </section>
          </div>
        </main>
      </div>
    );
  }
}


JobDashboard.propTypes = {
  translate: PropTypes.func.isRequired,
  draftedJobs: PropTypes.arrayOf(PropTypes.object),
  draftedJobsLoading: PropTypes.bool,
  postedJobs: PropTypes.arrayOf(PropTypes.object),
  postedJobsLoading: PropTypes.bool,
  qualifiedJobs: PropTypes.arrayOf(PropTypes.object),
  qualifiedJobsLoading: PropTypes.bool,
  presentedJobs: PropTypes.arrayOf(PropTypes.object),
  presentedJobsLoading: PropTypes.bool,
  closedJobs: PropTypes.arrayOf(PropTypes.object),
  closedJobsLoading: PropTypes.bool,
  onDragEnd: PropTypes.func,
  checkLoaderVisibility: PropTypes.func,
  getNextPage: PropTypes.func.isRequired,
  sortStage: PropTypes.func,
  draftJobsSortedBy: PropTypes.string,
  postedJobsSortedBy: PropTypes.string,
  qualifiedJobsSortedBy: PropTypes.string,
  presentedJobsSortedBy: PropTypes.string,
  closedJobsSortedBy: PropTypes.string,
};

JobDashboard.defaultProps = {
  draftedJobs: [],
  draftedJobsLoading: false,
  postedJobs: [],
  postedJobsLoading: false,
  qualifiedJobs: [],
  qualifiedJobsLoading: false,
  presentedJobs: [],
  presentedJobsLoading: false,
  closedJobs: [],
  closedJobsLoading: false,
  onDragEnd: () => {},
  checkLoaderVisibility: () => true,
  sortStage: () => {},
  draftJobsSortedBy: 'none',
  postedJobsSortedBy: 'none',
  qualifiedJobsSortedBy: 'none',
  presentedJobsSortedBy: 'none',
  closedJobsSortedBy: 'none',
};

export default withStyles()(withTranslate(JobDashboard));
