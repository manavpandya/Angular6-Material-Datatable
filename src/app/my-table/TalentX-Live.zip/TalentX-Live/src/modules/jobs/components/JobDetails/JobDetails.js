import React from 'react';
import PropTypes from 'prop-types';

import RecruiterJob from './RecruiterJob/RecruiterJobContainer';

const JobDetails = props => (
  <RecruiterJob
    chatType={props.chatType}
    showMessageDialog={props.showMessageDialog}
    handlerShowMessageDialog={props.handlerShowMessageDialog}
    handleSubmitMessage={props.handleSubmitMessage}
    job={props.job}
    addNote={props.addNote}
    deleteNote={props.deleteNote}
    newNoteDescription={props.newNoteDescription}
    changeNewNoteDescription={props.changeNewNoteDescription}
  />
);

JobDetails.propTypes = {
  chatType: PropTypes.object,  // eslint-disable-line
  showMessageDialog: PropTypes.bool,
  handlerShowMessageDialog: PropTypes.func,
  handleSubmitMessage: PropTypes.func,
  job: PropTypes.object, // eslint-disable-line
  addNote: PropTypes.func,
  deleteNote: PropTypes.func,
  newNoteDescription: PropTypes.string,
  changeNewNoteDescription: PropTypes.func,
};

JobDetails.defaultProps = {
  chatType: {},
  showMessageDialog: false,
  handlerShowMessageDialog: () => {},
  handleSubmitMessage: () => {},
  job: {},
  addNote: () => {},
  deleteNote: () => { },
  newNoteDescription: '',
  changeNewNoteDescription: () => {},
};

export default JobDetails;
