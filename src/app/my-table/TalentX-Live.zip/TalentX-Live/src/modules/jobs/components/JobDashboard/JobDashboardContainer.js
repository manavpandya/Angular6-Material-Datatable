import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import PropTypes from 'prop-types';
import JobDashboard from './JobDashboard';
import {
  flushAllJobs,
  getDraftedJobs,
  getPostedJobs,
  getQualifiedJobs,
  getPresentedJobs,
  getClosedJobs,
  uploadJob,
  moveJobLocal,
  moveJob,
  getJobtemplate,
  setSortedState,
} from '../../redux/actions';
import { showNotification } from '../../../../utils/Notifications';

const pageSize = 10;

class JobDashboardContainer extends Component {
  constructor(props) {
    super(props);
    this.onDragEnd = this.onDragEnd.bind(this);
    this.getNextPage = this.getNextPage.bind(this);
    this.checkLoaderVisibility = this.checkLoaderVisibility.bind(this);
    this.refresh = this.refresh.bind(this);
    this.sortStage = this.sortStage.bind(this);
  }

  onDragEnd(result) {
    // result.source.droppableId - will give us source stage's Id
    // result.destination.droppableId - will give us destination stage's Id
    // result.draggableId - will give us currently dragged element's Id (job's Id in this case)

    // dropped outside the list
    if (!result.destination) {
      return;
    }

    if (result.destination.droppableId === result.source.droppableId) {
      return;
    }

    this.props.moveJobLocal(
      result.draggableId,
      result.source.droppableId,
      result.destination.droppableId,
    );

    this.props.moveJob(
      result.draggableId,
      result.source.droppableId,
      result.destination.droppableId,
    ).then(() => {
      // never do flushAllJobs here. It will give you unexpected results.
      showNotification(this.props.translate('positionChanges'), 'success', 8000);
      setTimeout(() => {
        this.refresh(result.source.droppableId);
        this.refresh(result.destination.droppableId);
      }, 500);
    }).catch((err) => {
      showNotification(err.message, 'error', 8000);
    });
  }

  getNextPage(stageKey) {
    if (!this.props.isMoving) {
      switch (stageKey) {
        case 'draft':
          this.props.getDraftedJobs(
            this.props.draftedJobsCurrentPage + 1,
            this.props.draftJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
            10,
            this.props.searchedLocation,
          );
          break;
        case 'posted':
          this.props.getPostedJobs(
            this.props.postedJobsCurrentPage + 1,
            this.props.postedJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
            10,
            this.props.searchedLocation,
          );
          break;
        case 'qualified':
          this.props.getQualifiedJobs(
            this.props.qualifiedJobsCurrentPage + 1,
            this.props.qualifiedJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
            10,
            this.props.searchedLocation,
          );
          break;
        case 'presented':
          this.props.getPresentedJobs(
            this.props.presentedJobsCurrentPage + 1,
            this.props.presentedJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
            10,
            this.props.searchedLocation,
          );
          break;
        case 'closed':
          this.props.getClosedJobs(
            this.props.closedJobsCurrentPage + 1,
            this.props.closedJobsSortedBy,
            this.props.searchedEmployer,
            this.props.searchedJobTitle,
            10,
            this.props.searchedLocation,
          );
          break;
        default:
          break;
      }
    }
  }

  refresh(sourceOrDestination) {
    switch (sourceOrDestination) {
      case 'draft':
        this.props.getDraftedJobs(1, this.props.draftJobsSortedBy);
        break;
      case 'posted':
        this.props.getPostedJobs(1, this.props.postedJobsSortedBy);
        break;
      case 'qualified':
        this.props.getQualifiedJobs(1, this.props.qualifiedJobsSortedBy);
        break;
      case 'presented':
        this.props.getPresentedJobs(1, this.props.presentedJobsSortedBy);
        break;
      case 'closed':
        this.props.getClosedJobs(1, this.props.closedJobsSortedBy);
        break;
      default:
        break;
    }
  }

  checkLoaderVisibility(stageKey) {
    switch (stageKey) {
      case 'draft':
        return this.props.draftedJobsCurrentPage === 0
          ? true
          : (this.props.totalDraftedJobs / (this.props.draftedJobsCurrentPage * pageSize)) > 1;
      case 'posted':
        return this.props.postedJobsCurrentPage === 0
          ? true
          : (this.props.totalPostedJobs /
              (this.props.postedJobsCurrentPage * pageSize)) > 1;
      case 'qualified':
        return this.props.qualifiedJobsCurrentPage === 0
          ? true
          : (this.props.totalQualifiedJobs /
              (this.props.qualifiedJobsCurrentPage * pageSize)) > 1;
      case 'presented':
        return this.props.presentedJobsCurrentPage === 0
          ? true
          : (this.props.totalPresentedJobs /
              (this.props.presentedJobsCurrentPage * pageSize)) > 1;
      case 'closed':
        return this.props.closedJobsCurrentPage === 0
          ? true
          : (this.props.totalClosedJobs /
              (this.props.closedJobsCurrentPage * pageSize)) > 1;
      default:
        return true;
    }
  }

  sortStage(key, sortBy) {
    const { searchedEmployer, searchedJobTitle, searchedLocation } = this.props;
    this.props.setSortedState(key, sortBy);
    switch (key) {
      case 'draft':
        this.props.getDraftedJobs(
          1,
          sortBy,
          searchedEmployer,
          searchedJobTitle,
          10,
          searchedLocation,
        );
        break;
      case 'posted':
        this.props.getPostedJobs(
          1,
          sortBy,
          searchedEmployer,
          searchedJobTitle,
          10,
          searchedLocation,
        );
        break;
      case 'qualified':
        this.props.getQualifiedJobs(
          1,
          sortBy,
          searchedEmployer,
          searchedJobTitle,
          10,
          searchedLocation,
        );
        break;
      case 'presented':
        this.props.getPresentedJobs(
          1,
          sortBy,
          searchedEmployer,
          searchedJobTitle,
          10,
          searchedLocation,
        );
        break;
      case 'closed':
        this.props.getClosedJobs(
          1,
          sortBy,
          searchedEmployer,
          searchedJobTitle,
          10,
          searchedLocation,
        );
        break;
      default:
        break;
    }
  }

  render() {
    return (
      <JobDashboard
        flushAllJobs={this.props.flushAllJobs}
        draftedJobs={this.props.draftedJobs}
        draftedJobsCurrentPage={this.props.draftedJobsCurrentPage}
        totalDraftedJobs={this.props.totalDraftedJobs}
        draftedJobsLoading={this.props.draftedJobsLoading}
        postedJobs={this.props.postedJobs}
        postedJobsCurrentPage={this.props.postedJobsCurrentPage}
        totalPostedJobs={this.props.totalPostedJobs}
        postedJobsLoading={this.props.postedJobsLoading}
        qualifiedJobs={this.props.qualifiedJobs}
        qualifiedJobsCurrentPage={this.props.qualifiedJobsCurrentPage}
        totalQualifiedJobs={this.props.totalQualifiedJobs}
        qualifiedJobsLoading={this.props.qualifiedJobsLoading}
        presentedJobs={this.props.presentedJobs}
        presentedJobsCurrentPage={this.props.presentedJobsCurrentPage}
        totalPresentedJobs={this.props.totalPresentedJobs}
        presentedJobsLoading={this.props.presentedJobsLoading}
        closedJobs={this.props.closedJobs}
        closedJobsCurrentPage={this.props.closedJobsCurrentPage}
        totalClosedJobs={this.props.totalClosedJobs}
        closedJobsLoading={this.props.closedJobsLoading}
        onDragEnd={this.onDragEnd}
        getNextPage={this.getNextPage}
        checkLoaderVisibility={this.checkLoaderVisibility}
        sortStage={this.sortStage}
        draftJobsSortedBy={this.props.draftJobsSortedBy}
        postedJobsSortedBy={this.props.postedJobsSortedBy}
        qualifiedJobsSortedBy={this.props.qualifiedJobsSortedBy}
        presentedJobsSortedBy={this.props.presentedJobsSortedBy}
        closedJobsSortedBy={this.props.closedJobsSortedBy}
      />
    );
  }
}

JobDashboardContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  flushAllJobs: PropTypes.func,
  getDraftedJobs: PropTypes.func,
  getPostedJobs: PropTypes.func,
  getQualifiedJobs: PropTypes.func,
  getPresentedJobs: PropTypes.func,
  getClosedJobs: PropTypes.func,
  moveJobLocal: PropTypes.func,
  moveJob: PropTypes.func,
  setSortedState: PropTypes.func,
  draftedJobs: PropTypes.arrayOf(PropTypes.object),
  draftedJobsCurrentPage: PropTypes.number,
  totalDraftedJobs: PropTypes.number,
  draftedJobsLoading: PropTypes.bool,
  postedJobs: PropTypes.arrayOf(PropTypes.object),
  postedJobsCurrentPage: PropTypes.number,
  totalPostedJobs: PropTypes.number,
  postedJobsLoading: PropTypes.bool,
  qualifiedJobs: PropTypes.arrayOf(PropTypes.object),
  qualifiedJobsCurrentPage: PropTypes.number,
  totalQualifiedJobs: PropTypes.number,
  qualifiedJobsLoading: PropTypes.bool,
  presentedJobs: PropTypes.arrayOf(PropTypes.object),
  presentedJobsCurrentPage: PropTypes.number,
  totalPresentedJobs: PropTypes.number,
  presentedJobsLoading: PropTypes.bool,
  closedJobs: PropTypes.arrayOf(PropTypes.object),
  closedJobsCurrentPage: PropTypes.number,
  totalClosedJobs: PropTypes.number,
  closedJobsLoading: PropTypes.bool,
  searchedEmployer: PropTypes.string,
  searchedJobTitle: PropTypes.string,
  searchedLocation: PropTypes.string,
  isMoving: PropTypes.bool,
  history: PropTypes.object, // eslint-disable-line
  draftJobsSortedBy: PropTypes.string,
  postedJobsSortedBy: PropTypes.string,
  qualifiedJobsSortedBy: PropTypes.string,
  presentedJobsSortedBy: PropTypes.string,
  closedJobsSortedBy: PropTypes.string,
};

JobDashboardContainer.defaultProps = {
  flushAllJobs: () => {},
  getDraftedJobs: () => {},
  getPostedJobs: () => {},
  getQualifiedJobs: () => {},
  getPresentedJobs: () => {},
  getClosedJobs: () => {},
  moveJobLocal: () => {},
  moveJob: () => {},
  setSortedState: () => {},
  draftedJobs: [],
  draftedJobsCurrentPage: 0,
  totalDraftedJobs: 0,
  draftedJobsLoading: false,
  postedJobs: [],
  postedJobsCurrentPage: 0,
  totalPostedJobs: 0,
  postedJobsLoading: false,
  qualifiedJobs: [],
  qualifiedJobsCurrentPage: 0,
  totalQualifiedJobs: 0,
  qualifiedJobsLoading: false,
  presentedJobs: [],
  presentedJobsCurrentPage: 0,
  totalPresentedJobs: 0,
  presentedJobsLoading: false,
  closedJobs: [],
  closedJobsCurrentPage: 0,
  totalClosedJobs: 0,
  closedJobsLoading: false,
  searchedEmployer: '',
  searchedJobTitle: '',
  searchedLocation: '',
  isMoving: false,
  history: {},
  draftJobsSortedBy: 'none',
  postedJobsSortedBy: 'none',
  qualifiedJobsSortedBy: 'none',
  presentedJobsSortedBy: 'none',
  closedJobsSortedBy: 'none',
};
const mapStateToProps = state => ({
  flushAllJobs: state.recruiter.flushAllJobs,
  draftedJobs: state.recruiter.draftedJobs,
  draftedJobsCurrentPage: state.recruiter.draftedJobsCurrentPage,
  totalDraftedJobs: state.recruiter.totalDraftedJobs,
  draftedJobsLoading: state.recruiter.draftedJobsLoading,
  postedJobs: state.recruiter.postedJobs,
  postedJobsCurrentPage: state.recruiter.postedJobsCurrentPage,
  totalPostedJobs: state.recruiter.totalPostedJobs,
  postedJobsLoading: state.recruiter.postedJobsLoading,
  qualifiedJobs: state.recruiter.qualifiedJobs,
  qualifiedJobsCurrentPage: state.recruiter.qualifiedJobsCurrentPage,
  totalQualifiedJobs: state.recruiter.totalQualifiedJobs,
  qualifiedJobsLoading: state.recruiter.qualifiedJobsLoading,
  presentedJobs: state.recruiter.presentedJobs,
  presentedJobsCurrentPage: state.recruiter.presentedJobsCurrentPage,
  totalPresentedJobs: state.recruiter.totalPresentedJobs,
  presentedJobsLoading: state.recruiter.presentedJobsLoading,
  closedJobs: state.recruiter.closedJobs,
  closedJobsCurrentPage: state.recruiter.closedJobsCurrentPage,
  totalClosedJobs: state.recruiter.totalClosedJobs,
  closedJobsLoading: state.recruiter.closedJobsLoading,
  searchedEmployer: state.recruiter.searchedEmployer,
  searchedJobTitle: state.recruiter.searchedJobTitle,
  searchedLocation: state.recruiter.searchedLocation,
  uploadJobLoading: state.recruiter.uploadJobLoading,
  jobTemplates: state.recruiter.jobTemplates,
  noTemplatesData: state.recruiter.noTemplatesData,
  isMoving: state.recruiter.isMoving,
  draftJobsSortedBy: state.recruiter.draftJobsSortedBy,
  postedJobsSortedBy: state.recruiter.postedJobsSortedBy,
  qualifiedJobsSortedBy: state.recruiter.qualifiedJobsSortedBy,
  presentedJobsSortedBy: state.recruiter.presentedJobsSortedBy,
  closedJobsSortedBy: state.recruiter.closedJobsSortedBy,
  jobApplicationCount: state.recruiter.jobApplicationCount,
});

const mapDispatchToProps = dispatch => ({
  flushAllJobs: () =>
    dispatch(flushAllJobs()),
  getDraftedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getDraftedJobs(pageNo, sortBy, employer, key, perPage)),
  getPostedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getPostedJobs(pageNo, sortBy, employer, key, perPage, location)),
  getQualifiedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getQualifiedJobs(pageNo, sortBy, employer, key, perPage, location)),
  getPresentedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getPresentedJobs(pageNo, sortBy, employer, key, perPage, location)),
  getClosedJobs: (pageNo, sortBy, employer, key, perPage, location) =>
    dispatch(getClosedJobs(pageNo, sortBy, employer, key, perPage, location)),
  uploadJob: data => dispatch(uploadJob(data)),
  getJobtemplate: key => dispatch(getJobtemplate(key)),
  moveJobLocal: (jobId, source, destination) => dispatch(moveJobLocal(jobId, source, destination)),
  moveJob: (jobId, source, destination) => dispatch(moveJob(jobId, source, destination)),
  setSortedState: (key, value) => dispatch(setSortedState(key, value)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(JobDashboardContainer)));// eslint-disable-line
