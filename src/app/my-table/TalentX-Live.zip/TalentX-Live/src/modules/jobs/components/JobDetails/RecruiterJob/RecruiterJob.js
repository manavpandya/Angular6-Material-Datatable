import React, { Fragment } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
// import Gauge from 'react-svg-gauge';

import Divider from 'material-ui/Divider';
// import Badge from 'material-ui/Badge';
// import NotificationIcon from 'material-ui-icons/Notifications';
import InfoIcon from 'material-ui-icons/InfoOutline';
import Button from 'material-ui/Button';
import JobHeader from '../JobHeader';
import JobPipeline from '../JobPipeline';
// import JobNotifications from '../JobNotifications';
import JobDashboard from '../JobDashboard';
import TabHeader from '../TabHeader';
import CandidateListContainer from '../../../../../shared/compound/CandidateList/CandidateListContainer';
import CandidateActions from '../../CandidateActions';
import BoardHeader from '../../../../../shared/compound/board/BoardHeader';
import { formatMatched } from '../../../../../utils';
import getTabs from './tabs';

const FormatCandidateProfile = profile => ({
  company: profile.company || '-',
  id: profile.id,
  job_title: profile.job_title || '-',
  location: profile.location || '-',
  name: profile.name || '-',
  matchPercent: 88,
  contact_methods: profile.contact_methods,
  is_bookmarked: profile.is_bookmarked || false,
});

const setSelectedSubTabKey = (
  key,
  steps,
  currentSubTabKeys,
  setCurrentSubTabKey,
  setCurrentSubTabKeys,
) => {
  setCurrentSubTabKey(key);
  setCurrentSubTabKeys([
    ...currentSubTabKeys.filter(step => !steps.map(s => s.originalKey).includes(step)),
    key,
  ]);
};

const onTabClick = (
  tabs,
  currentTabLabel,
  setCurrentTabKey,
  setCurrentSubTabKey,
  currentSubTabKeys,
  flushCandidates,
) => {
  if (flushCandidates) flushCandidates();
  setCurrentTabKey(currentTabLabel, tabs.find(tab => tab.originalKey === currentTabLabel).countKey);
  const selectedSubTab = tabs.find(tab => tab.originalKey === currentTabLabel)
    .steps.find(innerTab => currentSubTabKeys.includes(innerTab.originalKey))
    || tabs.find(tab => tab.originalKey === currentTabLabel).steps[0];
  setCurrentSubTabKey(
    selectedSubTab.originalKey,
    selectedSubTab.countKey,
    () => {
      selectedSubTab.getData();
    },
  );
};

// this function is used to getMenuItems for candidates in SelectedSubTab from tabs
const getMenuItems = (tabs, currentTabLabel, currentSubTabKeys, isBulk) => {
  if (currentTabLabel === '') {
    return [];
  }
  const selectedSubTab = tabs.find(tab => tab.originalKey === currentTabLabel)
    .steps.find(innerTab => currentSubTabKeys.includes(innerTab.originalKey))
    || tabs.find(tab => tab.originalKey === currentTabLabel).steps[0];
  return isBulk ? selectedSubTab.bulkMenuItems : selectedSubTab.menuItems;
};


const RecruiterJob = (props) => {
  const tabs = getTabs({
    translate: props.translate,
    getMatchedCandidates: props.getMatchedCandidates,
    getCandidates: props.getCandidates,
    shortlistJobApplication: props.shortlistJobApplication,
    shortlistBulkApplication: props.shortlistBulkApplication,
    moveBulkApplication: props.moveBulkApplication,
    moveJobApplication: props.moveJobApplication,
    deleteJobApplication: props.deleteJobApplication,
    deleteJobApplicationBulk: props.deleteJobApplicationBulk,
    currentJobId: props.job.id,
    jobApplicationCount: props.jobApplicationCount,
    openAddToJobDialog: props.openAddToJobDialog,
    customerPage: props.customerPage,
  });
  return (
    Object.keys(props.job).length > 0
      ?
        <Fragment>
          <BoardHeader />
          <div className="page job">
            <Divider />
            <main>
              <JobPipeline
                resetFilterParamsMatched={props.resetFilterParamsMatched}
                fetchFacetMatched={props.fetchFacetMatched}
                jobData={props.job}
                tabs={tabs}
                selectAllCandidates={props.selectAllCandidates}
                candidatesLoading={props.candidatesLoading}
                summary={
                  <JobHeader
                    job={props.job}
                    locale={props.locale}
                    candidatesLoading={props.candidatesLoading}
                    customerPage={props.customerPage}
                  />
                }
                header={{
                  // details: (
                  //   <Badge badgeContent={props.job.notification || 5} className="notification">
                  //     <NotificationIcon className="header-icon" />
                  //   </Badge>
                  // ),
                  notifications: (
                    <Button className="pipeline-tab"><InfoIcon className="header-icon" /></Button>
                  ),
                  interview: (
                    <Button
                      className="pipeline-tab"
                      role="presentation"
                      onClick={() => {
                        onTabClick(tabs, 'interview', props.setCurrentTabKey, props.setCurrentSubTabKey, props.currentSubTabKeys, props.flushCandidates);
                      }}
                      onKeyDown={() => {}}
                    >
                      {/* <Gauge
                        value={props.job.find || 0}
                        width={50}
                        height={50}
                        label=""
                        color="green"
                        topLabelStyle={{ fontSize: 12, transform: 'translate(0px, 5px)' }}
                        minMaxLabelStyle={{ display: 'none' }}
                      /> */}
                      <p>
                        <span>
                          {props.translate('interview')}
                        </span>
                        <small>
                          {props.translate('presented')}&nbsp;
                          <strong>
                            {
                              props.jobApplicationCount && props.jobApplicationCount.Shortlist
                              && (
                                props.jobApplicationCount.Shortlist.Matched ||
                                props.jobApplicationCount.Shortlist.Matched === 0
                              )
                                ? formatMatched(props.jobApplicationCount.Shortlist.Matched)
                              : '-'
                            }
                          </strong>
                        </small>
                      </p>
                    </Button>
                  ),
                  offer: (
                    <Button
                      className="pipeline-tab"
                      role="presentation"
                      onClick={() => {
                        onTabClick(tabs, 'offer', props.setCurrentTabKey, props.setCurrentSubTabKey, props.currentSubTabKeys, props.flushCandidates);
                      }}
                      onKeyDown={() => {}}
                    >
                      {/* <Gauge
                        value={props.job.find || 0}
                        width={50}
                        height={50}
                        label=""
                        color="green"
                        topLabelStyle={{ fontSize: 12, transform: 'translate(0px, 5px)' }}
                        minMaxLabelStyle={{ display: 'none' }}
                      /> */}
                      <p>
                        <span>
                          {props.translate('offer')}
                        </span>
                        <small>
                          {props.translate('interviewed')}&nbsp;
                          <strong>
                            {
                              props.jobApplicationCount && props.jobApplicationCount.Shortlist
                              && (
                                props.jobApplicationCount.Shortlist.Matched ||
                                props.jobApplicationCount.Shortlist.Matched === 0
                              )
                                ? formatMatched(props.jobApplicationCount.Shortlist.Matched)
                              : '-'
                            }
                          </strong>
                        </small>
                      </p>
                    </Button>
                  ),
                  accepted: (
                    <Button
                      className="pipeline-tab"
                      role="presentation"
                      onClick={() => {
                        onTabClick(tabs, 'accepted', props.setCurrentTabKey, props.setCurrentSubTabKey, props.currentSubTabKeys, props.flushCandidates);
                      }}
                      onKeyDown={() => {}}
                    >
                      {/* <Gauge
                        value={props.job.find || 0}
                        width={50}
                        height={50}
                        label=""
                        color="green"
                        topLabelStyle={{ fontSize: 12, transform: 'translate(0px, 5px)' }}
                        minMaxLabelStyle={{ display: 'none' }}
                      /> */}
                      <p>
                        <span>
                          {props.translate('Hire')}
                        </span>
                        <small>
                          {props.translate('offered')}&nbsp;
                          <strong>
                            {
                              props.jobApplicationCount && props.jobApplicationCount.Shortlist
                              && (
                                props.jobApplicationCount.Shortlist.Matched ||
                                props.jobApplicationCount.Shortlist.Matched === 0
                              )
                                ? formatMatched(props.jobApplicationCount.Shortlist.Matched)
                              : '-'
                            }
                          </strong>
                        </small>
                      </p>
                    </Button>
                  ),
                  shortlist: (
                    <Button
                      className="pipeline-tab"
                      role="presentation"
                      onClick={() => {
                        if (props.currentTabKey !== 'shortlist') {
                          onTabClick(tabs, 'shortlist', props.setCurrentTabKey, props.setCurrentSubTabKey, props.currentSubTabKeys, props.flushCandidates);
                        }
                      }}
                      onKeyDown={() => {}}
                    >
                      {/* <Gauge
                        value={props.job.find || 0}
                        width={50}
                        height={50}
                        label=""
                        color="green"
                        topLabelStyle={{ fontSize: 12, transform: 'translate(0px, 5px)' }}
                        minMaxLabelStyle={{ display: 'none' }}
                      /> */}
                      <p>
                        <span>
                          {props.translate('shortlist')}
                        </span>
                        <small>
                          {props.translate('matched')}&nbsp;
                          <strong>
                            {
                              props.jobApplicationCount && props.jobApplicationCount.Shortlist
                              && (
                                props.jobApplicationCount.Shortlist.Matched ||
                                props.jobApplicationCount.Shortlist.Matched === 0
                              )
                                ? formatMatched(props.jobApplicationCount.Shortlist.Matched)
                              : '-'
                            }
                          </strong>
                        </small>
                      </p>
                    </Button>
                  ),
                  qualify: (
                    <Button
                      className="pipeline-tab"
                      role="presentation"
                      onClick={() => {
                        if (props.currentTabKey !== 'qualify') {
                          onTabClick(tabs, 'qualify', props.setCurrentTabKey, props.setCurrentSubTabKey, props.currentSubTabKeys, props.flushCandidates);
                        }
                        }}
                      onKeyDown={() => { }}
                    >
                      {/* <Gauge
                        value={props.job.qualify || 0}
                        width={50}
                        height={50}
                        label=""
                        color="gold"
                        topLabelStyle={{ fontSize: 12, transform: 'translate(0px, 5px)' }}
                        minMaxLabelStyle={{ display: 'none' }}
                      /> */}
                      <p>
                        <span>
                          {props.translate('qualify')}
                        </span>
                        <small>
                          {props.translate('shortlisted')}&nbsp;
                          <strong>
                            {
                              props.jobApplicationCount && props.jobApplicationCount.Qualify
                                && (
                                  props.jobApplicationCount.Qualify.Shortlisted ||
                                  props.jobApplicationCount.Qualify.Shortlisted === 0
                                )
                                ? props.jobApplicationCount.Qualify.Shortlisted
                                : '-'
                            }
                          </strong>
                        </small>
                      </p>
                    </Button>
                  ),
                  present: (
                    <Button
                      className="pipeline-tab"
                      role="presentation"
                      onClick={() => {
                        if (props.currentTabKey !== 'present') {
                          onTabClick(tabs, 'present', props.setCurrentTabKey, props.setCurrentSubTabKey, props.currentSubTabKeys, props.flushCandidates);
                        }
                      }}
                      onKeyDown={() => { }}
                    >
                      {/* <Gauge
                        value={props.job.present || 0}
                        width={50}
                        height={50}
                        label=""
                        color="green"
                        topLabelStyle={{ fontSize: 12, transform: 'translate(0px, 5px)' }}
                        minMaxLabelStyle={{ display: 'none' }}
                      /> */}
                      <p>
                        <span>
                          {props.translate('present')}
                        </span>
                        <small>
                          {props.translate('qualified')}&nbsp;
                          <strong>
                            {
                              props.jobApplicationCount && props.jobApplicationCount.Present
                                && (
                                  props.jobApplicationCount.Present.Qualified ||
                                  props.jobApplicationCount.Present.Qualified === 0
                                )
                                ? props.jobApplicationCount.Present.Qualified
                                : '-'
                            }
                          </strong>
                        </small>
                      </p>
                    </Button>
                  ),
                  // hiring: (
                  //   <div
                  //     className="pipeline-tab"
                  //     role="presentation"
                  //     onClick={() => {
                  //       onTabClick(tabs, 'hiring', props.setCurrentTabKey,
                  //          props.setCurrentSubTabKey, props.currentSubTabKeys);
                  //     }}
                  //     onKeyDown={() => { }}
                  //   >
                  //     <Gauge
                  //       value={props.job.hired || 0}
                  //       width={50}
                  //       height={50}
                  //       label=""
                  //       color="green"
                  //       topLabelStyle={{ fontSize: 12, transform: 'translate(0px, 5px)' }}
                  //       minMaxLabelStyle={{ display: 'none' }}
                  //     />
                  //     <p>
                  //       <span>
                  //         Hiring
                  //       </span>
                  //       <small>
                  //         Hired&nbsp;
                  //         <strong>5</strong>
                  //       </small>
                  //     </p>
                  //   </div>
                  // ),
                }}
                content={{
                  // details: (
                  //   <JobNotifications
                  //     job={props.job}
                  //     addNote={props.addNote}
                  //     deleteNote={props.deleteNote}
                  //     newNoteDescription={props.newNoteDescription}
                  //     changeNewNoteDescription={props.changeNewNoteDescription}
                  //   />
                  // ),
                  notifications: (
                    <JobDashboard
                      job={props.job}
                      downloadFile={props.downloadFile}
                    />
                  ),
                  [props.currentTabKey]: (
                    <CandidateListContainer
                      recruiterJobPage
                      chatType={props.chatType}
                      handleSubmitMessage={props.handleSubmitMessage}
                      showMessageDialog={props.showMessageDialog}
                      handlerShowMessageDialog={props.handlerShowMessageDialog}
                      tabs={tabs}
                      candidates={
                        props.matchedCandidates.profiles
                        || (props.jobApplicationList.applications
                          && props.jobApplicationList.applications.map((application) => {
                          const { profile } = application;
                          return {
                            ...FormatCandidateProfile(profile),
                            parentId: application.id,
                          };
                        }))
                      }
                      totalCandidates={
                        (
                          props.jobApplicationCount
                          && props.jobApplicationCount[props.currentTabCountKey]
                          && props.jobApplicationCount[props.currentTabCountKey][props.currentSubTabCountKey] // eslint-disable-line
                        ) || 0
                      }
                      totalMatchedCandidates={props.totalMatchedCandidates}
                      // selectedCandidates={props.selectedCandidates}
                      filters={
                        <TabHeader
                          filterParamMatched={props.filterParamMatched}
                          totalMatchedCandidates={props.totalMatchedCandidates}
                          tabs={tabs}
                          flushAllData={props.flushCandidates}
                          currentSubTabKeys={props.currentSubTabKeys}
                          setSelectedSubTabKey={(key, steps) =>
                            setSelectedSubTabKey(
                              key,
                              steps,
                              props.currentSubTabKeys,
                              props.setCurrentSubTabKey,
                              props.setCurrentSubTabKeys,
                            )}
                          step={props.currentTabKey}
                        >
                          <CandidateActions
                            menuItems={getMenuItems(
                              tabs,
                              props.currentTabKey,
                              props.currentSubTabKeys,
                              true,
                            )}
                            bulkAction
                            selectedCandidates={props.selectedCandidates}
                            isDisabled={props.job.status === 'closed' ? true : props.selectedCandidates.length === 0}
                          />
                        </TabHeader>
                      }
                      getMenuItems={getMenuItems}
                      currentTabKey={props.currentTabKey}
                      currentSubTabKey={props.currentSubTabKey}
                      currentSubTabKeys={props.currentSubTabKeys}
                      pagination={props.pagination}
                      setPagination={props.setPagination}
                      job={props.job}
                    />
                  ),
                }}
              />
              <Divider />
            </main>
          </div>
        </Fragment>
      : <div />
  );
};

RecruiterJob.propTypes = {
  locale: PropTypes.string,
  translate: PropTypes.func.isRequired,
  job: PropTypes.instanceOf(Object).isRequired,
  // addNote: PropTypes.func,
  // deleteNote: PropTypes.func,
  // newNoteDescription: PropTypes.string,
  // changeNewNoteDescription: PropTypes.func,
  getMatchedCandidates: PropTypes.func,
  matchedCandidates: PropTypes.instanceOf(Object),
  getCandidates: PropTypes.func,
  jobApplicationList: PropTypes.instanceOf(Object),
  flushCandidates: PropTypes.func,
  showMessageDialog: PropTypes.bool,
  handlerShowMessageDialog: PropTypes.func,
  handleSubmitMessage: PropTypes.func,
  chatType: PropTypes.instanceOf(Object).isRequired,
  shortlistJobApplication: PropTypes.func,
  shortlistBulkApplication: PropTypes.func,
  moveBulkApplication: PropTypes.func,
  moveJobApplication: PropTypes.func,
  deleteJobApplication: PropTypes.func,
  deleteJobApplicationBulk: PropTypes.func,
  selectedCandidate: PropTypes.instanceOf(Object), //eslint-disable-line
  pagination: PropTypes.objectOf(PropTypes.object),
  setPagination: PropTypes.func,
  currentTabKey: PropTypes.string,
  currentTabCountKey: PropTypes.string,
  currentSubTabKey: PropTypes.string,
  currentSubTabKeys: PropTypes.arrayOf(PropTypes.string),
  currentSubTabCountKey: PropTypes.string,
  setCurrentTabKey: PropTypes.func,
  setCurrentSubTabKey: PropTypes.func,
  setCurrentSubTabKeys: PropTypes.func,
  jobApplicationCount: PropTypes.instanceOf(Object),
  openAddToJobDialog: PropTypes.func,
  downloadFile: PropTypes.func,
  totalMatchedCandidates: PropTypes.number.isRequired,
  resetFilterParamsMatched: PropTypes.func,
  fetchFacetMatched: PropTypes.func,
  filterParamMatched: PropTypes.string,
  candidatesLoading: PropTypes.bool,
  selectedCandidates: PropTypes.arrayOf(PropTypes.any),
  selectAllCandidates: PropTypes.func,
  customerPage: PropTypes.bool,
};

RecruiterJob.defaultProps = {
  locale: '',
  // addNote: () => {},
  // newNoteDescription: '',
  // deleteNote: () => { },
  // changeNewNoteDescription: () => {},
  getMatchedCandidates: () => {},
  matchedCandidates: {},
  getCandidates: () => {},
  jobApplicationList: {},
  flushCandidates: () => {},
  showMessageDialog: false,
  handlerShowMessageDialog: () => {},
  handleSubmitMessage: () => {},
  shortlistJobApplication: () => {},
  shortlistBulkApplication: () => {},
  moveBulkApplication: () => {},
  moveJobApplication: () => {},
  deleteJobApplication: () => { },
  deleteJobApplicationBulk: () => { },
  selectedCandidate: {},
  pagination: {},
  setPagination: () => {},
  currentTabKey: '',
  currentTabCountKey: '',
  currentSubTabKey: '',
  currentSubTabKeys: [],
  currentSubTabCountKey: '-',
  setCurrentTabKey: () => {},
  setCurrentSubTabKey: () => {},
  setCurrentSubTabKeys: () => {},
  downloadFile: () => {},
  jobApplicationCount: {},
  openAddToJobDialog: () => {},
  resetFilterParamsMatched: () => {},
  fetchFacetMatched: () => {},
  filterParamMatched: '',
  candidatesLoading: false,
  selectedCandidates: [],
  selectAllCandidates: () => {},
  customerPage: false,
};

export default withTranslate(RecruiterJob);
