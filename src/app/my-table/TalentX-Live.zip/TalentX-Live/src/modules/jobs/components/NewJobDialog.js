import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import TextField from 'material-ui/TextField';
import Dialog, { DialogActions } from 'material-ui/Dialog';
import Slide from 'material-ui/transitions/Slide';
import AddIcon from 'material-ui-icons/Add';

const styles = {
  appBar: {
    position: 'relative',
  },
  flex: {
    flex: 1,
  },
};

function Transition(props) {
  return <Slide direction="up" {...props} />;
}

class NewJobDialog extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      open: false,
      active_tab: null,
    };

    this.handleClickOpen = this.handleClickOpen.bind(this);
    this.handleTabClick = this.handleTabClick.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }

  handleClickOpen() {
    this.setState({ open: true });
  }

  handleTabClick(tab) {
    this.setState({ active_tab: tab });
  }

  handleClose() {
    this.setState({ open: false });
  }

  render() {
    return (
      <div>
        <Button onClick={this.handleClickOpen} style={{ color: '#3598df' }}>
          <AddIcon style={{ color: '#3598df', width: '1rem', height: '1rem' }} />
          <h3 style={{ margin: 0 }}>New</h3>
        </Button>
        <Dialog open={this.state.open} transition={Transition}>
          <h2>Create New Job</h2>
          <div>
            <div>
              <TextField type="text" label="Search existing Templates ..." />
            </div>
            <br />
            <h2>Create a new job</h2>
            <div className="tabs">
              <ul className="tab-header">
                <li className={this.state.active_tab === null ? 'active' : ''}>
                  <Button onClick={() => this.handleTabClick(null)}>
                    Upload
                  </Button>
                </li>
                <li className={this.state.active_tab === 'TextInput' ? 'active' : ''}>
                  <Button id="TextInput" onClick={() => this.handleTabClick('TextInput')}>
                    Text Input
                  </Button>
                </li>
                <li className={this.state.active_tab === 'Blank' ? 'active' : ''}>
                  <Button id="Blank" onClick={() => this.handleTabClick('Blank')}>
                    Blank Job
                  </Button>
                </li>
              </ul>
              <div className="tab-content">
                <div className={this.state.active_tab === null ? 'active' : ''}>
                  Upload
                </div>
                <div className={this.state.active_tab === 'TextInput' ? 'active' : ''}>
                  Text Input
                </div>
                <div className={this.state.active_tab === 'Blank' ? 'active' : ''}>
                  Blank Job
                </div>
              </div>
            </div>
          </div>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary" autoFocus>
              Cancel
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

NewJobDialog.propTypes = {
  classes: PropTypes.object.isRequired, // eslint-disable-line
};

export default withStyles(styles)(NewJobDialog);
