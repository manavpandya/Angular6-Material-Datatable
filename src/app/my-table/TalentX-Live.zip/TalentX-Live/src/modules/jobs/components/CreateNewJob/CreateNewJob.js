import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { Form, Field, reduxForm, submit } from 'redux-form';
import { Link } from 'react-router-dom';
import { TextField } from 'redux-form-material-ui';
import Button from 'material-ui/Button';
import Dropzone from 'react-dropzone';
import Paper from 'material-ui/Paper';
import { required } from '../../../../utils/validators';
import Loader from '../../../../shared/basic/Loader';

const CreateNewJob = props => (
  <div>
    {
      props.uploadJobLoading && <Loader />
    }
    <div className="hide-scroll-dialog">
      <div>
        <div className="new-job-welcome">
          <main>
            <div className="search">
              <TextField
                name="searchTemplate"
                type="text"
                label={props.translate('searchTemplate')}
                onChange={props.searchTemplate}
              />
            </div>
            <header className="templates-header">
              <h3>{ props.translate('recommendedTemplate')}</h3>
            </header>
            {props.noTemplatesData && props.jobTemplates.length === 0 ? <span className="no-results-span">{ props.translate('noResultFound')}  </span> : ' '}
            <div className="templates">
              {props.jobTemplates.map(template => (
                <Paper
                  key={template.job_title}
                  elevation={1}
                  className="templates-paper color-grey"
                  onClick={() => props.openTemplate(template)}
                >
                  <h2>{template.job_title}</h2>
                  {template.executive_type ? <h6>{template.executive_type}</h6> : ''}
                  <h3>{template.employer}</h3>
                </Paper>))}
            </div>
          </main>
          <aside>
            <div className="upload">
              <h2> {props.translate('uploadModel')}</h2>
              <div className="tabs">
                <ul className="tab-header">
                  <li className={props.activeTab === 'a' ? 'active' : ''}>
                    <Button onClick={() => props.changeActiveTab('a')}>
                      {props.translate('fileUpload')}
                    </Button>
                  </li>
                  <li className={props.activeTab === 'b' ? 'active' : ''}>
                    <Button onClick={() => props.changeActiveTab('b')}>
                      {props.translate('textUpload')}
                    </Button>
                  </li>
                </ul>
                <div className="tab-content">
                  <div className={`dropzone-div new-job-dropzone ${props.activeTab === 'a' ? 'active' : ''}`}>
                    <Dropzone
                      multiple={false}
                      onDrop={props.onDropFiles}
                      accept=".doc,.pdf"
                    >
                      <p>
                        {props.translate('uploadMessage')}
                      </p>
                    </Dropzone>
                    <div>{props.translate('droppedFiles')}</div>
                    <span>
                      {
                        props.files.map(f =>
                          <li key={f.name}>{f.name} - {f.size} {props.translate('droppedBytes')} </li>)
                      }
                    </span>
                  </div>

                  <div className={props.activeTab === 'b' ? 'active' : ''}>
                    <Form onSubmit={props.handleSubmit(props.textInputJob)}>
                      <Field
                        name="jobInput"
                        component={TextField}
                        validate={required}
                        id="jobInput"
                        multiline
                        rows={5}
                        label={props.translate('jobInput')}
                        fullWidth
                      />
                    </Form>
                  </div>
                  <br />
                  {
                    props.activeTab === 'a'
                      ? (
                        <Button
                          className={`upload-button btn ${props.files.length > 0 ? 'btn-primary' : ' '}`}
                          color="primary"
                          disabled={!(props.files.length > 0)}
                          onClick={props.uploadJob}
                        >
                          {props.translate('uploadJob')}
                        </Button>
                      )
                    : (
                      <Button
                        type="submit"
                        color="primary"
                        className={`upload-button btn ${props.valid ? 'btn-primary' : ' '}`}
                        disabled={!props.valid}
                        onClick={() => props.dispatch(submit('newJobForm'))}
                      >
                        {props.translate('uploadModel')}
                      </Button>
                    )
                  }
                </div>
              </div>
            </div>
            <div className="blank">
              <Link
                className="btn btn-primary"
                to="/recruiter/jobs/new"
                onClick={props.closePostJob}
              >
                {props.translate('startFresh')}
              </Link>
            </div>
          </aside>
        </div>
      </div>
    </div>
  </div>
);

CreateNewJob.propTypes = {
  translate: PropTypes.func.isRequired,
  noTemplatesData: PropTypes.bool,
  jobTemplates: PropTypes.arrayOf(PropTypes.object),
  searchTemplate: PropTypes.func,
  activeTab: PropTypes.string,
  changeActiveTab: PropTypes.func,
  onDropFiles: PropTypes.func,
  files: PropTypes.array, // eslint-disable-line
  uploadJob: PropTypes.func,
  textInputJob: PropTypes.func,
  closePostJob: PropTypes.func,
  handleSubmit: PropTypes.func.isRequired,
  valid: PropTypes.bool.isRequired,
  dispatch: PropTypes.func,
  uploadJobLoading: PropTypes.bool,
};

CreateNewJob.defaultProps = {
  noTemplatesData: false,
  jobTemplates: [],
  searchTemplate: () => {},
  activeTab: 'a',
  changeActiveTab: () => {},
  onDropFiles: () => {},
  files: [],
  uploadJob: () => {},
  textInputJob: () => {},
  closePostJob: () => {},
  dispatch: () => {},
  uploadJobLoading: false,
};

export default reduxForm({ form: 'newJobForm' })(withTranslate(CreateNewJob));
