import {
  ShortlistMatchedMenuItems,
  QualifyShortlistedMenuItems,
  QualifyRejectedMenuItems,
  PresentQualifiedMenuItems,
  PresentPresentedMenuItems,
  ShortlistMatchedBulkMenuItems,
  QualifyShortlistedBulkMenuItems,
  QualifyRejectedBulkMenuItems,
  PresentQualifiedBulkMenuItems,
  PresentPresentedBulkMenuItems,
} from './menuItems';

const commonProps = props => ({
  translate: props.translate,
  shortlistApplication: props.shortlistJobApplication,
  shortlistBulkApplication: props.shortlistBulkApplication,
  moveBulkApplication: props.moveBulkApplication,
  moveApplication: props.moveJobApplication,
  deleteApplication: props.deleteJobApplication,
  deleteJobApplicationBulk: props.deleteJobApplicationBulk,
  currentCandidate: props.currentCandidate,
  currentJobId: props.currentJobId,
  openAddToJobDialog: props.openAddToJobDialog,
});
const tabs = props => (props.customerPage ? [{
  key: 'notifications',
  originalKey: 'notifications',
  label: 'Notifications',
  steps: [],
},
{
  key: 'interview',
  originalKey: 'interview',
  label: 'Interview',
  countKey: 'Shortlist',
  count: 320,
  steps: [
    {
      key: 'presented',
      originalKey: 'shortlist-matched',
      countKey: 'Presented',
      label: props.translate('presented'),
      count: props.jobApplicationCount && props.jobApplicationCount.Present
        && (
          props.jobApplicationCount.Present.Presented ||
          props.jobApplicationCount.Present.Presented === 0
        )
        ? props.jobApplicationCount.Present.Presented
        : '-',
      getData: () => props.getCandidates('presented'),
      bulkMenuItems: [
        ...PresentPresentedBulkMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('presented'),
        }),
      ],
      menuItems: [
        ...PresentPresentedMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('presented'),
        }),
      ],
    },
    {
      key: 'rejected',
      originalKey: 'qualify-rejected',
      countKey: 'Rejected',
      label: props.translate('rejected'),
      count: props.jobApplicationCount && props.jobApplicationCount.Qualify
          && (
            props.jobApplicationCount.Qualify.Rejected ||
            props.jobApplicationCount.Qualify.Rejected === 0
          )
        ? props.jobApplicationCount.Qualify.Rejected
        : '-',
      getData: () => props.getCandidates('rejected'),
      bulkMenuItems: [
        ...QualifyRejectedBulkMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('rejected'),
        }),
      ],
      menuItems: [
        ...QualifyRejectedMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('rejected'),
        }),
      ],
    },
  ],
},
{
  key: 'offer',
  originalKey: 'offer',
  label: 'Offer',
  countKey: 'Interviewed',
  count: 320,
  steps: [
    {
      key: 'interviewed',
      originalKey: 'qualify-interviewed',
      countKey: 'Rejected',
      label: props.translate('interviewed'),
      count: props.jobApplicationCount && props.jobApplicationCount.Present
          && (
            props.jobApplicationCount.Present.Presented ||
            props.jobApplicationCount.Present.Presented === 0
          )
        ? props.jobApplicationCount.Present.Presented
        : '-',
      getData: () => props.getCandidates('presented'),
      bulkMenuItems: [
        ...PresentPresentedBulkMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('presented'),
        }),
      ],
      menuItems: [
        ...PresentPresentedMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('presented'),
        }),
      ],
    },
    {
      key: 'rejected',
      originalKey: 'qualify-rejected',
      countKey: 'Rejected',
      label: props.translate('rejected'),
      count: props.jobApplicationCount && props.jobApplicationCount.Qualify
            && (
              props.jobApplicationCount.Qualify.Rejected ||
              props.jobApplicationCount.Qualify.Rejected === 0
            )
        ? props.jobApplicationCount.Qualify.Rejected
        : '-',
      getData: () => props.getCandidates('rejected'),
      bulkMenuItems: [
        ...QualifyRejectedBulkMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('rejected'),
        }),
      ],
      menuItems: [
        ...QualifyRejectedMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('rejected'),
        }),
      ],
    },
  ],
},
{
  key: 'accepted',
  originalKey: 'accepted',
  label: 'Interview',
  countKey: 'Shortlist',
  count: 320,
  steps: [
    {
      key: 'presented',
      originalKey: 'shortlist-matched',
      countKey: 'Presented',
      label: props.translate('Offered'),
      count: props.jobApplicationCount && props.jobApplicationCount.Present
        && (
          props.jobApplicationCount.Present.Presented ||
          props.jobApplicationCount.Present.Presented === 0
        )
        ? props.jobApplicationCount.Present.Presented
        : '-',
      getData: () => props.getCandidates('presented'),
      bulkMenuItems: [
        ...PresentPresentedBulkMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('presented'),
        }),
      ],
      menuItems: [
        ...PresentPresentedMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('presented'),
        }),
      ],
    },
    {
      key: 'rejected',
      originalKey: 'qualify-rejected',
      countKey: 'Rejected',
      label: props.translate('Hired'),
      count: props.jobApplicationCount && props.jobApplicationCount.Qualify
          && (
            props.jobApplicationCount.Qualify.Rejected ||
            props.jobApplicationCount.Qualify.Rejected === 0
          )
        ? props.jobApplicationCount.Qualify.Rejected
        : '-',
      getData: () => props.getCandidates('rejected'),
      bulkMenuItems: [
        ...QualifyRejectedBulkMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('rejected'),
        }),
      ],
      menuItems: [
        ...QualifyRejectedMenuItems({
          ...commonProps(props),
          getData: () => props.getCandidates('rejected'),
        }),
      ],
    },
  ],
},
] : [
  // {
  //   key: 'details',
  //   originalKey: 'details',
  //   label: 'Details',
  //   steps: [],
  // },
  {
    key: 'notifications',
    originalKey: 'notifications',
    label: 'Notifications',
    steps: [],
  },
  {
    key: 'shortlist',
    originalKey: 'shortlist',
    label: 'Shortlisted',
    countKey: 'Shortlist',
    count: 320,
    steps: [
      {
        key: 'matched',
        originalKey: 'shortlist-matched',
        countKey: 'Matched',
        label: props.translate('matched'),
        maxDisplayCount: 100,
        count: props.jobApplicationCount && props.jobApplicationCount.Shortlist
          && (
            props.jobApplicationCount.Shortlist.Matched ||
            props.jobApplicationCount.Shortlist.Matched === 0
          )
          ? props.jobApplicationCount.Shortlist.Matched
          : '-',
        getData: () => props.getMatchedCandidates(),
        bulkMenuItems: [
          ...ShortlistMatchedBulkMenuItems({
            ...commonProps(props),
            getData: () => props.getMatchedCandidates(),
          }),
        ],
        menuItems: [
          ...ShortlistMatchedMenuItems({
            ...commonProps(props),
            getData: () => props.getMatchedCandidates(),
          }),
        ],
      },
      // {
      //   key: 'interested',
      //   originalKey: 'shortlist-interested',
      //   label: 'Interested',
      //   count: 200,
      //   getData: () => props.getCandidates('interested'),
      //   menuItems: [
      //     ...ShortlistMenuItems({
      // ...commonProps(props),
      //       getData: () => props.getCandidates('interested'),
      //     }),
      //   ],
      // },
      // {
      //   key: 'reviewLater',
      //   originalKey: 'shortlist-reviewLater',
      //   label: 'Review Later',
      //   count: 15,
      //   getData: () => props.getCandidates('reviewLater'),
      //   menuItems: [
      //     ...ShortlistMenuItems({
      // ...commonProps(props),
      //       getData: () => props.getCandidates('reviewLater'),
      //     }),
      //   ],
      // },
      // {
      //   key: 'skipped',
      //   originalKey: 'shortlist-skipped',
      //   label: 'Skipped',
      //   count: 20,
      //   getData: () => props.getCandidates('skipped'),
      //   menuItems: [
      //     ...ShortlistMenuItems({
      // ...commonProps(props),
      //       getData: () => props.getCandidates('skipped'),
      //     }),
      //   ],
      // },
    ],
  },
  {
    key: 'qualify',
    originalKey: 'qualify',
    countKey: 'Qualify',
    label: props.translate('qualified'),
    count: 50,
    steps: [
      {
        key: 'shortlisted',
        originalKey: 'qualify-shortlisted',
        countKey: 'Shortlisted',
        label: props.translate('shortListed'),
        count: props.jobApplicationCount && props.jobApplicationCount.Qualify
          && (
            props.jobApplicationCount.Qualify.Shortlisted ||
            props.jobApplicationCount.Qualify.Shortlisted === 0
          )
          ? props.jobApplicationCount.Qualify.Shortlisted
          : '-',
        getData: () => props.getCandidates('shortlisted'),
        bulkMenuItems: [
          ...QualifyShortlistedBulkMenuItems({
            ...commonProps(props),
            getData: () => props.getCandidates('shortlisted'),
          }),
        ],
        menuItems: [
          ...QualifyShortlistedMenuItems({
            ...commonProps(props),
            getData: () => props.getCandidates('shortlisted'),
          }),
        ],
      },
      {
        key: 'rejected',
        originalKey: 'qualify-rejected',
        countKey: 'Rejected',
        label: props.translate('rejected'),
        count: props.jobApplicationCount && props.jobApplicationCount.Qualify
          && (
            props.jobApplicationCount.Qualify.Rejected ||
            props.jobApplicationCount.Qualify.Rejected === 0
          )
          ? props.jobApplicationCount.Qualify.Rejected
          : '-',
        getData: () => props.getCandidates('rejected'),
        bulkMenuItems: [
          ...QualifyRejectedBulkMenuItems({
            ...commonProps(props),
            getData: () => props.getCandidates('rejected'),
          }),
        ],
        menuItems: [
          ...QualifyRejectedMenuItems({
            ...commonProps(props),
            getData: () => props.getCandidates('rejected'),
          }),
        ],
      },
      // {
      //   key: 'contacted',
      //   originalKey: 'qualify-contacted',
      //   label: 'Contacted',
      //   count: 20,
      //   getData: () => props.getCandidates('contacted'),
      //   menuItems: [
      //     ...QualifyMenuItems({
      // ...commonProps(props),
      //       getData: () => props.getCandidates('contacted'),
      //     }),
      //   ],
      // },
      // {
      //   key: 'consented',
      //   originalKey: 'qualify-consented',
      //   label: 'Consented',
      //   count: 5,
      //   getData: () => props.getCandidates('consented'),
      //   menuItems: [
      //     ...QualifyMenuItems({
      // ...commonProps(props),
      //       getData: () => props.getCandidates('consented'),
      //     }),
      //   ],
      // },
      // {
      //   key: 'skipped',
      //   originalKey: 'qualify-skipped',
      //   label: 'Skipped',
      //   count: 5,
      //   getData: () => props.getCandidates('skipped'),
      //   menuItems: [
      //     ...QualifyMenuItems({
      // ...commonProps(props),
      //       getData: () => props.getCandidates('skipped'),
      //     }),
      //   ],
      // },
    ],
  },
  {
    key: 'present',
    originalKey: 'present',
    countKey: 'Present',
    label: props.translate('presented'),
    count: 10,
    steps: [
      {
        key: 'qualified',
        originalKey: 'present-qualified',
        countKey: 'Qualified',
        label: props.translate('qualified'),
        count: props.jobApplicationCount && props.jobApplicationCount.Present
          && (
            props.jobApplicationCount.Present.Qualified ||
            props.jobApplicationCount.Present.Qualified === 0
          )
          ? props.jobApplicationCount.Present.Qualified
          : '-',
        getData: () => props.getCandidates('qualified'),
        bulkMenuItems: [
          ...PresentQualifiedBulkMenuItems({
            ...commonProps(props),
            getData: () => props.getCandidates('qualified'),
          }),
        ],
        menuItems: [
          ...PresentQualifiedMenuItems({
            ...commonProps(props),
            getData: () => props.getCandidates('qualified'),
          }),
        ],
      },
      {
        key: 'presented',
        originalKey: 'present-presented',
        countKey: 'Presented',
        label: props.translate('presented'),
        count: props.jobApplicationCount && props.jobApplicationCount.Present
          && (
            props.jobApplicationCount.Present.Presented ||
            props.jobApplicationCount.Present.Presented === 0
          )
          ? props.jobApplicationCount.Present.Presented
          : '-',
        getData: () => props.getCandidates('presented'),
        bulkMenuItems: [
          ...PresentPresentedBulkMenuItems({
            ...commonProps(props),
            getData: () => props.getCandidates('presented'),
          }),
        ],
        menuItems: [
          ...PresentPresentedMenuItems({
            ...commonProps(props),
            getData: () => props.getCandidates('presented'),
          }),
        ],
      },
      // {
      //   key: 'skipped',
      //   originalKey: 'present-skipped',
      //   label: 'Skipped',
      //   count: 5,
      //   getData: () => props.getCandidates('skipped'),
      //   menuItems: [
      //     ...PresentMenuItems({
      // ...commonProps(props),
      //       getData: () => props.getCandidates('skipped'),
      //     }),
      //   ],
      // },
    ],
  },
  // {
  //   key: 'hiring',
  //   originalKey: 'hiring',
  //   label: 'Hired',
  //   count: 10,
  //   steps: [
  //     {
  //       key: 'viewed',
  //       originalKey: 'hiring-viewed',
  //       label: 'Viewed',
  //       count: 10,
  //       getData: () => props.getCandidates('viewed'),
  //       menuItems: [
  //         ...HiringMenuItems({
  // ...commonProps(props),
  //           getData: () => props.getCandidates('viewed'),
  //         }),
  //       ],
  //     },
  //     {
  //       key: 'interviewed',
  //       originalKey: 'hiring-interviewed',
  //       label: 'Interviewed',
  //       count: 5,
  //       getData: () => props.getCandidates('interviewed'),
  //       menuItems: [
  //         ...HiringMenuItems({
  // ...commonProps(props),
  //           getData: () => props.getCandidates('interviewed'),
  //         }),
  //       ],
  //     },
  //     {
  //       key: 'offered',
  //       originalKey: 'hiring-offered',
  //       label: 'Offered',
  //       count: 3,
  //       getData: () => props.getCandidates('offered'),
  //       menuItems: [
  //         ...HiringMenuItems({
  // ...commonProps(props),
  //           getData: () => props.getCandidates('offered'),
  //         }),
  //       ],
  //     },
  //     {
  //       key: 'rejected',
  //       originalKey: 'hiring-rejected',
  //       label: 'Rejected',
  //       count: 3,
  //       getData: () => props.getCandidates('rejected'),
  //       menuItems: [
  //         ...HiringMenuItems({
  // ...commonProps(props),
  //           getData: () => props.getCandidates('rejected'),
  //         }),
  //       ],
  //     },
  //     {
  //       key: 'hired',
  //       originalKey: 'hiring-hired',
  //       label: 'Hired',
  //       count: 1,
  //       getData: () => props.getCandidates('hired'),
  //       menuItems: [
  //         ...HiringMenuItems({
  // ...commonProps(props),
  //           getData: () => props.getCandidates('hired'),
  //         }),
  //       ],
  //     },
  //   ],
  // },
]
);

export default tabs;
