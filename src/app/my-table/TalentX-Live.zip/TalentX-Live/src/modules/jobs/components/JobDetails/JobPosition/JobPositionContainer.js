import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withRouter } from 'react-router';
import { getDraftedJobs, getPostedJobs, getQualifiedJobs, getPresentedJobs, closeJob, deleteJob, getClosedJobs } from '../../../redux/actions';
import JobPosition from './JobPosition';
import { showNotification } from '../../../../../utils/Notifications';

class JobPositionContainer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      anchorEl: null,
      openCloseJobDialog: false,
      openDeleteJobDialog: false,
    };

    this.handleCloseJob = this.handleCloseJob.bind(this);
    this.confirmJobClose = this.confirmJobClose.bind(this);
    this.handleDeleteJob = this.handleDeleteJob.bind(this);
    this.confirmDeleteJob = this.confirmDeleteJob.bind(this);
    this.handleClick = this.handleClick.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }


  handleClick(event) {
    this.setState({ anchorEl: event.currentTarget });
  }

  handleClose() {
    this.setState({ anchorEl: null });
  }

  handleCloseJob(status) {
    this.setState({ openCloseJobDialog: status });
  }

  handleDeleteJob(status) {
    this.setState({ openDeleteJobDialog: status });
  }

  confirmJobClose() {
    const { id, status } = this.props.job;
    this.props.closeJob(id).then(() => {
      setTimeout(() => {
        switch (status) {
          case 'draft':
            this.props.getDraftedJobs(1, this.props.draftJobsSortedBy);
            break;
          case 'posted':
            this.props.getPostedJobs(1, this.props.postedJobsSortedBy);
            break;
          case 'qualified':
            this.props.getQualifiedJobs(1, this.props.qualifiedJobsSortedBy);
            break;
          case 'presented':
            this.props.getPresentedJobs(1, this.props.presentedJobsSortedBy);
            break;
          default:
            break;
        }
        this.props.getClosedJobs(1, this.props.closedJobsSortedBy);
        this.handleCloseJob(false);
        showNotification(this.props.translate('jobClosed'), 'success', 8000);
        this.props.history.push('/recruiter');
      }, 500);
    });
  }

  confirmDeleteJob() {
    const { id } = this.props.job;
    this.props.deleteJob(id).then(() => {
      setTimeout(() => {
        this.props.getDraftedJobs(1, this.props.draftJobsSortedBy);
        this.handleDeleteJob(false);
        showNotification(this.props.translate('jobDeleted'), 'success', 8000);
        this.props.history.push('/recruiter');
      }, 500);
    });
  }

  render() {
    const { anchorEl, openCloseJobDialog, openDeleteJobDialog } = this.state;
    const options = [
      // { key: 'sendforapproval', value: <span>Send for Approval</span> },
      // { key: 'Approve', value: <span>Approve</span> },
      // { key: 'sharejob', value: <span>Share Job</span> },
    ];
    return (
      <div>
        <JobPosition
          job={this.props.job}
          anchorEl={anchorEl}
          options={options}
          openCloseJobDialog={openCloseJobDialog}
          openDeleteJobDialog={openDeleteJobDialog}
          closeJobLoading={this.props.closeJobLoading}
          deleteJobLoading={this.props.deleteJobLoading}
          jobId={this.props.job.id}
          jobStatus={this.props.job.status}
          jobTitle={this.props.job.job_description.job_title}
          handleClick={this.handleClick}
          handleClose={this.handleClose}
          handleCloseJob={this.handleCloseJob}
          confirmJobClose={this.confirmJobClose}
          handleDeleteJob={this.handleDeleteJob}
          confirmDeleteJob={this.confirmDeleteJob}
        />
      </div>
    );
  }
}

JobPositionContainer.propTypes = {
  translate: PropTypes.func.isRequired,
  job: PropTypes.object, // eslint-disable-line
  history: PropTypes.object, //eslint-disable-line
  closeJob: PropTypes.func,
  deleteJob: PropTypes.func,
  getDraftedJobs: PropTypes.func,
  getClosedJobs: PropTypes.func,
  getPostedJobs: PropTypes.func,
  getQualifiedJobs: PropTypes.func,
  getPresentedJobs: PropTypes.func,
  closeJobLoading: PropTypes.bool.isRequired,
  deleteJobLoading: PropTypes.bool.isRequired,
  draftJobsSortedBy: PropTypes.string,
  postedJobsSortedBy: PropTypes.string,
  qualifiedJobsSortedBy: PropTypes.string,
  presentedJobsSortedBy: PropTypes.string,
  closedJobsSortedBy: PropTypes.string,
};

JobPositionContainer.defaultProps = {
  job: {},
  history: {},
  closeJob: () => {},
  deleteJob: () => {},
  getClosedJobs: () => {},
  getDraftedJobs: () => {},
  getPostedJobs: () => {},
  getQualifiedJobs: () => {},
  getPresentedJobs: () => {},
  draftJobsSortedBy: 'none',
  postedJobsSortedBy: 'none',
  qualifiedJobsSortedBy: 'none',
  presentedJobsSortedBy: 'none',
  closedJobsSortedBy: 'none',
};

const mapStateToProps = state => ({
  closeJobLoading: state.recruiter.closeJobLoading,
  closeJobSuccess: state.recruiter.closeJobSuccess,
  closeJobError: state.recruiter.closeJobError,
  deleteJobLoading: state.recruiter.deleteJobLoading,
  deleteJobSuccess: state.recruiter.deleteJobSuccess,
  deleteJobError: state.recruiter.deleteJobError,
  draftJobsSortedBy: state.recruiter.draftJobsSortedBy,
  postedJobsSortedBy: state.recruiter.postedJobsSortedBy,
  qualifiedJobsSortedBy: state.recruiter.qualifiedJobsSortedBy,
  presentedJobsSortedBy: state.recruiter.presentedJobsSortedBy,
  closedJobsSortedBy: state.recruiter.closedJobsSortedBy,
});

const mapDispatchToProps = dispatch => ({
  closeJob: jobId => dispatch(closeJob(jobId)),
  deleteJob: jobId => dispatch(deleteJob(jobId)),
  getDraftedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getDraftedJobs(pageNo, sortBy, employer, key, perPage)),
  getPostedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getPostedJobs(pageNo, sortBy, employer, key, perPage)),
  getQualifiedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getQualifiedJobs(pageNo, sortBy, employer, key, perPage)),
  getPresentedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getPresentedJobs(pageNo, sortBy, employer, key, perPage)),
  getClosedJobs: (pageNo, sortBy, employer, key, perPage) =>
    dispatch(getClosedJobs(pageNo, sortBy, employer, key, perPage)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(withTranslate(JobPositionContainer)));// eslint-disable-line
