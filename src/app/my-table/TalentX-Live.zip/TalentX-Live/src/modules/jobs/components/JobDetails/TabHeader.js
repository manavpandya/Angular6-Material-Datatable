import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Arrow from 'material-ui-icons/FiberManualRecord';

const breadcrumb = (i) => {
  if (i !== 0) return (<Arrow className="icon" />);
  return null;
};

const subtabs = (
  filterParamMatched,
  totalMatchedCandidates,
  tab,
  selectedSubTab,
  setSelectedSubTab,
  flushAllData,
  setSelectedSubTabKey,
) => (
  tab.steps.map((step, idx) => ((selectedSubTab === 'shortlist-matched' && filterParamMatched)
    ?
    null
    : (
      <span
        key={step.originalKey}
        role="presentation"
        className={selectedSubTab === step.originalKey ? 'selected-sub-tab' : ''}
        onClick={() => {
          if (setSelectedSubTabKey) setSelectedSubTabKey(step.originalKey, tab.steps);
          if (flushAllData) flushAllData();
          if (step.getData) step.getData();
          setSelectedSubTab(step.originalKey);
        }}
        onKeyDown={() => {}}
      >
        <span>{breadcrumb(idx)}</span>
        <span>
          {step.label}&nbsp;&nbsp;
          {
          step.key === 'matched' && (step.count >= step.maxDisplayCount) ? `${step.maxDisplayCount}+`
          : step.count
          }
        </span>
      </span>
    )))
);

class TabHeader extends Component {
  constructor(props) {
    super(props);
    const currentSubTabKeys = props.tabs
      .find(tab => tab.originalKey === props.step)
      .steps.map(step => step.originalKey);
    const currentSubTabKey = currentSubTabKeys
      .find(element => props.currentSubTabKeys.includes(element));
    this.state = {
      selectedSubTab: currentSubTabKey || props.tabs
        .filter(tab => tab.originalKey === props.step)[0].steps[0].originalKey,
    };
    this.setSelectedSubTab = this.setSelectedSubTab.bind(this);
  }

  setSelectedSubTab(subTab) {
    this.setState({
      selectedSubTab: subTab,
    });
  }

  render() {
    return (
      <div className="sub-tab">
        <div className="t">
          {
            this.props.tabs.map(tab => tab.originalKey === this.props.step
              && subtabs(
                this.props.filterParamMatched,
                this.props.totalMatchedCandidates,
                tab,
                this.state.selectedSubTab,
                this.setSelectedSubTab,
                this.props.flushAllData,
                this.props.setSelectedSubTabKey,
              ))
          }
        </div>
        <div>
          {this.props.children}
        </div>
      </div>
    );
  }
}

TabHeader.propTypes = {
  tabs: PropTypes.array.isRequired, // eslint-disable-line
  step: PropTypes.string.isRequired, // eslint-disable-line
  children: PropTypes.element,
  flushAllData: PropTypes.func,
  setSelectedSubTabKey: PropTypes.func,
  currentSubTabKeys: PropTypes.arrayOf(PropTypes.string),
  totalMatchedCandidates: PropTypes.number.isRequired,
  filterParamMatched: PropTypes.string.isRequired,
};

TabHeader.defaultProps = {
  children: <p>No children specified</p>,
  flushAllData: () => {},
  setSelectedSubTabKey: () => {},
  currentSubTabKeys: [],
};

export default TabHeader;

