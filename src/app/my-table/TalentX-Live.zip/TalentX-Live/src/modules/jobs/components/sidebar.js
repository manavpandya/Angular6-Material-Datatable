import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import LinkButton from '../../../shared/basic/LinkButton';

const Sidebar = props => (
  <div className="sidebar-div-inner">
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('job_title')} >{props.translate('newJobTitle')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('job_description')}>{props.translate('jobDescription')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('job_application_close_date')} >{props.translate('applicationCloseDate')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('required_skills')}>{props.translate('jobRequiredSkill')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('desired_skills')}> {props.translate('jobDesiredSkill')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('qualifications')}>{props.translate('jobQualifications')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('industry_experience')}>{props.translate('jobIndustryExperience')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('certifications')}>{props.translate('jobCertification')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('language_proficiency')}>{props.translate('jobLanguageProficiency')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('location')}>{props.translate('jobLocation')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('employment_type')}>{props.translate('jobEmploymentType')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('duration')}>{props.translate('jobDuration')}</LinkButton></div>
    <div><LinkButton className="linkButton" onClick={() => props.handleExpandClick('ultimate_client')}>{props.translate('jobUltimateClient')}</LinkButton></div>
  </div>
);

Sidebar.propTypes = {
  translate: PropTypes.func.isRequired,
  handleExpandClick: PropTypes.func.isRequired, // eslint-disable-line react/forbid-prop-types
};

export default withTranslate(Sidebar);
