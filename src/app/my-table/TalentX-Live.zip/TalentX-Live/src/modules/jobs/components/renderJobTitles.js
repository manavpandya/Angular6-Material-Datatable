import React from 'react';
import PropTypes from 'prop-types';
import { Field } from 'redux-form';
import { TextField } from 'redux-form-material-ui';
import IconButton from 'material-ui/IconButton';
import PlusIcon from 'material-ui-icons/Add';
import DeleteIcon from 'material-ui-icons/DeleteForever';

const required = value => (value == null ? 'Required' : undefined);

export default class renderJobTitles extends React.Component {
  componentDidMount() {
    this.props.fields.length === 0 ? this.props.fields.push() : ''; // eslint-disable-line no-unused-expressions
  }

  render() {
    return (
      <div>
        <IconButton onClick={() => this.props.fields.push()}>
          <PlusIcon />
        </IconButton>
        <br />
        {
          this.props.fields.map((jobTitles, index) =>
          (
            <div className="relations-structure">
              <Field
                validate={required}
                name={jobTitles}
                component={TextField}
              />
              <IconButton onClick={() => this.props.fields.remove(index)}>
                <DeleteIcon />
              </IconButton>
            </div>
          ))
        }
      </div>
    );
  }
}

renderJobTitles.propTypes = {
  fields: PropTypes.object, // eslint-disable-line react/forbid-prop-types
};

renderJobTitles.defaultProps = {
  fields: {},
};

