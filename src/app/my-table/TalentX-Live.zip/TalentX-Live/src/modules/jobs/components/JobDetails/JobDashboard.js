import React from 'react';
import { withTranslate } from 'react-redux-multilingual';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
import PropTypes from 'prop-types';
import _ from 'lodash';
import ReduxBlockUI from 'react-block-ui/redux';
import MomentTranslate from '../../../../shared/basic/MomentTranslate';
import { sortAll } from '../../../../utils/index';
// import ExpandField from '../../../../shared/compound/ExpandField';

// const esc = str => str.split('\n').map(s => <p key={s}>{s}</p>);

const JobDashboard = props => (
  Object.keys(props.job).length > 0
    ?
      <ReduxBlockUI className="job-dashboard" tag="div" blocking={props.downloadFileLoading}>
        <aside />
        <main className="job-details">
          <h2>{`${props.job.job_description.job_title} [${props.job.no_of_positions}]`}</h2>
          {
            props.job.location.region &&
            <h2 className="location">{`${props.job.location.region}, ${props.job.location.country}`}</h2>
          }
          <div className="info-value">{props.job.job_description.description}</div>
          {
            props.job.job_description.required_skills.length > 0 &&
            <div>
              <h2 className="info-key">{props.translate('requiredSkills')}</h2>
              <span className="info-value">
                {
                  sortAll(_.uniqBy(props.job.job_description.required_skills, obj => obj.display_value.toLowerCase()), 'display_value').map(skill => skill.display_value).join(', ')
                }
              </span>
            </div>
          }
          {
          props.job.job_description.desired_skills
          && props.job.job_description.desired_skills.length > 0 &&
            <div>
              <h2 className="info-key">{props.translate('desiredSkills')}</h2>
              <span className="info-value">
                {
                  _.uniqBy(props.job.job_description.desired_skills, obj => obj.display_value.toLowerCase(), 'display_value').map(skill => skill.display_value).join(', ')
                }
              </span>
            </div>
          }
          {
            props.job.qualifications.degree.length > 0 &&
            <div>
              <h2 className="info-key">{props.translate('qualifications')}</h2>
              <span className="info-value">
                {
                  props.job.qualifications.degree.map(degree => degree).join(', ')
                }
              </span>
            </div>
          }
          {
            props.job.certification_license.certifications.length > 0 &&
            <div>
              <h2 className="info-key">{props.translate('candidateCertification')}</h2>
              <span className="info-value">
                {
                  props.job.certification_license.certifications.map(certification => certification).join(', ')
                }
              </span>
            </div>
          }
          {
            props.job.certification_license.licenses.length > 0 &&
            <div>
              <h2 className="info-key">{props.translate('candidateLicenses')}</h2>
              <span className="info-value">
                {
                  props.job.certification_license.licenses.map(license => license).join(', ')
                }
              </span>
            </div>
          }
          <h3>{props.translate('createdBy')}: {props.job.created_by.username}</h3>
          <h3>{props.translate('postedOn')}:
            <MomentTranslate
              fromNow={props.job.created_at}
            />
          </h3>
          {
            props.job.filename &&
            <div
              className="file-container"
              role="presentation"
              onClick={() => props.downloadFile(props.job.id)}
              onKeyDown={() => {}}
            >
              <InsertDriveFile className="file-icon" />
              <h2 className="file-name">
                {props.job.filename}
              </h2>
            </div>
          }
        </main>
        <aside />
      </ReduxBlockUI>
    : <div />
);

JobDashboard.propTypes = {
  translate: PropTypes.func.isRequired,
  job: PropTypes.object, // eslint-disable-line
  downloadFile: PropTypes.func,
  downloadFileLoading: PropTypes.bool,
};

JobDashboard.defaultProps = {
  job: {},
  downloadFile: () => {},
  downloadFileLoading: false,
};

export default withTranslate(JobDashboard);
