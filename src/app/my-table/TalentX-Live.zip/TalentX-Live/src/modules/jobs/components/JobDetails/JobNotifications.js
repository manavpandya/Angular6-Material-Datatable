import React, { Component } from 'react';
import TextField from 'material-ui/TextField';
import PropTypes from 'prop-types';
import { MenuList, MenuItem } from 'material-ui/Menu';
import MoreVertIcon from 'material-ui-icons/MoreVert';

import JobStackHolders from './JobStakeHolders';
import Menu from '../../../../shared/compound/Menu';
import MomentTranslate from '../../../../shared/basic/MomentTranslate';
import icon from '../../../../assets/images/candidate-profile.png';

// todo: const client = 'https://cdn1.iconfinder.com/data/icons/user-pictures/100/female1-512.png';
const me = icon;

class JobNotification extends Component {
  render() {
    return (
      <div className="job-dashboard notifications">
        <aside>
          <ul className="filters">
            <li>
              <span>All notifications</span>
              <strong>{this.props.job.notes.length}</strong>
            </li>
            <li>
              <span>Notes</span>
              <strong>{this.props.job.notes.filter(note => note.type === 'note').length}</strong>
            </li>
            <li>
              <span>Hired</span>
              <strong>{this.props.job.notes.filter(note => note.type === 'hired').length}</strong>
            </li>
          </ul>
        </aside>
        <main>
          <div className="message notes">
            <span className="date"><img className="avatar" src={me} alt="Avatar" /></span>
            <div className="main">
              <TextField
                placeholder="Add Note..."
                value={this.props.newNoteDescription}
                onChange={this.props.changeNewNoteDescription}
                onKeyPress={event => this.props.addNote(event, this.fake)}
              />
            </div>
          </div>
          <div className="job-history">
            <div ref={(fake) => { this.fake = fake; }} />
            {
              this.props.job.notes.map(note => (
                <div className={`${note.created_by === 'eogR-mEBxS1kk20SujXh' ? 'me' : 'client'} message ${note.read ? '' : 'unread'}`} key={note.id}>
                  <span className="date">
                    <MomentTranslate
                      fromNow={note.created_at}
                    />
                  </span>
                  <img className="avatar" src={me} alt="Avatar" />
                  <div className="main">
                    <div className="notes-menu">
                      <Menu
                        menuStyle={{
                          position: 'absolute',
                          top: 40,
                          right: 0,
                          zIndex: 2000,
                        }}
                        iconSuffix={<MoreVertIcon className="more-vert-note" />}
                        popup={
                          <MenuList role="menu">
                            <MenuItem onClick={() => this.props.deleteNote(note.id)}>
                              Delete
                            </MenuItem>
                          </MenuList>
                        }
                      />
                    </div>
                    <h3 className="title">
                      {/* todo: {(note.title && note.entity === 'candidate') ?
                        <div>
                          <CandidateProfile
                            candidate={note.candidate}
                            launcher={note.candidate.name}
                          />
                          {note.title.replace(/#{name}/ig, '')}
                        </div> :
                        note.title} */}
                      {
                        note.type === 'hired' ? 'Hired' : 'Note'
                      }
                    </h3>
                    {/* { todo:
                      notification.message && notification.entity !== 'candidates' &&
                      <span className="message-text">{notification.message}</span>
                    }
                    {
                      notification.candidates && notification.entity === 'candidates' &&
                      notification.candidates.map((candidate, i) => (
                        <span className="message-text" key={candidate.id}>
                          {i !== 0 ? <span>, </span> : ''}
                          <CandidateProfile candidate={candidate} launcher={candidate.name} />
                        </span>
                      ))
                    } */}
                    <span className="message-text">{note.description}</span>
                  </div>
                </div>
              ))
            }
          </div>
        </main>
        <aside>
          <JobStackHolders />
        </aside>
      </div>
    );
  }
}

JobNotification.propTypes = {
  job: PropTypes.object, // eslint-disable-line
  notifications: PropTypes.array, // eslint-disable-line
  addNote: PropTypes.func,
  newNoteDescription: PropTypes.string,
  changeNewNoteDescription: PropTypes.func,
  deleteNote: PropTypes.func,
};

JobNotification.defaultProps = {
  job: {},
  notifications: [],
  addNote: () => {},
  newNoteDescription: '',
  changeNewNoteDescription: () => {},
  deleteNote: () => { },
};

export default JobNotification;
