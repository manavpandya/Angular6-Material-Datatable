import React from 'react';

import { Link } from 'react-router-dom';
import TextField from 'material-ui/TextField';
import Button from 'material-ui/Button';

const NewJobXonged = () =>
  (
    <div>
      <form>
        <TextField label="Job Title" />
        <br />
        <TextField label="Job Location" />
        <br />
        <TextField label="Job Client" />
        <br />
        <TextField label="Job Project" />
        <br />
        <div className="sub-actions">
          <p>Add to Library</p>
        </div>
        <Link to="new/matches"><Button primary>Post</Button></Link>
      </form>
    </div>
  );

export default NewJobXonged;
