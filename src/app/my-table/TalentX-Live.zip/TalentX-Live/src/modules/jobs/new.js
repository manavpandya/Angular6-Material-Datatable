import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { Link } from 'react-router-dom';
import { withRouter } from 'react-router';
import AppBar from 'material-ui/AppBar';
import Card from 'material-ui/Card';
import PropTypes from 'prop-types';
import DeleteIcon from 'material-ui-icons/ArrowBack';
import InsertDriveFile from 'material-ui-icons/InsertDriveFile';
// import Select from 'react-select';
import NewJobContainer from './components/NewJob/NewJobContainer';
import Sidebar from './components/sidebar';

class RecruiterNewJob extends Component {
  constructor(props) {
    super(props);
    this.state = {
      expanded: [],
      scrollRef: '',
    };
    this.getTitle = this.getTitle.bind(this);
    this.handleExpandClick = this.handleExpandClick.bind(this);
    this.addToExpanded = this.addToExpanded.bind(this);
  }

  getTitle(filename, jobTitle) {
    if (filename) {
      return filename;
    }
    if (this.props.match.params.id) {
      if (this.props.location.state && this.props.location.state.job_status === 'posted') {
        return this.props.location.state.job_title;
      }
      return `Edit Job (${this.props.location.state.job_title})`;
    }
    if (jobTitle) {
      return `Template: ${jobTitle}`;
    }
    return '';
  }

  handleExpandClick(name) {
    const ele = document.getElementById(name);
    ele.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });

    if (this.state.expanded.includes(name)) {
      this.setState({
        expanded: [...this.state.expanded.filter(n => n !== name)],
        scrollRef: name,
      });
    } else {
      this.setState({
        expanded: [...this.state.expanded, name],
        scrollRef: name,
      });
    }
  }

  addToExpanded(expanders) {
    this.setState({
      expanded: [...new Set([...this.state.expanded].concat(...expanders))],
    });
  }

  render() {
    const expanded = this.state.expanded || [];
    const { location } = this.props;
    const { filename } = (location.state && location.state.initialValues) || '';
    const jobTitle = location.state
      && location.state.initialValues
      && location.state.initialValues.job_description
      ? location.state.initialValues.job_description.job_title
      : '';
    const sectorForUploadedFile = this.props.location.state &&
      this.props.location.state.initialValues ?
      this.props.location.state.initialValues.sector &&
      <div className="sector-rectangle right">
        {this.props.location.state.initialValues.sector.primary}
      </div>
      : null;
    return (
      <div className="page jobs">
        <div className="modal full-page job">
          <AppBar className="appbar job-dashboard-release-due-date">
            <div className="appbar-job-posting">
              <div className="flex-center">
                <Link to="/recruiter" className="back-arrow">
                  <DeleteIcon />
                </Link>
                <h1>{this.props.translate('jobDashboard')}</h1>
                &nbsp;&nbsp;
                <div className="pointer flex-center">
                  { filename ? <InsertDriveFile className="drive-file" /> : null }
                  {
                    <h2 className="filename">
                      {this.getTitle(filename, jobTitle)}
                    </h2>
                  }
                  {
                    <div className="filename">
                      {filename}
                    </div>
                    &&
                    <div className="sector">
                      {sectorForUploadedFile}
                    </div>
                  }
                  <div className="sector">
                    { this.props.location.state ?
                      this.props.location.state.sector &&
                      <div className="sector-rectangle right">
                        {this.props.location.state.sector}
                      </div>
                    : null
                    }
                  </div>
                </div>
              </div>
              {/* <Select
                className="sector-dropdown right"
                name="form-field-name"
                options={[
                  { value: 'one', label: 'One' },
                  { value: 'two', label: 'Two' },
                ]}
                placeholder="Select sector"
              /> */}
            </div>
          </AppBar>
          <section className="content">
            <aside className="status aside-padding">
              <div className="sidebar-div">
                <Card>
                  <Sidebar
                    handleExpandClick={this.handleExpandClick}
                  />
                </Card>
              </div>
            </aside>
            <main className="job-form">
              <NewJobContainer
                initialValues={location.state ? location.state.initialValues : {}}
                handleExpandClick={this.handleExpandClick}
                expanded={expanded}
                addToExpanded={this.addToExpanded}
                scrollRef={this.state.scrollRef}
              />
            </main>
          </section>
        </div>
      </div>
    );
  }
}

RecruiterNewJob.propTypes = {
  translate: PropTypes.func,
  location: PropTypes.object, // eslint-disable-line react/forbid-prop-types
  match: PropTypes.object, // eslint-disable-line
  sector: PropTypes.string, // eslint-disable-line
};

RecruiterNewJob.defaultProps = {
  translate: () => {},
  location: {},
  sector: '',
};

export default withRouter(withTranslate(RecruiterNewJob));
