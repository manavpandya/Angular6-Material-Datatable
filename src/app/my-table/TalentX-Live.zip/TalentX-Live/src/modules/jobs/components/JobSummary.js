import React, { Fragment } from 'react';
import moment from 'moment';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { withTranslate } from 'react-redux-multilingual';
import MomentTranslate from '../../../shared/basic/MomentTranslate';
import Metric from '../../../shared/basic/Metric';

const JobSummary = (props) => {
  const applications = props.job.applications
  && props.job.applications.reduce((obj, application) => ({
    ...obj,
    [application.key]: application.doc_count,
  }), {});
  return (
    <Link to={`/${props.customerPage ? 'customer' : 'recruiter'}/jobs/job/${props.job.id}`} onClick={props.onClick()}>
      <div className={`job job-summary ${props.job.read === false ? 'unread' : ''}`}>
        <div className="job-content">
          <h3 className="title">{`${props.job.job_description.job_title} ${props.job.no_of_positions ? `[${props.job.no_of_positions}]` : ''}` }</h3>
          <label htmlFor={props.job.id}>
            <small>
              {(props.job && props.job.customer && props.job.customer.name) ||
              props.job.job_description.employer}
            </small>
          </label>
          <div className="desc">
            {
              props.stageKey === 'posted' &&
              <Metric value={props.job.matched_profiles_count} htmlFor={props.job.id} label={props.translate('matched')} />
            }
            {
              (props.stageKey === 'posted' || props.stageKey === 'qualified') &&
              <div className="metrics">
                <label htmlFor={props.job.id}>
                  <strong>{applications.shortlisted || 0}</strong><span>{props.translate('shortlisted')}</span>
                </label>
              </div>
            }
            {
              (props.stageKey === 'qualified' || props.stageKey === 'presented') && !props.customerPage &&
              <div className="metrics">
                <label htmlFor={props.job.id}>
                  <strong>{applications.qualified || 0}</strong><span>{props.translate('qualified')}</span>
                </label>
              </div>
            }
            {
              props.stageKey === 'presented' &&
              <div className="metrics">
                <label htmlFor={props.job.id}>
                  <strong>{applications.presented || 0}</strong><span>{props.translate('presented')}</span>
                </label>
              </div>
            }
            {
              (props.stageKey === 'interviewed') &&
              <div className="metrics">
                <label htmlFor={props.job.id}>
                  <strong>{applications.presented || 0}</strong><span>{props.translate('presented')}</span>
                </label>
                <label htmlFor={props.job.id}>
                  <strong>{applications.interviewed || 0}</strong><span>{props.translate('interviewed')}</span>
                </label>
              </div>
            }
            {
              (props.stageKey === 'offered') &&
              <div className="metrics">
                <label htmlFor={props.job.id}>
                  <strong>{applications.interviewed || 0}</strong><span>{props.translate('interviewed')}</span>
                </label>
                <label htmlFor={props.job.id}>
                  <strong>{applications.offered || 0}</strong><span>{props.translate('offered')}</span>
                </label>
              </div>
            }
            {
              (props.stageKey === 'hired') &&
              <div className="metrics">
                <label htmlFor={props.job.id}>
                  <strong>{applications.offered || 0}</strong><span>{props.translate('offered')}</span>
                </label>
                <label htmlFor={props.job.id}>
                  <strong>{applications.hired || 0}</strong><span>{props.translate('hired')}</span>
                </label>
              </div>
            }
          </div>
          {
            props.job
            && props.job.job_description
            && props.job.job_description.job_due_date
            && props.job.job_description.job_release_date
            &&
            <Fragment>
              <div className="due-release-date">
                <div>
                  <span>Due: </span>
                  <strong>{moment(props.job.job_description.job_due_date).fromNow()}</strong>
                </div>
                <div>
                  <span>Released: </span>
                  <strong>{moment(props.job.job_description.job_release_date).fromNow()}</strong>
                </div>
              </div>
            </Fragment>
          }
          <p className="last-updated">
            <MomentTranslate
              fromNow={props.job.updated_at}
            />
          </p>
        </div>
      </div>
    </Link>
  );
};

JobSummary.propTypes = {
  translate: PropTypes.func.isRequired,
  job: PropTypes.object, // eslint-disable-line
  stageKey: PropTypes.string,
  onClick: PropTypes.func,
  customerPage: PropTypes.bool,
};


JobSummary.defaultProps = {
  job: {},
  stageKey: '',
  onClick: () => {},
  customerPage: false,
};

export default withTranslate(JobSummary);
