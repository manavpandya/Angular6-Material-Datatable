import * as SourcingAction from './actionTypes';

const initialState = {
  candidates: [],
  filterParam: '',
  all_jobs_opening: [],
  fetchCandidates: false,
  searchTalent: [],
  searchedTalent: false,
  totalCandidates: 0,
  candidatesLoading: false,
  available: 641,
  pastApplication: 83,
  facets: {},
  meta: {},
  filter: {
    query: '',
    facets: [],
    meta: [],
  },
  facetFetchProfile: [],
  loadingProfiles: false,
  profilesBookmarking: false,
  searchedValue: '',
  addToJob: {},
  addToJobLoading: false,
  addToJobError: null,
  distributionData: [],
  distributionDataLoading: false,
  distributionDataError: false,
  localFilterSuggestions: [],
  suggestionsLoading: false,
  tempToken: '',
  isResumeLoading: false,
  isNewSearch: false,
  checkedFilters: {},
  isRecentSearched: false,
  candidateProfilesLoading: false,
  candidateProfilesError: null,
  isPageSetToZero: false,
  clearFilters: true,
  selectedCandidates: [],
};

export default function (state = initialState, action) {
  switch (action.type) {
    case `${SourcingAction.UPLOAD_CANDIDATE_PROFILES}_SUCCESS`: {
      return {
        ...state,
        candidateProfilesLoading: false,
        candidateProfilesError: null,
      };
    }
    case `${SourcingAction.UPLOAD_CANDIDATE_PROFILES}_LOADING`: {
      return {
        ...state,
        candidateProfilesLoading: true,
        candidateProfilesError: null,
      };
    }
    case `${SourcingAction.UPLOAD_CANDIDATE_PROFILES}_ERROR`: {
      return {
        ...state,
        candidateProfilesLoading: false,
        candidateProfilesError: action.payload.data,
      };
    }
    case SourcingAction.SET_CLEAR_FILTER: {
      return {
        ...state,
        clearFilters: false,
      };
    }
    case SourcingAction.IS_NEW_SEARCH: {
      return {
        ...state,
        isNewSearch: action.payload,
      };
    }
    case `${SourcingAction.FETCH_PROFILE}_LOADING`: {
      return {
        ...state,
        loadingProfiles: true,
      };
    }
    case `${SourcingAction.FETCH_PROFILE}_SUCCESS`: {
      const { data } = action.payload;
      return {
        ...state,
        candidates: data.profiles ? data.profiles : [],
        totalCandidates: data.total,
        loadingProfiles: false,
        isRecentSearched: false,
        isPageSetToZero: false,
      };
    }
    case `${SourcingAction.FLUSH_ALL_CANDIDATES}`: {
      return {
        ...state,
        candidates: [],
        totalCandidates: 0,
        loadingProfiles: false,
      };
    }
    case SourcingAction.RESET_FILTER: {
      return {
        ...state,
        checkedFilters: {
          ...state.checkedFilters,
          [action.payload]: [],
        },
      };
    }
    case SourcingAction.CHECKED_FILTERS: {
      const obj = {
        ...state,
      };

      if (obj.checkedFilters[action.payload.key]) {
        if ((obj.checkedFilters[action.payload.key]).includes(action.payload.value)) {
          obj.checkedFilters = {
            ...obj.checkedFilters,
            [action.payload.key]: [
              ...(obj.checkedFilters[action.payload.key])
                .filter(val => val !== action.payload.value),
            ],
          };
        } else {
          obj.checkedFilters = {
            ...obj.checkedFilters,
            [action.payload.key]: [
              ...obj.checkedFilters[action.payload.key],
              action.payload.value,
            ],
          };
        }
      } else {
        obj.checkedFilters = {
          ...obj.checkedFilters,
          [action.payload.key]: [action.payload.value],
        };
      }
      return obj;
    }
    case `${SourcingAction.FETCH_FACET}_SUCCESS`: {
      return {
        ...state,
        facets: {
          ...action.payload.data.profile_facets,
          exclude_companies: action.payload.data.profile_facets.companies,
        },
        meta: action.payload.data.meta,
        filterParam: '',
        isNewSearch: true,
        checkedFilters: {},
        clearFilters: false,
        isRecentSearched: false,
        facetsLoading: false,
      };
    }
    case `${SourcingAction.FETCH_FACET}_LOADING`: {
      return {
        ...state,
        facetsLoading: true,
      };
    }
    case `${SourcingAction.FETCH_LOCAL_FILTER}_SUCCESS`: {
      return {
        ...state,
        localFilterSuggestions: action.payload.data.data,
        suggestionsLoading: false,
      };
    }
    case `${SourcingAction.GET_TEMP_TOKEN}_SUCCESS`: {
      return {
        ...state,
        tempToken: action.payload.tempToken,
        isResumeLoading: false,
      };
    }
    case `${SourcingAction.GET_TEMP_TOKEN}_LOADING`: {
      return {
        ...state,
        isResumeLoading: true,
      };
    }
    case `${SourcingAction.FETCH_LOCAL_FILTER}_LOADING`: {
      return {
        ...state,
        suggestionsLoading: true,
      };
    }
    case `${SourcingAction.FETCH_PROFILE_FACET}_SUCCESS`: {
      return {
        ...state,
        candidates: action.payload.data.profiles,
        totalCandidates: action.payload.data.total,
        candidatesLoading: false,
        filterParam: action.payload.filterParam,
        isPageSetToZero: true,
      };
    }
    case `${SourcingAction.FETCH_PROFILE_FACET}_LOADING`: {
      return {
        ...state,
        candidatesLoading: true,
      };
    }
    case SourcingAction.RESET_FILTER_PARAM: {
      return {
        ...state,
        filter: {},
        clearFilters: true,
        checkedFilters: '',
        filterParam: '',
        searchedValue: '',
      };
    }
    case `${SourcingAction.FETCH_JOBS}_SUCCESS`: {
      return {
        ...state,
        all_jobs_opening: action.payload.data.count,
      };
    }
    case `${SourcingAction.FETCH_SAVED_SEARCHES}_SUCCESS`: {
      return {
        ...state,
      };
    }
    case `${SourcingAction.FETCH_SUGGESTIONS}_SUCCESS`: {
      return {
        ...state,
      };
    }
    case `${SourcingAction.SET_FILTER}`: {
      if (action.payload.query && action.payload.query !== state.filter.query) {
        return {
          ...state,
          filter: { query: action.payload.query, facets: [], meta: [] },
        };
      }
      return {
        ...state,
        filter: {
          ...state.filter,
          ...action.payload,
        },
      };
    }
    case `${SourcingAction.GET_TALENT}_LOADING`: {
      return {
        ...state,
        loadingProfiles: true,
      };
    }
    case `${SourcingAction.GET_TALENT}_SUCCESS`: {
      return {
        ...state,
        key: action.value,
        candidates: action.payload.data.profiles,
        totalCandidates: action.payload.data.total,
        searchedTalent: true,
        loadingProfiles: false,
        // new added
        filterParam: '',
        isNewSearch: true,
        checkedFilters: {},
        clearFilters: true,
        isRecentSearched: true,
      };
    }
    case SourcingAction.GET_TALENT_VALUE: {
      return {
        ...state,
        searchedValue: action.payload,
      };
    }
    case SourcingAction.RESET_SEARCH: {
      return {
        ...state,
        searchedTalent: false,
      };
    }
    case `${SourcingAction.CANDIDATE_PROFILES_BOOKMARK_TALENT}_ERROR`: {
      return {
        ...state,
        profilesBookmarking: false,
      };
    }
    case `${SourcingAction.CANDIDATE_PROFILES_BOOKMARK_TALENT}_LOADING`: {
      return {
        ...state,
        profilesBookmarking: true,
      };
    }
    case `${SourcingAction.CANDIDATE_PROFILES_BOOKMARK_TALENT}_SUCCESS`: {
      return {
        ...state,
        profilesBookmarking: false,
        candidates: [...state.candidates.map((candidate) => {
          if (candidate.id === action.payload.candidateId) {
            const newCandidate = candidate;
            newCandidate.is_bookmarked = true;
            return newCandidate;
          }
          return candidate;
        })],
      };
    }
    case `${SourcingAction.REMOVE_CANDIDATE_PROFILES_BOOKMARK_TALENT}_ERROR`: {
      return {
        ...state,
        profilesBookmarking: false,
      };
    }
    case `${SourcingAction.REMOVE_CANDIDATE_PROFILES_BOOKMARK_TALENT}_LOADING`: {
      return {
        ...state,
        profilesBookmarking: true,
      };
    }
    case `${SourcingAction.REMOVE_CANDIDATE_PROFILES_BOOKMARK_TALENT}_SUCCESS`: {
      return {
        ...state,
        profilesBookmarking: false,
        candidates: [...state.candidates.map((candidate) => {
          if (candidate.id === action.payload.candidateId) {
            const newCandidate = candidate;
            newCandidate.is_bookmarked = false;
            return newCandidate;
          }
          return candidate;
        })],
      };
    }
    case SourcingAction.ADD_TO_JOB_SUCCESS: {
      return {
        ...state,
        addToJob: action.payload,
        addToJobLoading: false,
        addToJobError: null,
      };
    }
    case SourcingAction.ADD_TO_JOB_LOADING: {
      return {
        ...state,
        addToJob: {},
        addToJobLoading: true,
        addToJobError: null,
      };
    }
    case SourcingAction.ADD_TO_JOB_ERROR: {
      return {
        ...state,
        addToJob: {},
        addToJobLoading: false,
        addToJobError: action.payload,
      };
    }
    case SourcingAction.GET_DISTRIBUTION_LOADING: {
      return {
        ...state,
        distributionData: [],
        distributionDataError: false,
        distributionDataLoading: true,
      };
    }
    case SourcingAction.GET_DISTRIBUTION_ERROR: {
      return {
        ...state,
        distributionData: [],
        distributionDataError: true,
        distributionDataLoading: false,
      };
    }
    case SourcingAction.GET_DISTRIBUTION_SUCCESS: {
      return {
        ...state,
        distributionData: action.payload,
        distributionDataError: false,
        distributionDataLoading: false,
      };
    }
    case SourcingAction.GET_BOOKMARKED_CANDIDATES_SUCCESS: {
      return {
        ...state,
        candidates: action.payload.data.profiles,
        totalCandidates: action.payload.data.total,
        candidatesLoading: false,
      };
    }
    case SourcingAction.GET_BOOKMARKED_CANDIDATES_LOADING: {
      return {
        ...state,
        candidatesLoading: true,
      };
    }
    case SourcingAction.SELECT_ALL_CANDIDATES: {
      return {
        ...state,
        selectedCandidates: action.payload,
      };
    }
    case SourcingAction.SELECT_CANDIDATE: {
      return {
        ...state,
        selectedCandidates: [...state.selectedCandidates, action.payload],
      };
    }
    case SourcingAction.DESELECT_CANDIDATE: {
      return {
        ...state,
        selectedCandidates: [
          ...state.selectedCandidates
            .filter(candidate => candidate.id !== action.payload),
        ],
      };
    }
    default:
      return state;
  }
}
