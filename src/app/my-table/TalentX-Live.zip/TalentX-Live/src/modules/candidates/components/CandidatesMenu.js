import React, { Component } from 'react';
import { MenuItem } from 'material-ui/Menu';
import Select from 'material-ui/Select';
import Input from 'material-ui/Input';
import { withStyles } from 'material-ui/styles';
import Divider from 'material-ui/Divider';

const styles = {
  root: {
    display: 'flex',
    MuiPaper: {
      padding: 10,
    },
  },
};

class CandidatesMenu extends Component {
  constructor() {
    super();
    this.state = {
      board: 1,
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  render() {
    return (
      <Select
        value={this.state.board}
        onChange={this.handleChange}
        input={<Input name="board" />}
      >
        <MenuItem value={1}>All Candidates</MenuItem>
        <MenuItem value={20}>Starred</MenuItem>
        <MenuItem value={30}>Recent Applicants</MenuItem>
        <Divider />
        <MenuItem value={40}>Sr. Managers</MenuItem>
        <MenuItem value={50}>Project Managers</MenuItem>
        <Divider />
        <MenuItem value={0}>Create New Filter ...</MenuItem>
      </Select>
    );
  }
}

export default withStyles(styles)(CandidatesMenu);
