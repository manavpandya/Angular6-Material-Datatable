import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import BackIcon from 'material-ui-icons/Home';
import NotificationsIcon from 'material-ui-icons/Notifications';
import IconButton from 'material-ui/IconButton';
import SearchIn from '../../../shared/compound/SearchIn';
import CandidatesSavedSearches from './CandidatesSavedSearches';
import { fetchSavedSearches } from '../../candidates/redux/actions';

class CandidatesHeader extends Component {
  componentDidMount() {
    this.props.fetchSavedSearches();
  }
  render() {
    return (
      <header className="candidates-header">
        <div className="candidates-header__div" >
          <Link to="/recruiter">
            <BackIcon className="candidates-header__back-icon" />
          </Link>
          <h1><Link to="/recruiter/candidates">Sourcing</Link></h1>
          <div className="search">
            <SearchIn suggestions={this.props.job_titles_by_sector} />
          </div>
          <div className="search">
            <CandidatesSavedSearches saved={this.props.savedMock} />
          </div>
        </div>
        <div className="actions">
          <Link to="/recruiter/candidates/notifications" className="notifications">
            <IconButton>
              <NotificationsIcon />
              <span className="alert" />
            </IconButton>
          </Link>
        </div>
      </header>
    );
  }
}
CandidatesHeader.propTypes = {
  // translate: PropTypes.func.isRequired,
  fetchSavedSearches: PropTypes.func.isRequired,
  job_titles_by_sector: PropTypes.arrayOf.isRequired,
  savedMock: PropTypes.arrayOf.isRequired,
};

function mapStateToProps(state) {
  return {
    savedMock: state.profiles.savedMock,
  };
}

export default connect(mapStateToProps, { fetchSavedSearches })(withTranslate(CandidatesHeader));
