import React, { Component, Fragment } from 'react';
import PropTypes from 'prop-types';
import { MenuItem } from 'material-ui/Menu';
import Button from 'material-ui/Button';
import Dialog, {
  DialogActions,
} from 'material-ui/Dialog';
import Slide from 'material-ui/transitions/Slide';
import Input from 'material-ui/Input';
import SearchIcon from 'material-ui-icons/Search';
import Tooltip from 'material-ui/Tooltip';

const jobTitles = ['Applications Engineer', 'ARM Facilitator', 'Automation Engineer', 'Cementing Engineer', 'Certification Engineer', 'Chemical Engineer', 'Chief Engineer', 'Civil and Structural Engineer', 'Civil Engineer', 'Close Out Engineer', 'Commissioning Engineer', 'Completions Engineer', 'Construction Engineer', 'Contract Engineer', 'Contracts Engineer'];

function Transition(props) {
  return <Slide direction="up" {...props} />;
}

class ShortList extends Component {
  constructor() {
    super();
    this.state = {
      open: false,
      selected: null, // eslint-disable-line
    };
    this.handleClickOpen = this.handleClickOpen.bind(this);
    this.handleClose = this.handleClose.bind(this);
  }

  handleClickOpen() {
    this.setState({ open: true });
  }

  handleClose() {
    this.setState({ open: false });
  }

  render() {
    return (
      <Fragment>
        <MenuItem onClick={this.handleClickOpen}>
          { this.props.buttonLabel }
        </MenuItem>
        <Dialog open={this.state.open} transition={Transition}>
          <div className="job-list-dialog">
            <header>
              <h2>Add [candidate name] to ... </h2>
            </header>
            <Input
              placeholder="Search currently open jobs"
              inputProps={{ style: { padding: '0.5rem 0', fontSize: '0.8rem' } }}
              className="search"
              endAdornment={
                <SearchIcon />
              }
            />
            <main>
              <ul>
                {
                  jobTitles.map(j =>
                    (
                      <li className="job" key={j}>
                        <h2>
                          <span className="logo">
                            <Tooltip title="Shell, Australia, Prelude FLNG" placement="right">
                              <img src="/logos/shell.svg" alt="Shell" />
                            </Tooltip>
                          </span>
                          {j}
                        </h2>
                        <span className="posted">2d ago</span>
                      </li>
                  ))
                }
              </ul>
            </main>
          </div>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary">
              Cancel
            </Button>
            <Button onClick={this.handleClose} color="primary" raised autoFocus>
              Add to Job
            </Button>
          </DialogActions>
        </Dialog>
      </Fragment>
    );
  }
}

ShortList.propTypes = {
  buttonLabel: PropTypes.string.isRequired,
};

export default ShortList;
