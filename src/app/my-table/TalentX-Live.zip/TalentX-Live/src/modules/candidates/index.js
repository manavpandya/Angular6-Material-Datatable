import React from 'react';
import { connect } from 'react-redux';
import Candidate from './candidates';
import { setFilter, resetFiltered, addToJob, resetFilterParams, flushAllCandidates } from '../../modules/candidates/redux/actions';

const CandidatesContainer = props => (
  <Candidate {...props} showBookmarkedCandidates={false} />
);

function mapStateToProps(state) {
  return {
    filterParam: state.profiles.filterParam,
    searchedValue: state.profiles.searchedValue,
    facetsLoading: state.profiles.facetsLoading,
    isRecentSearched: state.profiles.isRecentSearched,
    candidates: state.profiles.candidates,
    totalCandidates: state.profiles.totalCandidates,
    loadingProfiles: state.profiles.loadingProfiles,
    addToJobLoading: state.profiles.addToJobLoading,
    selectedCandidates: state.profiles.selectedCandidates,
  };
}

export default connect(
  mapStateToProps,
  {
    setFilter,
    resetFiltered,
    addToJob,
    resetFilterParams,
    flushAllCandidates,
  },
)(CandidatesContainer);
