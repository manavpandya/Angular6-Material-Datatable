import React from 'react';
import CandidatesHeader from './CandidatesHeader';
// Need To Be Fix
// import CandidatesLeftMenu from './../../../modules/candidates/CandidatesLeftMenu';

const CandidateList = (
  <div className="page candidates">
    <CandidatesHeader />
    <main>
      {/* <CandidatesLeftMenu /> */}
      <div className="notifications">
        <h2>Notifications &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;New&nbsp;<strong>12</strong>
          <span className="alert" />
        </h2>
      </div>
    </main>
  </div>
);

export default CandidateList;
