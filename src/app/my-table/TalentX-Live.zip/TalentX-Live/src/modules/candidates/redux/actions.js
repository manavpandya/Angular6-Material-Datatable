import api from '../../../shared/api';
import * as ActionTypes from './actionTypes';

const FOR_PAGE = {
  per_page: 100,
  page: 1,
};

export function uploadCandidateProfiles(formData) {
  return {
    type: ActionTypes.UPLOAD_CANDIDATE_PROFILES,
    payload: api.post('/profile/upload', formData),
  };
}

export function fetchProfile(value = {
  search: '',
  per_page: 100,
  page: 1,
  filterParam: '',
}) {
  FOR_PAGE.per_page = value.per_page;
  FOR_PAGE.page = value.page <= 0 ? 1 : value.page;
  return {
    type: ActionTypes.FETCH_PROFILE,
    payload: api.get(`/profile/search?key=${value.search || ''}${value.filterParam || ''}&search_type=${value.filterParam ? 'query_filter' : ''}&page=${FOR_PAGE.page}&per_page=${FOR_PAGE.per_page}`),
  };
}

export function fetchFacet(searchedValue) {
  return {
    type: ActionTypes.FETCH_FACET,
    payload: api.get(`/profile/facets?key=${searchedValue || ''}&search_type=query_filter`),
  };
}

export function setNewSearch(isNewSearch) {
  return {
    type: ActionTypes.IS_NEW_SEARCH,
    payload: isNewSearch,
  };
}

export function getTempToken(profileId) {
  return {
    type: ActionTypes.GET_TEMP_TOKEN,
    payload: api.get('/temp_token')
      .then(res => ({
        tempToken: res.data.temp_token,
        profileId,
      })),
  };
}

export function fetchLocalFilterSearch(searchValue, filterType, mainSearchedValue) {
  return {
    type: ActionTypes.FETCH_LOCAL_FILTER,
    payload: searchValue && api.get(`/profile/search_facets?key=${mainSearchedValue}&search_type=query_filter&autocomplete=${filterType}=${encodeURIComponent(searchValue)}`),
  };
}

export function flushAllCandidates() {
  return {
    type: ActionTypes.FLUSH_ALL_CANDIDATES,
    payload: [],
  };
}

export function setCheckedFilters(key, value) {
  return {
    type: ActionTypes.CHECKED_FILTERS,
    payload: {
      key,
      value,
    },
  };
}

export function resetFilter(id) {
  return {
    type: ActionTypes.RESET_FILTER,
    payload: id,
  };
}

export function resetFilterParams() {
  return {
    type: ActionTypes.RESET_FILTER_PARAM,
    payload: '',
  };
}


export function profileSearch(query, boardSearch) {
  FOR_PAGE.page = 1;
  let finalQuery = '';

  if (query) {
    Object.keys(query).map((key) => { // loop over query for filters
      const values = [];
      if (query[key].items) { // check if there are selected options
        finalQuery = `${finalQuery}&${key === 'exclude_companies' ? 'exclude_fields' : 'fields'}[]=${query[key].filter}`;
        Object.keys(query[key].items).forEach((value) => {
          const val = values.length > 0 ? `||${encodeURIComponent(value)}` : `=${encodeURIComponent(value)}`;
          finalQuery = `${finalQuery}${val}`;
          values.push(values.length > 0 ? `||${encodeURIComponent(value)}` : `=${encodeURIComponent(value)}`);
        });
      }
      return true;
    });
  }
  return (dispatch) => {
    const action1 = {
      type: ActionTypes.FETCH_PROFILE_FACET,
      payload: api.get(`profile/search?search_type=query_filter&key=${boardSearch || ''}${finalQuery}&page=1&per_page=${FOR_PAGE.per_page}`)
        .then(res => ({
          data: res.data,
          filterParam: finalQuery,
          searchedValue: boardSearch,
        })),
    };
    dispatch(action1);
  };
}


export function fetchSinlgleProfile(id) {
  return {
    type: ActionTypes.FETCH_SINGLE_PROFILE,
    payload: api.get(`/profiles/${id}`),
  };
}

export function alljobsOpening() {
  return {
    type: ActionTypes.FETCH_JOBS,
    payload: api.get('/job_position/count?get_count_for=job_description.employer.raw'),
  };
}

export function fetchSavedSearches() {
  return {
    type: ActionTypes.FETCH_SAVED_SEARCHES,
  };
}

export function fetchSuggestions() {
  return {
    type: ActionTypes.FETCH_SUGGESTIONS,
  };
}

export function unsetClearFilter() {
  return {
    type: ActionTypes.SET_CLEAR_FILTER,
  };
}

export function searchTalent(value, filterParam) {
  return (dispatch) => {
    const action1 = {
      type: ActionTypes.GET_TALENT,
      payload: api.get(`/profile/search?key=${value || ''}&search_type=query_filter${filterParam || ''}&page=1&per_page=${FOR_PAGE.per_page}`),
    };
    const action2 = {
      type: ActionTypes.GET_TALENT_VALUE,
      payload: value,
    };
    dispatch(action1);
    dispatch(action2);
  };
}

export function setFilter(filter) {
  return {
    type: ActionTypes.SET_FILTER,
    payload: filter,
  };
}

export function resetFiltered() {
  return {
    type: ActionTypes.RESET_SEARCH,
  };
}

// bookmark candidates
export function bookmarkCandidate(params, whichReducer) {
  let actionType;
  switch (whichReducer) {
    case 'RecruiterJob':
      actionType = ActionTypes.RECRUITER_JOB_BOOKMARK_TALENT;
      break;
    case 'CandidateProfiles':
      actionType = ActionTypes.CANDIDATE_PROFILES_BOOKMARK_TALENT;
      break;
    default:
      actionType = ActionTypes.RECRUITER_JOB_BOOKMARK_TALENT;
      break;
  }
  return {
    type: actionType,
    payload: api.post('/bookmarks', {
      entity_id: params,
      entity_type: 'Profile',
    }).then(res => ({
      data: res.data,
      candidateId: params,
    })),
  };
}

export function removeBookmarkCandidate(params, whichReducer) {
  let actionType;
  switch (whichReducer) {
    case 'RecruiterJob':
      actionType = ActionTypes.REMOVE_RECRUITER_JOB_BOOKMARK_TALENT;
      break;
    case 'CandidateProfiles':
      actionType = ActionTypes.REMOVE_CANDIDATE_PROFILES_BOOKMARK_TALENT;
      break;
    default:
      actionType = ActionTypes.REMOVE_CANDIDATE_PROFILES_BOOKMARK_TALENT;
      break;
  }
  return {
    type: actionType,
    payload: api.delete('/bookmarks', {
      data: {
        entity_id: params,
        entity_type: 'Profile',
      },
    }).then(res => ({
      data: res.data,
      candidateId: params,
    })),
  };
}

export function addToJob(jobId, profileId) {
  return {
    type: ActionTypes.ADD_TO_JOB,
    payload: api.post(`/job_positions/${jobId}/applications`, { profile_id: profileId }),
  };
}

export function addToJobMultiple(jobId, profileId) {
  return {
    type: ActionTypes.ADD_TO_JOB,
    payload: api.post(`/job_position/${jobId}/applications`, { profile_ids: profileId, status: 'shortlisted' }),
  };
}

export function getDistribution(params = { size: 25 }) {
  let endPoint = `/profile/distribution?size=${params.size}`;
  if (params) {
    if (params.location) {
      if (params.location === '-') { endPoint += '&location='; } else { endPoint += `&location=${params.location}`; }
    }
    if (params.sector) {
      endPoint += `&sector=${params.sector}`;
    }
  }
  return {
    type: ActionTypes.GET_DISTRIBUTION,
    payload: api.get(endPoint)
      .then(res => res.data),
  };
}


export function getBookmarkedCandidates(value = {
  page: 1,
  perPage: 100,
}) {
  return {
    type: ActionTypes.GET_BOOKMARKED_CANDIDATES,
    payload: api.get(`/account/bookmarks?page=${value.page}&per_page=${value.perPage}`),
  };
}

export function selectAllCandidates(candidates) {
  return {
    type: ActionTypes.SELECT_ALL_CANDIDATES,
    payload: candidates,
  };
}

export function selectCandidate(candidate) {
  return {
    type: ActionTypes.SELECT_CANDIDATE,
    payload: candidate,
  };
}

export function deselectCandidate(candidateID) {
  return {
    type: ActionTypes.DESELECT_CANDIDATE,
    payload: candidateID,
  };
}
