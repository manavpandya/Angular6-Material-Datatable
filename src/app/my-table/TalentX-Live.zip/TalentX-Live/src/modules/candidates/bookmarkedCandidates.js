import React from 'react';
import { connect } from 'react-redux';
import Candidate from './candidates';
import { getTempToken, getBookmarkedCandidates, fetchProfile, fetchFacet, profileSearch, setFilter, resetFilterParams, flushAllCandidates, resetFiltered, removeBookmarkCandidate } from '../../modules/candidates/redux/actions';

const CandidatesContainer = props => (
  <Candidate {...props} showBookmarkedCandidates />
);

function mapStateToProps(state) {
  return {
    isResumeLoading: state.profiles.isResumeLoading,
    candidates: state.profiles.candidates,
    candidatesLoading: state.profiles.candidatesLoading,
    candidatesProfilesLoading: state.profiles.candidatesLoading,
    available: state.profiles.available,
    pastApplication: state.profiles.pastApplication,
    searchedTalent: state.profiles.searchedTalent,
    totalCandidates: state.profiles.totalCandidates,
    loadingProfiles: state.profiles.loadingProfiles,
    filter: state.profiles.filter,
    facets: state.profiles.facets,
    tempToken: state.profiles.tempToken,
    selectedCandidates: state.profiles.selectedCandidates,
  };
}

export default connect(
  mapStateToProps,
  {
    fetchProfile,
    getBookmarkedCandidates,
    fetchFacet,
    profileSearch,
    setFilter,
    resetFilterParams,
    flushAllCandidates,
    getTempToken,
    resetFiltered,
    removeBookmarkCandidate,
  },
)(CandidatesContainer);
