import _ from 'lodash';
import React from 'react';
import PropTypes from 'prop-types';
import Autosuggest from 'react-autosuggest';
import match from 'autosuggest-highlight/match';
import parse from 'autosuggest-highlight/parse';
import TextField from 'material-ui/TextField';
import Paper from 'material-ui/Paper';
import { MenuItem } from 'material-ui/Menu';
import { withStyles } from 'material-ui/styles';
import LoaderForSearch from './../../../shared/basic/LoaderForSearch';

// function getSuggestions(value, filterSuggestions) {
//   const inputValue = value.trim().toLowerCase();
//   const inputLength = inputValue.length;
//   let count = 0;
//   const suggestions = filterSuggestions || [];
//   return inputLength === 0
//     ? []
//     : suggestions.filter((suggestion) => {
//       const keep =
//         count < 5 && suggestion.key.toLowerCase().slice(0, inputLength) === inputValue;

//       if (keep) {
//         count += 1;
//       }

//       return keep;
//     });
// }

const styles = theme => ({
  container: {
    flexGrow: 1,
    position: 'relative',
    height: 100,
  },
  suggestionsContainerOpen: {
    position: 'absolute',
    zIndex: 1,
    marginTop: theme.spacing.unit,
    left: 0,
    right: 0,
  },
  suggestion: {
    display: 'block',
  },
  suggestionsList: {
    margin: 0,
    padding: 0,
    listStyleType: 'none',
  },
});

class IntegrationAutosuggest extends React.Component {
  constructor() {
    super();
    this.state = {
      value: '',
      suggestions: [],
      isLoading: false,
    };
    this.handleSuggestionsFetchRequested = this.handleSuggestionsFetchRequested.bind(this);
    this.handleSuggestionsClearRequested = this.handleSuggestionsClearRequested.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.search = this.search.bind(this);
    this.searchClick = this.searchClick.bind(this);
    this.renderInput = this.renderInput.bind(this);
    this.renderSuggestion = this.renderSuggestion.bind(this);
    this.debouncedLoadSuggestions = _.debounce(this.loadSuggestions, 500);
    this.getSuggestionValue = this.getSuggestionValue.bind(this);
  }

  getSuggestionValue(suggestion) { //eslint-disable-line
    return suggestion.key;
  }

  loadSuggestions(value) {
    this.setState({
      isLoading: true,
    });
    const filterType = this.props.currentFilterType;
    if (this.props.fetchLocalFilterSearch !== undefined) {
      this.props.fetchLocalFilterSearch(
        value,
        filterType,
        this.props.searchedValue,
      ).then(() => {
        this.setState({
          isLoading: false,
          suggestions: this.props.suggestions,
        });
      });
    }
  }

  search(event) {
    if (event.key === 'Enter') {
      const query = event.target.value;
      let matched = null;
      for(let data of this.props.suggestions) { //eslint-disable-line
        if (data.key.toLowerCase() === query.toLowerCase()) {
          matched = data;
        }
      }
      if (matched) {
        if (this.props.addToList) this.props.addToList(matched, true);
        this.setState({
          value: '',
        });
      }
    }
  }
  searchClick(event) {
    // if (event.key === 'Enter') {
    const query = event.value;
    let matched = null;
    for(let data of this.props.suggestions) { //eslint-disable-line
      if (data.key.toLowerCase() === query.toLowerCase()) {
        matched = data;
      }
    }
    // if (matched) {
    if (this.props.addToList) this.props.addToList(matched, true);
    setTimeout(() => {
      this.setState({
        value: '',
      });
    }, 10);
    // }
    // }
  }
  handleChange(event, { newValue }) {
    this.setState({
      value: newValue,
    });
  }

  handleSuggestionsFetchRequested({ value }) {
    this.debouncedLoadSuggestions(value);
  }

  handleSuggestionsClearRequested() {
    this.setState({
      suggestions: [],
    });
  }

  renderSuggestion(suggestion, { query, isHighlighted }) {
    const matches = match(suggestion, query);
    const parts = parse(suggestion, matches);
    return (
      <MenuItem selected={isHighlighted} component="div" className="suggestionMenuItem">
        <div className="suggestionMenu">
          {parts.map((part, index) => (part.highlight ? (
            <span
              key={String(index)}
              style={{ fontWeight: 300 }}
              role="presentation"
              onKeyDown={() => {}}
              onClick={() => this.searchClick({ value: part.text.key })}
            >
              {`${part.text.key} (${part.text.doc_count})`}
            </span>
          ) : (
            <strong
              key={String(index)}
              style={{ fontWeight: 500 }}
              role="presentation"
              onKeyDown={() => {}}
              onClick={() => this.searchClick({ value: part.text.key })}
            >
              {`${part.text.key} (${part.text.doc_count})`}
            </strong>
          )
        ))}
        </div>
      </MenuItem>
    );
  }

  renderSuggestionsContainer(options) { //eslint-disable-line
    const { containerProps, children } = options;
    if (containerProps.className) {
      return (
        <Paper {...containerProps} square>
          {children}
        </Paper>
      );
    }
    return null;
  }
  renderInput(inputProps) {
    const { classes, ref, ...other } = inputProps;

    return (
      <TextField
        fullWidth
        InputProps={{
          inputRef: ref,
          ...other,
        }}
        onKeyPress={this.search}
      />
    );
  }

  render() {
    const { classes } = this.props;
    return (
      <div>
        <Autosuggest
          theme={{
            container: classes.container,
            suggestionsContainerOpen: classes.suggestionsContainerOpen,
            suggestionsList: classes.suggestionsList,
            suggestion: classes.suggestion,
          }}
          renderInputComponent={this.renderInput}
          suggestions={this.state.suggestions}
          onSuggestionsFetchRequested={this.handleSuggestionsFetchRequested}
          onSuggestionsClearRequested={this.handleSuggestionsClearRequested}
          renderSuggestionsContainer={this.renderSuggestionsContainer}
          getSuggestionValue={this.getSuggestionValue}
          renderSuggestion={this.renderSuggestion}
          inputProps={{
            autoFocus: true,
            classes,
            placeholder: 'Search . . .',
            value: this.state.value,
            onChange: this.handleChange,
          }}
        />
        { (this.props.suggestionsLoading && this.state.isLoading) ? <LoaderForSearch /> : null }
      </div>
    );
  }
}

IntegrationAutosuggest.propTypes = {
  classes: PropTypes.objectOf(Object).isRequired,
  suggestions: PropTypes.arrayOf(Object).isRequired,
  addToList: PropTypes.func.isRequired,
  currentFilterType: PropTypes.string.isRequired,
  fetchLocalFilterSearch: PropTypes.func.isRequired,
  suggestionsLoading: PropTypes.bool.isRequired,
  searchedValue: PropTypes.string.isRequired,
};

export default withStyles(styles)(IntegrationAutosuggest);
