import React from 'react';
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
// import { LineMarkSeries } from 'react-vis';
import Dialog, { DialogActions } from 'material-ui/Dialog';
import Slide from 'material-ui/transitions/Slide';
import ChartIcon from 'material-ui-icons/ShowChart';
// import Sunburst from 'react-sunburst-d3-v4';
// import Badge from 'material-ui/Badge'
// import data from './data/distribution'

const styles = {
  appBar: {
    position: 'relative',
  },
  flex: {
    flex: 1,
  },
};

function Transition(props) {
  return <Slide direction="up" {...props} />;
}

class JobLibraryMatches extends React.Component {
  constructor() {
    super();
    this.state = {
      open: false,
      // active_tab: null,
    };
  }

  // onSelect(event) {
  //   console.log(event);
  // }

  handleClickOpen() {
    this.setState({ open: true });
  }

  handleClose() {
    this.setState({ open: false });
  }

  render() {
    return (
      <div>
        <Button onClick={this.handleClickOpen} color="primary">
          <ChartIcon />&nbsp;
          Trends
        </Button>
        <Dialog open={this.state.open} transition={Transition} maxWidth="md">
          <div className="trends-chart">
            {/* <LineMarkSeries
              data={data}
              style={{ line: { stroke: "blue" }, mark: { stroke: "red" } }}
            /> */}
          </div>
          <DialogActions>
            <Button onClick={this.handleClose} color="primary" autoFocus>
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </div>
    );
  }
}

export default withStyles(styles)(JobLibraryMatches);
