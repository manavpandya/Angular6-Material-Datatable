import React, { Component } from 'react';
import {
  FormControl,
  FormGroup,
  FormControlLabel,
} from 'material-ui/Form';
import Checkbox from 'material-ui/Checkbox';
import TextField from 'material-ui/TextField';
import Select from 'material-ui/Select';
import { MenuItem } from 'material-ui/Menu';

import Divider from 'material-ui/Divider';

class CandidatesFacet extends Component {
  constructor() {
    super();
    this.state = {
      available: true,
    };
    this.handleChange = this.handleChange.bind(this);
  }
  // THIS NEED TO FIX
  handleChange() {
    this.setState({ available: !this.state.available });
  }
  // handleChange = name => (event, checked) => {
  //   this.setState({ [name]: checked });
  // };
  render() {
    return (
      <div className="filters">
        <h2>Filters</h2>
        <Divider />
        <FormControl component="fieldset" className="filter">
          <FormGroup>
            <FormControlLabel
              control={
                <Checkbox
                  checked={this.state.available}
                  onChange={this.handleChange('available')}
                  value="available"
                />
              }
              label="Currently Available"
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={!this.state.available}
                  onChange={this.handleChange('available')}
                  value="availablefrom"
                />
              }
              label="Available From ..."
            />
          </FormGroup>
        </FormControl>
        <FormControl component="fieldset" className="filter">
          <FormGroup>
            <TextField
              id="location"
              label="Current Location"
            />
          </FormGroup>
        </FormControl>
        <FormControl component="fieldset" className="filter">
          <FormGroup>
            <div style={{ display: 'flex', alignItems: 'baseline' }}>
              <TextField
                id="ctc"
                label="Current CTC"
              />
              <Select
                id="currency"
                name="currency"
                value={1}
              >
                <MenuItem value={1}>AUD</MenuItem>
                <MenuItem value={2}>USD</MenuItem>
                <MenuItem value={3}>INR</MenuItem>
              </Select>
            </div>
          </FormGroup>
        </FormControl>
        <FormControl component="fieldset" className="filter">
          <h3>Tx Logs</h3>
          <FormGroup>
            <FormControlLabel
              control={<Checkbox />}
              label="Directly Applied"
            />
            <FormControlLabel
              control={<Checkbox />}
              label="Referral"
            />
            <FormControlLabel
              control={<Checkbox />}
              label="Approved for hire .."
            />
          </FormGroup>
        </FormControl>
      </div>
    );
  }
}
export default CandidatesFacet;
