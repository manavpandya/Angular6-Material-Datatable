import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import PropTypes from 'prop-types';
import BoardHeader from '../../shared/compound/board/BoardHeader';
import CandidateListContainer from '../../shared/compound/CandidateList/CandidateListContainer';
import AdvancedSearchPanel from './../../shared/compound/AdvancedSearchPanel';
import AddToJobDialog from '../../shared/compound/AddToJobDialog';
import CandidateActions from '../../modules/candidates/components/CandidateActions';

class Candidates extends Component {
  constructor(props) {
    super(props);
    this.state = {
      addtoJobCandidates: {},
      isAddToJobDialogOpen: false,
    };

    this.openAddToJobDialog = this.openAddToJobDialog.bind(this);
    this.closeAddToJobDialog = this.closeAddToJobDialog.bind(this);
  }

  openAddToJobDialog(candidateInfo) {
    this.setState({
      addtoJobCandidates: candidateInfo,
      isAddToJobDialogOpen: true,
    });
  }

  closeAddToJobDialog() {
    this.setState({ isAddToJobDialogOpen: false, addtoJobCandidates: {} });
  }

  render() {
    return (
      <div className="page candidates">
        <BoardHeader
          headerName="3002🚀"
          showBookmarkedCandidates={this.props.showBookmarkedCandidates}
        />
        <div className="results">
          {
              this.props.showBookmarkedCandidates === false
              ?
                <AdvancedSearchPanel
                  showFacets={[
                    { key: 'companies', type: 'checkbox', component: 'company' },
                    { key: 'exclude_companies', type: 'checkbox', component: 'company' },
                    { key: 'current_location', type: 'checkbox', component: 'location' },
                    { key: 'preferred_location', type: 'checkbox', component: 'location' },
                    { key: 'experience', type: 'slider' },
                    { key: 'job_titles', type: 'checkbox' },
                    { key: 'qualifications', type: 'checkbox' },
                    { key: 'skills', type: 'checkbox' },
                    { key: 'spoken_language', type: 'checkbox' },
                  ]}
                />
              :
                <div />
            }
          <main className={`${this.props.showBookmarkedCandidates ? 'main' : ''}`}>
            <CandidateListContainer
              facetsLoading={this.props.facetsLoading}
              isRecentSearched={this.props.isRecentSearched}
              candidates={this.props.candidates}
              openMenu={this.openMenu}
              match={this.props.match}
              loadingProfiles={this.props.loadingProfiles}
              addToJobLoading={this.props.addToJobLoading}
              showBookmarkedCandidates={this.props.showBookmarkedCandidates}
              totalCandidates={this.props.totalCandidates}
              filters={
                <div className="list-header">
                  <div className="candidates-result-metrics">
                    <h2>
                      { this.props.searchedValue || this.props.filterParam ?
                        <span>{this.props.translate('topMatches')}
                          <small className="light-grey">
                            {
                                this.props.searchedValue && this.props.filterParam ? null :
                                this.props.searchedValue && this.props.totalCandidates
                            }
                          </small>
                        </span>
                        :
                        <span>{this.props.totalCandidates} {this.props.translate('totalCandidates')}</span>
                      }
                    </h2>
                  </div>
                  <div className="bulk-action">
                    <CandidateActions
                      openAddToJobDialog={this.openAddToJobDialog}
                      bulkAction
                      selectedCandidates={this.props.selectedCandidates}
                      isDisabled={!this.props.selectedCandidates
                        || this.props.selectedCandidates.length === 0}
                    />
                  </div>
                </div>
                }
            />
          </main>
        </div>
        <AddToJobDialog
          addtoJobCandidates={this.state.addtoJobCandidates.length
            ? this.state.addtoJobCandidates[0] : this.state.addtoJobCandidates}
          addtoJobCandidatesMultiple={this.state.addtoJobCandidates.length
            ? this.state.addtoJobCandidates : []}
          isAddToJobDialogOpen={this.state.isAddToJobDialogOpen}
          closeAddToJobDialog={this.closeAddToJobDialog}
        />
      </div>
    );
  }
}

Candidates.propTypes = {
  translate: PropTypes.func.isRequired,
  match: PropTypes.object.isRequired, // eslint-disable-line
  candidates: PropTypes.arrayOf.isRequired,
  totalCandidates: PropTypes.number.isRequired,
  loadingProfiles: PropTypes.bool.isRequired,
  addToJobLoading: PropTypes.bool.isRequired,
  showBookmarkedCandidates: PropTypes.bool.isRequired,
  checkedFilters: PropTypes.object.isRequired, // eslint-disable-line
  isRecentSearched: PropTypes.bool.isRequired,
  facetsLoading: PropTypes.bool.isRequired,
  showFacets: PropTypes.objectOf(PropTypes.arrayOf), // eslint-disable-line
  searchedValue: PropTypes.string.isRequired,
  filterParam: PropTypes.string.isRequired,
  selectedCandidates: PropTypes.arrayOf(PropTypes.any).isRequired,
};

export default withTranslate(Candidates);
