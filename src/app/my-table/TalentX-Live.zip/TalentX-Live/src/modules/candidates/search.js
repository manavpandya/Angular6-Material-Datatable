import React from 'react';
import CandidatesHeader from '../candidates/components/CandidatesHeader';
// Need To Be Fix
// import CandidatesLeftMenu from './../../../modules/candidates/CandidatesLeftMenu';

const CandidateList = () => (
  <div className="page candidates">
    <CandidatesHeader />
    <main>
      {/* <CandidatesLeftMenu /> */}
    </main>
  </div>
);

export default CandidateList;
