import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import ExpandMoreIcon from 'material-ui-icons/ExpandMore';
import Menu from '../../../shared/compound/Menu';


const CandidatesSavedSearches = ({ saved }) => (
  <Menu
    label={<h3 className="saved-searches_h2" >Saved Searches</h3>}
    iconSuffix={<ExpandMoreIcon className="expand-more-icon" />}
    popup={
      <div className="nav candidates-searches">
        <div className="navitem">
          {saved.map(item => (
            <Link key={item.id} to={item.link} >
              {item.title}
              <strong><span className="alert" />{item.count}</strong>
            </Link>
          ))}
        </div>
      </div>
    }
  />
);

CandidatesSavedSearches.propTypes = {
  saved: PropTypes.arrayOf.isRequired,
};

export default CandidatesSavedSearches;
