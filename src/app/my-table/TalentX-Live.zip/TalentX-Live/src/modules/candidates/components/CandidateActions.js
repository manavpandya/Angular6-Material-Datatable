import React, { Component } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { connect } from 'react-redux';
import { PropTypes } from 'prop-types';
import MoreIcon from 'material-ui-icons/MoreVert';
import { MenuList, MenuItem } from 'material-ui/Menu';
// import ShortList from './ShortList';
import Menu from '../../../shared/compound/Menu';
import { bookmarkCandidate } from '../redux/actions';

class CandidateActions extends Component {
  constructor(props) {
    super(props);
    this.bookmark = this.bookmark.bind(this);
  }
  bookmark(value) {
    this.props.bookmarkCandidate(value);
  }
  render() {
    return (
      <div className="candidate-actions">
        <Menu
          label=""
          iconPrefix={<MoreIcon className="more-vert" style={{ color: this.props.isDisabled ? 'rgb(200, 200, 200)' : '#333' }} />}
          isDisabled={
            this.props.isDisabled
          }
          popup={
            <MenuList role="menu">
              <MenuItem
                className="menu-item"
                onClick={() => this.props.openAddToJobDialog(this.props.bulkAction
                  ? this.props.selectedCandidates : this.props.candidates)}
              >
                {this.props.translate('addToJob')}
              </MenuItem>
            </MenuList>
          }
        />
      </div>
    );
  }
}

CandidateActions.propTypes = {
  translate: PropTypes.func.isRequired,
  bookmarkCandidate: PropTypes.func.isRequired,
  openAddToJobDialog: PropTypes.func,
  candidates: PropTypes.objectOf(Object),
  isDisabled: PropTypes.bool,
  bulkAction: PropTypes.bool,
  selectedCandidates: PropTypes.arrayOf(PropTypes.any),
};

CandidateActions.defaultProps = {
  openAddToJobDialog: () => {},
  candidates: {},
  isDisabled: false,
  bulkAction: false,
  selectedCandidates: [],
};

export default connect(null, { bookmarkCandidate })(withTranslate(CandidateActions));
