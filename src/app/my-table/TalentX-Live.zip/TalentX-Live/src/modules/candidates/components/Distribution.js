import React, { Fragment } from 'react';
import { withTranslate } from 'react-redux-multilingual';
import { withStyles } from 'material-ui/styles';
import Button from 'material-ui/Button';
import CloseIcon from 'material-ui-icons/Close';
import Dialog, { DialogContent } from 'material-ui/Dialog';
import Slide from 'material-ui/transitions/Slide';
import ChartIcon from 'material-ui-icons/InsertChart';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import traverse from 'traverse';
import SunBurst from '../../../shared/basic/SunBurst';
import { getDistribution } from '../redux/actions';
import Loader from '../../../shared/basic/Loader';

const styles = {
  appBar: {
    position: 'relative',
  },
  flex: {
    flex: 1,
  },
  chartContainer: {
    verticalAlign: 'top',
    display: 'inherit',
  },
  chartChild: {
    display: 'inline-block',
    verticalAlign: 'top',
  },
};

function Transition(props) {
  return <Slide direction="up" {...props} />;
}

function modifiyData(data) {
  function changeKeyName() {
    // to skip first node as it doesn't have parent
    if (this.parent && this.parent.node.key !== undefined) {
      // if node is leaf node i.e key is 'doc_count' or 'key' then
      // change its key name from 'doc_count' to 'value'
      // else change key name from 'key' to 'name' for all nodes
      if (
        this.isLeaf &&
        (this.parent.node.children === undefined ||
          this.parent.node.children.length === 0)
      ) {
        this.parent.node.value = this.parent.node.doc_count;
      }
      this.parent.node.name = this.parent.node.key || '';
      delete this.parent.node.key;
    }
  }
  traverse(data).forEach(changeKeyName);
  return data;
}

class Distribution extends React.Component {
  constructor() {
    super();
    this.state = {
      open: false,
      stack: ['Locations'],
      size: 50,
    };
    this.fetchNextLevelData = this.fetchNextLevelData.bind(this);
    this.showTooltipOnHover = this.showTooltipOnHover.bind(this);
    this.handleBreadCrumbs = this.handleBreadCrumbs.bind(this);
    this.handleClose = this.handleClose.bind(this);
    this.handleSizeChange = this.handleSizeChange.bind(this);
  }

  handleBreadCrumbs(stackIndex) {
    const newStack = this.state.stack;
    newStack.length = stackIndex + 1;
    this.setState({
      stack: newStack,
    }, () => this.fetchNextLevelData());
  }

  showTooltipOnHover(node, nodeStack) {
    const { stack } = this.state;
    let label = 'Locations';
    if (stack.length === 2) { label = 'Sectors'; }
    if (stack.length === 3) { label = 'Skills'; }
    let tooltip = '';
    if (node.data) {
      tooltip += `Candidates: ${node.data.doc_count || node.value || 0}<br />`;
      if (stack.length > 1) { tooltip += `Location: ${stack[1]}<br />`; }
      if (stack.length > 2) { tooltip += `Sector: ${stack[2]}<br />`; }
      nodeStack.forEach((item, index) => {
        if (index !== 0) {
          tooltip += `${label}: ${item.data.name}<br />`;
        }
      });
    }
    return tooltip;
  }

  fetchNextLevelData(node) {
    const { stack, size } = this.state;
    if (node && node.depth === 1) {
      if (stack.length === 3) return;
      stack.push(node.data.name || '-');
      this.setState({
        stack,
      });
    }
    if (node && node.depth === 0) {
      if (stack.length > 1) { stack.pop(); }
      this.setState({
        stack,
      });
    }
    if (stack.length > 2) {
      this.props.getDistribution({
        location: stack[1],
        sector: stack[2],
        size,
      });
    } else if (stack.length > 1) {
      this.props.getDistribution({
        location: stack[1],
        size,
      });
    } else {
      this.props.getDistribution({
        size,
      });
    }
  }

  handleClickOpen() {
    const { size } = this.state;
    this.setState({ open: true });
    this.props.getDistribution({
      size,
    });
  }

  handleClose() {
    this.setState({ open: false, stack: ['Locations'] });
  }

  handleSizeChange(e) {
    this.setState({ size: e.target.value }, () => {
      const { stack, size } = this.state;
      if (stack.length > 2) {
        this.props.getDistribution({
          location: stack[1],
          sector: stack[2],
          size,
        });
      } else if (stack.length > 1) {
        this.props.getDistribution({
          location: stack[1],
          size,
        });
      } else {
        this.props.getDistribution({
          size,
        });
      }
    });
  }

  renderChart() {
    let { data } = this.props;

    data = modifiyData(data);
    let chart = null;
    if (this.props.error) {
      chart = <p>An error occured while fetching data. Please try again!</p>;
    } else {
      chart = this.props.loading ? (
        <Loader />
      ) : (
        <SunBurst
          data={data}
          title="Candidates"
          getTooltip={(node, stack) => this.showTooltipOnHover(node, stack)}
          fetchNextLevel={(node, callback) => this.fetchNextLevelData(node, callback)}
        />
      );
    }
    return chart;
  }

  render() {
    return (
      <div>
        <Button onClick={() => this.handleClickOpen()} color="primary">
          <ChartIcon />&nbsp; {this.props.translate('distribution')}
        </Button>
        <Dialog open={this.state.open} transition={Transition} maxWidth="xl">
          <DialogContent className="visualisation-dialog">
            <h1>Distribution</h1>
            <ul className="distribution-breadcrumb">
              {
                this.state.stack.map(((item, index) => (
                  <Fragment>
                    <li
                      className={index !== this.state.stack.length - 1 ? 'breadcrumbs' : ''}
                      role="presentation"
                      onKeyDown={() => {}}
                      onClick={() => {
                        if (index !== this.state.stack.length - 1) {
                          this.handleBreadCrumbs(index);
                        }
                      }}
                    >
                      {item}
                    </li>
                  </Fragment>
                )))
              }
            </ul>
            <div
              className="distribution-chart"
              style={styles.chartContainer}
            >
              <main style={styles.chartChild}>
                {
                  this.renderChart()
                }
              </main>
            </div>
            <span className="size-selection">
              <label htmlFor="distribution-size">Size: </label>
              <select
                name="distribution-size"
                id="distribution-size"
                value={this.state.size}
                onChange={this.handleSizeChange}
              >
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="75">75</option>
                <option value="100">100</option>
                <option value="125">125</option>
                <option value="150">150</option>
                <option value="175">175</option>
                <option value="200">200</option>
              </select>
            </span>
            <div className="actions">
              <Button onClick={this.handleClose} color="primary" autoFocus>
                <CloseIcon style={{ color: '#333', width: '1em', height: '1em' }} />
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }
}

Distribution.propTypes = {
  translate: PropTypes.func.isRequired,
  getDistribution: PropTypes.func.isRequired,
  data: PropTypes.instanceOf(Object).isRequired,
  loading: PropTypes.bool.isRequired,
  error: PropTypes.bool.isRequired,
};

const mapStateToProps = state => ({
  data: state.profiles.distributionData,
  loading: state.profiles.distributionDataLoading,
  error: state.profiles.distributionDataError,
});

export default connect(
  mapStateToProps,
  { getDistribution },
)(withStyles(styles)(withTranslate(Distribution)));
