import React from "react";
import {Card, CardActions, CardHeader , CardMedia , CardTitle ,CardText } from 'material-ui/Card';
import {blue500, red500, greenA200} from 'material-ui/styles/colors';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import FontIcon from 'material-ui/FontIcon';
import TextField from 'material-ui/TextField';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import Divider from 'material-ui/Divider';

class Contact extends React.Component {
  constructor() {
    super();
    this.state = {
        message: "Welcome To Contact Page",
        firstname :'',
        lastname : '',
        country : '',
        email : ''
    };
    this.formChange = this.formChange.bind(this);
    this.Submit = this.Submit.bind(this);
  }

  handleChange = (event, index, value) => this.setState({ country:  value});

  formChange = e => 
  {
    this.setState(
      {
        [e.target.name] : e.target.value     
      }
    )
  }

  Submit = e =>
  {
    e.preventDefault();
    console.log(JSON.stringify(this.state,null,2));
  }

  render() {
    
    const Mystyle =
    {
        textAlign : 'center',
        width:'25%',
        paddingLeft: '37%'
    }

    const CardStyle =
    {
        height : '150px'
    }

    return (
      <div>
        <form onSubmit={this.Submit} >
        <Card><br/>
          <h2>Contact me to get in touch</h2><br/>
          <Divider/>
          <TextField
            name="firstname"
            value = {this.state.firstname}
            onChange={(e) => this.formChange(e)}
            hintText="Enter your first name"
            floatingLabelText="First Name"/><br />
          <TextField
            name="lastname"
            value = {this.state.lastname}
            onChange={(e) => this.formChange(e)}
            hintText="Enter your last name"
            floatingLabelText="Last Name"
          /><br />
          <SelectField
            multiple={true}
            name="country"
            value = {this.state.country}
            onChange={(e) => this.formChange(e)}
            floatingLabelText="Country"
            onChange={this.handleChange}
            autoWidth={true}>
              <MenuItem value="India" primaryText="India" />
              <MenuItem value="U.S.A" primaryText="U.S.A" />
              <MenuItem value="Australia" primaryText="Australia" />
              <MenuItem value="Canada" primaryText="Canada" />
              <MenuItem value="London" primaryText="London" />
          </SelectField><br/>
          <TextField
            name="email"
            value = {this.state.email}
            onChange={(e) => this.formChange(e)}
            hintText="Enter email address"
            floatingLabelText="Email"/><br />
          <Divider/><br/>
          <RaisedButton type="Submit" label="Conact Me" primary={true} /><br/><br/>
        </Card>
        </form>
      </div>
    );
  }
}

export default Contact;
