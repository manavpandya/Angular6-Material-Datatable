import React from "react";
import {Card, CardActions, CardHeader , CardMedia , CardTitle ,CardText } from 'material-ui/Card';
import Divider from 'material-ui/Divider';
import FlatButton from 'material-ui/FlatButton';
import TextField from 'material-ui/TextField';

var MyClasses = {
  enter: {
    backgroundColor: "skyblue"
  },
  leave: {
    backgroundColor: "purple"
  }
};

class Events extends React.Component {
  constructor() {
    super();
    this.state = {
        message: '',
        eventStatus : 'enter'
    };
    
  }

  ClickEvent()
  {
      alert("Hello !!!");
  }

  onTextChange(event)
  {
    this.setState({
        message: event.target.value
    });
  }

  enter()
  {
    this.setState(
      {
        eventStatus : 'enter'
      }
    )
  }
    
  leave()
  {
    this.setState(
      {
        eventStatus : 'leave'
      }
    )
  }

  render() {

    return (
      <Card>
         <h1>Few glimps of events</h1><br/>
         <Divider/>
         <h1>1 - Button Click Event</h1><br/>
         <FlatButton
            onClick={this.ClickEvent}
            label="Click To See Alert"
            primary={true}/><br/>
         <Divider/>
         <h1>2 - Text change event</h1><br/>
         <TextField
         onChange={this.onTextChange.bind(this)}
            hintText="Hint Text"
            floatingLabelText="Floating Label Text"/><br />
        <h3>And your name goes here -> {this.state.message} </h3><br />
         <Divider/>
         <h1>3 - Hover event</h1><br/>
        <div 
          style={{height:'200px',width:'200px',backgroundColor: 'purple',marginLeft: '636px',...MyClasses[this.state.eventStatus] }}
          onMouseEnter={this.enter.bind(this)}
          onMouseLeave={this.leave.bind(this)}>
        </div>
      </Card>
    );
  }
}

export default Events;
