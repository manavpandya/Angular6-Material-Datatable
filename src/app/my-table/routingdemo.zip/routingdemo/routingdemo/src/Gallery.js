import React from "react";
import {Card, CardActions, CardHeader , CardMedia , CardTitle ,CardText } from 'material-ui/Card';
import Divider from 'material-ui/Divider';
import images from './image-api';

const imagesStyle = {
    height: '400px',
    width: '400px'
  };

const Thumbnail = props => {
    return (
      <div  className="gallery-image-thumbnail" title={props.title}>
        <img style={imagesStyle} src={props.imageUrl} className="gallery-image" alt={props.alt} />&nbsp;
      </div>
    );
  };
  
  const Gallerys = ({ images }) => {
    return (
      <section  className="gallery-images-container">
        {images.map((image,key) => {
          return <Thumbnail {...image} />;
        })}
      </section>
    );
  };

class Gallery extends React.Component {
  constructor() {
    super();
    this.state = {
        message: "Few Inspirational Quotes I Follow "
    };
  }
  render() {
    return (
      <Card>
        <CardHeader
            title="Manav Pandya"
            subtitle={this.state.message}
            avatar="https://csharpcorner-mindcrackerinc.netdna-ssl.com/UploadFile/AuthorImage/da303220160513054348.jpg"/>
        <Divider/>
        <CardText>
              This page describes about few quotes where i get motivated 
        </CardText>
        <Divider/>
        <CardMedia>
            <Gallerys images={images} />
        </CardMedia>
      </Card>
    );
  }
}

export default Gallery;
