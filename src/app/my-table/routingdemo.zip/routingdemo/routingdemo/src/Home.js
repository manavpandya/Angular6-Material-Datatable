import React from "react";

class Home extends React.Component {
  constructor() {
    super();
    this.state = {
        message: "Welcome To Home Page"
    };
  }
  render() {
    return (
      <section>
        <h1>{this.state.message}</h1>
      </section>
    );
  }
}

export default Home;
