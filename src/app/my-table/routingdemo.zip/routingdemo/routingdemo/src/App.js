import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import './contents/menu.css';
import { BrowserRouter as Router, Route, Link ,Switch} from "react-router-dom";
import Home from './Home';
import About from './About';
import Contacts from './Contact';
import Routes from './Routes';
import Header from './Header';
import Gallery from './Gallery';
import Events from './Events';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

class App extends Component {
  render() {
    return (
      
        <MuiThemeProvider>
          <div className="App">
              <Header/>
              <Routes/>
          </div>
        </MuiThemeProvider>
    );
  }
}

export default App;
