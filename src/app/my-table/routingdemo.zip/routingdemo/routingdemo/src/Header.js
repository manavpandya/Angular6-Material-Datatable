import React from "react";
import { Link } from "react-router-dom";


const Header = () => (
  <header>
    <nav>
    <div className="container">
        <ul style={{ width: '41%', marginLeft: '28%'}} id="nav">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About</Link>
                {/* <ul className="subs">
                    <li><a href="#">Submenu 2-1</a></li>
                    <li><a href="#">Submenu 2-2</a></li>
                    <li><a href="#">Submenu 2-3</a></li>
                    <li><a href="#">Submenu 2-4</a></li>
                    <li><a href="#">Submenu 2-5</a></li>
                    <li><a href="#">Submenu 2-6</a></li>
                    <li><a href="#">Submenu 2-7</a></li>
                    <li><a href="#">Submenu 2-8</a></li>
                </ul> */}
            </li>
            <li><Link to="/contact">Contact</Link></li>
            <li><a href="/gallery">Gallery</a></li>
            <li><a href="/events">Events</a></li>
            <li><a href="#">Menu 6</a></li>
            <li><a href="#">Back</a></li>
            <div id="lavalamp"></div>
        </ul>
    </div>
    </nav>
  </header>
);

export default Header;
