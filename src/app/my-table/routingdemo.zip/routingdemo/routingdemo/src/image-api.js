const images =
[
    {
        key : 1,
        title : 'Title 1',
        alt : 'Image may not found',
        imageUrl : 'https://quotespics.net/wp-content/uploads/2016/04/Famous-Quotes-Motivational-Quotes-Inspirational-Quotes-Life-Quotes-820.jpg'
    },
    {
        key : 2,
        title : 'Title 2',
        alt : 'Image may not found',
        imageUrl : 'https://quotespics.net/wp-content/uploads/2016/04/Motivation-Picture-Quote-Live-Your-Life.jpg'
    },
    {
        key : 3,
        title : 'Title 3',
        alt : 'Image may not found',
        imageUrl : 'https://quotespics.net/wp-content/uploads/2016/04/funny-inspirational-quotes-about-life-and-love1.jpg'
    },
    {
        key : 4,
        title : 'Title 4',
        alt : 'Image may not found',
        imageUrl : 'https://quotespics.net/wp-content/uploads/2016/04/inspirational-quotes-about-life-and-lesson.jpg'
    },
    {
        key : 5,
        title : 'Title 5',
        alt : 'Image may not found',
        imageUrl : 'https://quotespics.net/wp-content/uploads/2016/04/life-1.jpg'
    },
    {
        key : 6,
        title : 'Title 6',
        alt : 'Image may not found',
        imageUrl : 'https://theultralinx.com/.image/c_limit%2Ccs_srgb%2Cq_80%2Cw_960/MTM1Njg4Mjk2MzQ4MDQzMjc0/discipline-mockjpg.webp'
    }
]

export default images