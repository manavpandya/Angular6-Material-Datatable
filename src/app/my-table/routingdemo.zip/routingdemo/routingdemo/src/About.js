import React from "react";
import {Card, CardActions, CardHeader , CardMedia , CardTitle ,CardText } from 'material-ui/Card';
import {blue500, red500, greenA200} from 'material-ui/styles/colors';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import FlatButton from 'material-ui/FlatButton';
import FontIcon from 'material-ui/FontIcon';
import Divider from 'material-ui/Divider';

class About extends React.Component {
  constructor() {
    super();
    this.state = {
        message: "Welcome To About Page"
    };
  }
  render() {
    return (
      
      
      <Card>
          <CardHeader
            title="Manav Pandya"
            subtitle="Portfolio"
            avatar="https://csharpcorner-mindcrackerinc.netdna-ssl.com/UploadFile/AuthorImage/da303220160513054348.jpg"/>
          <Divider/>
          <CardMedia
            overlay={<CardTitle title="The Technology Gonna Learn" subtitle="React" />}>
            <img src="https://www.onlinebooksreview.com/uploads/blog_images/2017/10/19_reactjs.png" alt="" />
          </CardMedia>
          <Divider/>          
          <CardTitle title="It's All About My Portfolio" subtitle="Check This Out" />
          <Divider/>          
          <CardText>
              This is simple demo app thet created using multiple component and applied routing as well
          </CardText>
          <Divider/>          
          <CardActions>
              <FlatButton
                target="_blank"
                href="https://www.c-sharpcorner.com/members/manav-pandya"
                primary={true}
                label="Go To My C#Corner Profile" />
              <FlatButton
                target="_blank"
                label="GitHub Link"
                primary={true}/>
          </CardActions>
          <Divider/>          
      </Card>
    );
  }
}

export default About;
