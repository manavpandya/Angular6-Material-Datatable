export const GET_NOTES = 'GET_NOTES';
