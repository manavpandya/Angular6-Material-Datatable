export const GET_NOTES = 'GET_NOTES';
export const GET_USER = 'GET_USER';

export const USER_STATUS = 'USER_STATUS';
export const NOTES_STATUS = 'NOTES_STATUS';
