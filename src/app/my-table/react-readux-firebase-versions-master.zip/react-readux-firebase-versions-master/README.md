# react-readux-firebase-versions
Source code for udemy React Redux Firebase Course by Ryan Dhungel
<a href="https://www.udemy.com/react-redux-firebase/?couponCode=RRFTEN">Full course available on Udemy</a>
<hr />
<p>Update config credentials in /src/firebase.js then run yarn install and yarn start to start this application.</p>
