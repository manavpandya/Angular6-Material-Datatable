import React from 'react';

const Comment = ({ children }) => <div> &#8594; {children}</div>;

export default Comment;
