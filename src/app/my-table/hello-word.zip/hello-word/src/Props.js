import React,{Component} from 'react';

class Props extends Component {
    render(){
        return(
                <div>
                <h3>Array:{this.props.propsArray}</h3>
                </div>
                );
    }
}
Props.propTypes = {
    propArray: React.PropTypes.array.isRequired
}

Props.defaultProps = {
    propArray:[1,2,3,4,5,6]
}

export default Props;