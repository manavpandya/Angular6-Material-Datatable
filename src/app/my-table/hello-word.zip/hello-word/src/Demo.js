import React, { Component } from 'react';

class Demo extends Component{
    render(){
        return (
                <div>
                    Hello Word
                </div>
                );
    }
}

export default Demo;